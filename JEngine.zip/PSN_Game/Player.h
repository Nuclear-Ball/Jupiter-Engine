#pragma once
#include "../Engine/Engine.h"
#include <box2d/box2d.h>
#include "Global.h"
#include "Map.h"

namespace PsnGame {
	namespace PlayerObjType {
		JE::Anim::Clip<uint8, uint8> LoadAnimation(const std::string& path, pos2du16 frame_size, int amount, fl32 duration) {
			LLJGFX::Texture::Handle atlas = LLJGFX::Texture::Make(path);

			const std::vector<std::string> raw_txts = TextureProcessing::CropFromCroplist(atlas, TextureProcessing::GenerateCroplist(LLJGFX::Texture::GetSize(atlas), amount, frame_size));

			std::vector<JE::Anim::Frame<uint8>> frames;
			frames.reserve(raw_txts.size());

			for (const auto& i : raw_txts)
				frames.push_back({ .texture = LLJGFX::Texture::Make(i, frame_size), .duration = duration });
			LLJGFX::Texture::Delete(atlas);

			return { .frames = frames };
		}

		namespace PlayerConstants {
			const float MASS = 80;

			const JGFX::Texture player_texture = { psngame_res_loc + "PixelM.png", JGFX::TxtFiltMode::NEAREST, JGFX::TxtWrapMode::CLAMP_TO_BORDER };
			const pos2d32 size = { 14, 27 };
			const pos2df64 metric_size = J2D::ToMetric(size);

			JE::Anim::Handle<uint8, uint8> idle = JE::Anim::MakeClip<uint8, uint8>({ LoadAnimation(psngame_res_loc + "PixelM_idle.png", { 32,32 }, 6, 0.09) });
			JE::Anim::Handle<uint8, uint8> run = JE::Anim::MakeClip<uint8, uint8>({ LoadAnimation(psngame_res_loc + "PixelM_run.png", { 32,32 }, 6, 0.09) });

			const pos2df64 ground_sensor_size = { 0.5, 0.3 };
			const pos2df64 ground_sensor_offset = { 0, -(metric_size.y / 2.f - 0.05) };

			const fl64 MAX_WALKING_SPEED = 4;
			const fl64 MAX_SPRINT_SPEED = 8;
			const fl64 ACCEL = 16;
			const fl32 JUMP_FORCE = 780;
		}
	}
}
namespace JE {
	namespace Anim {
		template<>
		void UpdateAnimation(AnimState<uint8, uint8>& state, fl64 movement_speed) {
			if (movement_speed < 0.5) {
				state.active_clip = PsnGame::PlayerObjType::PlayerConstants::idle;
				const Clip<uint8, uint8>& c_clip = JE::Anim::GetClipData(PsnGame::PlayerObjType::PlayerConstants::idle);

				while (state.time_from_last_frame >= c_clip.frames[state.c_frame].duration) {
					state.time_from_last_frame -= c_clip.frames[state.c_frame].duration;

					if (state.c_frame < c_clip.frames.size() - 1) //���� ������� ���� � ���������� ��������� ��� ���� � ������, ��� ���� � ����� (������ ����������� ������ ���� �� �������)
						state.c_frame += 1;
					else if (state.c_frame == c_clip.frames.size() - 1) //���� ������� ���� ������ ������� ���������. � ��������� ������ ������� ��, ��� ������ ����� ����� ���� ��������
						state.c_frame = 0;
				}
			}
			else {
				if (state.active_clip != PsnGame::PlayerObjType::PlayerConstants::run)
					state.c_frame = 0;

				state.active_clip = PsnGame::PlayerObjType::PlayerConstants::run;
				const Clip<uint8, uint8>& c_clip = JE::Anim::GetClipData(PsnGame::PlayerObjType::PlayerConstants::run);


				//TODO: fix frame speed
				const fl64 meters_per_cycle = J2D::ToMetric(13 * 4);//should be just 13
				const fl64 meters_per_frame = meters_per_cycle / 6.;

				const fl32 frame_duration = meters_per_frame / movement_speed;

				while (state.time_from_last_frame >= frame_duration) {
					state.time_from_last_frame -= frame_duration;

					if (state.c_frame < c_clip.frames.size() - 1) //���� ������� ���� � ���������� ��������� ��� ���� � ������, ��� ���� � ����� (������ ����������� ������ ���� �� �������)
						state.c_frame += 1;
					else if (state.c_frame == c_clip.frames.size() - 1) //���� ������� ���� ������ ������� ���������. � ��������� ������ ������� ��, ��� ������ ����� ����� ���� ��������
						state.c_frame = 0;
				}
			}
		}
	}
}
namespace PsnGame{
	namespace PlayerObjType {
		struct ObjectData {
			b2BodyId phys_handle = b2_nullBodyId;
			b2ShapeId ground_sensor_handle = b2_nullShapeId;
			int ground_sensor_touch_contacts = 0;

			bool is_facing_right = false;

			LLJ2D::TransfBuff::Handle tbuff = LLJ2D::TransfBuff::Make();

			int c_frame = 0;
			fl32 time_from_last_frame = 0;
			JE::Anim::AnimState<uint8, uint8> state;

			bool was_jump_in_prev_frame = false;
		};

		namespace Func{
			pos2df64 GetPosition(LLJE::Object::Handle instance) 
				{ return JPhys::GetPos(LLJE::Object::GetData<ObjectData>(instance).phys_handle); }

			void Destroy(LLJE::Object::Handle instance) {
				auto& dat = LLJE::Object::GetData<ObjectData>(instance);
				b2DestroyBody(dat.phys_handle);

				delete (ObjectData*)LLJE::Object::GetDataPtr(instance);
			}

			void Update(LLJE::Object::Handle instance, const LLJE::EngineContext& ctx) {
				auto& dat = LLJE::Object::GetData<ObjectData>(instance);

				{
					b2SensorEvents sensor_events = b2World_GetSensorEvents(Scene::GetPhysHandle(LLJE::Layer::GetParentScene(LLJE::Object::GetParentLayer(instance))));

					for (int i = 0; i < sensor_events.beginCount; i++) {
						b2SensorBeginTouchEvent* begin_touch = sensor_events.beginEvents + i;

						if (JPhys::SensorHandleWrap{ begin_touch->sensorShapeId } == JPhys::SensorHandleWrap{ dat.ground_sensor_handle } || JPhys::SensorHandleWrap{ begin_touch->visitorShapeId } == JPhys::SensorHandleWrap{ dat.ground_sensor_handle })
							dat.ground_sensor_touch_contacts++;
						//active_collisions[{begin_touch->sensorShapeId}][{begin_touch->visitorShapeId}]++;
						//active_collisions[{begin_touch->visitorShapeId}][{begin_touch->sensorShapeId}]++;
					}
					for (int i = 0; i < sensor_events.endCount; i++) {
						b2SensorEndTouchEvent* end_touch = sensor_events.endEvents + i;

						if (JPhys::SensorHandleWrap{ end_touch->sensorShapeId } == JPhys::SensorHandleWrap{ dat.ground_sensor_handle } || JPhys::SensorHandleWrap{ end_touch->visitorShapeId } == JPhys::SensorHandleWrap{ dat.ground_sensor_handle })
							dat.ground_sensor_touch_contacts--;
						//active_collisions[{end_touch->sensorShapeId}][{end_touch->visitorShapeId}]--;
						//active_collisions[{end_touch->visitorShapeId}][{end_touch->sensorShapeId}]--;

						//if (active_collisions[{end_touch->sensorShapeId}][{end_touch->visitorShapeId}] == 0)
						//	active_collisions[{end_touch->sensorShapeId}].erase({ end_touch->visitorShapeId });
						//if (active_collisions[{end_touch->visitorShapeId}][{end_touch->sensorShapeId}] == 0)
						//	active_collisions[{end_touch->visitorShapeId}].erase({ end_touch->sensorShapeId });
					}
				}
				//const int touch_contacts = JPhys::active_collisions[{dat.ground_sensor_handle}].size();

				auto c_win = glfwGetCurrentContext();
				const bool sprint = glfwGetKey(c_win, GLFW_KEY_LEFT_SHIFT);

				const pos2df64 player_speed = glm::abs(JPhys::GetLinearVelocity(dat.phys_handle));

				if (glfwGetKey(c_win, GLFW_KEY_D)) {
					dat.is_facing_right = true;

					if (player_speed.x < (sprint ? PlayerConstants::MAX_SPRINT_SPEED : PlayerConstants::MAX_WALKING_SPEED)) {
						const pos2df64 movement_direction = { 1, 0 };
						const pos2df32 force = PlayerConstants::ACCEL * movement_direction * (fl64)PlayerConstants::MASS;

						JPhys::ApplyForceToCenterOriented(dat.phys_handle, force);
					}
				}
				if (glfwGetKey(c_win, GLFW_KEY_A)) {
					dat.is_facing_right = false;

					if (player_speed.x < (sprint ? PlayerConstants::MAX_SPRINT_SPEED : PlayerConstants::MAX_WALKING_SPEED)) {
						const pos2df64 movement_direction = { -1, 0 };
						const pos2df32 force = PlayerConstants::ACCEL * movement_direction * (fl64)PlayerConstants::MASS;

						JPhys::ApplyForceToCenterOriented(dat.phys_handle, force);
					}
				}
				fmt::println("Touch contacts: {}", dat.ground_sensor_touch_contacts);
				if (glfwGetKey(c_win, GLFW_KEY_SPACE) && dat.ground_sensor_touch_contacts) {
					if (!dat.was_jump_in_prev_frame) {
						b2Body_ApplyLinearImpulseToCenter(dat.phys_handle, { 0, PlayerConstants::JUMP_FORCE }, true);
					}
					dat.was_jump_in_prev_frame = true;
				}
				else {
					//if (was_jump_in_prev_frame) {
					//	pos2df64 player_speed = JPhys::GetLinearVelocity(player.phys_handle);
					//	b2Body_SetLinearVelocity(player.phys_handle, { (fl32)player_speed.x, 0 });
					//}

					dat.was_jump_in_prev_frame = false;
				}
				auto& frm = JE::Anim::GetCurrentFrame(dat.state, player_speed.x);

				LLJE::DrawSprite(frm.texture, LLJE::Object::GetPos(instance), ctx, { JPhys::GetRotation(dat.phys_handle), { dat.is_facing_right ? 1 : -1, 1}, J2D::ToMetric({14,13}) });
				//return LLJE::ObjectUtility::DrawListSimpleObject(LLJE::Object::GetPos(instance), relative_to, frm.texture, dat.tbuff, 
				//											{ JPhys::GetRotation(dat.phys_handle), { dat.is_facing_right ? 1 : -1, 1}, J2D::ToMetric({14,13}) });
			}
		}

		LLJE::Prefab::Handle player_prefab = Scene::Internal::player_obj_test = LLJE::Prefab::Make({ .Destroy = Func::Destroy, .Update = Func::Update, .GetPosition = Func::GetPosition });

		LLJE::Object::Handle MakePlayer(LLJE::Layer::Handle target_layer, pos2df64 pos) { 
			assert(MainGameLayer::IsTypeValid(target_layer));

			ObjectData* p_data = new ObjectData{};
			{
				b2BodyDef bodydef = b2DefaultBodyDef();
				bodydef.type = b2_dynamicBody;
				bodydef.fixedRotation = true;
				bodydef.position = { (fl32)pos.x, (fl32)pos.y };

				p_data->phys_handle = b2CreateBody(Scene::GetPhysHandle(LLJE::Layer::GetParentScene(target_layer)), &bodydef);

				const float radius = (float)PlayerConstants::metric_size.x / 2.f;
				b2Capsule capsule = { {0.f, -(float)(PlayerConstants::metric_size.y / 2. - radius)},
									  {0.f,  (float)(PlayerConstants::metric_size.y / 2. - radius)},
									 radius };

				b2ShapeDef shape_def = b2DefaultShapeDef();
				shape_def.friction = 0.2f;
				b2CreateCapsuleShape(p_data->phys_handle, &shape_def, &capsule);

				b2Polygon ground_sensor_hitbox = JPhys::MakeBoxPolygon(PlayerConstants::ground_sensor_size, PlayerConstants::ground_sensor_offset, 0);
				b2ShapeDef ground_sensor_def = b2DefaultShapeDef();
				ground_sensor_def.isSensor = true;
				p_data->ground_sensor_handle = b2CreatePolygonShape(p_data->phys_handle, &ground_sensor_def, &ground_sensor_hitbox);

				b2Body_SetMassData(p_data->phys_handle, { PlayerConstants::MASS, {0,0}, 0/*player.mass*/ });
			}

			return LLJE::Object::Make(target_layer, player_prefab, p_data); 
		}
		void SetPosition(LLJE::Object::Handle obj, pos2d64 pos) {
			auto& dat = LLJE::Object::GetData<ObjectData>(obj);
			b2Body_SetTransform(dat.phys_handle, JPhys::ConvertToBV(pos), JPhys::B2FromAngle(0));
		}
	}
}