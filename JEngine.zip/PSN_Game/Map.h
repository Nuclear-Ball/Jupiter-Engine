#pragma once
#include <JGFX/JGFX.h>
#include "../Engine/Engine.h"
#include <box2d/box2d.h>
#include <unordered_set>

namespace PsnGame {
namespace Tile {
	struct Data;
	typedef JE::MHandle<Data> Handle;
	const Handle NULL_TILE = { nullptr };
}
namespace Tile {
	struct Data {
		LLJGFX::Texture::Handle texture = JGFX::NULL_TXT;
		std::vector<JE::ChainShape> collision_mesh;
		J2D::TransfProps props = {};
		fl32 base_transparency = 0;
	};

	namespace Internal {
		JE::AnonymousManager<Data> manager;
	}
	bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

	const Data& GetData(Handle handle) { 
		assert(IsValid(handle));
		return Internal::manager[handle]; 
	}
	Data& GetDataForEditor(Handle handle) {
		assert(IsValid(handle));
		return Internal::manager[handle];
	}

	inline Handle Make(const Data& dat) 
		{ return Internal::manager.Add(dat); }
	inline Handle Make(
		LLJGFX::Texture::Handle texture,
		const std::vector<JE::ChainShape>& collision_mesh,
		const J2D::TransfProps& props = {},
		const fl32 base_transparency = 0
	)
		{ return Make({ .texture = texture, .collision_mesh = collision_mesh, .props = props, .base_transparency = base_transparency }); }
	void Delete(Handle handle) { 
		//Later
		if (IsValid(handle)) {
			auto& dat = Internal::manager[handle];
			Internal::manager.Remove(handle);
		}
	}
	}


	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	namespace Scene {
	namespace Internal {
		struct Data {
			b2WorldId world = b2_nullWorldId;
			LLJE::Object::Handle player_obj = LLJE::Object::NULL_OBJECT;
			int last_update_frame = 0;
		};
		LLJE::Prefab::Handle player_obj_test = LLJE::Prefab::NULL_PREFAB;
		LLJE::ScenePreset::Handle compare_handle = LLJE::ScenePreset::NULL_PRESET;
	}

	typedef LLJE::Scene::Handle Handle;
	const Handle NULL_SCENE = { nullptr };

	inline bool IsTypeValid(Handle handle) {
		assert(LLJE::Scene::IsValid(handle));
		return LLJE::Scene::GetPreset(handle) == Internal::compare_handle;
	}

	Internal::Data& GetDataUnsafe(Handle handle) {
		assert(IsTypeValid(handle));
		return LLJE::Scene::Advanced::GetAdditionalData<Internal::Data>(handle);
	}
	}

	namespace MainGameLayer {
		namespace Internal {
			LLJE::LayerPreset::Handle compare_handle = LLJE::LayerPreset::NULL_PRESET;
		}
	}
	namespace MainGameLayer {

	namespace Internal {
		const std::string je_vertex_shader_source =
			"#version 330 core\n"

			"layout(location = 0) in vec2 v_pos;\n"
			"layout(location = 1) in vec2 v_uv;\n"

			"uniform mat4 precomputed_matrix;"

			"out vec2 TexCoord;\n"

			"void main(){\n"
			"    gl_Position = precomputed_matrix * vec4(v_pos, 0.0, 1.0);\n"
			"    TexCoord = v_uv;\n"
			"}";
		const std::string je_fragment_shader_source = 
			"#version 330 core\n"

			"out vec4 FragColor;\n"
			"in vec2 TexCoord;\n"

			"uniform sampler2D ourTexture;\n"

			"void main(){\n"
			"    FragColor = texture(ourTexture, vec2(TexCoord.x, 1.f - TexCoord.y));\n"
			"}";
		LLJ2D::Shader2D::Handle tmap_shader = LLJ2D::Shader2D::Make(je_vertex_shader_source, je_fragment_shader_source);

		struct IrDrawListElement {
			//LLJ2D::TransfBuff::Handle transforms = LLJ2D::TransfBuff::NULL_TBUFF;
			JGFX::VertexCollection mesh;
			Tile::Handle tile = Tile::NULL_TILE;
		};
		struct ChunkData {
			Tile::Handle* tiles;

			b2BodyId phys_handle = b2_nullBodyId;
			std::vector<b2ChainId> collision_meshes;

			//std::vector<JGFX::VertexCollection> cached_mesh;
			std::vector<IrDrawListElement> cached_draw_list;
			std::vector<JE::ChainShape> cached_collision_mesh;

			int cache_ver = 0;

			LLJE::GenericObjMap::ChunkData obj_dat = {};
		};
		struct Data {
			pos2df64 grid_size;
			pos2du16 tiles_in_chunk;

			int curr_global_version = 0;

			LLJE::Chunksystem::ChunkMapData<ChunkData> chmap; //It was made as a pointers, because the struct itself is quite heavy 
			LLJE::GenericObjMap::ObjectmapData obj_dat;
		};
	}

	typedef LLJE::Layer::Handle Handle;
	const Handle NULL_TMAP = { nullptr };
		
	inline bool IsTypeValid(LLJE::Layer::Handle handle) {
		assert(LLJE::Layer::IsValid(handle));
		return LLJE::Layer::GetPreset(handle) == Internal::compare_handle;
	}
	inline bool IsValid(Handle handle)
		{ return LLJE::Layer::IsValid(handle); }

	pos2df64 GetGridSize(Handle handle) { 
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return ((Internal::Data*)LLJE::Layer::Advanced::GetAdditionalData(handle))->grid_size; 
	}
	pos2du16 GetChunkSize(Handle handle) { 
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle).tiles_in_chunk; 
	}
	
	const Internal::Data& GetData(Handle handle) {
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle);
	}

	namespace Functions {
		void MakeChunk(LLJE::Layer::Handle map, pos2d32 pos, Internal::ChunkData& c_chunk, void* dat = nullptr) {
			const pos2du16 chunk_size = GetChunkSize(map); 
			const pos2df64 grid_size = GetGridSize(map);

			c_chunk.tiles = (Tile::Handle*)malloc(sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
			memset(c_chunk.tiles, 0, sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);

			auto& scene_dat = LLJE::Scene::Advanced::GetAdditionalData<Scene::Internal::Data>(LLJE::Layer::GetParentScene(map));
			{
				b2BodyDef def = b2DefaultBodyDef();
				def.type = b2_staticBody;
				def.position = JPhys::ConvertToBV(LLJE::Convert::MetricFromChunk(pos, grid_size * (pos2df64)chunk_size));
				c_chunk.phys_handle = b2CreateBody(scene_dat.world, &def);
			}
		}
		void DeleteChunk(LLJE::Layer::Handle map, pos2d32 pos, Internal::ChunkData& c_chunk, void* = nullptr) {
			free(c_chunk.tiles);
			b2DestroyBody(c_chunk.phys_handle);

			LLJE::GenericObjMap::DestroyChunk(map, pos);
		}
		const JGFX::VertexLayout chunk_vertex_layout = {
			JGFX::VertexAttribute{0, JGFX::AttribType::FL32, 2},//pos
			JGFX::VertexAttribute{1, JGFX::AttribType::FL32, 2},//uv
		};
		struct ChunkMeshVertex {
			pos2df32 pos;
			pos2df32 uv;
		};
		const std::vector<ChunkMeshVertex> template_tile_mesh = {
				{{0, 0}, {0, 0}}, // bottom left
				{{0, 1}, {0, 1}}, // top left
				{{1, 1}, {1, 1}}, // top right
				{{1, 0}, {1, 0}}, // bottom right
		};
		const std::vector<uint32> template_tile_indices = {
				0, 1, 2,  // first Triangle
				0, 2, 3   // second Triangle
		};

		struct TmpChunkCache {
			std::vector<ChunkMeshVertex> mesh;
			std::vector<uint32> indexing_data;
		};

		void CacheChunk(Internal::Data& map_dat, Internal::ChunkData& chunk_dat) {
			const pos2du16& chunk_size = map_dat.tiles_in_chunk;
			const pos2df32 grid_size = map_dat.grid_size;

			std::unordered_map<Tile::Handle, TmpChunkCache> tmp_cache;
			std::vector<JE::ChainShape> chain_segments;

			for (int y = 0; y < chunk_size.y; y++) {
				for (int x = 0; x < chunk_size.x; x++) {
					const Tile::Handle c_tile_handle = chunk_dat.tiles[chunk_size.x * y + x];
					if (!Tile::IsValid(c_tile_handle))
						continue;

					auto& c_mesh = tmp_cache[c_tile_handle];
					const pos2df32 local_tile_pos = pos2df32{ x, y } * grid_size;
					const uint32 tile_start_vertex_id = c_mesh.mesh.size();
					
					for(auto& i : template_tile_mesh) //Vertex data
						c_mesh.mesh.push_back({ .pos = (i.pos * grid_size) + local_tile_pos, .uv = i.uv });
					for (auto& i : template_tile_indices) //Indexing data
						c_mesh.indexing_data.push_back(i + tile_start_vertex_id);

					const auto& tile_data = Tile::GetData(c_tile_handle);
					const auto& collision_mesh = tile_data.collision_mesh;

					for (const auto& i : collision_mesh)
						JE::Mesher::AddChainShape(i, chain_segments, local_tile_pos);
				}
			}

			chunk_dat.cached_draw_list.clear();
			for (const auto& [tile, c_mesh] : tmp_cache) {
				chunk_dat.cached_draw_list.push_back(Internal::IrDrawListElement{ .mesh = JGFX::VertexCollection(), .tile = tile});
				//chunk_dat.cached_draw_list.back().mesh.bound_buffers = {}; //PLEASE WORK!!!!
				chunk_dat.cached_draw_list.back().mesh.AddBuffer(JGFX::VertexBuffer{ c_mesh.mesh, chunk_vertex_layout }, "mesh");
				chunk_dat.cached_draw_list.back().mesh.SetIndexingData(c_mesh.indexing_data);
			}
			auto test = chunk_dat.cached_draw_list[0].mesh["mesh"].data<ChunkMeshVertex>();
			
			{
				for (const auto& i : chunk_dat.collision_meshes)
					b2DestroyChain(i);
				chunk_dat.collision_meshes.clear();
				chunk_dat.collision_meshes.reserve(chain_segments.size());

				//chain is implicitly longer than 1
				for (auto& i : chain_segments) {
					b2ChainDef chain_def = b2DefaultChainDef();
					chain_def.friction = 0.7;
					chain_def.isLoop = i.is_loop;

					chain_def.points = (b2Vec2*)i.points.data();
					chain_def.count = i.points.size();

					chunk_dat.collision_meshes.push_back(b2CreateChain(chunk_dat.phys_handle, &chain_def));
				}
			}
			chunk_dat.cache_ver = map_dat.curr_global_version;
		}

		void TileChunkUpdater(LLJE::Layer::Handle map, pos2d32 pos, const LLJE::EngineContext& ctx, void*) {
			Internal::Data& c_map = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(map);
			if (!LLJE::Chunksystem::DoesChunkExists(c_map.chmap, pos)) return;

			Internal::ChunkData& c_chunk = LLJE::Chunksystem::GetChunk(c_map.chmap, pos);
			if (c_chunk.cache_ver != c_map.curr_global_version)
				CacheChunk(c_map, c_chunk);

			const glm::mat4 chunk_pv = (glm::mat4)glm::translate<double>(ctx.layer_pv, {(pos2df64)pos * LLJE::Chunksystem::GetMetricChunkSize(c_map.chmap), 0});
			LLJGFX::ShaderProgram::SetUniform(Internal::tmap_shader, "precomputed_matrix", chunk_pv);
			for (auto& i : c_chunk.cached_draw_list)
				JGFX::Draw(i.mesh, Tile::GetData(i.tile).texture, Internal::tmap_shader);
		}
		void ObjectChunkUpdater(LLJE::Layer::Handle map, pos2d32 pos, const LLJE::EngineContext& ctx, void*) {
			LLJE::GenericObjMap::UpdateChunk(map, pos, ctx);
		}

		void UpdateLayer(LLJE::Layer::Handle map, const LLJE::EngineContext& ctx) {
			auto& layer_data = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(map);
			LLJE::Chunksystem::UpdateAndRenderChunks<Internal::ChunkData, TileChunkUpdater>(layer_data.chmap, map, ctx);
			LLJE::Chunksystem::UpdateAndRenderChunks<Internal::ChunkData, ObjectChunkUpdater>(layer_data.chmap, map, ctx);
		}
		void Destroy(LLJE::Layer::Handle handle) {
			auto& layer_data = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle);
			LLJE::Chunksystem::Clear<Internal::ChunkData, Functions::DeleteChunk>(layer_data.chmap, handle);
			delete (Internal::Data*)LLJE::Layer::Advanced::GetAdditionalData(handle);
		}
	}
	const LLJE::LayerPreset::Handle preset = LLJE::ObjectSys::LinkPreset(
		Internal::compare_handle = LLJE::LayerPreset::Make({ .UpdateLayer = Functions::UpdateLayer, .GetLayerTransformationMatrix = [](LLJE::Layer::Handle, pos2df64) {return glm::dmat4(1); }, .DeleteLayerData = Functions::Destroy }),
		LLJE::ObjectSys::MapIntegrationPreset{
			.GetMapData = [](LLJE::Layer::Handle layer) -> LLJE::GenericObjMap::ObjectmapData& { return LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(layer).obj_dat; },
			.GetChunkData = [](LLJE::Layer::Handle layer, pos2d32 pos) -> LLJE::GenericObjMap::ChunkData& { return LLJE::Chunksystem::GetChunk(LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(layer).chmap, pos).obj_dat; },
			.MakeChunk = [](LLJE::Layer::Handle layer, pos2d32 pos)->LLJE::GenericObjMap::ChunkData& { return LLJE::Chunksystem::MakeChunk<Internal::ChunkData, Functions::MakeChunk>(LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(layer).chmap, layer, pos, nullptr).obj_dat; },
			.DoesChunkExists = [](LLJE::Layer::Handle layer, pos2d32 pos) { return LLJE::Chunksystem::DoesChunkExists(LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(layer).chmap, pos); },
			.GetMetricChunkSize = [](LLJE::Layer::Handle layer) { return LLJE::Chunksystem::GetMetricChunkSize(LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(layer).chmap); },

			.notify_callbacks = {
				.AddObject = [](LLJE::Object::Handle obj) {
					if (LLJE::Object::GetPrefab(obj) == Scene::Internal::player_obj_test) {
						auto& scene_data = Scene::GetDataUnsafe(LLJE::Object::GetParentScene(obj));
						assert(!LLJE::Object::IsValid(scene_data.player_obj)); //Ensures that there could be only 1 player object

						scene_data.player_obj = obj;
					}
					//if the obj is player
				},
				.RemoveObject = [](LLJE::Object::Handle obj) {
					if (LLJE::Object::GetPrefab(obj) == Scene::Internal::player_obj_test) {
						auto& scene_data = Scene::GetDataUnsafe(LLJE::Object::GetParentScene(obj));
						scene_data.player_obj = LLJE::Object::NULL_OBJECT;
					}
					//if the obj is player
				}
			}
		}
	);

	inline void SetTile(Handle handle, Tile::Handle tile, pos2d64 pos){
		assert(IsValid(handle));
		assert(IsTypeValid(handle));

		const pos2du16 chunk_size = GetChunkSize(handle);
		const pos2d32 chunk_pos = LLJE::Convert::ChunkFromTile(pos, chunk_size);
		const pos2du16 local_tile_pos = LLJE::Convert::LocalTileFromGlobalTile(pos, chunk_size);

		auto layer_data = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle);
		if (!LLJE::Chunksystem::DoesChunkExists(layer_data.chmap, chunk_pos))
			LLJE::Chunksystem::MakeChunk<Internal::ChunkData, Functions::MakeChunk>(layer_data.chmap, handle, chunk_pos);
		Internal::ChunkData& c_chunk = LLJE::Chunksystem::GetChunk(layer_data.chmap, chunk_pos);

		c_chunk.tiles[chunk_size.x * local_tile_pos.y + local_tile_pos.x] = tile;
		c_chunk.cache_ver = layer_data.curr_global_version - 1;
	}
	inline Tile::Handle GetTile(Handle handle, pos2d64 pos) {
		assert(IsValid(handle));
		assert(IsTypeValid(handle));

		const pos2du16 chunk_size = GetChunkSize(handle);
		const pos2d32 chunk_pos = LLJE::Convert::ChunkFromTile(pos, chunk_size);
		const pos2du16 local_tile_pos = LLJE::Convert::LocalTileFromGlobalTile(pos, chunk_size);

		auto layer_data = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle);
		if (!LLJE::Chunksystem::DoesChunkExists(layer_data.chmap, chunk_pos))
			return Tile::NULL_TILE;
		const Internal::ChunkData& c_chunk = LLJE::Chunksystem::GetChunk(layer_data.chmap, chunk_pos);

		return c_chunk.tiles[chunk_size.x * local_tile_pos.y + local_tile_pos.x];
	}

	inline void Clear(Handle handle) {
		LLJE::Chunksystem::Clear<Internal::ChunkData, Functions::DeleteChunk>(LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle).chmap, handle);
	}
	/*
	inline void TransferData(Map::Handle to, Handle from) {
		Map::TurnInto(Map::ToLayer(to), GetGridSize(from), GetChunkSize(from));
		LLJE::ChunkMap::ExecuteForAllChunks(ToLayer(from),
			[](LLJE::Layer::Handle src_layer, pos2d32 chunk_pos, void* target_map) {
				const LLJE::Layer::Handle target = *(LLJE::Layer::Handle*)target_map;
				const auto& targ_data = LLJE::Layer::GetEditableLayerData(target);
				const auto& type_specific_data = LLJE::Layer::Advanced::GetAdditionalDataC<Map::Internal::TmapData>(target);

				auto& new_chunk = LLJE::ChunkMap::MakeEmptyChunk(target, chunk_pos);
				Map::Functions::MakeChunk(new_chunk, type_specific_data.tiles_in_chunk, chunk_pos, type_specific_data.grid_size);

				auto& targ_chunk_data = *(Map::Internal::ChunkData*)new_chunk.data;

				auto& src_chunk_data = LLJE::ChunkMap::GetChunk<Internal::ChunkData>(src_layer, chunk_pos);

				memcpy(targ_chunk_data.tiles, src_chunk_data.tiles, sizeof(Tile::Handle) * type_specific_data.tiles_in_chunk.x * type_specific_data.tiles_in_chunk.y);
				targ_chunk_data.cache_ver--;
			},
			&to
		);
	}
	*/
	/*
	inline Map::Handle CreateNewGameMap(Handle handle) {
		const LLJE::Layer::Handle src = ToLayer(handle);
		const auto& src_data = LLJE::Layer::GetEditableLayerData(src);
		LLJE::Layer::Handle new_map = LLJE::Layer::Make(
			src_data.parallax_speed,
			src_data.props,
			src_data.pos,
			src_data.transparency,
			src_data.is_visible,
			src_data.upper_view_range_extension,
			src_data.lower_view_range_extension
		);
		const auto conv = Map::TurnInto(new_map, GetGridSize(handle), GetChunkSize(handle));
		TransferData(conv, handle);
		return conv;
	}
	*/
	/*
	inline void Copy(LLJE::Layer::Handle to, Handle from) {
		assert(LLJE::Layer::IsValid(to));
		assert(IsValid(from));
		assert(IsTypeValid(from));

		Handle conv_layer = TurnInto(to, GetGridSize(from), GetChunkSize(from));
		LLJE::Layer::SetLayerSettings(to, LLJE::Layer::GetEditableLayerSettings(from));
		//TODO: also copy all of the layer settings data, such as parallax speed, offset, etc
		
		LLJE::ChunkMap::ExecuteForAllChunks(from,
			[](LLJE::Layer::Handle map, pos2d32 pos, void* to_map) -> void {
				const LLJE::Layer::Handle to = { (LLJE::Layer::Internal::Data*)to_map };
				const Internal::ChunkData& from_chunk = *(Internal::ChunkData*)LLJE::ChunkMap::GetChunk(map, pos).data;

				const pos2du16 chunk_size = GetChunkSize(map);
				Functions::MakeChunk(to, pos);

				auto& to_chunk = *(Internal::ChunkData*)LLJE::ChunkMap::GetChunk(to, pos).data;
				memcpy(to_chunk.tiles, from_chunk.tiles, sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
				to_chunk.cache_ver--;
			},
		to.data);
	}*/

	inline LLJE::Layer::Handle MakeLayer(LLJE::Scene::Handle scene, LLJE::Layer::SceneInsertionDirection direction = LLJE::Layer::BACK, int insertion_id = 0, 
							pos2df64 grid_size = {1,1}, pos2du16 chunk_size = {16,16}) {
		Internal::Data* tmp_dat = new Internal::Data{ .grid_size = grid_size, .tiles_in_chunk = chunk_size, .chmap = {.metric_chunk_size = grid_size * (pos2df64)chunk_size} };
		return LLJE::Layer::Make(
			preset,
			scene,
			direction,
			insertion_id,
			tmp_dat
		); 
	}
	/*
	inline LLJE::Layer::Handle MakeLayer(Handle from, LLJE::Scene::Handle target_scene, LLJE::Layer::SceneInsertionDirection direction = LLJE::Layer::BACK, int insertion_id = 0) {
		assert(IsValid(from));
		assert(IsTypeValid(from));
		Internal::TmapData tmp_dat = GetData(from);
		LLJE::Layer::Handle handle = LLJE::Layer::Make(target_scene, direction, insertion_id, {}, preset, &tmp_dat);
		Copy(handle, from);
		return handle;
	}
	*/
	inline void Delete(Handle handle) 
		{ LLJE::Layer::Delete(handle); }
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	namespace Scene {
	namespace Functions {
		void DeleteSceneData(Scene::Handle scene) {
			auto& data = LLJE::Scene::Advanced::GetAdditionalData<Internal::Data>(scene);
			b2DestroyWorld(data.world);
			delete (Internal::Data*)LLJE::Scene::Advanced::GetAdditionalDataPtr(scene);
		}

		void AddLayer(LLJE::Scene::Handle scene, LLJE::Layer::Handle layer) {
			assert(LLJE::Layer::GetPreset(layer) == MainGameLayer::Internal::compare_handle);
		}

		void Update(Scene::Handle scene, J2D::Cam2D& camera, void*, size_t) {
			auto& data = LLJE::Scene::Advanced::GetAdditionalData<Internal::Data>(scene);

			if (data.last_update_frame != JGFX::FrameCount()) {
				b2World_Step(data.world, JGFX::GetDeltaTimeValue(), 8);
				data.last_update_frame = JGFX::FrameCount();
				JPhys::UpdateCollisions(data.world);
			}

			if (LLJE::Object::IsValid(data.player_obj))
				camera.center_pos = LLJE::Object::GetPos(data.player_obj);
		}
	}
	const LLJE::ScenePreset::Handle preset = Internal::compare_handle = LLJE::ScenePreset::Make({.AddLayer = Functions::AddLayer, .DeleteSceneData = Functions::DeleteSceneData, .UpdateScene = Functions::Update });// , Functions::ChmapCopier);

	b2WorldId GetPhysHandle(Handle handle) {
		assert(IsTypeValid(handle));
		return LLJE::Scene::Advanced::GetAdditionalData<Internal::Data>(handle).world;
	}
	/*
	inline void TurnInto(Scene::Handle scene) { 
		assert(LLJE::Scene::IsValid(scene));
		const auto& layer_list = LLJE::Scene::ListLayers(scene);
		for (const auto& i : layer_list)
			assert(MainGameLayer::IsTypeValid(i));



		b2WorldDef def = b2DefaultWorldDef();
		def.gravity = { 0, -13.8 };
		Internal::Data init_dat = { .world = b2CreateWorld(&def) };
		LLJE::Scene::Advanced::SetPreset(scene, preset, &init_dat);
	}*/

	//void Copy(LLJE::Scene::Handle to, Scene::Handle from) {
	//	assert(IsTypeValid(from));

	//	LLJE::Scene::ClearLayerList(to);
	//	TurnInto(to);


	//	const auto& src_layers = LLJE::Scene::ListLayers(from);
	//	for (const auto& i : src_layers)
	//		MainGameLayer::MakeLayer(i, to);


		/*
		When needed, put here code for copying scene data
		*/

	//	LLJE::Scene::SetBackgroundColor(to, LLJE::Scene::GetBackgroundColor(from));
	//}

	inline Handle Make(rgb color = LLJE::Scene::Internal::DEFAULT_BACKGROUND_COLOR) { 
		b2WorldDef def = b2DefaultWorldDef();
		def.gravity = { 0, -13.8 };
		Internal::Data* init_dat = new Internal::Data{ .world = b2CreateWorld(&def) };

		return LLJE::Scene::Make(color, preset, init_dat);  
	}
	//inline Handle Make(Handle from) {
	//	Handle handle = LLJE::Scene::Make();
	//	Copy(handle, from);
	//	return handle;
	//}
	} //Namespace Scene
}