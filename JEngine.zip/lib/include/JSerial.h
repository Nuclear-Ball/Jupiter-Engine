﻿#pragma once
//#include <unique_ptr>
#include <vector>
#include <unordered_map>
#include <string>
#include <cassert>
#include <array>

namespace JSerial {
	enum class TypeEnum : uint8_t {
		BOOL,
		INT8,
		INT16,
		INT32,
		INT64,
		FLOAT32,
		FLOAT64,
		COMPLEX_OBJECT
	};
	constexpr int SIZE_TABLE[] = {
		sizeof(bool),
		sizeof(int8_t),
		sizeof(int16_t),
		sizeof(int32_t),
		sizeof(int64_t),
		sizeof(float),
		sizeof(double),
		0,
	};
	namespace Internal {
		template<typename T>
		constexpr inline TypeEnum DeduceType() 
			{ assert(0 && "Unsupported type"); return TypeEnum::BOOL; }
		template<>
		constexpr inline TypeEnum DeduceType<bool>() 
			{ return TypeEnum::BOOL; }
		template<>
		constexpr inline TypeEnum DeduceType<uint8_t>() 
			{ return TypeEnum::INT8; }
		template<>
		constexpr inline TypeEnum DeduceType<int8_t>() 
			{ return TypeEnum::INT8; }
		template<>
		constexpr inline TypeEnum DeduceType<char>() 
			{ return TypeEnum::INT8; }

		template<>
		constexpr inline TypeEnum DeduceType<uint16_t>() 
			{ return TypeEnum::INT16; }
		template<>
		constexpr inline TypeEnum DeduceType<int16_t>() 
			{ return TypeEnum::INT16; }

		template<>
		constexpr inline TypeEnum DeduceType<uint32_t>() 
			{ return TypeEnum::INT32; }
		template<>
		constexpr inline TypeEnum DeduceType<int32_t>() 
			{ return TypeEnum::INT32; }

		template<>
		constexpr inline TypeEnum DeduceType<uint64_t>() 
			{ return TypeEnum::INT64; }
		template<>
		constexpr inline TypeEnum DeduceType<int64_t>() 
			{ return TypeEnum::INT64; }


		template<>
		constexpr inline TypeEnum DeduceType<float>() 
			{ return TypeEnum::FLOAT32; }
		template<>
		constexpr inline TypeEnum DeduceType<double>() 
			{ return TypeEnum::FLOAT64; }
	}

	constexpr size_t ARBITRARY_ELEMENT_COUNT = (size_t)-1;
	constexpr uint16_t UNDEFINED_TYPE_SIZE = (uint16_t)-1;
	constexpr size_t UNDEFINED_ARRAY_BINARY_SIZE = (size_t)-1;

	struct GenericType {
		TypeEnum type;
		std::string optional_struct_name;
		std::vector<size_t> array_fixed_sizes_for_dimensions;
	};
	inline GenericType Struct(const std::string& target_struct_name) {
		return GenericType{
			.type = TypeEnum::COMPLEX_OBJECT,
			.optional_struct_name = target_struct_name,
			.array_fixed_sizes_for_dimensions = {}
		};
	}
	inline GenericType Array(const GenericType& base_type, size_t fixed_element_count = ARBITRARY_ELEMENT_COUNT) {
		auto dimensions = base_type.array_fixed_sizes_for_dimensions;
		dimensions.insert(dimensions.begin(), fixed_element_count);

		return GenericType{
			.type = base_type.type,
			.optional_struct_name = base_type.optional_struct_name,
			.array_fixed_sizes_for_dimensions = std::move(dimensions)
		};
	}
	inline GenericType NumericType(TypeEnum type) {
		assert(type != TypeEnum::COMPLEX_OBJECT);
		return GenericType{
			.type = type
		};
	}
	inline GenericType String() {
		return GenericType{
			.type = TypeEnum::INT8,
			.array_fixed_sizes_for_dimensions = { ARBITRARY_ELEMENT_COUNT }
		};
	}

	struct FieldTemplate {
		std::string name;
		GenericType type;
	};
	struct StructFieldsTemplate {
		std::unordered_map<std::string, GenericType> fields;

		StructFieldsTemplate(std::initializer_list<FieldTemplate> fields) {
			this->fields.reserve(fields.size());
			for (const auto& i : fields)
				this->fields[i.name] = i.type;
		}
		StructFieldsTemplate() = default;
	};
	struct InitializationStructTemplate {
		std::string name;
		StructFieldsTemplate fields;
	};

	struct TemplateSet {
		std::unordered_map<std::string, StructFieldsTemplate> struct_templates;

		TemplateSet(std::initializer_list<InitializationStructTemplate> structs) {
			struct_templates.reserve(structs.size());
			for (const auto& i : structs)
				struct_templates[i.name] = i.fields;
		}
		TemplateSet() = default;
	};

	void Integrate(TemplateSet& to, const TemplateSet& from) {
		for (auto&[name, type] : from.struct_templates)
			to.struct_templates[name] = type;
	}
	TemplateSet MergeSets(const TemplateSet& to, const TemplateSet& from) {
		TemplateSet res = to;
		for (const auto& [name, type] : from.struct_templates)
			res.struct_templates[name] = type;
		return res;
	}

	namespace Internal {
		struct CompiledFieldTemplate {
			std::string name;

			TypeEnum top_level_type = TypeEnum::INT8;
			uint16_t complex_type_id = 0;

			std::vector<size_t> binary_sizes_of_the_children_elements; //0 = top dimension
			std::vector<size_t> element_count_for_dimensions;

			uint16_t cached_binary_size = UNDEFINED_TYPE_SIZE;
			size_t cached_offset = 0;
		};
		struct CompiledStructTemplate {
			std::vector<CompiledFieldTemplate> fields;
			std::unordered_map<std::string, uint16_t> ids;

			uint16_t cached_size = UNDEFINED_TYPE_SIZE;
			std::string name;
		};

		//It was made as a separate function only for recursion to be possible
		size_t GetStructBinarySize(std::vector<CompiledStructTemplate>& structs, CompiledStructTemplate& c_struct) {
			if (c_struct.cached_size != UNDEFINED_TYPE_SIZE)
				return c_struct.cached_size;

			size_t size = 0;

			for (auto& c_field : c_struct.fields) {
				c_field.binary_sizes_of_the_children_elements.resize(c_field.element_count_for_dimensions.size());

				size_t field_size = 0;

				if (c_field.top_level_type == TypeEnum::COMPLEX_OBJECT)
					field_size = GetStructBinarySize(structs, structs[c_field.complex_type_id]);
				else field_size = SIZE_TABLE[(int)c_field.top_level_type];


				for (int array_depth_level = c_field.element_count_for_dimensions.size() - 1; array_depth_level >= 0; array_depth_level--) {
					//we should get the size of the lower dimension
					c_field.binary_sizes_of_the_children_elements[array_depth_level] = field_size;
					field_size = c_field.element_count_for_dimensions[array_depth_level] == ARBITRARY_ELEMENT_COUNT ? sizeof(size_t) : field_size * c_field.element_count_for_dimensions[array_depth_level];
				}

				c_field.cached_offset = size;
				c_field.cached_binary_size = field_size;
				size += field_size;
			}
			c_struct.cached_size = size;

			return size;
		}
	}
	struct CompiledTemplateSet {
		std::vector<Internal::CompiledStructTemplate> types;
		std::unordered_map<std::string, uint16_t> ids;
	};

	CompiledTemplateSet CompileTemplates(const TemplateSet& src) {
		std::unordered_map<std::string, uint16_t> linked_set_ids;
		std::vector<Internal::CompiledStructTemplate> linked_templates;
		{
			std::vector<StructFieldsTemplate> linked_set_vec;
			linked_set_vec.reserve(src.struct_templates.size());

			for (const auto& i : src.struct_templates) {
				linked_set_vec.push_back(i.second);
				linked_set_ids.insert({ i.first, linked_set_vec.size() - 1 });
			}

			//Linking structs
			//TODO: check for dependency recursion
			
			linked_templates.resize(linked_set_vec.size());

			for (const auto& [struct_name, struct_id] : linked_set_ids) {
				const auto& c_struct = linked_set_vec[struct_id];
				//link structs
				Internal::CompiledStructTemplate linked_struct = {
					.name = struct_name
				};
				linked_struct.fields.reserve(c_struct.fields.size());

				for (const auto& [field_name, field_type] : c_struct.fields) {
#ifndef NDEBUG
					if (field_type.type == TypeEnum::COMPLEX_OBJECT)
						assert(linked_set_ids.contains(field_type.optional_struct_name));
#endif
					linked_struct.fields.push_back(Internal::CompiledFieldTemplate{
						.name = field_name,
						.top_level_type = field_type.type,
						.complex_type_id = (field_type.type == TypeEnum::COMPLEX_OBJECT ? linked_set_ids.find(field_type.optional_struct_name)->second : (uint16_t)0),
						.element_count_for_dimensions = field_type.array_fixed_sizes_for_dimensions
					});
					linked_struct.ids.insert({ field_name, linked_struct.fields.size() - 1 });
				}

				linked_templates[struct_id] = std::move(linked_struct);
			}
		}
		//Calculate sizes & offsets
		for (auto& c_struct : linked_templates)
			Internal::GetStructBinarySize(linked_templates, c_struct);

		//Calculate field offsets

		return { .types = linked_templates, .ids = linked_set_ids };
	}

	struct SerializedStruct {
		uint16_t struct_template_id = 0;
		std::string static_data;
		std::string dynamic_data;
	};
	struct SerializedArray {
		uint16_t struct_template_id = 0;
		uint16_t field_id;
		size_t elem_count = 0;
		uint8_t depth = 0;
		std::string static_data;
		std::string dynamic_data;
	};
	SerializedArray GetArrBase(const CompiledTemplateSet& templ, const std::string& struct_name, const std::string& field_name) {
		assert(templ.ids.contains(struct_name));
		const uint16_t struct_id = templ.ids.find(struct_name)->second;
		const auto& c_struct = templ.types[struct_id];

		assert(c_struct.ids.contains(field_name));
		const uint16_t field_id = c_struct.ids.find(field_name)->second;
		const auto& c_field = c_struct.fields[field_id];

		assert(c_field.element_count_for_dimensions.size());

		return {
			.struct_template_id = struct_id,
			.field_id = field_id,
			.depth = 0
		};
	}
	SerializedArray GetArrBase(const CompiledTemplateSet& templ, const SerializedArray& higher_level_arr) {
		const auto& c_struct = templ.types[higher_level_arr.struct_template_id];
		const auto& c_field = c_struct.fields[higher_level_arr.field_id];

		assert(higher_level_arr.depth + 1 < c_field.element_count_for_dimensions.size());

		return {
			.struct_template_id = higher_level_arr.struct_template_id,
			.field_id = higher_level_arr.field_id,
			.depth = (uint8_t)(higher_level_arr.depth + 1)
		};
	}
	
	namespace Internal {
		template<typename T>
		size_t SerializeNumericType(TypeEnum target_type, T data) { //size_t is here just as a container for 8 bytes(max size for the numeric type), this all is to store without unnecessary memory allocation, but possible to be copied
			assert(DeduceType<T>() != TypeEnum::COMPLEX_OBJECT);

#ifdef JSERIAL_CONVERT_NUMERIC_TYPES
			switch (target_type) {
			case TypeEnum::BOOL: { const bool tmp = (bool)data; return *(size_t*)&tmp; }
			case TypeEnum::INT8: { const int8_t tmp = (int8_t)data; return *(size_t*)&tmp; }
			case TypeEnum::INT16: { const int16_t tmp = (int16_t)data; return *(size_t*)&tmp; }
			case TypeEnum::INT32: { const int32_t tmp = (int32_t)data; return *(size_t*)&tmp; }
			case TypeEnum::INT64: { const int64_t tmp = (int64_t)data; return *(size_t*)&tmp; }
			case TypeEnum::FLOAT32: { const float tmp = (float)data; return *(size_t*)&tmp; }
			case TypeEnum::FLOAT64: { const double tmp = (double)data; return *(size_t*)&tmp; }
			default:
				return 0;//This line is just to let this thing compile
			}
#else
			assert(target_type == DeduceType<T>());
			return *(size_t*)&data;
#endif
		}
	}
	void Reserve(size_t size, SerializedArray& target, const CompiledTemplateSet& templ) { //Tested with numeric types
		assert(target.struct_template_id < templ.types.size());
		const auto& c_parent_struct_template = templ.types[target.struct_template_id];

		assert(target.field_id < c_parent_struct_template.fields.size());
		const auto& c_field_def = c_parent_struct_template.fields[target.field_id];

		assert(c_field_def.element_count_for_dimensions.size() != 0); //Must be an array
		
		target.static_data.reserve(c_field_def.binary_sizes_of_the_children_elements[target.depth] * size);
	}

	template<typename T> 
	void PushBack(SerializedArray& target, const CompiledTemplateSet& templ, const T& elem) { //Tested
		assert(target.struct_template_id < templ.types.size());
		const auto& c_parent_struct_template = templ.types[target.struct_template_id];

		assert(target.field_id < c_parent_struct_template.fields.size());
		const auto& c_field_def = c_parent_struct_template.fields[target.field_id];

		assert(c_field_def.element_count_for_dimensions.size() != 0); //Must be an array
		assert(target.depth == (c_field_def.element_count_for_dimensions.size() - 1) && c_field_def.top_level_type != TypeEnum::COMPLEX_OBJECT); //Only allow serialization if its in the bottom dimension and not a complex type
		assert(target.elem_count + 1 <= c_field_def.element_count_for_dimensions[target.depth]); //After insertion cannot be more than the fixed length


		const size_t serialized_num = Internal::SerializeNumericType(c_field_def.top_level_type, elem); //It needs to be copied, otherwise memory corruption will happen
		target.static_data.insert(target.static_data.size(), (const char*)&serialized_num, (size_t)SIZE_TABLE[(int)c_field_def.top_level_type]);
		target.elem_count++;
	}
	template<>
	void PushBack<SerializedArray>(SerializedArray& target, const CompiledTemplateSet& templ, const SerializedArray& elem){
		assert(target.struct_template_id < templ.types.size());
		const auto& c_parent_struct_template = templ.types[target.struct_template_id];

		assert(target.field_id < c_parent_struct_template.fields.size());
		const auto& c_field_def = c_parent_struct_template.fields[target.field_id];

		assert(c_field_def.element_count_for_dimensions.size() != 0); //Must be an array
		assert(target.depth < (c_field_def.element_count_for_dimensions.size() - 1)); //Only allow serialization if its in the bottom dimension and a complex type
		assert(target.depth + 1 == elem.depth); //Only allow pushing back the array of element type(aka with depth less than of a parent

		assert(target.elem_count + 1 <= c_field_def.element_count_for_dimensions[target.depth]); //After insertion cannot be more than the fixed length

		//if it has fixed size - then embed it
		//if not fixed - add to the dynamic data
		if (c_field_def.element_count_for_dimensions[elem.depth] != ARBITRARY_ELEMENT_COUNT) {
			assert(target.elem_count == c_field_def.element_count_for_dimensions[elem.depth]); //It must have the same amount of elements as in the template
			target.static_data.insert(target.static_data.size(), elem.static_data);
			target.dynamic_data.insert(target.dynamic_data.size(), elem.dynamic_data);
		}
		else {
			const size_t insertion_pos = target.dynamic_data.size();
			target.static_data.insert(target.static_data.size(), (const char*)&insertion_pos, sizeof(size_t));//Insert a pointer to the main array 

			const size_t array_size = elem.elem_count;
			target.dynamic_data.insert(target.dynamic_data.size(), (const char*)&array_size, sizeof(size_t)); //Insert array element count header

			target.dynamic_data.insert(target.dynamic_data.size(), elem.static_data);
			target.dynamic_data.insert(target.dynamic_data.size(), elem.dynamic_data); //Add both static and dynamic data
		}
		target.elem_count++;
	}
	template<>
	void PushBack<SerializedStruct>(SerializedArray& target, const CompiledTemplateSet& templ, const SerializedStruct& elem) {
		assert(target.struct_template_id < templ.types.size());
		const auto& c_parent_struct_template = templ.types[target.struct_template_id];

		assert(target.field_id < c_parent_struct_template.fields.size());
		const auto& c_field_def = c_parent_struct_template.fields[target.field_id];

		assert(c_field_def.element_count_for_dimensions.size() != 0); //Must be an array
		assert(target.depth == (c_field_def.element_count_for_dimensions.size() - 1) && c_field_def.top_level_type == TypeEnum::COMPLEX_OBJECT); //Only allow serialization if its in the bottom dimension and a complex type

		assert(target.elem_count + 1 <= c_field_def.element_count_for_dimensions[target.depth]); //After insertion cannot be more than the fixed length

		target.static_data.insert(target.static_data.size(), elem.static_data);
		target.dynamic_data.insert(target.dynamic_data.size(), elem.dynamic_data);

		target.elem_count++;
	}
	template<>
	void PushBack(SerializedArray& target, const CompiledTemplateSet& templ, const std::string& elem) {
		assert(target.struct_template_id < templ.types.size());
		const auto& c_parent_struct_template = templ.types[target.struct_template_id];

		assert(target.field_id < c_parent_struct_template.fields.size());
		const auto& c_field_def = c_parent_struct_template.fields[target.field_id];

		assert(c_field_def.element_count_for_dimensions.size() != 0); //Must be an array
		assert(target.depth == (c_field_def.element_count_for_dimensions.size() - 2) && c_field_def.top_level_type == TypeEnum::INT8); //Only allow serialization if its in the bottom dimension + 1 and is a char

		assert(target.elem_count + 1 <= c_field_def.element_count_for_dimensions[target.depth]); //After insertion cannot be more than the fixed length

		SerializedArray new_arr = GetArrBase(templ, target);
		Reserve(elem.size(), new_arr, templ);

		for (const auto& i : elem)
			PushBack(new_arr, templ, i);

		PushBack(target, templ, new_arr);
	}
	template<typename T>
	void PushBack(SerializedArray& target, const CompiledTemplateSet& templ, const std::vector<T>& elem) {
		assert(target.struct_template_id < templ.types.size());
		const auto& c_parent_struct_template = templ.types[target.struct_template_id];

		assert(target.field_id < c_parent_struct_template.fields.size());
		const auto& c_field_def = c_parent_struct_template.fields[target.field_id];

		assert(c_field_def.element_count_for_dimensions.size() != 0); //Must be an array
		assert(target.depth != (c_field_def.element_count_for_dimensions.size() - 1)); //Only allow serialization if its not in the bottom dimension and not a complex type

		assert(target.elem_count + 1 <= c_field_def.element_count_for_dimensions[target.depth]); //After insertion cannot be more than the fixed length

		SerializedArray new_arr = {
			.struct_template_id = target.struct_template_id,
			.field_id = target.field_id,
			.depth = (uint8_t)(target.depth + 1)
		};

		Reserve(elem.size(), new_arr, templ);

		for (const auto& i : elem)
			PushBack(new_arr, templ, i);

		PushBack(target, templ, new_arr);
	}

	template<typename T> SerializedArray SerializeArray(const std::string& field_name, const CompiledTemplateSet& templ, const std::vector<T>& src) {

	}

	template<typename T>
	struct Field {
		std::string name;
		T value;
	};

	namespace Internal {
		template<typename T>
		void InsertFields(const CompiledStructTemplate& c_struct, std::string& to, std::vector<std::string>& field_dynamic_data, size_t& field_count, const CompiledTemplateSet& templ, Field<T> ser_elem) {
			assert(c_struct.ids.contains(ser_elem.name));
			const auto& c_field = c_struct.fields[c_struct.ids.find(ser_elem.name)->second];

			assert(c_field.top_level_type != TypeEnum::COMPLEX_OBJECT && !c_field.element_count_for_dimensions.size());
			assert(DeduceType<T>() != TypeEnum::COMPLEX_OBJECT);
			const size_t tmp = SerializeNumericType(c_field.top_level_type, ser_elem.value);
			memcpy(&to[c_field.cached_offset], &tmp, SIZE_TABLE[(int)c_field.top_level_type]);

			field_count++;
		}
		template<>
		void InsertFields<SerializedStruct>(const CompiledStructTemplate& c_struct, std::string& to, std::vector<std::string>& field_dynamic_data, size_t& field_count, const CompiledTemplateSet& templ, Field<SerializedStruct> ser_elem) {
			assert(c_struct.ids.contains(ser_elem.name));
			const uint16_t field_id = c_struct.ids.find(ser_elem.name)->second;
			const auto& c_field = c_struct.fields[field_id];

			assert(c_field.top_level_type == TypeEnum::COMPLEX_OBJECT && !c_field.element_count_for_dimensions.size());
			assert(c_field.complex_type_id == ser_elem.value.struct_template_id); //The struct must have the same type as the field
			memcpy(&to[c_field.cached_offset], ser_elem.value.static_data.data(), ser_elem.value.static_data.size());

			field_dynamic_data[field_id] = std::move(ser_elem.value.dynamic_data);
			//Dynamic data will be added separately to maintain the required order
			//to_dynamic.insert(to_dynamic.size(), ser_elem.value.dynamic_data);

			field_count++;
		}
		template<>
		void InsertFields<SerializedArray>(const CompiledStructTemplate& c_struct, std::string& to, std::vector<std::string>& field_dynamic_data, size_t& field_count, const CompiledTemplateSet& templ, Field<SerializedArray> ser_elem) {
			assert(c_struct.ids.contains(ser_elem.name));
			const uint16_t field_id = c_struct.ids.find(ser_elem.name)->second;
			const auto& c_field = c_struct.fields[field_id];

			assert(c_field.element_count_for_dimensions.size());
			assert(ser_elem.value.depth == 0);

			std::string& c_dyn_data = field_dynamic_data[field_id];
			c_dyn_data = "";

			if (c_field.element_count_for_dimensions[0] != ARBITRARY_ELEMENT_COUNT) //fixed-size arrays must be embedded
				memcpy(&to[c_field.cached_offset], ser_elem.value.static_data.data(), ser_elem.value.static_data.size());
			else {
				//we shoulnt do anything to static data, since doing pointer stuff is linker's responsibility
				const size_t arr_size = ser_elem.value.elem_count;
				c_dyn_data.insert(c_dyn_data.size(), (const char*)&arr_size, sizeof(size_t)); //Insert array element count header
				c_dyn_data.insert(c_dyn_data.size(), ser_elem.value.static_data);
			}
			c_dyn_data.insert(c_dyn_data.size(), ser_elem.value.dynamic_data);
			//Dynamic data will be added separately to maintain the required order

			field_count++;
		}
		template<>
		void InsertFields<std::string>(const CompiledStructTemplate& c_struct, std::string& to, std::vector<std::string>& field_dynamic_data, size_t& field_count, const CompiledTemplateSet& templ, Field<std::string> ser_elem) {
			assert(c_struct.ids.contains(ser_elem.name));
			const uint16_t field_id = c_struct.ids.find(ser_elem.name)->second;
			const auto& c_field = c_struct.fields[field_id];

			assert(c_field.element_count_for_dimensions.size() == 1);
			assert(c_field.top_level_type == TypeEnum::INT8);

			SerializedArray arr = GetArrBase(templ, c_struct.name, c_field.name);
			Reserve(ser_elem.value.size(), arr, templ);
			for (const auto& i : ser_elem.value)
				PushBack(arr, templ, i);
			InsertFields(c_struct, to, field_dynamic_data, field_count, templ, Field{ ser_elem.name, arr });
		}
		template<>
		inline void InsertFields<const char*>(const CompiledStructTemplate& c_struct, std::string& to, std::vector<std::string>& field_dynamic_data, size_t& field_count, const CompiledTemplateSet& templ, Field<const char*> ser_elem) 
			{ InsertFields(c_struct, to, field_dynamic_data, field_count, templ, Field{ ser_elem.name, std::string(ser_elem.value) }); }
		template<typename T>
		void InsertFields( const CompiledStructTemplate& c_struct, std::string& to, std::vector<std::string>& field_dynamic_data, size_t& field_count, const CompiledTemplateSet& templ, Field<std::vector<T>> ser_elem) {
			assert(c_struct.ids.contains(ser_elem.name)); //No field with such name exists
			const uint16_t field_id = c_struct.ids.find(ser_elem.name)->second;
			const auto& c_field = c_struct.fields[field_id];

			assert(c_field.element_count_for_dimensions.size()); //Trying to serialize an array, but field is not that

			SerializedArray arr = GetArrBase(templ, c_struct.name, c_field.name);
			Reserve(ser_elem.value.size(), arr, templ);
			for (const auto& i : ser_elem.value)
				PushBack(arr, templ, i);

			InsertFields(c_struct, to, field_dynamic_data, field_count, templ, Field{ ser_elem.name, arr });
		}

		template<typename T, typename ...Oth>
		void InsertFields(const CompiledStructTemplate& c_struct, std::string& to, std::vector<std::string>& field_dynamic_data, size_t &field_count, const CompiledTemplateSet& templ, Field<T> ser_elem, Oth... oth) {
			InsertFields(c_struct, to, field_dynamic_data, field_count, templ, ser_elem);
			InsertFields(c_struct, to, field_dynamic_data, field_count, templ, oth...);
		}
	}

	template<typename ...Args>
	SerializedStruct SerializeStruct(const std::string& struct_name, const CompiledTemplateSet& templ, Args... oth) {
		assert(templ.ids.contains(struct_name)); //The specified struct does not exist
		const uint16_t struct_id = templ.ids.find(struct_name)->second;
		const Internal::CompiledStructTemplate& c_struct = templ.types[struct_id];

		SerializedStruct res = { .struct_template_id = struct_id };
		res.static_data.resize(c_struct.cached_size);

		size_t field_count = 0;

		std::vector<std::string> field_dynamic_data(c_struct.fields.size());
		//Insert all the fields
		Internal::InsertFields(c_struct, res.static_data, field_dynamic_data, field_count, templ, oth...);

		for (auto& i : field_dynamic_data)
			res.dynamic_data += i;

		assert(field_count == c_struct.fields.size());

		return res;
	}

	struct ManuallySerializableStruct {
		std::string static_data;
		std::vector<std::string> field_dynamic_data;
		std::vector<bool> serialized_fields;

		uint16_t struct_id = 0;
	};

	ManuallySerializableStruct InitializeManuallySerializableStruct(const std::string& struct_name, const CompiledTemplateSet& templ) {
		assert(templ.ids.contains(struct_name));
		const uint16_t struct_id = templ.ids.find(struct_name)->second;
		const Internal::CompiledStructTemplate& c_struct = templ.types[struct_id];

		ManuallySerializableStruct res = { .static_data = std::string(c_struct.cached_size, (char)0), .field_dynamic_data = std::vector<std::string>{c_struct.fields.size()}, .serialized_fields = std::vector<bool>(c_struct.fields.size()), .struct_id = struct_id};
		return res;
	}

	template<typename T>
	void SerializeField(ManuallySerializableStruct& dest, const CompiledTemplateSet& templ, const std::string& field_name, const T& value) {
		size_t dummy = 0;
		const Internal::CompiledStructTemplate& c_struct = templ.types[dest.struct_id];
		Internal::InsertFields(c_struct, dest.static_data, dest.field_dynamic_data, dummy, templ, Field{ field_name, value });
		dest.serialized_fields[c_struct.ids.find(field_name)->second] = true;
	}

	SerializedStruct SerializeStruct(const CompiledTemplateSet& templ, const ManuallySerializableStruct& src) {
#ifndef NDEBUG
		for (const auto& i : src.serialized_fields) assert(i); //I.e. every field must be serialized
#endif // NDEBUG


		SerializedStruct res = { .struct_template_id = src.struct_id, .static_data = src.static_data };

		for (auto& i : src.field_dynamic_data)
			res.dynamic_data += i;

		return res;
	}

	namespace Internal {
		void LinkStruct(const CompiledTemplateSet& templ, uint16_t struct_id, size_t base_offset, size_t& dyn_ptr, std::string& src);

		size_t LinkArray(const CompiledTemplateSet& templ, uint16_t struct_id, uint16_t field_id, uint8_t depth, size_t base_offset, size_t& dyn_ptr, std::string& src) { //it should return the position of the array
			const auto& c_struct = templ.types[struct_id];
			const auto& c_field = c_struct.fields[field_id];

			size_t elem_count = c_field.element_count_for_dimensions[depth];
			size_t arr_static_part_offset = base_offset;

			const size_t adress_to_return = dyn_ptr;

			if (elem_count == ARBITRARY_ELEMENT_COUNT) { //If its dynamic
				elem_count = *(size_t*)&src[dyn_ptr];
				dyn_ptr += sizeof(size_t);
				arr_static_part_offset = dyn_ptr;
				dyn_ptr += c_field.binary_sizes_of_the_children_elements[depth] * elem_count;
			}

			//Iterate over all the elements if elements are either arrays, or structs
			if (depth != c_field.element_count_for_dimensions.size() - 1) {
				//iterate trough all of them
				for (int i = 0; i < elem_count; i++) {
					const size_t elem_offset = arr_static_part_offset + c_field.binary_sizes_of_the_children_elements[depth] * i;

					//If the elements below are dynamic, link it
					const size_t linked_pos = LinkArray(templ, struct_id, field_id, depth + 1, elem_offset, dyn_ptr, src);
					if (c_field.element_count_for_dimensions[0] == ARBITRARY_ELEMENT_COUNT) //If this shit is dynamic
						*(size_t*)&src[elem_offset] = linked_pos;
				}
			}
			else if (c_field.top_level_type == TypeEnum::COMPLEX_OBJECT) {
				for (int i = 0; i < elem_count; i++) {
					const size_t elem_offset = arr_static_part_offset + c_field.binary_sizes_of_the_children_elements[depth] * i;
					LinkStruct(templ, c_field.complex_type_id, elem_offset, dyn_ptr, src);
				}
			}

			return adress_to_return;
		}

		void LinkStruct(const CompiledTemplateSet& templ, uint16_t struct_id, size_t base_offset, size_t& dyn_ptr, std::string& src) {
			//if theres anything dynamic(can be get by checking dimensions)
			//then go to dyn data
			const auto& c_struct = templ.types[struct_id];

			for (int c_field_id = 0; c_field_id < c_struct.fields.size(); c_field_id++) {
				const auto& c_field = c_struct.fields[c_field_id];
				const size_t field_offset = base_offset + c_field.cached_offset;
				//go trough all the dimensions
				//if its not fixed size - then link all the elements
				if (c_field.element_count_for_dimensions.size()) {
					const size_t linked_pos = LinkArray(templ, struct_id, c_field_id, 0, field_offset, dyn_ptr, src);
					if (c_field.element_count_for_dimensions[0] == ARBITRARY_ELEMENT_COUNT) //If this shit is dynamic
						*(size_t*)&src[field_offset] = linked_pos;
				}
				else if (c_field.top_level_type == TypeEnum::COMPLEX_OBJECT)
					LinkStruct(templ, c_field.complex_type_id, field_offset, dyn_ptr, src);
			}
		}
		//Header: "JSERIAL[2 bytes for major][2 for minor][2 for patch]"
		const TemplateSet SRC_JSERIAL_FIELD_SERIALIZATION_TEMPLATE = {
			{ 
				.name = "Document", 
				.fields = {
					{ .name = "structs",                 .type = Array(Struct("Struct")) },
					{ .name = "root_struct_template_id", .type = NumericType(TypeEnum::INT16) }
				}
			},
			{ 
				.name = "Struct", 
				.fields = {
					{ .name = "name", .type = String() },
					{ .name = "fields", .type = Array(Struct("Field")) }
				}
			},
			{ 
				.name = "Field", 
				.fields = {
					{ .name = "name", .type = String() },
					{ .name = "type", .type = Struct("Type") }
				}
			},
			{ 
				.name = "Type", 
				.fields = {
					{ .name = "top_level_type", .type = NumericType(TypeEnum::INT8) },
					{ .name = "target_struct_id", .type = NumericType(TypeEnum::INT16) },
					{ .name = "fixed_sizes_for_dimensions", .type = Array(NumericType(TypeEnum::INT64)) },
				}
			}
		};
		const CompiledTemplateSet TEMPLATE_SERIALIZATION_TEMPLATE = CompileTemplates(SRC_JSERIAL_FIELD_SERIALIZATION_TEMPLATE);

		const uint16_t MAJOR_VERSION = 0;
		const uint16_t MINOR_VERSION = 0;
		const uint16_t PATCH_VERSION = 0;

		const std::string HEADER = "JSERIAL" + std::string((const char*)&MAJOR_VERSION, sizeof(uint16_t)) + std::string((const char*)&MINOR_VERSION, sizeof(uint16_t)) + std::string((const char*)&PATCH_VERSION, sizeof(uint16_t)) + std::string(sizeof(size_t), char(0));
		const size_t TEMPLATE_END_VALUE_LOC = 13;
		const size_t HEADER_END = HEADER.size();

		std::string SerializeTemplateSet(const CompiledTemplateSet& templ, uint16_t root_struct_template_id) {
			std::vector<SerializedStruct> serialized_structs;
			serialized_structs.reserve(templ.types.size());

			for (const auto& c_struct : templ.types) {
				std::vector<SerializedStruct> serialized_fields;
				for (const auto& c_field : c_struct.fields) {
					SerializedStruct c_serialized_type = SerializeStruct("Type", TEMPLATE_SERIALIZATION_TEMPLATE,
						Field{
							"top_level_type",
							(uint8_t)c_field.top_level_type
						},
						Field{
							"target_struct_id",
							c_field.complex_type_id
						},
						Field{
							"fixed_sizes_for_dimensions",
							c_field.element_count_for_dimensions
						}
					);

					SerializedStruct c_serialized_field = SerializeStruct("Field", TEMPLATE_SERIALIZATION_TEMPLATE,
						Field{
							"name",
							c_field.name
						},
						Field{
							"type", 
							c_serialized_type
						}
					);
					serialized_fields.push_back(c_serialized_field);
				}

				serialized_structs.push_back(JSerial::SerializeStruct("Struct", TEMPLATE_SERIALIZATION_TEMPLATE,
					Field{
						"fields",
						serialized_fields
					},
					Field{
						"name",
						c_struct.name
					}
				));
			}
			SerializedStruct document = JSerial::SerializeStruct("Document", TEMPLATE_SERIALIZATION_TEMPLATE,
				Field{
					"structs",
					serialized_structs
				},
				Field{
					"root_struct_template_id",
					root_struct_template_id
				}
			);
			//Link it
			std::string combined = HEADER + document.static_data + document.dynamic_data;
			size_t dynamic_data_ptr = HEADER_END + document.static_data.size();

			Internal::LinkStruct(TEMPLATE_SERIALIZATION_TEMPLATE, document.struct_template_id, HEADER_END, dynamic_data_ptr, combined);

			*(size_t*)&combined[TEMPLATE_END_VALUE_LOC] = combined.size();

			return combined;
		}
	}
	std::string CreateDocument(const CompiledTemplateSet& templ, const SerializedStruct& root_struct) {
		const Internal::CompiledStructTemplate& c_struct = templ.types[root_struct.struct_template_id];

		std::string serialized_template = Internal::SerializeTemplateSet(templ, root_struct.struct_template_id);
		std::string res = serialized_template + root_struct.static_data + root_struct.dynamic_data;
		size_t dynamic_data_ptr = root_struct.static_data.size() + serialized_template.size();

		Internal::LinkStruct(templ, root_struct.struct_template_id, serialized_template.size(), dynamic_data_ptr, res);

		return res;
	}

	struct Document {
		CompiledTemplateSet templates;
		std::string raw_data;
		uint16_t root_structure_id = 0;
		size_t root_structure_offset = 0;
	};
	struct ParsedStruct {
		uint16_t struct_template_id = 0;
		//size_t type_set_hash;//debug only

		size_t offset;
	};
	struct ParsedArray {
		size_t offset = 0;
		uint16_t parent_struct_id = 0;
		uint16_t field_id_in_struct = 0;
		uint16_t depth = 0;

		size_t element_count = 0;
	};
	
	namespace Internal {
		inline size_t GetFieldOffset(const ParsedStruct& data, const CompiledStructTemplate& templ, uint16_t field_id) {
			return templ.fields[field_id].cached_offset + data.offset;
		}

		inline size_t GetArrayStartOffset(const std::string& src, size_t offset, size_t fixed_size) 
			{ return (fixed_size == ARBITRARY_ELEMENT_COUNT ? *(size_t*)&src[offset] + sizeof(size_t) : offset); } //Arrays with fixed size at the top level always get embedded inside of a struct
		inline size_t GetArrayElementCount(const std::string& src, size_t offset, size_t fixed_size) 
			{ return (fixed_size == ARBITRARY_ELEMENT_COUNT ? *(size_t*)&src[*(size_t*)&src[offset]] : fixed_size); }

		template<typename T> 
		T DeserializeSimpleType(const std::string& src, size_t offset, TypeEnum type) {
			assert(Internal::DeduceType<T>() != TypeEnum::COMPLEX_OBJECT);

#ifdef JSERIAL_CONVERT_NUMERIC_TYPES
			switch (type) {
			case TypeEnum::BOOL:
				return (T)(*(bool*)&src[offset]);
			case TypeEnum::INT8:
				return (T)(*(int8_t*)&src[offset]);
			case TypeEnum::INT16:
				return (T)(*(int16_t*)&src[offset]);
			case TypeEnum::INT32:
				return (T)(*(int32_t*)&src[offset]);
			case TypeEnum::INT64:
				return (T)(*(int64_t*)&src[offset]);

			case TypeEnum::FLOAT32:
				return (T)(*(float*)&src[offset]);
			case TypeEnum::FLOAT64:
				return (T)(*(double*)&src[offset]);

			default:
				return (T)0;//This line is just to let this thing compile
			}
#else
			assert(type == Internal::DeduceType<T>());
			return *(T*)&src[offset];
#endif
		}

		template<typename T>
		std::vector<T> DeserializeVec(const ParsedStruct& data, const Document& src, uint16_t field_id, const std::vector<T>& dummy_for_type_deduction);

		template<typename T>
		T DeserializeVec(const ParsedStruct& data, const Document& src, uint16_t field_id, const T& dummy_for_type_deduction) {
			return T{};//God please let this thing finally compile
		}

		template<typename T>
		bool IsVector(const std::vector<T>& x) { return true; }
		template<typename T>
		bool IsVector(const T& x) { return false; }
	}

	//Tested
	template<typename T>
	T Deserialize(const ParsedStruct& data, const Document& src, uint16_t field_id) {
		if (Internal::IsVector(T{})) //I had to put it here because of c++'s awful template system
			return Internal::DeserializeVec(data, src, field_id, T{});

		assert(data.struct_template_id < src.templates.types.size());
		const auto& c_parent_struct_template = src.templates.types[data.struct_template_id];

		assert(field_id < c_parent_struct_template.fields.size());
		const auto& c_field_def = c_parent_struct_template.fields[field_id];

		assert(c_field_def.element_count_for_dimensions.size() == 0 && c_field_def.top_level_type != TypeEnum::COMPLEX_OBJECT); //If its not an array or complex object

		const size_t offset = Internal::GetFieldOffset(data, c_parent_struct_template, field_id);

		return Internal::DeserializeSimpleType<T>(src.raw_data, offset, c_field_def.top_level_type);
	}
	template<>
	ParsedStruct Deserialize(const ParsedStruct& data, const Document& src, uint16_t field_id) {
		assert(data.struct_template_id < src.templates.types.size());
		const auto& c_parent_struct_template = src.templates.types[data.struct_template_id];

		assert(field_id < c_parent_struct_template.fields.size());
		const auto& c_field_def = c_parent_struct_template.fields[field_id];

		assert(c_field_def.element_count_for_dimensions.size() == 0 && c_field_def.top_level_type == TypeEnum::COMPLEX_OBJECT);

		const auto& c_field_template = src.templates.types[c_field_def.complex_type_id];

		return {
			.struct_template_id = c_field_def.complex_type_id,
			.offset = Internal::GetFieldOffset(data, c_parent_struct_template, field_id) //It doesnt have any headers or smth
		};
	}
	template<>
	ParsedArray Deserialize(const ParsedStruct& data, const Document& src, uint16_t field_id) {
		assert(data.struct_template_id < src.templates.types.size());
		const auto& c_parent_struct_template = src.templates.types[data.struct_template_id];

		assert(field_id < c_parent_struct_template.fields.size());
		const auto& c_field_def = c_parent_struct_template.fields[field_id];

		assert(c_field_def.element_count_for_dimensions.size() != 0); //Must be an array

		const size_t base_field_offset = Internal::GetFieldOffset(data, c_parent_struct_template, field_id);

		return {
			.offset = Internal::GetArrayStartOffset(src.raw_data, base_field_offset, c_field_def.element_count_for_dimensions[0]),
			.parent_struct_id = data.struct_template_id,
			.field_id_in_struct = field_id,
			.depth = 0, //It always will be 0, since we are always at the top level
			.element_count = Internal::GetArrayElementCount(src.raw_data, base_field_offset, c_field_def.element_count_for_dimensions[0])
		};
	}
	template<>
	std::string Deserialize(const ParsedStruct& data, const Document& src, uint16_t elem_id) {
		const ParsedArray s_arr = Deserialize<ParsedArray>(data, src, elem_id);
		return std::string(&src.raw_data[s_arr.offset], s_arr.element_count);
	}
	template<typename T>
	T Deserialize(const ParsedStruct& data, const Document& src, const std::string& field_name) {
		assert(data.struct_template_id < src.templates.types.size());
		const auto& c_parent_struct_template = src.templates.types[data.struct_template_id];

		assert(c_parent_struct_template.ids.contains(field_name));

		return Deserialize<T>(data, src, c_parent_struct_template.ids.find(field_name)->second);
	}
	



	//--------------------------------------------------ARRAY DESERIALIZATION----------------------------------------------------------------------
	namespace Internal {
		template<typename T>
		std::vector<T> DeserializeVec(const ParsedArray& arr, const Document& src, size_t elem_id, const std::vector<T>& dummy_for_type_deduction);

		template<typename T>
		T DeserializeVec(const ParsedArray& arr, const Document& src, size_t elem_id, const T& dummy_for_type_deduction) {
			return T{};//God please let this finally compile🙏🙏😭😭😭
		}
	}

	template<typename T>
	T Deserialize(const ParsedArray& arr, const Document& src, size_t elem_id) {
		if (Internal::IsVector(T{})) //I had to put it here because of c++'s awful template system
			return Internal::DeserializeVec(arr, src, elem_id, T{});

		assert(elem_id < arr.element_count);

		assert(arr.parent_struct_id < src.templates.types.size());
		const auto& c_parent_struct_template = src.templates.types[arr.parent_struct_id];

		assert(arr.field_id_in_struct < c_parent_struct_template.fields.size());
		const auto& c_field_def = c_parent_struct_template.fields[arr.field_id_in_struct];

		assert(arr.depth == (c_field_def.element_count_for_dimensions.size() - 1) && c_field_def.top_level_type != TypeEnum::COMPLEX_OBJECT); //Only allow deserialization if its in the bottom dimension and not a complex type

		const size_t offset = arr.offset + c_field_def.binary_sizes_of_the_children_elements[arr.depth] * elem_id;

		return Internal::DeserializeSimpleType<T>(src.raw_data, offset, c_field_def.top_level_type);
	}
	template<>
	ParsedStruct Deserialize(const ParsedArray& arr, const Document& src, size_t elem_id) {
		assert(elem_id < arr.element_count);

		assert(arr.parent_struct_id < src.templates.types.size());
		const auto& c_parent_struct_template = src.templates.types[arr.parent_struct_id];

		assert(arr.field_id_in_struct < c_parent_struct_template.fields.size());
		const auto& c_field_def = c_parent_struct_template.fields[arr.field_id_in_struct];

		assert(arr.depth == (c_field_def.element_count_for_dimensions.size() - 1) && c_field_def.top_level_type == TypeEnum::COMPLEX_OBJECT); //Only allow deserialization if its in the bottom dimension and not a complex type

		return {
			.struct_template_id = c_field_def.complex_type_id,
			.offset = arr.offset + c_field_def.binary_sizes_of_the_children_elements[arr.depth] * elem_id
		};
	}
	template<>
	ParsedArray Deserialize(const ParsedArray& arr, const Document& src, size_t elem_id) {
		assert(elem_id < arr.element_count);

		assert(arr.parent_struct_id < src.templates.types.size());
		const auto& c_parent_struct_template = src.templates.types[arr.parent_struct_id];

		assert(arr.field_id_in_struct < c_parent_struct_template.fields.size());
		const auto& c_field_def = c_parent_struct_template.fields[arr.field_id_in_struct];

		assert(c_field_def.element_count_for_dimensions.size() != 0); //Must be an array

		const size_t offset = arr.offset + c_field_def.binary_sizes_of_the_children_elements[arr.depth] * elem_id;

		return {
			.offset = Internal::GetArrayStartOffset(src.raw_data, offset, c_field_def.element_count_for_dimensions[0]),
			.parent_struct_id = arr.parent_struct_id,
			.field_id_in_struct = arr.field_id_in_struct,
			.depth = (uint16_t)(arr.depth + 1),
			.element_count = Internal::GetArrayElementCount(src.raw_data, offset, c_field_def.element_count_for_dimensions[0])
		};
	}
	template<>
	std::string Deserialize(const ParsedArray& arr, const Document& src, size_t elem_id) {
		const ParsedArray s_arr = Deserialize<ParsedArray>(arr, src, elem_id);
		return std::string(&src.raw_data[s_arr.offset], s_arr.element_count);
	}

	namespace Internal {
		template<typename T>
		std::vector<T> DeserializeVec(const ParsedArray& arr, const Document& src, size_t elem_id, const std::vector<T>& dummy_for_type_deduction) {
			const ParsedArray s_arr = Deserialize<ParsedArray>(arr, src, elem_id);

			std::vector<T> res;
			res.reserve(s_arr.element_count);

			for (int i = 0; i < s_arr.element_count; i++) {
				if (Internal::IsVector(T{}))
					res.push_back(DeserializeVec(arr, src, elem_id, T{}));
				else
					res.push_back(Deserialize<T>(s_arr, src, i));
			}

			return res;
		}
		
		template<typename T>
		std::vector<T> DeserializeVec(const ParsedStruct& data, const Document& src, uint16_t field_id, const std::vector<T>& dummy_for_type_deduction) {
			ParsedArray s_arr = Deserialize<ParsedArray>(data, src, field_id);

			std::vector<T> res;
			res.reserve(s_arr.element_count);

			for (size_t i = 0; i < s_arr.element_count; i++) {
				if (Internal::IsVector(T{}))
					res.push_back(DeserializeVec(s_arr, src, i, T{}));
				else
					res.push_back(Deserialize<T>(s_arr, src, i));
			}
			return res;
		}
	}

	Document ParseDocument(const std::string& src) {
		ParsedStruct doc_data = {
			.struct_template_id = Internal::TEMPLATE_SERIALIZATION_TEMPLATE.ids.find("Document")->second,
			.offset = Internal::HEADER.size()
		};
		Document doc = {
			.templates = Internal::TEMPLATE_SERIALIZATION_TEMPLATE,
			.raw_data = src,
		};

		std::vector<ParsedStruct> structs = Deserialize<std::vector<ParsedStruct>>(doc_data, doc, "structs");
		CompiledTemplateSet set;
		set.types.reserve(structs.size());
		set.ids.reserve(structs.size());

		for (const auto& c_struct : structs) {
			std::vector<ParsedStruct> fields = Deserialize<std::vector<ParsedStruct>>(c_struct, doc, "fields");//Parse fields

			Internal::CompiledStructTemplate deserialized_template;
			deserialized_template.fields.reserve(fields.size());
			deserialized_template.ids.reserve(fields.size());

			for (const auto& c_field : fields) {
				
				ParsedStruct type = Deserialize<ParsedStruct>(c_field, doc, "type");

				Internal::CompiledFieldTemplate deserialized_field = {
					.name = Deserialize<std::string>(c_field, doc, "name"),
					.top_level_type = (TypeEnum)Deserialize<int8_t>(type, doc, "top_level_type"),
					.complex_type_id = (uint16_t)Deserialize<int16_t>(type, doc, "target_struct_id"),
					.element_count_for_dimensions = Deserialize<std::vector<size_t>>(type, doc, "fixed_sizes_for_dimensions")
				};
				deserialized_template.ids.insert({ deserialized_field.name, deserialized_template.fields.size() });
				deserialized_template.fields.push_back(std::move(deserialized_field));
			}
			deserialized_template.name = Deserialize<std::string>(c_struct, doc, "name");
			set.ids.insert({ deserialized_template.name, set.types.size() });
			set.types.push_back(std::move(deserialized_template));
		}

		//Linking
		for (auto& c_struct : set.types)
			Internal::GetStructBinarySize(set.types, c_struct);

		doc.root_structure_id = Deserialize<uint16_t>(doc_data, doc, "root_struct_template_id");
		doc.templates = set;
		doc.root_structure_offset = *(size_t*)&src[Internal::TEMPLATE_END_VALUE_LOC];

		return doc;
	}
	ParsedStruct GetRootStructure(const Document& doc) {
		return ParsedStruct{
			.struct_template_id = doc.root_structure_id,
			.offset = doc.root_structure_offset
		};
	}
}