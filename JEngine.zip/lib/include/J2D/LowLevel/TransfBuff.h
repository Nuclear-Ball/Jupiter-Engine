#pragma once
#include <JGFX/JGFX.h>
#include <JupiterUtils.h>

namespace LLJ2D {
	namespace Internal {
		const JGFX::VertexLayout transf_layout = {
			{2, JGFX::AttType<float>(), 4, true},
			{3, JGFX::AttType<float>(), 4, true},
			{4, JGFX::AttType<float>(), 4, true},
			{5, JGFX::AttType<float>(), 4, true}
		};
		const JGFX::VertexLayout transparency_layout = {
			{6, JGFX::AttType<float>(), 1, true}
		};

		struct TransfBuffData {
			LLJGFX::VBuff::Handle buff = { 0 };
			LLJGFX::VBuff::Handle transparency = { 0 };
			size_t user_transparency_size = 0;
		};
		constexpr TransfBuffData DEFAULT_TBUFF = {};
		JE::AnonymousManager<TransfBuffData> transf_buff_manager;
	}

	namespace TransfBuff {
		typedef JE::MHandle<Internal::TransfBuffData> Handle;

		constexpr Handle NULL_TBUFF = { nullptr };

		inline bool IsValid(Handle handle) 
			{ return Internal::transf_buff_manager.DoesExists(handle); }
	}
	namespace Internal {
		inline void CheckTBuffValidity(TransfBuff::Handle handle){
#ifndef NDEBUG
			if (!TransfBuff::IsValid(handle))
				throw std::runtime_error("Requested transformation buffer does not exists");
#endif
		}
		inline TransfBuffData& GetTBuff(TransfBuff::Handle handle) { return transf_buff_manager[handle]; }
		inline const TransfBuffData& GetRoTBuff(TransfBuff::Handle handle)
			{ return handle == TransfBuff::NULL_TBUFF ? DEFAULT_TBUFF : transf_buff_manager[handle]; }
	}

	namespace TransfBuff {
		inline void SetData(Handle handle, const glm::mat4* data, size_t size) { 
			Internal::CheckTBuffValidity(handle);
			Internal::TransfBuffData dat = Internal::GetTBuff(handle);
			//Change transparency size
			const size_t transparency_size = LLJGFX::VBuff::GetSize(dat.transparency);
			if (transparency_size < size) {
				const size_t binary_old_size = transparency_size * sizeof(fl32);
				const size_t binary_target_size = size * sizeof(fl32);

				fl32* data_to_set = (fl32*)malloc(binary_target_size);
				memcpy(data_to_set, data, binary_old_size);
				memset(data_to_set + binary_old_size, 0, binary_target_size - binary_old_size);

				LLJGFX::VBuff::SetData(dat.transparency, data_to_set, size);
			}

			LLJGFX::VBuff::SetData(Internal::GetTBuff(handle).buff, data, size); 
		}
		inline void SetData(Handle handle, const std::vector<glm::mat4>& data) { SetData(handle, data.data(), data.size()); }
		inline void SetData(Handle handle, const glm::mat4& data) { SetData(handle, &data, 1); }

		inline void SetTransparency(Handle handle, const fl32* data, size_t size) {
			Internal::CheckTBuffValidity(handle);

			Internal::TransfBuffData dat = Internal::GetTBuff(handle);
			dat.user_transparency_size = size;

			fl32* data_to_set = nullptr;
			const size_t min_size = LLJGFX::VBuff::GetSize(dat.buff);
			if (dat.user_transparency_size < min_size) { //Expanding and filling the transparency buffer, so it wouldnt crash
				const size_t binary_size = size * sizeof(fl32);
				const size_t binary_min_size = min_size * sizeof(fl32);

				data_to_set = (fl32*)malloc(binary_min_size);
				memcpy(data_to_set, data, binary_size);
				memset(data_to_set + binary_size, 0, binary_min_size - binary_size);

				size = min_size;
			}
			else data_to_set = (fl32*)data;

			LLJGFX::VBuff::SetData(dat.transparency, data_to_set, size);
		}
		inline void SetTransparency(Handle handle, const std::vector<fl32>& data) { SetTransparency(handle, data.data(), data.size()); }
		inline void SetTransparency(Handle handle, const fl32& data) { SetTransparency(handle, &data, 1); }

		inline std::vector<glm::mat4> GetData(Handle handle) 
			{ return LLJGFX::VBuff::GetData<glm::mat4>(Internal::GetRoTBuff(handle).buff); }
		inline size_t GetSize(Handle handle) 
			{ return LLJGFX::VBuff::GetSize(Internal::GetRoTBuff(handle).buff); }

		inline std::vector<fl32> GetTransparency(Handle handle) { 
			std::vector<fl32> transparency_data = LLJGFX::VBuff::GetData<fl32>(Internal::GetRoTBuff(handle).transparency); 
			transparency_data.resize(Internal::GetRoTBuff(handle).user_transparency_size); //Its all to hide the fact, that the transparency buffer is being resized
			return transparency_data;
		}
		inline size_t GetTransparencySize(Handle handle)
			{ return Internal::GetRoTBuff(handle).user_transparency_size; }

		inline void Copy(Handle to, Handle from) { SetData(to, GetData(from)); }

		inline Handle Make() {
			LLJGFX::VBuff::Handle vb_handle = LLJGFX::VBuff::Make();
			LLJGFX::VBuff::SetLayout(vb_handle, Internal::transf_layout);

			LLJGFX::VBuff::Handle transparency_handle = LLJGFX::VBuff::Make();
			LLJGFX::VBuff::SetLayout(transparency_handle, Internal::transparency_layout);

			return Internal::transf_buff_manager.Add({ vb_handle, transparency_handle });
		}
		inline Handle Make(const glm::mat4* data, size_t size, const fl32* transparency_data = nullptr, size_t t_size = 0) {
			Handle handle = Make();
			SetData(handle, data, size);
			SetTransparency(handle, transparency_data, t_size);
			return handle;
		}
		inline Handle Make(const std::vector<glm::mat4>& data, const std::vector<fl32>& transparency = {}) {
			Handle handle = Make();
			SetData(handle, data);
			SetTransparency(handle, transparency);
			return handle;
		}
		inline Handle Make(const glm::mat4& data, fl32 transparency = 0) {
			Handle handle = Make();
			SetData(handle, data);
			SetTransparency(handle, transparency);
			return handle;
		}
		inline Handle Make(Handle cpy) {
			Handle handle = Make();
			Copy(handle, cpy);
			return handle;
		}

		inline void Delete(Handle handle) { 
			if (handle != NULL_TBUFF) {
				LLJGFX::VBuff::Delete(Internal::transf_buff_manager[handle].buff);
				LLJGFX::VBuff::Delete(Internal::transf_buff_manager[handle].transparency);
				Internal::transf_buff_manager.Remove(handle);
			}
		}
	}
	namespace Internal {
		TransfBuff::Handle default_tbuff = TransfBuff::NULL_TBUFF;

		void InitTBuff() { default_tbuff = TransfBuff::Make(); }
	}
}