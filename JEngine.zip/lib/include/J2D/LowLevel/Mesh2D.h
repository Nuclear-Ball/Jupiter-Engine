#pragma once
#include <JGFX/JGFX.h>
#include <JupiterUtils.h>

namespace LLJ2D {
	namespace Internal {
		const JGFX::VertexLayout mesh_layout = {{ 0, JGFX::AttType<float>(), 2},
												{ 1, JGFX::AttType<float>(), 2}};

		struct MeshData {
			LLJGFX::VRef::Handle vref_handle = { 0 };
			LLJGFX::VBuff::Handle data_handle = { 0 };
		};
		constexpr MeshData DEFAULT_MESH = {};
		JE::AnonymousManager<MeshData> mesh_manager;
	}

	namespace Mesh {
		struct Vertex2D {
			pos2df32 pos = { 0, 0 };
			pos2df32 uv = { 0, 0 };
		};

		typedef JE::MHandle<Internal::MeshData> Handle;

		constexpr Handle NULL_MESH = { nullptr };

		inline bool IsValid(Handle handle) 
			{ return Internal::mesh_manager.DoesExists(handle); }
	}
	namespace Internal {
		inline void CheckMeshValidity(Mesh::Handle handle) {
#ifndef NDEBUG
			if (!Mesh::IsValid(handle))
				throw std::runtime_error("Requested mesh does not exists");
#endif
		}
		inline MeshData& GetMesh(Mesh::Handle handle) { return mesh_manager[handle]; }
		inline const MeshData& GetRoMesh(Mesh::Handle handle) 
			{ return handle == Mesh::NULL_MESH ? DEFAULT_MESH : mesh_manager[handle]; }
	}
	namespace Mesh{
		inline void SetData(Handle handle, const Vertex2D* vertices, size_t v_size, 
										   const LLJGFX::HandleType* indexes, size_t i_size) {
			Internal::CheckMeshValidity(handle);
			LLJGFX::VBuff::SetData(Internal::GetMesh(handle).data_handle, vertices, v_size);
			LLJGFX::VRef::SetIndexingData(Internal::GetMesh(handle).vref_handle, indexes, i_size);
		}
		inline void SetData(Handle handle, const std::vector<Vertex2D>& vertices, 
										   const std::vector<LLJGFX::HandleType>& indexes)
			{ SetData(handle, vertices.data(), vertices.size(), indexes.data(), indexes.size()); }

		inline std::vector<Vertex2D> GetVertexData(Handle handle) 
			{ return LLJGFX::VBuff::GetData<Vertex2D>(Internal::GetRoMesh(handle).data_handle); }
		inline std::vector<LLJGFX::HandleType> GetIndexData(Handle handle)
			{ return LLJGFX::VRef::GetIndexingData(Internal::GetRoMesh(handle).vref_handle); }
		
		inline size_t GetSize(Handle handle) 
			{ return LLJGFX::VBuff::GetSize(Internal::GetRoMesh(handle).data_handle); }
		//Somehow add other buffers (later)

		inline void Copy(Handle to, Handle from) { SetData(to, GetVertexData(from), GetIndexData(from)); }

		inline Handle Make() {
			LLJGFX::VBuff::Handle data_handle = LLJGFX::VBuff::Make();
			LLJGFX::VBuff::SetLayout(data_handle, Internal::mesh_layout);
			LLJGFX::VRef::Handle vref_handle = LLJGFX::VRef::Make({data_handle}, {});

			return Internal::mesh_manager.Add({ vref_handle, data_handle });
		}
		inline Handle Make(const Vertex2D* vertices, size_t v_size,
						   const LLJGFX::HandleType* indexes, size_t i_size) {
			Handle handle = Make(); 
			SetData(handle, vertices, v_size, indexes, i_size);
			return handle;
		}
		inline Handle Make(const std::vector<Vertex2D>& vertices, 
						   const std::vector<LLJGFX::HandleType>& indexes) {
			Handle handle = Make();
			SetData(handle, vertices, indexes);
			return handle;
		}
		inline Handle Make(Handle cpy) {
			Handle handle = Make();
			Copy(handle, cpy);
			return handle;
		}
		
		inline void Delete(Handle handle) {
			const Internal::MeshData& data = Internal::GetMesh(handle);
			LLJGFX::VBuff::Delete(data.data_handle);
			LLJGFX::VRef::Delete(data.vref_handle);

			Internal::mesh_manager.Remove(handle);
		}
	}
	namespace Internal {
		const std::vector<Mesh::Vertex2D> vertices = {
				{{0, 0}, {0, 0}}, // bottom left
				{{0, 1}, {0, 1}}, // top left
				{{1, 1}, {1, 1}}, // top right
				{{1, 0}, {1, 0}}, // bottom right
		};
		const std::vector<uint32> indices = {
				0, 1, 2,  // first Triangle
				0, 2, 3   // second Triangle
		};

		Mesh::Handle default_mesh = Mesh::NULL_MESH;// = Mesh::Make(vertices, indices);

		void InitMesh() { default_mesh = Mesh::Make(vertices, indices); }
	}
}