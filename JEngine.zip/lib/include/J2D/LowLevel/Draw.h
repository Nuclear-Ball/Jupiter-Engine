#pragma once
#include <JGFX/JGFX.h>

#include "Mesh2D.h"
#include "TransfBuff.h"
#include "Shader2D.h"

namespace LLJ2D {
	namespace Internal {
		struct TextureArg {
			std::vector<LLJGFX::TmpTextureSlotBinding> bindings;

			inline TextureArg() = default;
			inline TextureArg(const std::vector<LLJGFX::TmpTextureSlotBinding>& textures) { bindings = textures; }
			inline TextureArg(const std::initializer_list<LLJGFX::TmpTextureSlotBinding>& textures) { bindings = textures; }
			inline TextureArg(LLJGFX::Texture::Handle txt) { bindings = {{0, txt}}; }
		};
	}
	void Init() {
		Internal::InitMesh();
		Internal::InitTBuff();
	}

	glm::mat4 curr_pv;

	void Prepare() {
		bool was_dt = LLJGFX::Opt::IsActive(LLJGFX::Opt::DEPTH_TEST);
		if (was_dt)
			LLJGFX::Opt::Disable(LLJGFX::Opt::DEPTH_TEST);
		bool was_bl = LLJGFX::Opt::IsActive(LLJGFX::Opt::BLEND);
		if (!was_bl)
			LLJGFX::Opt::Enable(LLJGFX::Opt::BLEND);
	}

	inline void Draw(Mesh::Handle mesh, TransfBuff::Handle transforms, 
						Internal::TextureArg textures = {},
						Shader2D::Handle shader = { nullptr }) {
		if (!LLJ2D::Shader2D::IsValid(Internal::bound_2d_shader))
			Internal::bound_2d_shader = Internal::default_shader;

		const Shader2D::Handle curr_sh = shader.data == nullptr ? Internal::bound_2d_shader : shader;
		LLJ2D::Shader2D::SetPV(curr_sh, curr_pv);

		//For correct rendering the depth testing should be disabled, and blending enabled
#ifdef AUTOMATIC_PREPARE
		bool was_dt = LLJGFX::Opt::IsActive(LLJGFX::Opt::DEPTH_TEST);
		if (was_dt) 
			LLJGFX::Opt::Disable(LLJGFX::Opt::DEPTH_TEST);
		bool was_bl = LLJGFX::Opt::IsActive(LLJGFX::Opt::BLEND);
		if (!was_bl)
			LLJGFX::Opt::Enable(LLJGFX::Opt::BLEND);
#endif
			

		const Internal::MeshData& m_dat = Internal::GetMesh(mesh);
		const Internal::TransfBuffData& t_dat = Internal::GetTBuff(transforms);
		LLJGFX::VRef::AttachVBuffs(m_dat.vref_handle, { t_dat.buff, t_dat.transparency });

		LLJGFX::Draw(m_dat.vref_handle, textures.bindings, curr_sh, LLJ2D::TransfBuff::GetSize(transforms));

		LLJGFX::VRef::DetachVBuff(m_dat.vref_handle, t_dat.buff);
		LLJGFX::VRef::DetachVBuff(m_dat.vref_handle, t_dat.transparency);

#ifdef AUTOMATIC_PREPARE
		if (was_dt) LLJGFX::Opt::Enable(LLJGFX::Opt::DEPTH_TEST);
		if (was_bl) LLJGFX::Opt::Disable(LLJGFX::Opt::BLEND);
#endif
	}
	inline void Draw(TransfBuff::Handle transforms,
						Internal::TextureArg textures = {},
						Shader2D::Handle shader = { nullptr }) 
		{ Draw(Internal::default_mesh, transforms, textures, shader); }

	inline void Draw(Mesh::Handle mesh, const glm::mat4& transform, fl32 transparency = 0.f,
						Internal::TextureArg textures = {},
						Shader2D::Handle shader = { nullptr }) { 
		TransfBuff::SetData(Internal::default_tbuff, transform);
		TransfBuff::SetTransparency(Internal::default_tbuff, transparency);
		Draw(mesh, Internal::default_tbuff, textures, shader); 
	}
	inline void Draw(const glm::mat4& transform, fl32 transparency = 0.f,
						Internal::TextureArg textures = {},
						Shader2D::Handle shader = { nullptr }) {
		TransfBuff::SetData(Internal::default_tbuff, transform);
		TransfBuff::SetTransparency(Internal::default_tbuff, transparency);
		Draw(Internal::default_mesh, Internal::default_tbuff, textures, shader);
	}

	inline void Draw(Mesh::Handle mesh, const std::vector<glm::mat4>& transforms, const std::vector<fl32>& transparency = {},
		Internal::TextureArg textures = {},
		Shader2D::Handle shader = { nullptr }) {
		TransfBuff::SetData(Internal::default_tbuff, transforms);
		TransfBuff::SetTransparency(Internal::default_tbuff, transparency);
		Draw(mesh, Internal::default_tbuff, textures, shader);
	}
	inline void Draw(const std::vector<glm::mat4>& transforms, const std::vector<fl32>& transparency = {},
		Internal::TextureArg textures = {},
		Shader2D::Handle shader = { nullptr }) {
		TransfBuff::SetData(Internal::default_tbuff, transforms);
		TransfBuff::SetTransparency(Internal::default_tbuff, transparency);
		Draw(Internal::default_mesh, Internal::default_tbuff, textures, shader);
	}

	inline void DisplayFramebuffer(LLJGFX::Texture::Handle fbuff) 
		{ JGFX::Draw(Internal::default_mesh.data->vref_handle, fbuff, Internal::fb_shader); }

	void DisplayFramebuffer(LLJGFX::Texture::Handle fbuff, LLJGFX::Window::Handle target) {
		const LLJGFX::Window::Handle old_ctx = { LLJGFX::Internal::curr_context };
		const LLJGFX::Texture::Handle old_fb = LLJGFX::Internal::bound_framebuffer_texture;

		LLJGFX::BindFramebuffer(target);

		DisplayFramebuffer(fbuff);

		if (old_fb.data != nullptr)
			LLJGFX::BindFramebuffer(old_fb);
		else
			LLJGFX::BindFramebuffer(old_ctx);
	}
	void DisplayFramebuffer(LLJGFX::Texture::Handle fbuff, LLJGFX::Texture::Handle target) {
		const LLJGFX::Window::Handle old_ctx = { LLJGFX::Internal::curr_context };
		const LLJGFX::Texture::Handle old_fb = LLJGFX::Internal::bound_framebuffer_texture;

		LLJGFX::BindFramebuffer(target);

		DisplayFramebuffer(fbuff);

		if (old_fb.data != nullptr)
			LLJGFX::BindFramebuffer(old_fb);
		else
			LLJGFX::BindFramebuffer(old_ctx);
	}
}
