#pragma once
#include <JGFX/JGFX.h>

namespace LLJ2D{
	namespace Shader2D {
		using LLJGFX::ShaderProgram::Handle;
		using LLJGFX::ShaderProgram::IsValid;
		using LLJGFX::ShaderProgram::Compile;
		using LLJGFX::ShaderProgram::SetUniform;

		inline void SetPV(Handle handle, const glm::mat4& pv){ SetUniform(handle, "pv", pv); }

		using LLJGFX::ShaderProgram::GetAttachedFragmentShader;
		using LLJGFX::ShaderProgram::GetAttachedVertexShader;
		using LLJGFX::ShaderProgram::Make;
		using LLJGFX::ShaderProgram::Delete;
	}

	namespace Internal {
		const std::string default_vs = 
			"#version 330 core\n"

			"layout(location = 0) in vec2 v_pos;\n"
			"layout(location = 1) in vec2 v_uv;\n"
			"layout(location = 2) in mat4 instance_mat;\n"

			"layout(location = 6) in float instance_transparency;\n"

			"uniform mat4 pv;\n"

			"out vec2 TexCoord;\n"
			"out float transparency;\n"

			"void main(){\n"
			"    gl_Position = pv * instance_mat * vec4(v_pos, 0.0, 1.0);\n"
			"    TexCoord = v_pos;\n"
			"    transparency = instance_transparency;\n"
			"}";


		const std::string default_fs = 
			"#version 330 core\n"

			"out vec4 FragColor;\n"
			"in vec2 TexCoord;\n"
			"in float transparency;\n"

			"uniform sampler2D ourTexture;\n"

			"void main(){\n"
			"    vec4 color = texture(ourTexture, vec2(TexCoord.x, 1.f - TexCoord.y));\n"
			"    FragColor = vec4(color.rgb, color.a - transparency);\n"
			"}";

		const Shader2D::Handle default_shader = Shader2D::Make(default_vs, default_fs);

		const std::string fb_shader_v = "#version 330 core\n"
			"layout(location = 0) in vec2 aPos;\n"
			"out vec2 TexCoord;\n"
			"void main() {\n"
			"    gl_Position = vec4((aPos.x - 0.5) * 2, (aPos.y - 0.5) * 2, 0.0, 1.0);\n"
			"    TexCoord = aPos;\n"
			"}";
		const std::string fb_shader_f = "#version 330 core\n"

			"out vec4 FragColor;\n"
			"in vec2 TexCoord;\n"

			"uniform float transparency;\n"
			"uniform sampler2D ourTexture;\n"

			"void main(){\n"
			"    vec4 color = texture(ourTexture, TexCoord);\n"
			"    FragColor = vec4(color.rgb, color.a - transparency);\n"
			"}";
		LLJGFX::ShaderProgram::Handle fb_shader = LLJGFX::ShaderProgram::Make(fb_shader_v, fb_shader_f);

		Shader2D::Handle bound_2d_shader = default_shader;
	}
	namespace Shader2D {
		void Bind(Handle handle) {
			LLJGFX::ShaderProgram::Bind(handle);
			Internal::bound_2d_shader = handle;
		}
	}
}