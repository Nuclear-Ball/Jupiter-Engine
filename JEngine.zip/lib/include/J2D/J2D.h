#pragma once
#include "LowLevel/Draw.h"
#include "Camera.h"
#include "Mesh2D.h"
#include "Shader2D.h"
#include "TransfBuff.h"

namespace J2D {
	struct TxtFuncArg : public LLJ2D::Internal::TextureArg{
		using LLJ2D::Internal::TextureArg::TextureArg;

		inline TxtFuncArg(const JGFX::Texture& txt) { bindings = { {0, txt.handle()}}; }
		inline TxtFuncArg(const std::vector<JGFX::Internal::TextureSlotBinding>& oo_bindings) 
			{ bindings.resize(oo_bindings.size()); memcpy(bindings.data(), oo_bindings.data(), oo_bindings.size() * sizeof(JGFX::Internal::TextureSlotBinding)); }
	};

	using LLJ2D::Prepare;

	inline void Draw(MeshFuncArg mesh, TBuffFuncArg transformations, TxtFuncArg textures = {}, JGFX::Internal::ShHandleArgumentWrapper shader = {}) 
		{ LLJ2D::Draw(mesh, transformations, textures, shader); }
	inline void Draw(TBuffFuncArg transformations, TxtFuncArg textures = {}, JGFX::Internal::ShHandleArgumentWrapper shader = {})
		{ LLJ2D::Draw(transformations, textures, shader); }

	inline void Draw(MeshFuncArg mesh, glm::mat4 transform, fl32 transparency = 0.f, TxtFuncArg textures = {}, JGFX::Internal::ShHandleArgumentWrapper shader = {})
		{ LLJ2D::Draw(mesh, transform, transparency, textures, shader); }
	inline void Draw(glm::mat4 transform, fl32 transparency = 0.f, TxtFuncArg textures = {}, JGFX::Internal::ShHandleArgumentWrapper shader = {})
		{ LLJ2D::Draw(transform, transparency, textures, shader); }

	inline void Draw(MeshFuncArg mesh, const std::vector<glm::mat4>& transforms, const std::vector<fl32>& transparency = {}, TxtFuncArg textures = {}, JGFX::Internal::ShHandleArgumentWrapper shader = {})
		{ LLJ2D::Draw(mesh, transforms, transparency, textures, shader); }
	inline void Draw(const std::vector<glm::mat4>& transforms, const std::vector<fl32>& transparency = {}, TxtFuncArg textures = {}, JGFX::Internal::ShHandleArgumentWrapper shader = {})
		{ LLJ2D::Draw(transforms, transparency, textures, shader); }

	inline void Draw(MeshFuncArg mesh, TxtFuncArg textures, pos2df64 pos, 
						const TransfProps& props = {}, fl32 transparency = 0.f,
						JGFX::Internal::ShHandleArgumentWrapper shader = {}) {
		const pos2du16 size = textures.bindings.size() ? LLJGFX::Texture::GetSize(textures.bindings[0].texture_handle) : pos2du16{ (uint16)PIXELS_PER_METER, (uint16)PIXELS_PER_METER };
		LLJ2D::Draw(mesh, props.MakeMatrix(pos, size), transparency, textures, shader);
	}
	inline void Draw(TxtFuncArg textures, pos2df64 pos, const TransfProps& props = {}, 
					 fl32 transparency = 0.f, JGFX::Internal::ShHandleArgumentWrapper shader = {}) {
		const pos2du16 size = textures.bindings.size() ? LLJGFX::Texture::GetSize(textures.bindings[0].texture_handle) : pos2du16{ (uint16)PIXELS_PER_METER, (uint16)PIXELS_PER_METER };
		LLJ2D::Draw(props.MakeMatrix(pos, size), transparency, textures, shader);
	}

	inline void DisplayFramebuffer(JGFX::Internal::TxtFnArg fbuff) 
		{ LLJ2D::DisplayFramebuffer(fbuff); }

	inline void DisplayFramebuffer(JGFX::Internal::TxtFnArg fbuff, JGFX::Internal::WinFnArg target) 
		{ LLJ2D::DisplayFramebuffer(fbuff, target); }
	inline void DisplayFramebuffer(JGFX::Internal::TxtFnArg fbuff, JGFX::Internal::TxtFnArg target)
		{ LLJ2D::DisplayFramebuffer(fbuff, target); }
}