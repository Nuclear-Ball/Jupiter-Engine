#pragma once
#include <JGFX/pos2d.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/rotate_vector.hpp>

namespace J2D {
	fl64 PIXELS_PER_METER = 16;

	inline pos2df64 ToMetric(pos2df64 pixel_pos) { return pixel_pos / PIXELS_PER_METER; }
	inline fl64 ToMetric(fl64 pixel_pos) { return pixel_pos / PIXELS_PER_METER; }

	inline pos2df64 ToPixels(pos2df64 metric_pos) { return metric_pos * PIXELS_PER_METER; }
	inline fl64 ToPixels(fl64 metric_pos) { return metric_pos * PIXELS_PER_METER; }

	/*inline glm::dmat4 RoundMatrixToPixels(const glm::dmat4& matrix) {
		glm::mat4 res = matrix;

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++)
				res[i][j] = (fl64)((int)(res[i][j] * 2500)) / 00.;
		}
		return res;
	}*/

	struct TransfProps {
		fl32 rotation = 0.0f;
		pos2df64 scale = { 1.0, 1.0 };
		pos2df64 origin = { 0,0 };

		glm::dmat4 MakeMatrix(glm::dmat4 matrix = glm::dmat4(1)) const {
			matrix = glm::rotate<fl64>(matrix, glm::radians<fl64>(rotation),
			                           {0.0f, 0.0f, 1.0f});
			matrix = glm::translate<fl64>(matrix, {-origin * scale, 0.0f});
			matrix = glm::scale<fl64>(matrix, {scale, 1.0f});

			return matrix;
		}

		inline glm::dmat4 MakeMatrixMetricSize(pos2df64 metric_size, glm::dmat4 matrix = glm::dmat4(1)) const {
			glm::dmat4 model = MakeMatrix(matrix);
			model = glm::scale<fl64>(model, { metric_size, 1. });

			return model;
		}
		inline glm::dmat4 MakeMatrixMetricSize(pos2df64 pos, pos2df64 metric_size) const {
			glm::dmat4 model = glm::translate<fl64>(glm::dmat4(1), { pos, 0. });
			model = MakeMatrixMetricSize(metric_size, model);

			return model;
		}

		inline glm::dmat4 MakeMatrix(pos2du16 texture_size, glm::dmat4 matrix = glm::dmat4(1)) const {
			glm::dmat4 model = MakeMatrix(matrix);
			model = glm::scale<fl64>(model, { (pos2df64)texture_size / PIXELS_PER_METER, 1. });

			return model;
		}
		inline glm::dmat4 MakeMatrix(pos2df64 pos, pos2du16 texture_size) const {
			glm::dmat4 model = glm::translate<fl64>(glm::dmat4(1), { pos, 0. });
			model = MakeMatrix(texture_size, model);

			return model;
		}

	};

	struct TransfProps3D {
		glm::dvec3 rotation = glm::vec3{ 0.0f };
		glm::dvec3 scale = { 1., 1., 1. };

		glm::dmat4 MakeMatrix(glm::dmat4 matrix = glm::dmat4(1)) const {
			matrix = glm::rotate<fl64>(matrix, glm::radians(rotation.x),
			                           {1., 0., 0.});
			matrix = glm::rotate<fl64>(matrix, glm::radians(rotation.y),
			                           {0., 1., 0.});
			matrix = glm::rotate<fl64>(matrix, glm::radians(rotation.z),
			                           {0., 0., 1.});

			matrix = glm::scale<fl64>(matrix, scale);

			return matrix;
		}
	};
}