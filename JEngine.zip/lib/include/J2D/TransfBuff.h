#pragma once
#include "LowLevel/TransfBuff.h"

namespace J2D {
	class TransfBuffer {
	private:
		LLJ2D::TransfBuff::Handle handle_ = LLJ2D::TransfBuff::NULL_TBUFF;

		inline void BeforeModification() {
			if (handle_ == LLJ2D::TransfBuff::NULL_TBUFF)
				handle_ = LLJ2D::TransfBuff::Make();
		}
	public:
		inline TransfBuffer& SetData(const glm::mat4* transf, size_t size) {
			BeforeModification();
			LLJ2D::TransfBuff::SetData(handle_, transf, size);
			return *this;
		}
		inline TransfBuffer& SetData(const std::vector<glm::mat4>& transf) {
			BeforeModification();
			LLJ2D::TransfBuff::SetData(handle_, transf);
			return *this;
		}
		inline TransfBuffer& SetData(const glm::mat4& transf) {
			BeforeModification();
			LLJ2D::TransfBuff::SetData(handle_, transf);
			return *this;
		}

		inline TransfBuffer& SetTransparency(const fl32* transf, size_t size) {
			BeforeModification();
			LLJ2D::TransfBuff::SetTransparency(handle_, transf, size);
			return *this;
		}
		inline TransfBuffer& SetTransparency(const std::vector<fl32>& transf) {
			BeforeModification();
			LLJ2D::TransfBuff::SetTransparency(handle_, transf);
			return *this;
		}
		inline TransfBuffer& SetTransparency(const fl32& transf) {
			BeforeModification();
			LLJ2D::TransfBuff::SetTransparency(handle_, transf);
			return *this;
		}

		inline std::vector<glm::mat4> data() const
			{ return LLJ2D::TransfBuff::GetData(handle_); }
		inline size_t size() const
			{ return LLJ2D::TransfBuff::GetSize(handle_); }

		inline std::vector<fl32> transparency_data() const
			{ return LLJ2D::TransfBuff::GetTransparency(handle_); }
		inline size_t transparency_size() const
			{ return LLJ2D::TransfBuff::GetTransparencySize(handle_); }

		inline LLJ2D::TransfBuff::Handle handle() const { return handle_; }

		inline TransfBuffer() = default;
		inline TransfBuffer(const std::vector<glm::mat4>& transf, const std::vector<fl32>& transparency = {}) { SetData(transf); SetTransparency(transparency); }
		inline TransfBuffer(const glm::mat4* transf, size_t size, const fl32* transparency = nullptr, size_t t_size = 0) { SetData(transf, size); SetTransparency(transparency, t_size); }
		inline TransfBuffer(const glm::mat4& transf, fl32 transparency) { SetData(transf); SetTransparency(transparency); }

		inline TransfBuffer& operator=(const TransfBuffer& cpy) {
			BeforeModification();
			LLJ2D::TransfBuff::Copy(handle_, cpy.handle_);
			return *this;
		}
		inline TransfBuffer(const TransfBuffer& cpy) { operator=(cpy); }

		inline TransfBuffer& operator=(TransfBuffer&& cpy) {
			this->~TransfBuffer();
			std::swap(handle_, cpy.handle_);
			return *this;
		}
		inline TransfBuffer(TransfBuffer&& cpy) { operator=(std::move(cpy)); }

		~TransfBuffer() {
			LLJ2D::TransfBuff::Delete(handle_);
			handle_ = LLJ2D::TransfBuff::NULL_TBUFF;
		}
	};

	struct TBuffFuncArg : public LLJ2D::TransfBuff::Handle {
		inline TBuffFuncArg() = default;
		inline TBuffFuncArg(LLJ2D::TransfBuff::Handle handle) { data = handle.data; }
		inline TBuffFuncArg(const TransfBuffer& obj) { data = obj.handle().data; }
	};
}