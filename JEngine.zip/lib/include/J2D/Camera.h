#pragma once
#include <JGFX/JGFX.h>
#include <array>
#include <algorithm>

#include <JGFX/JGFX.h>
#include "Transformations.h"

namespace J2D {
	struct ViewRange {
		pos2df64 max = {};
		pos2df64 min = {};
	};

	pos2df64 ScreenCoordsToGlobal(pos2df64 pos, fl64 screen_height, const glm::dmat4& view) {
		const glm::dvec4 res = view / glm::dvec4(pos.x, screen_height - pos.y, 1.f, 1.f);
		return { res.x, res.y };
	}

	inline ViewRange ViewRangeFromMat(pos2df64 metric_screen_size, const glm::mat4& view) {
		const pos2df64 upper_left =  ScreenCoordsToGlobal({ 0,                    0                    }, metric_screen_size.y, view);
		const pos2df64 lower_left =  ScreenCoordsToGlobal({ 0,                    metric_screen_size.y }, metric_screen_size.y, view);
		const pos2df64 lower_right = ScreenCoordsToGlobal({ metric_screen_size.x, metric_screen_size.y }, metric_screen_size.y, view);
		const pos2df64 upper_right = ScreenCoordsToGlobal({ metric_screen_size.x, 0                    }, metric_screen_size.y, view);

		const pos2df64 range_max = { std::max({upper_left.x, lower_left.x, lower_right.x, upper_right.x }),
									std::max({upper_left.y, lower_left.y, lower_right.y, upper_right.y }) };
		const pos2df64 range_min = { std::min({upper_left.x, lower_left.x, lower_right.x, upper_right.x }),
									std::min({upper_left.y, lower_left.y, lower_right.y, upper_right.y }) };

		return { range_max, range_min };
	}

	class TransparentCam2D {
	public:
		pos2df64 center_pos = { 0, 0 };
		TransfProps props;

		inline TransparentCam2D(pos2df64 c_pos = { 0., 0. }, TransfProps pr = {}) {
			center_pos = c_pos;
			props = pr;
		}

		pos2du16 size() const {
			if (LLJGFX::Internal::bound_framebuffer_texture.data != nullptr)
				return LLJGFX::Texture::GetSize({ LLJGFX::Internal::bound_framebuffer_texture.data });
			else if (LLJGFX::Internal::curr_context != nullptr)
				return LLJGFX::Window::GetSize({ LLJGFX::Internal::curr_context });
			
			//to silence the warning
			return { 0,0 };
		}

		inline pos2df64 metric_size() const { return (pos2df64)size() / PIXELS_PER_METER; }

		inline glm::dmat4 MakeViewMatrix() const {
			glm::dmat4 view = props.MakeMatrix(
								glm::translate<fl64>(glm::dmat4{ 1 },
									{ metric_size() / 2. + props.origin, 0. }));
			view = glm::translate<fl64>(view, { -center_pos + props.origin, 0. });
			return view;
		}
		inline glm::dmat4 MakePV() const {
			const pos2df64 c_metric_size = metric_size();
			return glm::ortho<fl64>(0, c_metric_size.x, 0, c_metric_size.y, 100, -100) * MakeViewMatrix();
		}

		inline pos2df64 ScreenCoordsToAbs(pos2df64 pos) const { return ScreenCoordsToGlobal(pos, metric_size().y, MakeViewMatrix()); }
		inline ViewRange ViewRange() const { return ViewRangeFromMat(metric_size(), MakeViewMatrix()); }

		inline void Bind() const { LLJ2D::curr_pv = MakePV(); }
	};

	class Cam2D {
	public:
		JGFX::Texture frm;
		pos2df64 center_pos = { 0, 0 };
		TransfProps props;

		inline Cam2D(pos2du16 size, pos2df64 c_pos = { 0., 0. }, TransfProps pr = {}){
			frm = {size};
			center_pos = c_pos;
			props = pr;
		}

		inline pos2du16 size() const { return frm.size(); }
		inline pos2df64 metric_size() const { return ToMetric(size()); }

		inline glm::dmat4 MakeViewMatrix() const {
			glm::dmat4 view = props.MakeMatrix(
				glm::translate<fl64>(glm::dmat4{1},
						{ metric_size() / 2. + props.origin, 0.}));
			view = glm::translate<fl64>(view, { -center_pos + props.origin, 0. });
			return view;
		}
		inline glm::dmat4 MakeProjectionMatrix() const {
			const pos2df64 c_metric_size = metric_size();
			return glm::ortho<fl64>(0, c_metric_size.x, 0, c_metric_size.y, 100, -100);
		}
		inline glm::dmat4 MakePV() const {
			return MakeProjectionMatrix() * MakeViewMatrix();
		}

		inline pos2df64 ScreenCoordsToAbs(pos2df64 pos) const { return ScreenCoordsToGlobal(pos, metric_size().y, MakeViewMatrix()); }
		inline ViewRange ViewRange() const { return ViewRangeFromMat(metric_size(), MakeViewMatrix()); }

		inline void Bind() const {
			LLJ2D::curr_pv = MakePV();
			frm.Bind();
		}
	};
	class MetricCam2D {
	public:
		JGFX::Texture frm;
		pos2df64 center_pos = { 0, 0 };
		pos2df64 metric_size = { 0,0 };
		TransfProps props;

		inline MetricCam2D(pos2du16 buffer_size, pos2df64 metric_size, pos2df64 c_pos = { 0., 0. }, TransfProps pr = {}) {
			frm = { buffer_size };
			this->metric_size = metric_size;
			center_pos = c_pos;
			props = pr;
		}

		inline pos2du16 size() const { return frm.size(); }

		inline glm::dmat4 MakeViewMatrix() const {
			glm::dmat4 view = props.MakeMatrix(
				glm::translate<fl64>(glm::dmat4{ 1 },
					{ metric_size / 2. + props.origin, 0. }));
			view = glm::translate<fl64>(view, { -center_pos + props.origin, 0. });
			return view;
		}
		inline glm::dmat4 MakeProjectionMatrix() const {
			const pos2df64 c_metric_size = metric_size;
			return glm::ortho<fl64>(0, c_metric_size.x, 0, c_metric_size.y, 100, -100);
		}
		inline glm::dmat4 MakePV() const {
			return MakeProjectionMatrix() * MakeViewMatrix();
		}

		inline pos2df64 ScreenCoordsToAbs(pos2df64 pos) const { return ScreenCoordsToGlobal(pos, metric_size.y, MakeViewMatrix()); }
		inline ViewRange ViewRange() const { return ViewRangeFromMat(metric_size, MakeViewMatrix()); }

		inline void Bind() const {
			LLJ2D::curr_pv = MakePV();
			frm.Bind();
		}
	};
}