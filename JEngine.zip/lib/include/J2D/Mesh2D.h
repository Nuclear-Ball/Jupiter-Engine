#pragma once
#include "LowLevel/Mesh2D.h"

namespace J2D {
	using LLJ2D::Mesh::Vertex2D;

	class Mesh2D {
	private:
		LLJ2D::Mesh::Handle handle_ = LLJ2D::Mesh::NULL_MESH;

		inline void BeforeModification() {
			if (handle_ == LLJ2D::Mesh::NULL_MESH)
				handle_ = LLJ2D::Mesh::Make();
		}
	public:
		inline Mesh2D& SetVertexData(const Vertex2D* vertices, size_t v_size, 
									 const LLJGFX::HandleType* indexes, size_t i_size) {
			BeforeModification();
			LLJ2D::Mesh::SetData(handle_, vertices, v_size, indexes, i_size);
			return *this;
		}
		inline Mesh2D& SetVertexData(const std::vector<Vertex2D>& vertices, 
									 const std::vector<LLJGFX::HandleType>& indexes) {
			BeforeModification();
			LLJ2D::Mesh::SetData(handle_, vertices, indexes);
			return *this;
		}

		inline std::vector<Vertex2D> data() const { return LLJ2D::Mesh::GetVertexData(handle_); }
		inline std::vector<LLJGFX::HandleType> indexing_data() const { return LLJ2D::Mesh::GetIndexData(handle_); }
		inline size_t size() const { return LLJ2D::Mesh::GetSize(handle_); }
		inline size_t indexing_size() const { return LLJ2D::Mesh::GetSize(handle_); }
		inline LLJ2D::Mesh::Handle handle() const { return handle_; }

		inline Mesh2D() = default;
		inline Mesh2D(const Vertex2D* vertices, size_t v_size, 
					  const LLJGFX::HandleType* indexes, size_t i_size) 
			{ SetVertexData(vertices, v_size, indexes, i_size); }
		inline Mesh2D(const std::vector<Vertex2D>& vertices, 
					  const std::vector<LLJGFX::HandleType>& indexes) 
			{ SetVertexData(vertices, indexes); }

		inline Mesh2D& operator=(const Mesh2D& cpy) {
			LLJ2D::Mesh::Copy(handle_, cpy.handle_);
			return *this;
		}
		inline Mesh2D(const Mesh2D& cpy) { operator=(cpy); }

		inline Mesh2D& operator=(Mesh2D&& cpy) {
			this->~Mesh2D();
			std::swap(handle_, cpy.handle_);
			return *this;
		}
		inline Mesh2D(Mesh2D&& cpy) { operator=(std::move(cpy)); }

		inline ~Mesh2D() {
			LLJ2D::Mesh::Delete(handle_);
			handle_ = LLJ2D::Mesh::NULL_MESH;
		}
	};

	struct MeshFuncArg : public LLJ2D::Mesh::Handle {
		inline MeshFuncArg() = default;
		inline MeshFuncArg(LLJ2D::Mesh::Handle handle) { data = handle.data; }
		inline MeshFuncArg(const Mesh2D& obj) { data = obj.handle().data; }
	};
}