#pragma once
#include "LowLevel/Shader2D.h"

namespace J2D {
	class Shader2D : public JGFX::ShaderProgram {
		Shader2D& SetPV(const glm::mat4& pv) { LLJ2D::Shader2D::SetPV(handle(), pv); return *this; }
		const Shader2D& SetPV(const glm::mat4& pv) const { LLJ2D::Shader2D::SetPV(handle(), pv); return *this; }
		Shader2D& Bind()  {
			LLJ2D::Shader2D::Bind(handle());
			return *this;
		}
	};
}