#pragma once
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <stdexcept>

namespace JE {
	template<typename T> struct MHandle {
		T* data;

		inline bool operator==(const MHandle<T>& oth) const { return data == oth.data; }
	};
}
namespace std {
	template <typename D> struct hash<JE::MHandle<D>> {
		inline constexpr size_t operator()(const JE::MHandle<D>& handle) const { return (size_t)handle.data; }
	};
}
/*
namespace JE {
	template<typename T> struct VHandle {
		uint16 handle;

		inline bool operator==(const VHandle<T>& oth) const { return handle == oth.handle; }
	};
}
namespace std {
	template <typename D> struct hash<JE::VHandle<D>> {
		inline constexpr size_t operator()(const JE::VHandle<D>& handle) const { return (size_t)handle.handle; }
	};
}*/

namespace JE {
	template <typename T> class Manager {
	private:
		std::unordered_map<std::string, MHandle<T>> handle_by_name;
		std::unordered_map<MHandle<T>, std::string> name_by_handle;

		std::string SaveName(const std::string& orig_name) {
			std::string save_name = orig_name;

			for (int i = 1; DoesExists(save_name); i++)
				save_name = (orig_name + " (" + std::to_string(i) + ")");

			return save_name;
		}

	public:
		inline bool DoesExists(MHandle<T> handle) const { return name_by_handle.contains(handle); }
		inline bool DoesExists(const std::string& name) const { return handle_by_name.contains(name); }

		inline MHandle<T> GetHandle(const std::string& name) const {
#ifndef NDEBUG
			if (!DoesExists(name))
				throw std::runtime_error("Requested by name object does not exists");
#endif
			return handle_by_name.find(name)->second;
		}
		inline std::string GetName(MHandle<T> handle) const {
#ifndef NDEBUG
			if (!DoesExists(handle))
				throw std::runtime_error("Requested object does not exists");
#endif

			return name_by_handle.find(handle)->second;
		}

		inline T& Get(MHandle<T> handle) {
#ifndef NDEBUG
			if (!DoesExists(handle))
				throw std::runtime_error("Requested object does not exists");
#endif
			return *handle.data;
		}
		inline T& Get(const std::string& name) { return Get(GetHandle(name)); }
		inline const T& Get(MHandle<T> handle) const {
#ifndef NDEBUG
			if (!DoesExists(handle))
				throw std::runtime_error("Requested object does not exists");
#endif
			return *handle.data;
		}
		inline const T& Get(const std::string& name) const { return Get(GetHandle(name)); }

		inline T& operator[](MHandle<T> handle) { return Get(handle); }
		inline T& operator[](const std::string& name) { return Get(name); }

		MHandle<T> Add(T&& obj, const std::string& name) {
			const std::string save_name = SaveName(name);

			const MHandle<T> ret = { new T{std::move(obj)} };

			handle_by_name[save_name] = ret;
			name_by_handle[ret] = save_name;

			return ret;
		}
		inline MHandle<T> Add(const T& obj, const std::string& name) {
			T tmp = obj;
			return Add(std::move(tmp), name);
		}

		inline Manager& Remove(MHandle<T> handle) {
#ifndef NDEBUG
			if (!DoesExists(handle))
				throw std::runtime_error("Requested object does not exists");
#endif

			handle_by_name.erase(GetName(handle));
			name_by_handle.erase(handle);

			delete handle.data;
			return *this;
		}
		inline Manager& Remove(const std::string& name) { Remove(GetHandle(name)); }

		Manager& Rename(MHandle<T> handle, const std::string& new_name) {
#ifndef NDEBUG
			if (!DoesExists(handle))
				throw std::runtime_error("Requested object does not exists");
#endif

			handle_by_name.erase(GetName(handle));
			const std::string checked_new_name = SaveName(new_name);

			handle_by_name[checked_new_name] = handle;
			name_by_handle[handle] = checked_new_name;

			return *this;
		}
		Manager& Rename(const std::string& old_name, const std::string& new_name) {
			Rename(GetHandle(old_name), new_name);
			return *this;
		}

		inline size_t size() const { return handle_by_name.size(); }

		Manager() = default;

		Manager(const Manager& cpy) = delete;
		Manager& operator=(const Manager& cpy) = delete;

		Manager(Manager&& cpy) = default;
		Manager& operator=(Manager&& cpy) = default;

		~Manager() {
			for (const auto& i : handle_by_name)
				delete i.second.data;

			handle_by_name.clear();
			name_by_handle.clear();
		}
	};
	template <typename T> class AnonymousManager {
	private:
		std::unordered_set<MHandle<T>> all_handles;
	public:
		volatile uint8_t dummy_for_initialization = 25;

		inline bool DoesExists(MHandle<T> handle) const { return all_handles.contains(handle); }

		MHandle<T> Add(T&& obj) {
			const MHandle<T> ret = { new T{std::move(obj)} };
			all_handles.insert(ret);

			return ret;
		}
		MHandle<T> Add(const T& obj) {
			T tmp = obj;
			return Add(std::move(tmp));
		}
		inline AnonymousManager& Remove(MHandle<T> handle) {
			if (!DoesExists(handle))
				return *this;
				//throw std::runtime_error("Requested object does not exists");

			all_handles.erase(handle);
			delete handle.data;
			return *this;
		}

		inline T& Get(MHandle<T> handle) {
#ifndef NDEBUG
			if (!DoesExists(handle))
				throw std::runtime_error("Requested object does not exists");
#endif
			return *handle.data;
		}

		inline T& operator[](MHandle<T> handle) { return Get(handle); }

		inline size_t size() const { return all_handles.size(); }
		inline const std::unordered_set<MHandle<T>>& raw_data() const { return all_handles; }


		AnonymousManager() = default;

		AnonymousManager(const AnonymousManager& cpy) = delete;
		AnonymousManager& operator=(const AnonymousManager& cpy) = delete;

		AnonymousManager(AnonymousManager&& cpy) = default;
		AnonymousManager& operator=(AnonymousManager&& cpy) = default;

		~AnonymousManager() {
			for (const MHandle<T>& i : all_handles)
				delete i.data;
			all_handles.clear();
		}
	};

	template <typename T> class NoInitAnonymousManager {
	private:
		std::unordered_set<MHandle<T>>* all_handles;
	public:
		inline bool DoesExists(MHandle<T> handle) const { return all_handles->contains(handle); }

		MHandle<T> Add(T&& obj) {
			const MHandle<T> ret = { new T{std::move(obj)} };
			all_handles->insert(ret);

			return ret;
		}
		MHandle<T> Add(const T& obj) {
			T tmp = obj;
			return Add(std::move(tmp));
		}
		inline NoInitAnonymousManager& Remove(MHandle<T> handle) {
			if (!DoesExists(handle))
				return *this;
			//throw std::runtime_error("Requested object does not exists");

			all_handles->erase(handle);
			delete handle.data;
			return *this;
		}

		inline T& Get(MHandle<T> handle) {
#ifndef NDEBUG
			if (!DoesExists(handle))
				throw std::runtime_error("Requested object does not exists");
#endif
			return *handle.data;
		}

		inline T& operator[](MHandle<T> handle) { return Get(handle); }

		inline size_t size() const { return all_handles->size(); }
		inline const std::unordered_set<MHandle<T>>& raw_data() const { return *all_handles; }

		void Init() {
			all_handles = new std::unordered_set<MHandle<T>>{};
		}

		NoInitAnonymousManager() {
			//fmt::println("Created manager for type: {}", typeid(T).name());
		}

		NoInitAnonymousManager(const NoInitAnonymousManager& cpy) = delete;
		NoInitAnonymousManager& operator=(const NoInitAnonymousManager& cpy) = delete;

		NoInitAnonymousManager(NoInitAnonymousManager&& cpy) = default;
		NoInitAnonymousManager& operator=(NoInitAnonymousManager&& cpy) = default;

		~NoInitAnonymousManager() {
			for (const MHandle<T>& i : *all_handles)
				delete i.data;
			//all_handles->clear();

			delete all_handles;
		}
	};
	/*
	template <typename T> class ValueManager {
	private:
		size_t last_handle = 0;
		std::unordered_map<VHandle<T>, T> all_handles;
	public:
		inline bool DoesExists(VHandle<T> handle) const { return all_handles.contains(handle); }

		inline ValueManager& ForceAdd(T&& obj, VHandle<T> handle) {
			all_handles[handle] = std::move(obj);
			return *this;
		}
		inline ValueManager& ForceAdd(const T& obj, VHandle<T> handle) {
			T tmp = obj;
			return ForceAdd(std::move(tmp), handle);
		}

		inline VHandle<T> Add(T&& obj) {
			const VHandle<T> ret = { last_handle++ };
			ForceAdd(std::move(obj), ret);

			return ret;
		}
		inline VHandle<T> Add(const T& obj) {
			T tmp = obj;
			return Add(std::move(tmp));
		}

		inline ValueManager& Remove(VHandle<T> handle) {
#ifndef NDEBUG
			if (!DoesExists(handle))
				throw std::runtime_error("Requested object does not exists");
#endif

			all_handles.erase(handle);
			return *this;
		}

		inline T& Get(VHandle<T> handle) {
#ifndef NDEBUG
			if (!DoesExists(handle))
				throw std::runtime_error("Requested object does not exists");
#endif
			return all_handles[handle];
		}

		inline T& operator[](VHandle<T> handle) { return Get(handle); }

		inline size_t size() const { return all_handles.size(); }

		ValueManager() = default;

		ValueManager(const ValueManager& cpy) = default;
		ValueManager& operator=(const ValueManager& cpy) = default;

		ValueManager(ValueManager&& cpy) = default;
		ValueManager& operator=(ValueManager&& cpy) = default;

		inline ~ValueManager() {
			all_handles.clear();
			last_handle = 0;
		}
	};*/
}