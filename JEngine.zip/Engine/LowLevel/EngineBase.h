#pragma once
#include <JupiterUtils.h>
#include <JGFX/JGFX.h>
#include <J2D/J2D.h>
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/hash.hpp>

namespace LLJE {
	struct EngineContext {
		J2D::Cam2D* cam = nullptr;
		glm::dmat4 base_layer_mat = {};
		glm::dmat4 global_pv = {};
		glm::dmat4 layer_pv = {};
		//glm::dmat4 active_pv = {};

		J2D::ViewRange global_view_range = {};
		J2D::ViewRange layer_view_range = {};
	};
}