#pragma once
#include <JGFX/JGFX.h>
#include <J2D/J2D.h>
#include "EngineBase.h"

namespace LLJE {
	namespace Internal {
		const std::string je_vertex_shader_source =
			"#version 330 core\n"

			"layout(location = 0) in vec2 v_pos;\n"
			"layout(location = 1) in vec2 v_uv;\n"
			"layout(location = 2) in mat4 instance_mat;\n"

			"layout(location = 6) in float instance_transparency;\n"

			"uniform mat4 pv;\n"
			"uniform mat4 base_transform;\n"
			"uniform float base_transparency;\n"

			"out vec2 TexCoord;\n"
			"out float transparency;\n"

			"void main(){\n"
			"    gl_Position = pv * instance_mat * base_transform * vec4(v_pos, 0.0, 1.0);\n"
			"    TexCoord = v_pos;\n"
			"    transparency = base_transparency + instance_transparency;\n"
			"}";
		const std::string je_fragment_shader_source = LLJ2D::Internal::default_fs;
		LLJ2D::Shader2D::Handle je_default_shader = LLJ2D::Shader2D::Make(je_vertex_shader_source, je_fragment_shader_source);

		const std::string sprite_shader_vertex_source =
			"#version 330 core\n"

			"layout(location = 0) in vec2 v_pos;\n"
			"layout(location = 1) in vec2 v_uv;\n"

			"uniform mat4 precomputed_mat;\n"
			"uniform float base_transparency;\n"

			"out vec2 TexCoord;\n"
			"out float transparency;\n"

			"void main(){\n"
			"    gl_Position = precomputed_mat * vec4(v_pos, 0.0, 1.0);\n"
			"    TexCoord = v_pos;\n"
			"    transparency = base_transparency;\n"
			"}";
		const std::string sprite_shader_fragment_source = LLJ2D::Internal::default_fs;
		LLJ2D::Shader2D::Handle sprite_shader = LLJ2D::Shader2D::Make(sprite_shader_vertex_source, sprite_shader_fragment_source);
	}
	void DrawSprite(JGFX::Internal::TxtFnArg txt, pos2df64 pos, const EngineContext& ctx, const J2D::TransfProps& props = {}, fl32 transparency = 0) {
		const auto c_mat = (glm::mat4)(ctx.layer_pv * props.MakeMatrix(pos, LLJGFX::Texture::GetSize(txt)));
		LLJ2D::Shader2D::SetUniform(Internal::sprite_shader, "precomputed_mat", c_mat);
		LLJ2D::Shader2D::SetUniform(Internal::sprite_shader, "base_transparency", transparency);

		LLJGFX::Draw(LLJ2D::Internal::default_mesh.data->vref_handle, {{0, txt}}, Internal::sprite_shader);
	}
	void DrawSpriteMetric(JGFX::Internal::TxtFnArg txt, pos2df32 metric_size, pos2df64 pos, const EngineContext& ctx, const J2D::TransfProps& props = {}, fl32 transparency = 0) {
		if (txt.data != nullptr) {
			const auto c_mat = (glm::mat4)(ctx.layer_pv * props.MakeMatrixMetricSize(pos, metric_size));
			LLJ2D::Shader2D::SetUniform(Internal::sprite_shader, "precomputed_mat", c_mat);
			LLJ2D::Shader2D::SetUniform(Internal::sprite_shader, "base_transparency", transparency);

			LLJGFX::Draw(LLJ2D::Internal::default_mesh.data->vref_handle, { {0, txt} }, Internal::sprite_shader);
		}
	}
	pos2df64 RoundToPixels(pos2df64 src_pos) {
		return J2D::ToMetric(glm::round(J2D::ToPixels(src_pos))) + pos2df64{ 0.001 };
	}

	namespace Renderer {
		/*struct LLDrawListData {
			LLJ2D::TransfBuff::Handle transforms = LLJ2D::TransfBuff::NULL_TBUFF;
			LLJGFX::Texture::Handle texture = { nullptr };

			glm::mat4 base_transform = glm::mat4(1);
			fl32 base_transparency = 0.f;
		};

		//New API: chunks are now responsible for rendering themselves

		//struct NewDrawListElem {
		//	LLJGFX::VRef::Handle mesh;
		//	LLJGFX::ShaderProgram::Handle shader;
		//	std::vector<TmpTextureSlotBinding> texture_bindings

		//};

		void RenderDrawList(const LLDrawListData& draw_list) {
			LLJ2D::Shader2D::SetUniform(Internal::je_default_shader, "base_transform", draw_list.base_transform);
			LLJ2D::Shader2D::SetUniform(Internal::je_default_shader, "base_transparency", draw_list.base_transparency);
			LLJ2D::Draw(draw_list.transforms, draw_list.texture, Internal::je_default_shader);
		}*/
	}
}