#pragma once
#include <JGFX/JGFX.h>
#include <J2D/J2D.h>
#include <JupiterUtils.h>

//#include "ChunkMap.h"
#include "Scene.h"
#include "EngineBase.h"
//#include "Renderer.h"
#include <fmt/core.h>

JGFX::Texture marker = { "../../Engine/DebugMarker.png" };

namespace LLJE {
	void Render(J2D::Cam2D& dest, Scene::Handle scene, void* additional_data = nullptr, size_t type_hash = 0) {
		const glm::mat4 old_pv = LLJ2D::curr_pv;
		//LLJGFX::DrawTo
		ScenePreset::TryCallUpdate(Scene::GetPreset(scene), scene, dest, additional_data, type_hash);
		EngineContext ctx = { .cam = &dest, .global_pv = dest.MakePV(), .global_view_range = dest.ViewRange() };
		dest.Bind();
		J2D::Prepare();
		const std::vector<Layer::Handle>& layers = Scene::ListLayers(scene);
		JGFX::Clear(Scene::GetBackgroundColor(scene));
		
		for (Layer::Handle c_layer : layers) {
			assert(Layer::IsValid(c_layer));

			ctx.base_layer_mat = Layer::GetBaseTransform(c_layer, dest);
			ctx.layer_view_range = J2D::ViewRangeFromMat(dest.metric_size(), dest.MakeViewMatrix() * ctx.base_layer_mat);
			ctx.layer_pv = ctx.global_pv * ctx.base_layer_mat;

			LayerPreset::GetData(Layer::GetPreset(c_layer)).UpdateLayer(c_layer, ctx);
		}

		//Rebind everything back
		LLJ2D::curr_pv = old_pv;
	}
	/*
	//WARNING: UNSAFE AND TEMPORARY
	void DrawLayer(J2D::Cam2D& dest, Layer::Handle layer) {
		const glm::mat4 old_pv = LLJ2D::curr_pv;

		dest.Bind();
		J2D::Prepare();

		LLJE::Scene::Handle scene = LLJE::Layer::GetParentScene(layer);
		JGFX::Clear(Scene::GetBackgroundColor(scene));

		const auto view_range = dest.ViewRange();
		const glm::dmat4 base_mat = dest.MakeViewMatrix();

		const auto& layer_dat = Layer::GetEditableLayerSettings(layer);

		if (layer_dat.is_visible && Layer::Advanced::GetPreset(layer) != LayerPreset::NULL_PRESET) {
			const glm::dmat4 base_layer_transform = Layer::GetBaseTransform(layer, dest);
			const glm::dmat4 layer_mat = base_mat * base_layer_transform;
			//LLJ2D::curr_pv = dest.MakeProjectionMatrix() * layer_mat;

			const auto src_layer_view_range = J2D::ViewRangeFromMat(dest.metric_size(), dest.MakeViewMatrix() * base_layer_transform);
			const pos2df64 max_layer_view_range = src_layer_view_range.max + layer_dat.upper_view_range_extension;
			const pos2df64 min_layer_view_range = src_layer_view_range.min - layer_dat.lower_view_range_extension;

			//tmap rendering
			{
				//const ChunkMap::Handle c_tmap = Layer::GetTmap(c_layer);
				const pos2du16 chunk_size = ChunkMap::GetChunkSize(layer);

				const ::pos2d32 min_chunk_range = Convert::ChunkFromMetric(min_layer_view_range, chunk_size);
				const ::pos2d32 max_chunk_range = Convert::ChunkFromMetric(max_layer_view_range, chunk_size);

				for (int chunk_x = min_chunk_range.x; chunk_x <= max_chunk_range.x; chunk_x++) {
					for (int chunk_y = min_chunk_range.y; chunk_y <= max_chunk_range.y; chunk_y++) {
						const pos2df64 metric_chunk_pos = Convert::MetricFromChunk({ chunk_x, chunk_y }, chunk_size);
						glm::dmat4 base_chunk_mat = glm::translate(layer_mat, { metric_chunk_pos, 0 });
						LLJ2D::curr_pv = dest.MakeProjectionMatrix() * base_chunk_mat;

						auto c_drawlist = ChunkMap::GetRoDrawList(layer, { chunk_x, chunk_y });

						for (auto& c_elem : c_drawlist) {
							c_elem.base_transparency = c_elem.base_transparency + layer_dat.transparency;
							Renderer::RenderDrawList(c_elem);
						}
					}
				}
			}
		}

		//Rebind everything back
		LLJ2D::curr_pv = old_pv;
	}*/
}