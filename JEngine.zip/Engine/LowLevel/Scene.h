#pragma once
#include <JupiterUtils.h>
#include <JGFX/JGFX.h>
#include <J2D/J2D.h>
//#include "Renderer.h"
#include "EngineBase.h"
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/hash.hpp>
//#include "ChunkMap.h"

namespace LLJE {
	namespace Convert {
		::pos2d32 ChunkFromMetric(pos2df64 metric_pos, pos2df64 metric_chunk_size)
			{ return (pos2d64)(metric_pos / metric_chunk_size) + pos2d64{ metric_pos.x < 0 ? -1 : 0, metric_pos.y < 0 ? -1 : 0 }; }
		pos2df64 MetricFromChunk(pos2d32 chunk_pos, pos2df64 metric_chunk_size)
			{ return pos2df64(chunk_pos) * metric_chunk_size; }
	}
	namespace Layer {
		namespace Internal {
			struct Data;
		}
		typedef JE::MHandle<Internal::Data> Handle;

		namespace Internal {
			void DeleteWithoutRemovingFromTheScene(Handle handle);
		}
		void Delete(Handle handle);
	}
	namespace LayerPreset {
		struct Data {
			void(*UpdateLayer)(Layer::Handle layer, const EngineContext& ctx) = nullptr;
			void(*DeleteLayerData)(Layer::Handle map) = nullptr;

			glm::dmat4(*GetLayerTransformationMatrix)(Layer::Handle map, pos2df64 cam_pos) = nullptr; //We dont use engine context here to allow to use this functionality externally
		};
		typedef JE::MHandle<Data> Handle;

		namespace Internal {
			const Data DEFAULT = {};
			JE::AnonymousManager<Data> manager;
		}
		const Handle NULL_PRESET = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }


		Data& GetData(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle];
		}

		Handle Make(const Data& preset) 
			{ return Internal::manager.Add(preset); }

		void Delete(Handle handle) 
			{ Internal::manager.Remove(handle); }
	}

	namespace Scene {
		namespace Internal {
			struct Data;
		}
		typedef JE::MHandle<Internal::Data> Handle;
	}
	namespace ScenePreset {
		struct Data {
			void(*UpdateScene)(Scene::Handle scene, J2D::Cam2D& camera, void* additional_data, size_t type_hash) = nullptr;
			void(*AddLayer)(Scene::Handle scene, Layer::Handle layer) = nullptr; //Will be managed automatically
			void(*RemoveLayer)(Scene::Handle scene, Layer::Handle layer) = nullptr;
			void(*SwapLayers)(Scene::Handle scene, int id1, int id2) = nullptr;
			//void(*LayerPresetChange)(Scene::Handle scene, Layer::Handle layer) = nullptr;

			//void(*InitializeSceneData)(Scene::Handle raw_scene, void* initialization_data) = nullptr; //This is actually needed when the type of a scene is changed
			void(*DeleteSceneData)(Scene::Handle scene) = nullptr;

			void* data = nullptr;
		};
		typedef JE::MHandle<Data> Handle;

		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}
		const Handle NULL_PRESET = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }


		Data& GetData(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle];
		}

		void TryCallUpdate(Handle handle, Scene::Handle scene, J2D::Cam2D& camera, void* data, size_t type_hash) {
			if (ScenePreset::IsValid(handle)) {
				const auto& callback = ScenePreset::GetData(handle).UpdateScene;

				if (callback != nullptr)
					callback(scene, camera, data, type_hash);
			}
		}
		void TryCallAddLayer(Handle handle, Scene::Handle scene, Layer::Handle layer) {
			if (ScenePreset::IsValid(handle)) {
				const auto& callback = ScenePreset::GetData(handle).AddLayer;

				if (callback != nullptr)
					callback(scene, layer);
			}
		}
		void TryCallRemoveLayer(Handle handle, Scene::Handle scene, Layer::Handle layer) {
			if (ScenePreset::IsValid(handle)) {
				const auto& callback = ScenePreset::GetData(handle).RemoveLayer;

				if (callback != nullptr)
					callback(scene, layer);
			}
		}
		void TryCallSwapLayers(Handle handle, Scene::Handle scene, int id1, int id2) {
			if (ScenePreset::IsValid(handle)) {
				const auto& callback = ScenePreset::GetData(handle).SwapLayers;

				if (callback != nullptr)
					callback(scene, id1, id2);
			}
		}
		/*void TryCallInitializeSceneData(Handle handle, Scene::Handle scene, void* data) {
			if (ScenePreset::IsValid(handle)) {
				const auto& callback = ScenePreset::GetData(handle).InitializeSceneData;

				if (callback != nullptr)
					callback(scene, data);
			}
		}*/
		void TryCallDeleteSceneData(Handle handle, Scene::Handle scene) {
			if (ScenePreset::IsValid(handle)) {
				const auto& callback = ScenePreset::GetData(handle).DeleteSceneData;

				if (callback != nullptr)
					callback(scene);
			}
		}

		Handle Make(const Data& preset) 
			{ return Internal::manager.Add(preset); }
		void Delete(Handle handle) 
			{ Internal::manager.Remove(handle); }
	}

	namespace Scene {
		typedef JE::MHandle<Internal::Data> Handle;
		const Handle NULL_SCENE = { nullptr };

		namespace Internal {
			const rgb DEFAULT_BACKGROUND_COLOR = { 0, 70, 120 };

			struct Data {
				std::vector<Layer::Handle> layers;
				rgb background_color = { 0, 0, 0 };
				ScenePreset::Handle preset;
				void* additional_data;
			};
			JE::AnonymousManager<Data> manager;
		}

		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		ScenePreset::Handle GetPreset(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].preset;
		}

		namespace Advanced{
			inline void SetAdditionalDataPtr(Handle handle, void* data) { 
				assert(IsValid(handle));
				auto& dat = Internal::manager[handle];

				dat.additional_data = data; 
			}
			inline void* GetAdditionalDataPtr(Handle handle) { 
				assert(IsValid(handle));
				return Internal::manager[handle].additional_data; 
			}
			template<typename T>
			inline T& GetAdditionalData(Handle handle) 
				{ return *(T*)GetAdditionalDataPtr(handle); }
		}

		void SwapLayers(Handle handle, int id1, int id2) {
			assert(IsValid(handle));
			auto& dat = Internal::manager[handle];
			assert(id1 < dat.layers.size());
			assert(id2 < dat.layers.size());

			ScenePreset::TryCallSwapLayers(dat.preset, handle, id1, id2);
			std::swap(dat.layers[id1], dat.layers[id2]);
		}

		void SetBackgroundColor(Handle handle, rgb color) { 
			assert(IsValid(handle));
			Internal::manager[handle].background_color = color; 
		}
		rgb GetBackgroundColor(Handle handle) { 
			assert(IsValid(handle));
			return Internal::manager[handle].background_color; 
		}

		const std::vector<Layer::Handle>& ListLayers(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].layers;
		}

		void ClearLayerList(Handle handle) {
			assert(IsValid(handle));

			auto& dat = Internal::manager[handle];
			const auto copied_list = dat.layers; //List must be copied to not invalidate the loop iterator when deleting

			for (Layer::Handle i : copied_list)
				Layer::Delete(i);
		}

		Handle Make(rgb background_color = Internal::DEFAULT_BACKGROUND_COLOR, ScenePreset::Handle preset = ScenePreset::NULL_PRESET, void* additional_scene_data = nullptr) {
			return Internal::manager.Add(Internal::Data{ .background_color = background_color, .preset = preset, .additional_data = additional_scene_data });
		}

		void Delete(Handle handle) {
			if (IsValid(handle)) {
				auto& dat = Internal::manager[handle];

				for (Layer::Handle i : dat.layers)
					Layer::Internal::DeleteWithoutRemovingFromTheScene(i);

				ScenePreset::TryCallDeleteSceneData(dat.preset, handle);
				Internal::manager.Remove(handle);
			}
		}
	}

	namespace Layer {
		enum SceneInsertionDirection {
			FRONT,
			BACK
		};
		namespace Internal {
			struct Data {
				LayerPreset::Handle preset = LayerPreset::NULL_PRESET;
				void* additional_data = nullptr;
				Scene::Handle internal_parent_scene;
			};

			JE::AnonymousManager<Data> manager;

			void DeleteWithoutRemovingFromTheScene(Handle handle) {
				auto& dat = Internal::manager[handle];

				if (LayerPreset::IsValid(dat.preset)) {
					LayerPreset::GetData(dat.preset).DeleteLayerData(handle);
					manager.Remove(handle);
				}
			}
		}

		typedef JE::MHandle<Internal::Data> Handle;
		const Handle NULL_LAYER = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		inline Scene::Handle GetParentScene(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].internal_parent_scene;
		}

		LayerPreset::Handle GetPreset(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].preset;
		}

		namespace Advanced{
			inline void SetAdditionalData(Handle handle, void* data) { 
				assert(IsValid(handle));
				auto& dat = Internal::manager[handle];

				dat.additional_data = data; 
			}
			inline void* GetAdditionalData(Handle handle) { 
				assert(IsValid(handle));
				return Internal::manager[handle].additional_data; 
			}
			template<typename T>
			inline T& GetAdditionalDataC(Handle handle) 
				{ return *(T*)GetAdditionalData(handle); }
		}
		inline glm::dmat4 GetBaseTransform(Handle handle, ::pos2df64 cam_pos) {
			assert(IsValid(handle));
			const auto& dat = Internal::manager[handle];

			return LayerPreset::GetData(dat.preset).GetLayerTransformationMatrix(handle, cam_pos);
		}
		inline glm::dmat4 GetBaseTransform(Handle handle, const J2D::Cam2D& cam) 
			{ return GetBaseTransform(handle, cam.center_pos); }

		inline ::pos2df64 GlobalPosToLayerPos(Handle handle, ::pos2df64 global_pos, ::pos2df64 cam_pos) 
			{ return GetBaseTransform(handle, cam_pos) / glm::vec4(global_pos, 0, 1); }
		inline ::pos2df64 LayerPosToGlobalPos(Handle handle, ::pos2df64 local_layer_pos, ::pos2df64 cam_pos) 
			{ return GetBaseTransform(handle, cam_pos) * glm::vec4(local_layer_pos, 0, 1); }

		inline ::pos2df64 GlobalPosToLayerPos(Handle handle, ::pos2df64 global_pos, const J2D::Cam2D& cam) 
			{ return GlobalPosToLayerPos(handle, global_pos, cam.center_pos); }
		inline ::pos2df64 LayerPosToGlobalPos(Handle handle, ::pos2df64 local_layer_pos, const J2D::Cam2D& cam) 
			{ return LayerPosToGlobalPos(handle, local_layer_pos, cam.center_pos); }

		void MoveTo(Layer::Handle handle, Scene::Handle target_scene, SceneInsertionDirection direction = BACK, int insertion_id = 0) {
			auto& dat = Internal::manager[handle];

			auto& src_scene_dat = Scene::Internal::manager[dat.internal_parent_scene];
			auto& targ_scene_dat = Scene::Internal::manager[target_scene];
			
			//Remove from the old scene
			ScenePreset::TryCallRemoveLayer(Scene::GetPreset(dat.internal_parent_scene), dat.internal_parent_scene, handle);
			int id = 0;
			for (; src_scene_dat.layers[id] != handle; id++);
			src_scene_dat.layers.erase(src_scene_dat.layers.begin() + id);

			//Insert into a new one
			dat.internal_parent_scene = target_scene;
			targ_scene_dat.layers.insert(direction == BACK ? (targ_scene_dat.layers.end() - insertion_id) : (targ_scene_dat.layers.begin() + insertion_id), handle);
			ScenePreset::TryCallAddLayer(Scene::GetPreset(dat.internal_parent_scene), dat.internal_parent_scene, handle);
		}
		
		Handle Make(LayerPreset::Handle preset, Scene::Handle target_scene, SceneInsertionDirection direction = BACK, int insertion_id = 0, void* additional_layer_data = nullptr) {
			assert(Scene::IsValid(target_scene));
			assert(preset != LayerPreset::NULL_PRESET);

			Handle handle = Internal::manager.Add(Internal::Data{.preset = preset, .internal_parent_scene = target_scene, .additional_data = additional_layer_data});

			auto& scene_dat = Scene::Internal::manager[target_scene];

			ScenePreset::TryCallAddLayer(scene_dat.preset, target_scene, handle);

			scene_dat.layers.insert(direction == BACK ? (scene_dat.layers.end() - insertion_id) : (scene_dat.layers.begin() + insertion_id), handle);
			
			return handle;
		}

		void Delete(Handle handle) {
			if (IsValid(handle)) {
				auto& dat = Internal::manager[handle];

				ScenePreset::TryCallRemoveLayer(Scene::GetPreset(dat.internal_parent_scene), dat.internal_parent_scene, handle);
				
				if (LayerPreset::IsValid(dat.preset))
					LayerPreset::GetData(dat.preset).DeleteLayerData(handle);

				auto& scene_dat = Scene::Internal::manager[dat.internal_parent_scene];

				int id = 0;
				for (; scene_dat.layers[id] != handle; id++);
				scene_dat.layers.erase(scene_dat.layers.begin() + id);

				Internal::manager.Remove(handle);
			}
		}
	}

	/*
	namespace ChunkMap {
		
	}
	*/
	namespace Convert {
		//TODO: fix integer negative numbers (aka -1 => -2, when it should -1 => -1)
		inline constexpr pos2d64 TileFromMetric(pos2df64 metric_pos, pos2df64 grid_size)
			{ return (pos2d64)(metric_pos / grid_size) + pos2d64{ metric_pos.x < 0 ? -1 : 0, metric_pos.y < 0 ? -1 : 0 }; }

		inline constexpr pos2df64 MetricFromTile(pos2d64 tile_pos, pos2df64 grid_size) {
			const pos2df64 global_tile_pos = pos2df64(tile_pos) * grid_size;
			return global_tile_pos;
		}

		//the part with a ternary is for removing the -0 situation, and making coordinates correct
		inline constexpr ::pos2d32 ChunkFromTile(pos2d64 tile_pos, ::pos2du16 chunk_size) {
			const ::pos2d32 initial_pos = tile_pos / pos2d64(chunk_size);
			const pos2d64 remainder = tile_pos % pos2d64(chunk_size);
			return initial_pos + ::pos2d32{ (remainder.x != 0 && tile_pos.x < 0) ? -1 : 0, (remainder.y != 0 && tile_pos.y < 0) ? -1 : 0 };
		}

		inline constexpr pos2d64 TileFromChunk(::pos2d32 chunk_pos, ::pos2du16 chunk_size)
			{ return pos2d64(chunk_pos) * (pos2d64)chunk_size; }



		inline constexpr ::pos2du16 LocalTileFromGlobalTile(pos2d64 tile_pos, ::pos2du16 chunk_size) {
			const ::pos2du16 initial = ::pos2du16(tile_pos % pos2d64(chunk_size));
			const ::pos2du16 corrected = (chunk_size + initial) % chunk_size; //fixes the number(otherwise its like 65529 or smth, basically a negative number in an unsigned form)

			return corrected;
		}


		inline pos2d64 GlobalTileFromLocalTile(::pos2d32 chunk_pos, ::pos2du16 local_tile_pos, pos2d64 chunk_size) 
			{ return TileFromChunk(chunk_pos, chunk_size) + (pos2d64)local_tile_pos; }
	}

	namespace Chunksystem {
		template<typename T>
		struct ChunkMapData {
			pos2df64 metric_chunk_size = { 16, 16 }; //In meters
			std::unordered_map<pos2d32, T*> chunkmap;

			pos2df64 upper_view_range_extension = { 0,0 };
			pos2df64 lower_view_range_extension = { 0,0 };
		};

		template<typename T>
		inline void SetMetricChunkSize(ChunkMapData<T>& dat, pos2df64 size) 
			{ dat.metric_chunk_size = size; }
		template<typename T>
		inline const pos2df64& GetMetricChunkSize(const ChunkMapData<T>& dat) 
			{ return dat.metric_chunk_size; }

		template<typename T>
		inline bool DoesChunkExists(const ChunkMapData<T>& dat, pos2d32 pos) 
			{ return dat.chunkmap.contains(pos); }

		template<typename T>
		inline T& GetChunk(ChunkMapData<T>& dat, pos2d32 pos) {
			assert(DoesChunkExists(dat, pos));
			return *dat.chunkmap.find(pos)->second;
		}

		template<typename T, void(*InitializeChunkData)(Layer::Handle layer, pos2d32 pos, T& data, void* additional_data)>
		inline T& MakeChunk(ChunkMapData<T>& dat, Layer::Handle layer, pos2d32 pos, void* additional_data = nullptr) {
			assert(!DoesChunkExists(dat, pos));
			T& chunk_dat = *(dat.chunkmap[pos] = new T{});
			InitializeChunkData(layer, pos, chunk_dat, additional_data);
			return chunk_dat;
		}
		template<typename T, void(*DeleteChunkData)(Layer::Handle layer, pos2d32 pos, T& data, void* additional_data)>
		inline void DeleteChunk(ChunkMapData<T>& dat, Layer::Handle layer, pos2d32 pos, void* additional_data = nullptr) {
			if (DoesChunkExists(dat, pos)) {
				DeleteChunkData(layer, pos, *dat.chunkmap[pos], additional_data);
				delete dat.chunkmap[pos];
				dat.chunkmap.erase(pos);
			}
		}
		template<typename T>
		size_t ChunkCount(ChunkMapData<T>& dat) 
			{ return dat.chunkmap.size(); }
		template<typename T>
		void ExecuteForAllChunks(ChunkMapData<T>& dat, Layer::Handle layer, void(*func)(Layer::Handle map, ::pos2d32 pos, void* additional_data), void* additional_data = nullptr) {
			assert(func != nullptr);
			for (const auto& i : dat.chunkmap)
				func(layer, i.first, additional_data);
		}
		/*
		void ExecuteForAllChunksSafe(Layer::Handle handle, void(*func)(Layer::Handle map, ::pos2d32 pos, void* additional_data), void* additional_data = nullptr) {
			assert(func != nullptr);

			assert(Layer::IsValid(handle));
			auto dat = Layer::Internal::manager[handle].internal_chmap_data; //Must copy for safety reasons

			for (const auto& i : dat.chunkmap)
				func(handle, i.first, additional_data);
		}*/
		template<typename T, void(*DeleteChunkData)(Layer::Handle layer, pos2d32 pos, T& data, void* additional_data)>
		void Clear(ChunkMapData<T>& dat, Layer::Handle layer, void* additional_data = nullptr) {
			//assert(Layer::IsValid(handle));
			for (auto& [pos, chunk_ptr] : dat.chunkmap) {
				DeleteChunkData(layer, pos, *chunk_ptr, additional_data);
				delete dat.chunkmap[pos];
			}
			dat.chunkmap.clear(); 
		}


		template<typename T, void(*UpdateChunk)(Layer::Handle layer, pos2d32 pos, const EngineContext& ctx, void* additional_data)>
		void UpdateAndRenderChunks(ChunkMapData<T>& dat, Layer::Handle layer, const EngineContext& ctx, void* additional_data = nullptr) {
			const pos2df64& chunk_size = dat.metric_chunk_size;
			const pos2df64 max_layer_view_range = ctx.layer_view_range.max + dat.upper_view_range_extension;
			const pos2df64 min_layer_view_range = ctx.layer_view_range.min - dat.lower_view_range_extension;


			const pos2d32 min_chunk_range = Convert::ChunkFromMetric(min_layer_view_range, chunk_size);
			const pos2d32 max_chunk_range = Convert::ChunkFromMetric(max_layer_view_range, chunk_size);

			for (int chunk_x = min_chunk_range.x; chunk_x <= max_chunk_range.x; chunk_x++) {
				for (int chunk_y = min_chunk_range.y; chunk_y <= max_chunk_range.y; chunk_y++) {
					const pos2df64 metric_chunk_pos = Convert::MetricFromChunk({ chunk_x, chunk_y }, chunk_size);

					UpdateChunk(layer, {chunk_x, chunk_y}, ctx, additional_data);
				}
			}
		}
		//struct 

		namespace Internal {

		}
	}
}