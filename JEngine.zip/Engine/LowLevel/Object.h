#pragma once
#include "Scene.h"

namespace LLJE {
	namespace Object {
		struct Data;
		typedef JE::MHandle<Data> Handle;
		const Handle NULL_OBJECT = { nullptr };
	}
	namespace Prefab {
		struct Data {
			void(*Destroy)(Object::Handle instance) = nullptr;
			//void (*MoveToDifferentLayer)(Object::Handle instance) = nullptr;

			pos2df64(*GetPosition)(Object::Handle instance) = nullptr;
			void(*Update)(Object::Handle instance, const EngineContext& ctx) = nullptr;
		};

		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}

		typedef JE::MHandle<Data> Handle;
		const Handle NULL_PREFAB = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		const Data& GetData(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle];
		}

		inline Handle Make(const Data& dat)
			{ return Internal::manager.Add(dat); }
		void Delete(Handle handle)
			{ Internal::manager.Remove(handle); }
		void UpdateChunkPosition(Handle handle){

		}
	}

	namespace GenericObjMap {
		struct ObjectmapData {};
		struct ChunkData {
			std::vector<Object::Handle> objects;
		};
	}
	namespace ObjectSys {
		struct OptionalCallbacks {
			void (*AddObject)(Object::Handle object) = nullptr;
			void (*RemoveObject)(Object::Handle object) = nullptr;
		};
		struct MapIntegrationPreset {
			GenericObjMap::ObjectmapData&(*GetMapData)(Layer::Handle handle) = nullptr;
			GenericObjMap::ChunkData&(*GetChunkData)(Layer::Handle handle, pos2d32 pos) = nullptr;
			GenericObjMap::ChunkData&(*MakeChunk)(Layer::Handle handle, pos2d32 pos) = nullptr;
			bool (*DoesChunkExists)(Layer::Handle handle, pos2d32 pos) = nullptr;
			pos2df64 (*GetMetricChunkSize)(Layer::Handle handle);


			OptionalCallbacks notify_callbacks = {};
		};

		namespace Internal {
			std::unordered_map<LayerPreset::Handle, MapIntegrationPreset> presets;
		}
		LayerPreset::Handle LinkPreset(LayerPreset::Handle main_layer_preset, const MapIntegrationPreset& preset) {
			assert(LayerPreset::IsValid(main_layer_preset));
			Internal::presets[main_layer_preset] = preset;
			return main_layer_preset;
		}

		bool IsPresetObj(LayerPreset::Handle preset) {
			assert(LayerPreset::IsValid(preset));
			return Internal::presets.contains(preset);
		}
		bool IsLayerObj(Layer::Handle layer) {
			assert(Layer::IsValid(layer));
			return Internal::presets.contains(Layer::GetPreset(layer));
		}

		const MapIntegrationPreset& GetPreset(LayerPreset::Handle preset) {
			assert(LayerPreset::IsValid(preset));
			return Internal::presets.find(preset)->second;
		}
		const MapIntegrationPreset& GetPreset(Layer::Handle layer) {
			assert(Layer::IsValid(layer));
			return GetPreset(Layer::GetPreset(layer));
		}
	}

	namespace GenericObjMap {
		namespace Internal {
			void InsertObject(Layer::Handle handle, Object::Handle obj);
		}
	}
	namespace Object {
		struct Data {
			Prefab::Handle prefab;
			void* data;

			LLJE::Layer::Handle parent_layer;
			pos2d32 chunk_location = { 0,0 };
		};
		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		template<typename T>
		T& GetData(Handle handle) { 
			assert(IsValid(handle));
			return *(T*)Internal::manager[handle].data; 
		}
		void SetDataPtr(Handle handle, void* ptr) {
			assert(IsValid(handle));
			Internal::manager[handle].data = ptr;
		}
		void* GetDataPtr(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].data;
		}

		/*
		void Update(Handle handle, const glm::dmat4& layer_base_mat) { 
			assert(IsValid(handle));
			Prefab::GetData(Internal::manager[handle].prefab).Update(handle, layer_base_mat);
		}*/

		pos2df64 GetPos(Handle handle) { 
			assert(IsValid(handle));
			return Prefab::GetData(Internal::manager[handle].prefab).GetPosition(handle);
		}
		LLJE::Layer::Handle GetParentLayer(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].parent_layer;
		}
		LLJE::Scene::Handle GetParentScene(Handle handle) {
			assert(IsValid(handle));
			return LLJE::Layer::GetParentScene(GetParentLayer(handle));
		}
		Prefab::Handle GetPrefab(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].prefab;
		}

		void MoveToLayer(Handle handle, Layer::Handle to) {
			assert(IsValid(handle));

			const auto& preset = ObjectSys::GetPreset(GetParentLayer(handle));
			preset.notify_callbacks.RemoveObject(handle);

			GenericObjMap::Internal::InsertObject(to, handle);
		}

		Handle Make(LLJE::Layer::Handle insert_to, Prefab::Handle prefab, void* data = nullptr) { 
			assert(Prefab::IsValid(prefab));
			assert(ObjectSys::IsLayerObj(insert_to));

			Handle handle = Internal::manager.Add({ .prefab = prefab, .data = data, .parent_layer = insert_to });
			//insert it
			GenericObjMap::Internal::InsertObject(insert_to, handle);

			return handle;
		}
		void Delete(Handle handle) {
			if (IsValid(handle)) {
				const auto& preset = ObjectSys::GetPreset(GetParentLayer(handle));
				preset.notify_callbacks.RemoveObject(handle);

				Prefab::GetData(Internal::manager[handle].prefab).Destroy(handle);
				Internal::manager.Remove(handle);
			}
		}
	}

	namespace GenericObjMap {
		namespace Internal {
			void InsertObject(Layer::Handle handle, Object::Handle obj) {
				const auto& preset = ObjectSys::GetPreset(handle);
				const pos2d32 target_chunk = Convert::ChunkFromMetric(Object::GetPos(obj), preset.GetMetricChunkSize(handle));
				

				if (!preset.DoesChunkExists(handle, target_chunk))
					preset.MakeChunk(handle, target_chunk);

				auto& obj_dat = Object::Internal::manager[obj];
				obj_dat.parent_layer = handle;
				obj_dat.chunk_location = target_chunk;

				preset.notify_callbacks.AddObject(obj);

				auto& chunkdat = preset.GetChunkData(handle, target_chunk);
				chunkdat.objects.push_back(obj);
			}
		}

		void UpdateChunk(Layer::Handle map, pos2d32 pos, const EngineContext& ctx) {
			const auto& preset = ObjectSys::GetPreset(map);

			if (!preset.DoesChunkExists(map, pos))
				return;
			ChunkData& chunk_dat = preset.GetChunkData(map, pos);

			//Actual update loop
			for (const auto& i : chunk_dat.objects) {
				if (Object::IsValid(i) && (Object::GetParentLayer(i) == map))
					Prefab::GetData(Object::GetPrefab(i)).Update(i, ctx);
			}


			//Postpass for moving objects and removing invalid handles
			for (int i = 0; i < chunk_dat.objects.size(); i++) {
				const auto& c_obj_handle = chunk_dat.objects[i];
				if (!Object::IsValid(c_obj_handle) || (Object::GetParentLayer(c_obj_handle) != map)) {
					chunk_dat.objects.erase(chunk_dat.objects.begin() + i);

					i--;
				}
				else {
					const pos2d32 target_chunk = Convert::ChunkFromMetric(Object::GetPos(c_obj_handle), preset.GetMetricChunkSize(map));

					if (target_chunk != pos) { //move to a different chunk
						if (!preset.DoesChunkExists(map, target_chunk))
							preset.MakeChunk(map, target_chunk);
						auto& target_chunkdat = preset.GetChunkData(map, target_chunk);

						target_chunkdat.objects.push_back(chunk_dat.objects[i]);
						chunk_dat.objects.erase(chunk_dat.objects.begin() + i);

						auto& obj_dat = Object::Internal::manager[c_obj_handle];
						obj_dat.chunk_location = target_chunk;

						i--;
					}
				}
			}
		}
		void DestroyChunk(Layer::Handle map, pos2d32 pos) {
			const auto& preset = ObjectSys::GetPreset(map);
			ChunkData& chunk_dat = preset.GetChunkData(map, pos);

			for (const auto& i : chunk_dat.objects)
				Object::Delete(i);
		}
	}

	namespace ObjectUtility {

		//inline pos2df64 GetMetricCallChunkPos()
		//	{ return Convert::MetricFromChunk(GenericObjMap::CallInfo::call_chunk, ChunkMap::GetChunkSize(GenericObjMap::CallInfo::called_from)); }
		/*
		Renderer::LLDrawListData DlSprite(JGFX::Internal::TxtFnArg txt,
			LLJ2D::TransfBuff::Handle tbuff,
			const J2D::TransfProps& props, pos2df64 pos, fl32 transparency = 0)
		{
			glm::mat4 obj_mat = props.MakeMatrix(pos, LLJGFX::Texture::GetSize(txt));
			LLJ2D::TransfBuff::SetData(tbuff, obj_mat);

			return { .transforms = tbuff, .texture = txt, .base_transparency = transparency };
		}*/

		//std::vector<Renderer::LLDrawListData> DrawListSimpleObject(pos2df64 pos, pos2df64 relative_to, JGFX::Internal::TxtFnArg txt, LLJ2D::TransfBuff::Handle tbuff, const J2D::TransfProps& props, fl32 transparency = 0)
		//	{ return { DlSprite(txt, tbuff, props, pos - relative_to, transparency) }; }
	}

	namespace AABB_Multichunk {
		struct AABB {
			pos2df64 min;
			pos2df64 max;
		};

		namespace Component {
			void Update() {

			}

			//AABB GetAABB();
		}
	}
}
