#pragma once
#include "Scene.h"

namespace LLJE {
	//------------------------------------Standart tile system----------------------------
	/*
	namespace Tile {
		namespace Internal {
			struct Data {
				LLJGFX::Texture::Handle texture = { nullptr };
				J2D::TransfProps props = {};
				fl32 base_transparency = 0.f;
			};

			const Data DEFAULT = {};
			JE::AnonymousManager<Data> manager;
		}

		typedef JE::MHandle<Internal::Data> Handle;
		const Handle NULL_TILE = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		namespace Internal {
			inline void CheckValidity(Handle handle) {
#ifndef NDEBUG
				if (!IsValid(handle))
					throw std::runtime_error("Requested tile does not exists");
#endif
			}
			inline Data& Get(Handle handle) {
				Internal::CheckValidity(handle);
				return manager[handle];
			}
			inline const Data& GetRo(Handle handle)
				{ return IsValid(handle) ? manager[handle] : DEFAULT; }
		}
	
		typedef Internal::Data TileData;

		inline TileData& GetEditableTileData(Handle handle) { return Internal::Get(handle); }
		inline const TileData& GetRoTileData(Handle handle) { return Internal::GetRo(handle); }

		inline void SetTexture(Handle handle, LLJGFX::Texture::Handle texture) { Internal::Get(handle).texture = texture; }
		inline void SetProps(Handle handle, J2D::TransfProps props) { Internal::Get(handle).props = props; }
		inline void SetTransparency(Handle handle, fl32 base_transparency) { Internal::Get(handle).base_transparency = base_transparency; }

		inline LLJGFX::Texture::Handle GetTexture(Handle handle) { return Internal::GetRo(handle).texture; }
		inline pos2df64 GetMetricTextureSize(Handle handle) { return (pos2df64)LLJGFX::Texture::GetSize(Internal::GetRo(handle).texture) / J2D::PIXELS_PER_METER; }
		inline J2D::TransfProps GetProps(Handle handle) { return Internal::GetRo(handle).props; }
		inline fl32 GetTransparency(Handle handle) { return Internal::GetRo(handle).base_transparency; }

		void Copy(Handle to, Handle from) {
			assert(IsValid(to));
			assert(IsValid(from));

			const auto& from_dat = Internal::GetRo(from);
			auto& to_dat = Internal::Get(to);

			to_dat.texture = LLJGFX::Texture::Make();
			LLJGFX::Texture::Copy(to_dat.texture, from_dat.texture);
			to_dat.props = from_dat.props;
			to_dat.base_transparency = from_dat.base_transparency;
		}

		inline Handle Make(LLJGFX::Texture::Handle texture = { nullptr }, J2D::TransfProps props = {}, fl32 base_transparency = 0.f) 
			{ return Internal::manager.Add({ texture, props, base_transparency }); }
		inline Handle Make(Handle from) {
			Handle handle = Make();
			Copy(handle, from);
			return handle;
		}

		inline void Delete(Handle handle) {
			Internal::manager.Remove(handle);
		}
	}
	namespace PersistentTile {
		namespace Internal {
			struct Data {
				LLJGFX::Texture::Handle texture = { nullptr };
				J2D::TransfProps props = {};
				fl32 base_transparency = 0.f;
			};

			const Data DEFAULT = {};
			JE::AnonymousManager<Data> manager;
		}

		typedef JE::MHandle<Internal::Data> Handle;
		const Handle NULL_PTILE = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		namespace Internal {
			inline void CheckValidity(Handle handle) {
#ifndef NDEBUG
				if (!IsValid(handle))
					throw std::runtime_error("Requested tile does not exists");
#endif
			}
			inline Data& Get(Handle handle) {
				Internal::CheckValidity(handle);
				return manager[handle];
			}
			inline const Data& GetRo(Handle handle)
				{ return IsValid(handle) ? manager[handle] : DEFAULT; }
		}
	
		typedef Internal::Data TileData;

		inline const TileData& GetRoTileData(Handle handle) { return Internal::GetRo(handle); }

		inline LLJGFX::Texture::Handle GetTexture(Handle handle) { return Internal::GetRo(handle).texture; }
		inline pos2df64 GetMetricTextureSize(Handle handle) { return (pos2df64)LLJGFX::Texture::GetSize(Internal::GetRo(handle).texture) / J2D::PIXELS_PER_METER; }
		inline J2D::TransfProps GetProps(Handle handle) { return Internal::GetRo(handle).props; }
		inline fl32 GetTransparency(Handle handle) { return Internal::GetRo(handle).base_transparency; }

		inline Handle Make(LLJGFX::Texture::Handle texture = { nullptr }, J2D::TransfProps props = {}, fl32 base_transparency = 0.f) 
			{ return Internal::manager.Add({ texture, props, base_transparency }); }
		inline Handle Make(Handle from) {
			Handle handle = Make();
			{
				const auto& from_dat = Internal::GetRo(from);
				auto& to_dat = Internal::Get(handle);

				to_dat.texture = LLJGFX::Texture::Make();
				LLJGFX::Texture::Copy(to_dat.texture, from_dat.texture);
				to_dat.props = from_dat.props;
				to_dat.base_transparency = from_dat.base_transparency;
			}
			return handle;
		}

		inline void Delete(Handle handle) {
			if (IsValid(handle)) {
				auto& dat = Internal::Get(handle);

				Internal::manager.Remove(handle);
			}
		}
	}

	//-------------------------------------Default tilemap implementation-----------------
	
	
	namespace Tilemap { //Default tilemap system
		namespace Internal {
			struct DTM_RandomAhhPlaceholderJustForTypeSafety {};

			struct TmapData {
				pos2df64 grid_size;
				pos2du16 tiles_in_chunk;
			};

			struct IrDrawListElement {
				LLJ2D::TransfBuff::Handle transforms = LLJ2D::TransfBuff::NULL_TBUFF;
				Tile::Handle tile = Tile::NULL_TILE;
			};

			struct ChunkData {
				Tile::Handle* tiles;
				bool is_cache_valid = false;
				std::vector<IrDrawListElement> draw_list;
			};

			ChmapPreset::Handle compare_handle = ChmapPreset::NULL_PRESET;
		}

		typedef JE::MHandle<Internal::DTM_RandomAhhPlaceholderJustForTypeSafety> Handle;
		const Handle NULL_TMAP = { nullptr };
		
		inline bool IsTypeValid(ChunkMap::Handle handle) {
			assert(ChunkMap::IsValid(handle));
			return Chunkmap::GetPreset(handle) == Internal::compare_handle;
		}

		inline ChunkMap::Handle ToChmap(Handle handle)
			{ return { ( ChunkMap::Internal::ChunkmapData*)handle.data }; }
		inline bool IsValid(Handle handle)
			{ return ChunkMap::IsValid(ToChmap(handle)); }

		inline Handle FromChmap(ChunkMap::Handle generic_handle) { 
			assert(ChunkMap::IsValid(generic_handle));
			assert(IsTypeValid(generic_handle));

			return { (Internal::DTM_RandomAhhPlaceholderJustForTypeSafety*)generic_handle.data }; 
		}

		void SetGridSize(Handle handle, pos2df64 size) {
			assert(IsValid(handle));

			auto& tmap_data = *(Internal::TmapData*)Chunkmap::GetAdditionalData(ToChmap(handle));

			Chunkmap::SetChunkSize(ToChmap(handle), size * (pos2df64)tmap_data.tiles_in_chunk);
			tmap_data.grid_size = size;
		}
		pos2df64 GetGridSize(Handle handle) { 
			assert(IsValid(handle));
			return ((Internal::TmapData*)Chunkmap::GetAdditionalData(ToChmap(handle)))->grid_size; 
		}
		pos2du16 GetChunkSize(Handle handle) { 
			assert(IsValid(handle));
			return ((Internal::TmapData*)Chunkmap::GetAdditionalData(ToChmap(handle)))->tiles_in_chunk; 
		}
		

		namespace Functions {
			void MakeChunk(Chunkmap::ChunkData& dat, pos2du16 chunk_size) {
				dat.data = new Internal::ChunkData{};
				Internal::ChunkData& c_chunk = *(Internal::ChunkData*)dat.data;

				c_chunk.tiles = (Tile::Handle*)malloc(sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
				memset(c_chunk.tiles, 0, sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
			}

			void DeleteChunk(Chunkmap::Handle map, pos2d32 pos, void* = nullptr) {
				Chunkmap::ChunkData& c_raw_chunk = LLJE::Chunkmap::GetChunk(map, pos);
				Internal::ChunkData& c_chunk = *(Internal::ChunkData*)c_raw_chunk.data;
				free(c_chunk.tiles);

				for (auto& i : c_chunk.draw_list)
					LLJ2D::TransfBuff::Delete(i.transforms);

				delete (Internal::ChunkData*)c_raw_chunk.data;
			}
			
			std::vector<LLJE::Renderer::LLDrawListData> ConvertIrDrawList(const std::vector<Internal::IrDrawListElement>& ir_cache) {
				std::vector<LLJE::Renderer::LLDrawListData> res;
				res.reserve(ir_cache.size());

				for (const auto& i : ir_cache) {
					const auto& tile_dat = Tile::GetRoTileData(i.tile);

					res.push_back({ i.transforms, tile_dat.texture, tile_dat.props.MakeMatrix(LLJGFX::Texture::GetSize(tile_dat.texture)), tile_dat.base_transparency });
				}

				return res;
			}
			std::vector<LLJE::Renderer::LLDrawListData> ChunkCacher(LLJE::ChunkMap::Handle map, pos2d32 pos) {
				if (!LLJE::Chunkmap::DoesChunkExists(map, pos))
					return {};

				Internal::ChunkData& c_chunk = *(Internal::ChunkData*)LLJE::Chunkmap::GetChunk(map, pos).data;


				if (c_chunk.is_cache_valid) {
					const auto& tmp = ConvertIrDrawList(c_chunk.draw_list);
					return tmp;
				}


				//cache chunk
				const pos2du16 chunk_size = GetChunkSize(FromChmap(map));
				const pos2df64 grid_size = GetGridSize(FromChmap(map));

				std::unordered_map<Tile::Handle, std::vector<glm::mat4>> tmp_cache;

				for (int y = 0; y < chunk_size.y; y++) {
					for (int x = 0; x < chunk_size.x; x++) {
						tmp_cache[c_chunk.tiles[chunk_size.x * y + x]].push_back(glm::translate(glm::mat4(1), { x * grid_size.x, y * grid_size.y, 0.f }));
					}
				}

				for (const auto& i : c_chunk.draw_list)
					LLJ2D::TransfBuff::Delete(i.transforms);
				c_chunk.draw_list.clear();
				c_chunk.draw_list.reserve(tmp_cache.size());

				for (const auto& i : tmp_cache) {
					if (i.first != Tile::NULL_TILE) {
						LLJGFX::Texture::Handle c_txt = Tile::GetTexture(i.first);
						c_chunk.draw_list.push_back({ .transforms = LLJ2D::TransfBuff::Make(i.second, {}), .tile = i.first });
					}
				}
				c_chunk.is_cache_valid = true;

				return ConvertIrDrawList(c_chunk.draw_list);
			}
			void ChmapCopier(Chunkmap::Handle to, Chunkmap::Handle from) {
				Handle to_tmap = FromChmap(to);
				Handle from_tmap = FromChmap(from);

				Chunkmap::ExecuteForAllChunks(to, Functions::DeleteChunk);
				Chunkmap::Clear(to);

				SetGridSize(FromChmap(to), GetGridSize(FromChmap(from)));

				Internal::TmapData* tmap_data = (Internal::TmapData*)Chunkmap::GetAdditionalData(to);
				if (tmap_data == nullptr) {
					tmap_data = new Internal::TmapData;
					Chunkmap::SetAdditionalData(to, tmap_data);
				}

				((Internal::TmapData*)Chunkmap::GetAdditionalData(to))->tiles_in_chunk = GetChunkSize(FromChmap(from));

				Chunkmap::ExecuteForAllChunks(from,
					[](Chunkmap::Handle map, pos2d32 pos, void* to_map) -> void {
						const Chunkmap::Handle to = { (Chunkmap::Internal::ChunkmapData*)to_map };
						const Internal::ChunkData& from_chunk = *(Internal::ChunkData*)LLJE::Chunkmap::GetChunk(map, pos).data;

						auto& to_chunk = *(Internal::ChunkData*)Chunkmap::MakeChunk(to, pos).data;

						const pos2du16 chunk_size = GetChunkSize(FromChmap(map));
						to_chunk.tiles = (Tile::Handle*)malloc(sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
						memcpy(to_chunk.tiles, from_chunk.tiles, sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
					},
					to.data);
			}
		}
		const ChmapPreset::Handle preset = Internal::compare_handle = ChmapPreset::Make(Functions::ChunkCacher, Functions::ChmapCopier);

		inline void SetTile(Handle handle, Tile::Handle tile, pos2d64 pos){
			assert(IsValid(handle));

			const pos2du16 chunk_size = GetChunkSize(handle);
			const pos2d32 chunk_pos = Convert::ChunkFromTile(pos, chunk_size);
			const pos2du16 local_tile_pos = Convert::LocalTileFromGlobalTile(pos, chunk_size);

			if (!Chunkmap::DoesChunkExists(ToChmap(handle), chunk_pos))
				Functions::MakeChunk(Chunkmap::MakeChunk(ToChmap(handle), chunk_pos), chunk_size);
			Internal::ChunkData& c_chunk = *(Internal::ChunkData*)Chunkmap::GetChunk(ToChmap(handle), chunk_pos).data;

			c_chunk.tiles[chunk_size.x * local_tile_pos.y + local_tile_pos.x] = tile;
			c_chunk.is_cache_valid = false;
		}
		inline Tile::Handle GetTile(Handle handle, pos2d64 pos) {
			assert(IsValid(handle));

			const pos2du16 chunk_size = GetChunkSize(handle);
			const pos2d32 chunk_pos = Convert::ChunkFromTile(pos, chunk_size);
			const pos2du16 local_tile_pos = Convert::LocalTileFromGlobalTile(pos, chunk_size);

			if (!Chunkmap::DoesChunkExists(ToChmap(handle), chunk_pos))
				return Tile::NULL_TILE;
			const Internal::ChunkData& c_chunk = *(Internal::ChunkData*)LLJE::Chunkmap::GetChunk(ToChmap(handle), chunk_pos).data;

			return c_chunk.tiles[chunk_size.x * local_tile_pos.y + local_tile_pos.x];
		}

		inline void Copy(Handle to, Handle from) {
			assert(IsValid(to));
			assert(IsValid(from));

			Chunkmap::ExecuteForAllChunks(ToChmap(to), Functions::DeleteChunk);
			Chunkmap::Clear(ToChmap(to));
			
			SetGridSize(to, GetGridSize(from));
			((Internal::TmapData*)Chunkmap::GetAdditionalData(ToChmap(to)))->tiles_in_chunk = GetChunkSize(from);

			Chunkmap::ExecuteForAllChunks(ToChmap(from),
				[](Chunkmap::Handle map, pos2d32 pos, void* to_map) -> void {
					const Chunkmap::Handle to = { (Chunkmap::Internal::ChunkmapData*)to_map };
					const Internal::ChunkData& from_chunk = *(Internal::ChunkData*)LLJE::Chunkmap::GetChunk(map, pos).data;

					auto& to_chunk = *(Internal::ChunkData*)Chunkmap::MakeChunk(to, pos).data;

					const pos2du16 chunk_size = GetChunkSize(FromChmap(map));
					to_chunk.tiles = (Tile::Handle*)malloc(sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
					memcpy(to_chunk.tiles, from_chunk.tiles, sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
				},
			to.data);
		}

		inline Handle Make(pos2df64 grid_size = { 1,1 }, pos2du16 chunk_size = { 16,16 }) { 
			return FromChmap(Chunkmap::Make(
					grid_size * (pos2df64)chunk_size, 
					preset, 
					new Internal::TmapData{.grid_size = grid_size, .tiles_in_chunk = chunk_size}
			)); 
		}
		inline Handle Make(Handle from) { 
			assert(IsValid(from));

			Handle handle = Make();
			Copy(handle, from);
			return handle;
		}

		inline void Delete(Handle handle) {
			if (IsValid(handle)) {
				Chunkmap::ExecuteForAllChunks(ToChmap(handle), Functions::DeleteChunk);
				Chunkmap::Delete(ToChmap(handle));
			}
		}
	}
	
	//-------------------------------------Default background tilemap implementation------
	namespace BackgroundTmap {
		
		namespace Internal {
			struct BTM_TypeSafetyDummy {};
		}
		typedef JE::MHandle<Internal::BTM_TypeSafetyDummy> Handle;
		const Handle NULL_BGTM = { nullptr };

		struct BgElemPool {
			std::vector<Tile::Handle> segments;
			typedef Tile::Handle(*SegmentSelector)(const BgElemPool& pool, Handle map, pos2d64 pos);
			static Tile::Handle DEFAULT_SELECTOR(const BgElemPool& pool, Handle map, pos2d64 pos) {
				return pool.segments.size() ? pool.segments[0] : Tile::NULL_TILE;
			}
			SegmentSelector SelectSegment = DEFAULT_SELECTOR;
		};

		namespace Internal {
			struct BTM_Data : public Tilemap::Internal::TmapData {
				//Tilemap::Internal::TmapData dat;
				BgElemPool elems;
			};
		}
		inline Chunkmap::Handle ToChmap(Handle handle)
			{ return { (Chunkmap::Internal::ChunkmapData*)handle.data }; }
		inline Handle FromChmap(Chunkmap::Handle generic_handle)
			{ return { (Internal::BTM_TypeSafetyDummy*)generic_handle.data }; }

		namespace Internal {
			inline Tilemap::Handle ToTmap(Handle handle) 
				{ return Tilemap::FromChmap(ToChmap(handle)); }
		}
		void SetGridSize(Handle handle, pos2df64 size)
			{ Tilemap::SetGridSize(Internal::ToTmap(handle), size); }
		pos2df64 GetGridSize(Handle handle)
			{ return Tilemap::GetGridSize(Internal::ToTmap(handle)); }
		pos2du16 GetChunkSize(Handle handle) 
			{ return Tilemap::GetChunkSize(Internal::ToTmap(handle)); }

		inline bool IsValid(Handle handle)
			{ return Tilemap::IsValid(Internal::ToTmap(handle)); }

		inline void SetElementPool(Handle handle, const BgElemPool& pool)
			{ (*(Internal::BTM_Data*)Chunkmap::GetAdditionalData(ToChmap(handle))).elems = pool; }
		inline const BgElemPool& GetElementPool(Handle handle)
			{ return (*(Internal::BTM_Data*)Chunkmap::GetAdditionalData(ToChmap(handle))).elems; }
		inline BgElemPool& GetEditableElementPool(Handle handle)
			{ return (*(Internal::BTM_Data*)Chunkmap::GetAdditionalData(ToChmap(handle))).elems; }

		namespace Functions {
			void MakeChunk(Chunkmap::ChunkData& dat, pos2du16 chunk_size, const BgElemPool& pool, pos2d32 chunk_pos, Handle map) {
				const pos2d64 base_chunk_tile_pos = Convert::TileFromChunk(chunk_pos, chunk_size);
				Tilemap::Internal::ChunkData& c_dat = *(Tilemap::Internal::ChunkData*)dat.data;

				for (int y = 0; y < chunk_size.y; y++) {
					for (int x = 0; x < chunk_size.x; x++)
						c_dat.tiles[chunk_size.x * y + x] = pool.SelectSegment(pool, map, base_chunk_tile_pos + pos2d64{ x, y });
				}
			}

			std::vector<LLJE::Renderer::LLDrawListData> ChunkCacher(LLJE::Chunkmap::Handle map, pos2d32 pos) {
				if(!Chunkmap::DoesChunkExists(map, pos))
					MakeChunk(Chunkmap::MakeChunk(map, pos), GetChunkSize(FromChmap(map)), GetElementPool(FromChmap(map)), pos, FromChmap(map));

				return Tilemap::Functions::ChunkCacher(map, pos);
			}
		}

		inline void SetSegment(Handle handle, Tile::Handle tile, pos2d64 pos) { 
			const pos2du16 chunk_size = GetChunkSize(handle);
			const pos2d32 chunk_pos = Convert::ChunkFromTile(pos, chunk_size);
			const pos2du16 local_tile_pos = Convert::LocalTileFromGlobalTile(pos, chunk_size);

			if (!Chunkmap::DoesChunkExists(ToChmap(handle), chunk_pos))
				Functions::MakeChunk(Chunkmap::MakeChunk(ToChmap(handle), chunk_pos), chunk_size, GetElementPool(handle), chunk_pos, handle);
			Tilemap::Internal::ChunkData& c_chunk = *(Tilemap::Internal::ChunkData*)Chunkmap::GetChunk(ToChmap(handle), chunk_pos).data;

			c_chunk.tiles[chunk_size.x * local_tile_pos.y + local_tile_pos.x] = tile;
			c_chunk.is_cache_valid = false;
		}
		inline Tile::Handle GetSegment(Handle handle, pos2d64 pos) { 
			const pos2du16 chunk_size = GetChunkSize(handle);
			const pos2d32 chunk_pos = Convert::ChunkFromTile(pos, chunk_size);
			const pos2du16 local_tile_pos = Convert::LocalTileFromGlobalTile(pos, chunk_size);

			if (!Chunkmap::DoesChunkExists(ToChmap(handle), chunk_pos)) {
				const auto& pool = GetElementPool(handle);
				return pool.SelectSegment(pool, handle, pos);
			}
			Tilemap::Internal::ChunkData& c_chunk = *(Tilemap::Internal::ChunkData*)Chunkmap::GetChunk(ToChmap(handle), chunk_pos).data;

			return c_chunk.tiles[chunk_size.x * local_tile_pos.y + local_tile_pos.x];
		}


		//inline void Copy(Handle to, Handle from) {
			//GenericChunkmap::Copy(GetGenericTmapHandle(to), GetGenericTmapHandle(from));
			//SetElementPool(to, GetElementPool(from));
		//}
		const ChmapPreset::Handle preset = ChmapPreset::Make(Functions::ChunkCacher);

		inline Handle Make(pos2df64 grid_size = { 1,1 }, pos2du16 chunk_size = { 16,16 }, const BgElemPool& pool = {}) {
			Internal::BTM_Data* dat = new Internal::BTM_Data{ grid_size, chunk_size, pool,  };

			return FromChmap(Chunkmap::Make(grid_size * (pos2df64)chunk_size, preset, dat));
		}

		inline Handle Make(Tile::Handle size_from, pos2du16 chunk_size = { 16,16 }, const BgElemPool& pool = {})
			{ return Make(LLJE::Tile::GetMetricTextureSize(size_from), chunk_size, pool); }

		//inline Handle Make(Handle from) {
		//	Handle handle = Make();
		//	Copy(handle, from);
		//	return handle;
		//}

		inline void Delete(Handle handle) 
			{ Tilemap::Delete(Internal::ToTmap(handle)); }
	}*/

	//-------------------------------------Object map implementation----------------------
	namespace Object {
		struct Data;
		typedef JE::MHandle<Data> Handle;
		const Handle NULL_TMAP = { nullptr };
	}
	namespace Prefab {
		/*
		Insertable functions:

		- Update(drawlist return) function

		- Constructor (deprecated)
		- Destructor

		Prefab is immutable
		*/
		struct Data {
			void(*Destroy)(Object::Handle instance) = nullptr;
			void (*MoveToDifferentLayer)(Object::Handle instance) = nullptr;

			pos2df64(*GetPosition)(Object::Handle instance) = nullptr;
			std::vector<LLJE::Renderer::LLDrawListData>(*Update)(Object::Handle instance) = nullptr;

			void* data;
		};

		namespace Internal {
			const Data DEFAULT = {};
			JE::AnonymousManager<Data> manager;
		}

		typedef JE::MHandle<Data> Handle;
		const Handle NULL_PREFAB = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		const Data& GetData(Handle handle) { 
			assert(IsValid(handle));
			return Internal::manager[handle]; 
		}

		inline Handle Make(const Data& dat) 
			{ return Internal::manager.Add(dat); }
		inline Handle Make(
				void(*Destructor)(Object::Handle instance),
				std::vector<LLJE::Renderer::LLDrawListData>(*Update)(Object::Handle instance),
				pos2df64(*GetPosition)(Object::Handle instance),
				void* additional_data = nullptr
		)
			{ return Make({.Destroy = Destructor, .GetPosition = GetPosition, .Update = Update, .data = additional_data}); }
		void Delete(Handle handle) 
			{ Internal::manager.Remove(handle); }
	}


	
	namespace GenericObjMap {
		//namespace CallInfo {
		//	Layer::Handle called_from = Layer::NULL_LAYER;
		//	pos2d32 call_chunk = { 0, 0 };
		//}

		struct ObjectmapData {};
		struct ChunkData {
			std::vector<Object::Handle> objects;
		};
		
		/*
		template <ChunkData&(*GetChunkData)(Layer::Handle handle, pos2d32 pos), void(*MakeChunk)(Layer::Handle handle, pos2d32 pos)>
		void InsertObject(Layer::Handle handle, Object::Handle obj, ObjectmapData& map_data) {
			const pos2d32 target_chunk = Convert::ChunkFromMetric(Object::GetPos(obj), ChunkMap::GetChunkSize(handle));

			//handle should be added to the list of all handles in the map
			//it also should be added to the target chunk
			//if chunk doesnt exists - create it
			map_data.object_chunk_positions[obj] = target_chunk;

			if (!ChunkMap::DoesChunkExists(handle, target_chunk))
				MakeChunk(handle, target_chunk);

			auto& chunkdat = GetChunkData(handle, target_chunk);
			chunkdat.objects.push_back(obj);
		}

		template <ChunkData& (*GetChunkData)(Layer::Handle handle, pos2d32 pos)>
		void RemoveObject(Layer::Handle handle, Object::Handle obj, ObjectmapData& map_data) {
			const pos2d32 target_chunk = map_data.object_chunk_positions.find(obj)->second;

			auto& chunkdat = GetChunkData(handle, target_chunk);
			for (int i = 0; i < chunkdat.objects.size(); i++) {
				if (chunkdat.objects[i] == obj) {
					std::swap(chunkdat.objects.back(), chunkdat.objects[i]);
					chunkdat.objects.pop_back();
					break;
				}
			}
			map_data.object_chunk_positions.erase(obj);
		}
		*/
		//template <ChunkData&(*GetChunkData)(Layer::Handle handle, pos2d32 pos), void(*MakeChunk)(Layer::Handle handle, pos2d32 pos)>
		std::vector<Renderer::LLDrawListData> UpdateChunk(Layer::Handle map, pos2d32 pos, ObjectmapData& map_data) {
			if (!ChunkMap::DoesChunkExists(map, pos))
				return {};
			ChunkData& chunk_dat = GetChunkData(map, pos);

			std::vector<LLJE::Renderer::LLDrawListData> res;

			//Actual update loop
			for (const auto& i : chunk_dat.objects) {
				if (Object::IsValid(i)) {
					std::vector<LLJE::Renderer::LLDrawListData> obj_draw_list = Object::Update(i);
					res.insert(res.end(), obj_draw_list.begin(), obj_draw_list.end());
				}
			}


			//Postpass for moving objects and removing invalid handles
			for (int i = 0; i < chunk_dat.objects.size(); i++) {
				if (!Object::IsValid(chunk_dat.objects[i])) {
					chunk_dat.objects.erase(chunk_dat.objects.begin() + i);
					map_data.object_chunk_positions.erase(chunk_dat.objects[i]);

					i--;
				}
				else {
					const pos2d32 target_chunk = Convert::ChunkFromMetric(Object::GetPos(chunk_dat.objects[i]), ChunkMap::GetChunkSize(map));

					if (target_chunk != pos) { //move to a different chunk
						if (!ChunkMap::DoesChunkExists(map, target_chunk))
							MakeChunk(map, target_chunk);
						auto& target_chunkdat = GetChunkData(map, target_chunk);

						map_data.object_chunk_positions[chunk_dat.objects[i]] = target_chunk;
						target_chunkdat.objects.push_back(chunk_dat.objects[i]);
						chunk_dat.objects.erase(chunk_dat.objects.begin() + i);

						i--;
					}
				}
			}
			return res;
		}
		//inline pos2d32 ObjChunkPos(Object::Handle obj, ObjectmapData& map_data) {
		//	assert(Object::IsValid(obj) && "Requested object does not exist or was deleted");

		//	return map_data.object_chunk_positions.find(obj)->second;
		//}
	}
	namespace ObjectSys {
		struct MapIntegrationPreset {
			GenericObjMap::ObjectmapData& (*GetMapData)(Layer::Handle handle) = nullptr;
			GenericObjMap::ChunkData& (*GetChunkData)(Layer::Handle handle, pos2d32 pos) = nullptr;
			GenericObjMap::ChunkData& (*MakeChunk)(Layer::Handle handle, pos2d32 pos) = nullptr;
		};

		namespace Internal {
			std::unordered_map<LayerPreset::Handle, MapIntegrationPreset> presets;
		}

		bool IsPresetObj(LayerPreset::Handle preset) {
			assert(LayerPreset::IsValid(preset));
			return Internal::presets.contains(preset);
		}
		bool IsLayerObj(Layer::Handle layer) {
			assert(Layer::IsValid(layer));
			return Internal::presets.contains(Layer::Advanced::GetPreset(layer));
		}
	}

	namespace Object {
		/*
		Object data:

		- pointer to instance-specific data
		- prefab handle
		- last frame when was updated(counter) - to prevent multiple updates per frame
		- Position

		Bound prefab cannot be changed after the object is created
		*/
		struct Data {
			Prefab::Handle prefab;
			void* data;

			LLJE::Layer::Handle parent_layer;
			pos2d32 chunk_location = { 0,0 };
		};

		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}

		typedef JE::MHandle<Data> Handle;
		const Handle NULL_OBJECT = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		//const Data& GetGenericObjectData(Handle handle) { 
		//	assert(IsValid(handle));
		//	return Internal::manager[handle]; 
		//}

		template<typename T>
		T& GetData(Handle handle) { 
			assert(IsValid(handle));
			return *(T*)Internal::manager[handle].data; 
		}

		std::vector<LLJE::Renderer::LLDrawListData> Update(Handle handle) { 
			assert(IsValid(handle));
			return Prefab::GetData(Internal::manager[handle].prefab).Update(handle);
		}

		pos2df64 GetPos(Handle handle) { 
			assert(IsValid(handle));
			return Prefab::GetData(Internal::manager[handle].prefab).GetPosition(handle);
		}
		LLJE::Layer::Handle GetParentLayer(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].parent_layer;
		}
		void MoveToLayer(Handle handle, Layer::Handle to) {

		}

		Handle Make(LLJE::Layer::Handle insert_to, Prefab::Handle prefab, void* data = nullptr) { 
			assert(Prefab::IsValid(prefab));
			assert(ObjectSys::IsLayerObj(insert_to));

			Handle handle = Internal::manager.Add({ .prefab = prefab, .data = data, .parent_layer = insert_to });
			//insert it

			return handle;
		}
		void Delete(Handle handle) {
			if (IsValid(handle)) {
				Prefab::GetData(Internal::manager[handle].prefab).Destroy(handle);
				Internal::manager.Remove(handle);
			}
		}
	}

	namespace ObjectUtility {

		//inline pos2df64 GetMetricCallChunkPos()
		//	{ return Convert::MetricFromChunk(GenericObjMap::CallInfo::call_chunk, ChunkMap::GetChunkSize(GenericObjMap::CallInfo::called_from)); }

		Renderer::LLDrawListData DlSprite(JGFX::Internal::TxtFnArg txt, 
											LLJ2D::TransfBuff::Handle tbuff, 
											const J2D::TransfProps& props, pos2df64 pos, fl32 transparency = 0) 
		{
			glm::mat4 obj_mat = props.MakeMatrix(pos, LLJGFX::Texture::GetSize(txt));
			LLJ2D::TransfBuff::SetData(tbuff, obj_mat);

			return { .transforms = tbuff, .texture = txt, .base_transparency = transparency };
		}

		std::vector<Renderer::LLDrawListData> DlSimpleObject(pos2df64 pos, JGFX::Internal::TxtFnArg txt,
														   LLJ2D::TransfBuff::Handle tbuff,
														   const J2D::TransfProps& props, fl32 transparency = 0)
		{
			return { DlSprite(txt, tbuff, props, pos - GetMetricCallChunkPos(), transparency) };
		}
	}

	namespace ObjectOnlyMap {
		using GenericObjMap::ChunkData;

		namespace Internal {
			struct DTM_RandomAhhPlaceholderJustForTypeSafety {};

			using GenericObjMap::ObjectmapData;

			LayerPreset::Handle testing_preset = LayerPreset::NULL_PRESET; //This is for testing if layer has the correct type
		}

		typedef JE::MHandle<Internal::DTM_RandomAhhPlaceholderJustForTypeSafety> Handle;
		const Handle NULL_OBJMAP = { nullptr };

		inline bool IsObjMap(Layer::Handle generic_handle) { return Layer::Advanced::GetPreset(generic_handle) == Internal::testing_preset; }
		inline Layer::Handle ToLayer(Handle handle) { return { ( Layer::Internal::Data*)handle.data }; }
		inline Handle FromLayer(Layer::Handle generic_handle) { 
			assert(IsObjMap(generic_handle));
			return { (Internal::DTM_RandomAhhPlaceholderJustForTypeSafety*)generic_handle.data }; 
		}

		void SetChunkSize(Handle handle, pos2df64 size) 
			{ ChunkMap::SetChunkSize(ToLayer(handle), size); }
		pos2du16 GetChunkSize(Handle handle)
			{ return ChunkMap::GetChunkSize(ToLayer(handle)); }

		inline bool IsValid(Handle handle)
			{ return Layer::IsValid(ToLayer(handle)); }

		namespace Functions {
			void MakeChunk(ChunkMap::ChunkData& dat) {
				dat.data = new ChunkData{};
			}
			void DeleteChunk(ChunkMap::ChunkData& dat) 
				{ delete (ChunkData*)dat.data; }
			void RDeleteChunk(ChunkMap::ChunkData& dat) {
				ChunkData& c_chunk = *(ChunkData*)dat.data;
				for (const auto& i : c_chunk.objects)
					Object::Delete(i);

				delete (ChunkData*)dat.data;
			}
		}
		namespace Internal {
			ObjectmapData& GetMapData(Layer::Handle handle) {
				return Layer::Advanced::GetAdditionalDataC<ObjectmapData>(handle);
			}
			ChunkData& GetChunkData(Layer::Handle handle, pos2d32 chunk_pos) 
				{ return ChunkMap::GetChunk<ChunkData>(handle, chunk_pos); }
			void MakeChunk(Layer::Handle handle, pos2d32 pos)
				{ Functions::MakeChunk(ChunkMap::MakeEmptyChunk(handle, pos)); }
		}
		inline bool IsObjectThere(Object::Handle obj, Handle handle) { 
			auto& dat = Layer::Advanced::GetAdditionalDataC<Internal::ObjectmapData>(ToLayer(handle));
			return GenericObjMap::IsObjectThere(obj, dat);
		}
		inline pos2d32 ObjChunkPos(Object::Handle obj, Handle handle) {
			auto& dat = Layer::Advanced::GetAdditionalDataC<Internal::ObjectmapData>(ToLayer(handle));
			return GenericObjMap::ObjChunkPos(obj, dat);
		}

		namespace Functions {
			std::vector<LLJE::Renderer::LLDrawListData> ChunkCacher(Layer::Handle map, pos2d32 pos) {
				if (!LLJE::ChunkMap::DoesChunkExists(map, pos))
					return {};

				auto& map_data = Layer::Advanced::GetAdditionalDataC<Internal::ObjectmapData>(map);
				const auto& cache = GenericObjMap::UpdateChunk<Internal::GetChunkData, Internal::MakeChunk>(map, pos, map_data);

				auto& chunk_dat = ChunkMap::GetChunk<ChunkData>(map, pos);
				if (!chunk_dat.objects.size()) {
					Functions::DeleteChunk(ChunkMap::GetChunk(map, pos));
					ChunkMap::DeleteChunk(map, pos);
				}
				return cache;
			}

			void InitializeLayerData(Layer::Handle map, void*) {
				Layer::Advanced::SetAdditionalData(map, new Internal::ObjectmapData{});
			}
			void DestroyLayerData(Layer::Handle map) {
				ChunkMap::ExecuteForAllChunks(map, [](Layer::Handle map, pos2d32 pos, void*) {  Functions::RDeleteChunk(ChunkMap::GetChunk(map, pos)); });
				delete (Internal::ObjectmapData*)Layer::Advanced::GetAdditionalData(map);
			}
		}

		LayerPreset::Handle preset = Internal::testing_preset = LayerPreset::Make(Functions::ChunkCacher, Functions::InitializeLayerData, Functions::DestroyLayerData);

		
		inline Handle TurnInto(Layer::Handle layer) { Layer::Advanced::SetPreset(layer, preset); return FromLayer(layer); }

		inline Layer::Handle MakeLayer(Scene::Handle target_scene, Layer::SceneInsertionDirection direction = Layer::BACK, int insertion_id = 0, const Layer::LayerSettings& settings = {}) {
			return Layer::Make(
					target_scene,
					direction,
					insertion_id,
					settings,
					preset
			); 
		}
		
		//inline void Delete(Handle handle) {
		//	Layer::Delete(ToLayer(handle));
		//}
		/*
		//Also deletes all the objects inside
		inline void RDelete(Handle handle) {
			Chunkmap::ExecuteForAllChunks(ToChmap(handle), [](LLJE::ChunkMap::Handle map, pos2d32 pos, void*) {  Functions::RDeleteChunk(Chunkmap::GetChunk(map, pos)); });
			delete (Internal::ObjectmapData*)Chunkmap::GetAdditionalData(ToChmap(handle));
			Chunkmap::Delete(ToChmap(handle));
		}
		*/
	}
}
