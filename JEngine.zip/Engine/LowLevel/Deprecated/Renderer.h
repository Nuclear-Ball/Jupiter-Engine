#pragma once
#include <JGFX/JGFX.h>
#include <J2D/J2D.h>

namespace LLJE {
	namespace Internal {
		const std::string je_vertex_shader_source =
			"#version 330 core\n"

			"layout(location = 0) in vec2 v_pos;\n"
			"layout(location = 1) in vec2 v_uv;\n"
			"layout(location = 2) in mat4 instance_mat;\n"

			"layout(location = 6) in float instance_transparency;\n"

			"uniform mat4 pv;\n"
			"uniform mat4 base_transform;\n"
			"uniform float base_transparency;\n"

			"out vec2 TexCoord;\n"
			"out float transparency;\n"

			"void main(){\n"
			"    gl_Position = pv * instance_mat * base_transform * vec4(v_pos, 0.0, 1.0);\n"
			"    TexCoord = v_pos;\n"
			"    transparency = base_transparency + instance_transparency;\n"
			"}";
		const std::string je_fragment_shader_source = LLJ2D::Internal::default_fs;
		LLJ2D::Shader2D::Handle je_default_shader = LLJ2D::Shader2D::Make(je_vertex_shader_source, je_fragment_shader_source);
	}

	namespace Renderer {
		struct LLDrawListData {
			LLJ2D::TransfBuff::Handle transforms = LLJ2D::TransfBuff::NULL_TBUFF;
			LLJGFX::Texture::Handle texture = { nullptr };

			glm::mat4 base_transform = glm::mat4(1);
			fl32 base_transparency = 0.f; 
		};
		
		//New API: chunks are now responsible for rendering themselves

		//struct NewDrawListElem {
		//	LLJGFX::VRef::Handle mesh;
		//	LLJGFX::ShaderProgram::Handle shader;
		//	std::vector<TmpTextureSlotBinding> texture_bindings

		//};

		void RenderDrawList(const LLDrawListData& draw_list) {
			LLJ2D::Shader2D::SetUniform(Internal::je_default_shader, "base_transform", draw_list.base_transform);
			LLJ2D::Shader2D::SetUniform(Internal::je_default_shader, "base_transparency", draw_list.base_transparency);
			LLJ2D::Draw(draw_list.transforms, draw_list.texture, Internal::je_default_shader);
		}
	}
}

/*
		struct EngineTransfBuffer {
			LLJ2D::TransfBuff::Handle buff = LLJ2D::TransfBuff::NULL_TBUFF;
			void* owner_unique_id = nullptr;
		};

		size_t MAX_TBUFFS = 1024;

		JE::AnonymousManager<EngineTransfBuffer> transfbuffs;

		JE::MHandle<Internal::EngineTransfBuffer> AllocTbuff(void* unique_id) {
			if (transfbuffs.size() < MAX_TBUFFS)
				return transfbuffs.Add({ LLJ2D::TransfBuff::Make(), unique_id });

			else {
				transfbuffs.raw_data().end()->data;
			}
		}

		struct DrawListElement {
		private:
			JE::MHandle<Internal::EngineTransfBuffer> cached_transforms;
			void* unique_id = nullptr;

			std::vector<glm::mat4> local_cached_transforms;
			std::vector<fl32> local_cached_transparencies;

			inline void Init() { unique_id = (void*)(new char); }
			inline void Recache() {
				const Internal::EngineTransfBuffer& c_tbuff = Internal::transfbuffs[cached_transforms];
				LLJ2D::TransfBuff::SetData(c_tbuff.buff, local_cached_transforms);
				LLJ2D::TransfBuff::SetTransparency(c_tbuff.buff, local_cached_transparencies);
			}
		public:
			LLJGFX::Texture::Handle texture = { nullptr };
			glm::mat4 base_transform = glm::mat4(1);
			fl32 base_transparency = 0.f;

			DrawListElement& SetTransforms(const std::vector<glm::mat4>& transforms) {
				local_cached_transforms = transforms;
				if (Internal::transfbuffs.DoesExists(cached_transforms)) {
					const Internal::EngineTransfBuffer& c_tbuff = Internal::transfbuffs[cached_transforms];
					if (c_tbuff.owner_unique_id == unique_id)
						LLJ2D::TransfBuff::SetData(c_tbuff.buff, transforms);
				}
				return *this;
			}
			DrawListElement& SetTransparencies(const std::vector<fl32>& transparencies) {
				local_cached_transparencies = transparencies;
				if (Internal::transfbuffs.DoesExists(cached_transforms)) {
					const Internal::EngineTransfBuffer& c_tbuff = Internal::transfbuffs[cached_transforms];
					if (c_tbuff.owner_unique_id == unique_id)
						LLJ2D::TransfBuff::SetTransparency(c_tbuff.buff, transparencies);
				}
				return *this;
			}

			inline std::vector<glm::mat4> transforms() const { return local_cached_transforms; }
			inline std::vector<fl32> transparencies() const { return local_cached_transparencies; }

			//inline DrawListElement() { Init(); }
			inline DrawListElement(const std::vector<glm::mat4>& transforms = {},
								   const std::vector<fl32>& transparencies = {},
								   LLJGFX::Texture::Handle txt = { nullptr },
								   const glm::mat4& base_transf = glm::mat4(1), fl32 base_transp = 0.f) {
				Init();
				SetTransforms(transforms);
				SetTransparencies(transparencies);
				texture = txt;
				base_transform = base_transf;
				base_transparency = base_transp;
			}

			inline DrawListElement& operator=(const DrawListElement& cpy) {
				SetTransforms(cpy.local_cached_transforms);
				SetTransparencies(cpy.local_cached_transparencies);
				texture = cpy.texture;
				base_transform = cpy.base_transform;
				base_transparency = cpy.base_transparency;
				return *this;
			}
			inline DrawListElement(const DrawListElement& cpy) { Init(); operator=(cpy); }

			inline DrawListElement& operator=(DrawListElement&& cpy) {
				delete (char*)unique_id;
				unique_id = nullptr;

				std::swap(unique_id, cpy.unique_id);
				std::swap(local_cached_transforms, cpy.local_cached_transforms);
				std::swap(local_cached_transparencies, cpy.local_cached_transparencies);
				std::swap(texture, cpy.texture);
				std::swap(base_transform, cpy.base_transform);
				std::swap(base_transparency, cpy.base_transparency);

				return *this;
			}
			inline DrawListElement(DrawListElement&& cpy) { operator=(std::move(cpy)); }

			LLDrawListData GetLLDrawList() const {
				if (Internal::transfbuffs.DoesExists(cached_transforms)) {
					const Internal::EngineTransfBuffer& c_tbuff = Internal::transfbuffs[cached_transforms];
					if (c_tbuff.owner_unique_id != unique_id) {
						((DrawListElement*)this)->cached_transforms = Internal::AllocTbuff(unique_id);
						((DrawListElement*)this)->Recache();
					}
				}
				else {
					((DrawListElement*)this)->cached_transforms = Internal::AllocTbuff(unique_id);
					((DrawListElement*)this)->Recache();
				}

				return { Internal::transfbuffs[cached_transforms].buff, texture, base_transform, base_transparency };
			}

			~DrawListElement() { delete (char*)unique_id; }
		};
*/