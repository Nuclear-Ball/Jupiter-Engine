#pragma once
#include <JGFX/JGFX.h>

namespace LLJE {
	
}