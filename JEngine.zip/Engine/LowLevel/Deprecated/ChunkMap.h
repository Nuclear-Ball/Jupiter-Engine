#pragma once
#include <JupiterUtils.h>
#include <JGFX/JGFX.h>
#include <J2D/J2D.h>
#include <JGFX/pos2d.h>
#include "Renderer.h"
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/hash.hpp>
/*
namespace LLJE {
	
	namespace Chunkmap {
		struct ChunkData {
			void* data = nullptr;
		};
		namespace Internal {
			struct ChunkmapData;
		}
		typedef JE::MHandle<Internal::ChunkmapData> Handle;

		typedef std::vector<LLJE::Renderer::LLDrawListData>(*ChunkCacher)(Handle map, pos2d32 chunk_pos);
		typedef void(*ChmapCopier)(Handle to, Handle from);
	}
	
	namespace Chunkmap {
		namespace Internal {
			struct ChunkmapData {
				ChmapPreset::Handle preset = ChmapPreset::NULL_PRESET;

				pos2df64 chunk_size = { 16, 16 }; //In meters
				void* additional_data = nullptr;

				std::unordered_map<pos2d32, ChunkData> chunkmap;
			};
			
			const ChunkmapData DEFAULT_CHUNKMAP = {};
			JE::AnonymousManager<ChunkmapData> manager;
		}

		const Handle NULL_CHMAP = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		inline void SetChunkSize(Handle handle, pos2df64 size) { 
			assert(IsValid(handle));
			Internal::manager[handle].chunk_size = size; 
		}
		inline pos2df64 GetChunkSize(Handle handle) { 
			assert(IsValid(handle));
			return Internal::manager[handle].chunk_size;
		}


		inline bool DoesChunkExists(Handle handle, pos2d32 pos) {
			assert(IsValid(handle));
			return Internal::manager[handle].chunkmap.contains(pos);
		}

		inline ChunkData& GetChunk(Handle handle, pos2d32 pos) {
			assert(IsValid(handle));
			Internal::ChunkmapData& dat = Internal::manager[handle];
			assert(dat.chunkmap.contains(pos));

			return dat.chunkmap.find(pos)->second;
		}
		template<typename T>
		inline T& GetChunk(Handle handle, pos2d32 pos) 
			{ return *(T*)GetChunk(handle, pos).data; }


		inline ChunkData& MakeChunk(Handle handle, pos2d32 pos) {
			assert(IsValid(handle));
			Internal::ChunkmapData& dat = Internal::manager[handle];

			return dat.chunkmap[pos];
		}
		inline void DeleteChunk(Handle handle, pos2d32 pos) {
			assert(IsValid(handle));
			Internal::ChunkmapData& dat = Internal::manager[handle];

			if (DoesChunkExists(handle, pos))
				dat.chunkmap.erase(pos);
		}
			
		std::vector<LLJE::Renderer::LLDrawListData> GetRoDrawList(Handle handle, pos2d32 chunk_pos) {
			assert(IsValid(handle));
			Internal::ChunkmapData& dat = Internal::manager[handle];

			return ChmapPreset::GetData(dat.preset).CacheChunk(handle, chunk_pos);
		}

		void ExecuteForAllChunks(Handle handle, void(*func)(Handle map, pos2d32 pos, void* additional_data), void* additional_data = nullptr) {
			assert(func != nullptr);

			assert(IsValid(handle));
			Internal::ChunkmapData& dat = Internal::manager[handle];

			for (const auto& i : dat.chunkmap)
				func(handle, i.first, additional_data);
		}

		void Clear(Handle handle) { 
			assert(IsValid(handle));
			Internal::manager[handle].chunkmap.clear(); 
		}

		inline void SetAdditionalData(Handle handle, void* data) { 
			assert(IsValid(handle));
			auto& dat = Internal::manager[handle];

			dat.additional_data = data; 
		}

		inline void* GetAdditionalData(Handle handle) { 
			assert(IsValid(handle));
			return Internal::manager[handle].additional_data; 
		}

		template<typename T>
		inline T& GetAdditionalDataC(Handle handle) 
			{ return *(T*)GetAdditionalData(handle); }

		inline void SetPreset(Handle handle, ChmapPreset::Handle preset) { 
			assert(IsValid(handle));
			Internal::manager[handle].preset = preset; 
		}

		ChmapPreset::Handle GetPreset(Handle handle) { 
			assert(IsValid(handle));
			return Internal::manager[handle].preset; 
		}

		inline void Copy(Handle to, Handle from){
			assert(IsValid(to));
			assert(IsValid(from));

			const auto& from_dat = Internal::manager[from];
			auto& to_dat = Internal::manager[to];

			to_dat.chunk_size = from_dat.chunk_size;
			to_dat.preset = from_dat.preset;

			ChmapPreset::GetData(from_dat.preset).CopyChmap(to, from);
		}

		inline Handle Make(pos2df64 chunk_size, ChmapPreset::Handle preset, void* additional_data = nullptr) 
			{ return Internal::manager.Add(Internal::ChunkmapData{ .preset = preset, .chunk_size = chunk_size, .additional_data = additional_data }); }
		inline Handle Make(Handle from) {
			Handle handle = Make({}, ChmapPreset::NULL_PRESET);
			Copy(handle, from);
			return handle;
		}

		inline void Delete(Handle handle) {
			if (IsValid(handle))
				Internal::manager.Remove(handle);
		};
	}
}*/