/*
���������� �������:
	
	void DrawCapsule (b2Vec2 p1, b2Vec2 p2, float radius, b2HexColor color, void *context)
	void DrawCircle (b2Vec2 center, float radius, b2HexColor color, void *context)
	void DrawPoint (b2Vec2 p, float size, b2HexColor color, void *context)	
	void DrawPolygon (const b2Vec2 *vertices, int vertexCount, b2HexColor color, void *context)
	void DrawSegment (b2Vec2 p1, b2Vec2 p2, b2HexColor color, void *context)
	void DrawSolidCapsule (b2Vec2 p1, b2Vec2 p2, float radius, b2HexColor color, void *context)
	void DrawSolidCircle (b2Transform transform, float radius, b2HexColor color, void *context)
	void DrawSolidPolygon (b2Transform transform, const b2Vec2 *vertices, int vertexCount, float radius, b2HexColor color, void *context)
	void DrawString (b2Vec2 p, const char *s, void *context)
	void DrawTransform (b2Transform transform, void *context)


	��������� ��� ������ ������� b2World_Draw

	*/
#pragma once
#include "Phys.h"
#include "fmt/core.h"
#include <JGFX/JGFX.h>

void APIENTRY GLDebugMessageCallback(GLenum source, GLenum type, GLuint id,
                            GLenum severity, GLsizei length,
                            const GLchar *msg, const void *data) {
  char* _source;
  char* _type;
  char* _severity;

  switch (source) {
    case GL_DEBUG_SOURCE_API:
      _source = "API"; break;
    case GL_DEBUG_SOURCE_WINDOW_SYSTEM:
      _source = "WINDOW SYSTEM"; break;
    case GL_DEBUG_SOURCE_SHADER_COMPILER:
      _source = "SHADER COMPILER"; break;
    case GL_DEBUG_SOURCE_THIRD_PARTY:
      _source = "THIRD PARTY"; break;
    case GL_DEBUG_SOURCE_APPLICATION:
      _source = "APPLICATION"; break;
    case GL_DEBUG_SOURCE_OTHER:
      _source = "UNKNOWN"; break;
    default:
        _source = "UNKNOWN"; break;
    }

    switch (type) {
      case GL_DEBUG_TYPE_ERROR:
        _type = "ERROR"; break;
      case GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR:
        _type = "DEPRECATED BEHAVIOR"; break;
      case GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR:
        _type = "UDEFINED BEHAVIOR"; break;
      case GL_DEBUG_TYPE_PORTABILITY:
        _type = "PORTABILITY"; break;
      case GL_DEBUG_TYPE_PERFORMANCE:
        _type = "PERFORMANCE"; break;
      case GL_DEBUG_TYPE_OTHER:
        _type = "OTHER"; break;
      case GL_DEBUG_TYPE_MARKER:
        _type = "MARKER"; break;
      default:
        _type = "UNKNOWN"; break;
    }

    switch (severity) {
      case GL_DEBUG_SEVERITY_HIGH:
        _severity = "HIGH"; break;
      case GL_DEBUG_SEVERITY_MEDIUM:
        _severity = "MEDIUM"; break;
      case GL_DEBUG_SEVERITY_LOW:
        _severity = "LOW"; break;
      case GL_DEBUG_SEVERITY_NOTIFICATION:
        _severity = "NOTIFICATION"; break;
      default:
        _severity = "UNKNOWN"; break;
    }

    printf("%d: %s of %s severity, raised from %s: %s\n",
            id, _type, _severity, _source, msg);
}

namespace RenderedData {
	namespace Point {
		const char* vs = 
			"#version 330\n"

			"layout(location = 0) in int dummy;\n"

			"uniform mat4 projection;\n"
			"uniform vec2 pos;\n"
			"uniform float size;\n"
			"uniform vec4 color;\n"

			"out vec4 f_color;\n"

			"void main(void) {\n"
			"	f_color = color;\n"
			"	gl_Position = projection * vec4(pos, 0.0f, 1.0f);\n"
			"   gl_PointSize = size;\n"
			"}\n";

		const char* fs = 
			"#version 330\n"

			"in vec4 f_color;\n"
			"out vec4 color;\n"

			"void main(void) {\n"
			"	color = f_color;\n"
			"}\n";

		JGFX::ShaderProgram point_sh = { vs, fs };

		JGFX::VertexCollection vb = JGFX::VertexCollection{ false };

		void Init() {
			vb.Init();

			JGFX::VertexLayout layout = { JGFX::VertexAttribute{ 0, JGFX::AttribType::I32 } };
			vb.AddBuffer(JGFX::VertexBuffer{ std::vector<int>{0}, layout }, "");
		}
	}
	namespace Line {
		const char* vs = 
			"#version 330\n"

			"uniform mat4 projection;\n"

			"layout(location = 0) in vec2 v_position;\n"
			"layout(location = 1) in vec4 v_color;\n"

			"out vec4 f_color;\n"

			"void main(void) {\n"
			"	f_color = v_color;\n"
			"	gl_Position = projection * vec4(v_position, 0.0f, 1.0f);\n"
			"}\n";

		const char* fs = 
			"#version 330\n"

			"in vec4 f_color;\n"
			"out vec4 color;\n"

			"void main(void) {\n"
			"	color = f_color;\n"
			"}\n";

		JGFX::ShaderProgram sh = { vs, fs };

		struct Point {
			pos2df32 pos;
			rgb color;
		};

		JGFX::VertexCollection buff = JGFX::VertexCollection{ false };

		void Init() {
			buff.Init();

			JGFX::VertexLayout layout = { JGFX::VertexAttribute{ 0, JGFX::AttribType::FL32, 2 }, 
										  JGFX::VertexAttribute{ 1, JGFX::AttribType::UI8, 4, 0, true } };
			buff.AddBuffer(JGFX::VertexBuffer{ std::vector<Point>{}, layout }, "points");
		}

		void DrawLines(const std::vector<Point>& points) {
			if (points.size() == 0)
				return;
			assert(points.size() % 2 == 0);

			buff["points"].SetData(points);

			sh.SetUniform("projection", LLJ2D::curr_pv);
			{
				LLJGFX::Internal::UnbindBuffers();
				glBindVertexArray(buff.handle().handle);
				glUseProgram(sh.handle().data->gpu_handle);

				glLineWidth(3);
				glDrawArrays(GL_LINES, 0, points.size());

				glBindVertexArray(0);
				LLJGFX::Internal::RebindBoundShader();
			}
		}
	}
	namespace Circle {
		const char* vs = 
			"#version 330\n"

			"uniform mat4 projection;\n"
			"uniform float pixelScale;\n"

			"uniform vec2 position;\n"
			"uniform float radius;\n"
			"uniform vec4 color;\n"

			"layout(location = 0) in vec2 v_localPosition;\n"

			"out vec2 f_position;\n"
			"out vec4 f_color;\n"
			"out float f_thickness;\n"

			"void main() {\n"
				"f_position = v_localPosition;\n"
				"f_color = color;\n"
				"float radius = radius;\n"

				// resolution.y = pixelScale * radius
				"f_thickness = 3.0f / (pixelScale * radius);\n"

				"vec2 p = vec2(radius * v_localPosition.x, radius * v_localPosition.y) + position;\n"
				"gl_Position = projection * vec4(p, 0.0f, 1.0f);\n"
			"}\n";

		const char* fs = 
			"#version 330\n"

			"in vec2 f_position;\n"
			"in vec4 f_color;\n"
			"in float f_thickness;\n"

			"out vec4 fragColor;\n"

			"void main() {\n"
				// radius in unit quad
				"float radius = 1.0;\n"

				// distance to circle
				"vec2 w = f_position;\n"
				"float dw = length(w);\n"
				"float d = abs(dw - radius);\n"

				"fragColor = vec4(f_color.rgb, smoothstep(f_thickness, 0.0, d));\n"
			"}\n";

		JGFX::ShaderProgram sh = {vs, fs};

		JGFX::VertexCollection buff = JGFX::VertexCollection{ false };

		void Init() {
			buff.Init();

			JGFX::VertexLayout layout = { JGFX::VertexAttribute{ 0, JGFX::AttribType::FL32, 2 } };
			const float a = 1.1f;
			buff.AddBuffer(JGFX::VertexBuffer{ std::vector<pos2df32>{ { -a, -a }, { a, -a }, { -a, a }, { a, -a }, { a, a }, { -a, a } }, layout }, "mesh");
			buff.SetIndexingData(JGFX::Indexate(6));
		}

		fl32 circle_pixel_scale = 30;
	}
	namespace SolidCircle {
		const char* vs = 
			"#version 330\n"

			"uniform mat4 projection;\n"
			"uniform float pixelScale;\n"

			"layout(location = 0) in vec2 v_localPosition;\n"
			"uniform vec4 transform;\n"
			"uniform float radius;\n"
			"uniform vec4 color;\n"

			"out vec2 f_position;\n"
			"out vec4 f_color;\n"
			"out float f_thickness;\n"

			"void main() {\n"
				"f_position = v_localPosition;\n"
				"f_color = color;\n"
				"float radius = radius;\n"

				// resolution.y = pixelScale * radius
				"f_thickness = 3.0f / (pixelScale * radius);\n"
    
				"float x = transform.x;\n"
				"float y = transform.y;\n"
				"float c = transform.z;\n"
				"float s = transform.w;\n"
				"vec2 p = vec2(radius * v_localPosition.x, radius * v_localPosition.y);\n"
				"p = vec2((c * p.x - s * p.y) + x, (s * p.x + c * p.y) + y);\n"
				"gl_Position = projection * vec4(p, 0.0f, 1.0f);\n"
			"}\n";
		const char* fs = 
			"#version 330\n"

			"in vec2 f_position;\n"
			"in vec4 f_color;\n"
			"in float f_thickness;\n"

			"out vec4 fragColor;\n"

			// https://en.wikipedia.org/wiki/Alpha_compositing
			"vec4 blend_colors(vec4 front, vec4 back) {\n"
				"vec3 cSrc = front.rgb;\n"
				"float alphaSrc = front.a;\n"
				"vec3 cDst = back.rgb;\n"
				"float alphaDst = back.a;\n"

				"vec3 cOut = cSrc * alphaSrc + cDst * alphaDst * (1.0 - alphaSrc);\n"
				"float alphaOut = alphaSrc + alphaDst * (1.0 - alphaSrc);\n"
				"cOut = cOut / alphaOut;\n"

				"return vec4(cOut, alphaOut);\n"
			"}\n"

			"void main() {\n"
				// radius in unit quad
				"float radius = 1.0;\n"

				// distance to axis line segment
				"vec2 e = vec2(radius, 0);\n"
				"vec2 w = f_position;\n"
				"float we = dot(w, e);\n"
				"vec2 b = w - e * clamp(we / dot(e, e), 0.0, 1.0);\n"
				"float da = length(b);\n"

				// distance to circle
				"float dw = length(w);\n"
				"float dc = abs(dw - radius);\n"

				// union of circle and axis
				"float d = min(da, dc);\n"

				"vec4 borderColor = f_color;\n"
				"vec4 fillColor = 0.6f * borderColor;\n"

				// roll the fill alpha down at the border
				"vec4 back = vec4(fillColor.rgb, fillColor.a * smoothstep(radius + f_thickness, radius, dw));\n"

				// roll the border alpha down from 1 to 0 across the border thickness
				"vec4 front = vec4(borderColor.rgb, smoothstep(f_thickness, 0.0f, d));\n"

				"fragColor = blend_colors(front, back);\n"
			"}\n";
		JGFX::ShaderProgram sh = { vs, fs };

		using Circle::buff;

	}
	namespace SolidCapsule {
		const char* vs = 
			"#version 330\n"

			"uniform mat4 projection;\n"
			"uniform float pixelScale;\n"

			"layout(location = 0) in vec2 v_localPosition;\n"
			"uniform vec4 transform;\n"
			"uniform float radius;\n"
			"uniform float length;\n"
			"uniform vec4 color;\n"

			"out vec2 f_position;\n"
			"out vec4 f_color;\n"
			"out float f_length;\n"
			"out float f_thickness;\n"

			"void main() {\n"
				"f_position = v_localPosition;\n"
				"f_color = color;\n"

				"float radius = radius;\n"
				"float length = length;\n"

				// scale quad large enough to hold capsule
				"float scale = radius + 0.5 * length;\n"

				// quad range of [-1, 1] implies normalize radius and length
				"f_length = length / scale;\n"

				// resolution.y = pixelScale * scale
				"f_thickness = 3.0f / (pixelScale * scale);\n"

				"float x = transform.x;\n"
				"float y = transform.y;\n"
				"float c = transform.z;\n"
				"float s = transform.w;\n"
				"vec2 p = vec2(scale * v_localPosition.x, scale * v_localPosition.y);\n"
				"p = vec2((c * p.x - s * p.y) + x, (s * p.x + c * p.y) + y);\n"
				"gl_Position = projection * vec4(p, 0.0, 1.0);\n"
			"}\n";
		const char* fs = 
			"#version 330\n"

			"in vec2 f_position;\n"
			"in vec4 f_color;\n"
			"in float f_length;\n"
			"in float f_thickness;\n"

			"out vec4 color;\n"

			// Thanks to baz and kolyan3040 for help on this shader
			// todo this can be optimized a bit, keeping some terms for clarity

			// https://en.wikipedia.org/wiki/Alpha_compositing
			"vec4 blend_colors(vec4 front, vec4 back) {\n"
				"vec3 cSrc = front.rgb;\n"
				"float alphaSrc = front.a;\n"
				"vec3 cDst = back.rgb;\n"
				"float alphaDst = back.a;\n"

				"vec3 cOut = cSrc * alphaSrc + cDst * alphaDst * (1.0 - alphaSrc);\n"
				"float alphaOut = alphaSrc + alphaDst * (1.0 - alphaSrc);\n"

				// remove alpha from rgb
				"cOut = cOut / alphaOut;\n"

				"return vec4(cOut, alphaOut);\n"
			"}\n"

			"void main() {\n"
				// radius in unit quad
				"float radius = 0.5 * (2.0 - f_length);\n"

				"vec4 borderColor = f_color;\n"
				"vec4 fillColor = 0.6f * borderColor;\n"

				"vec2 v1 = vec2(-0.5 * f_length, 0);\n"
				"vec2 v2 = vec2(0.5 * f_length, 0);\n"

				// distance to line segment
				"vec2 e = v2 - v1;\n"
				"vec2 w = f_position - v1;\n"
				"float we = dot(w, e);\n"
				"vec2 b = w - e * clamp(we / dot(e, e), 0.0, 1.0);\n"
				"float dw = length(b);\n"

				// SDF union of capsule and line segment
				"float d = min(dw, abs(dw - radius));\n"

				// roll the fill alpha down at the border
				"vec4 back = vec4(fillColor.rgb, fillColor.a * smoothstep(radius + f_thickness, radius, dw));\n"

				// roll the border alpha down from 1 to 0 across the border thickness
				"vec4 front = vec4(borderColor.rgb, smoothstep(f_thickness, 0.0f, d));\n"

				"color = blend_colors(front, back);\n"
			"}\n";

		JGFX::ShaderProgram sh = { vs, fs };

		using Circle::buff;
	}
	namespace SolidPolygon {
		const char* vs = 
			"#version 330\n"

			"uniform mat4 projection;\n"
			"uniform float pixelScale;\n"

			"uniform vec4 transform;\n"
			"uniform vec4 points12;\n"
			"uniform vec4 points34;\n"
			"uniform vec4 points56;\n"
			"uniform vec4 points78;\n"
			"uniform int point_count;\n"
			"uniform float radius;\n"
			"uniform vec4 color;\n"

			"layout(location = 0) in vec2 v_localPosition;\n"

			"out vec2 f_position;\n"
			"out vec4 f_color;\n"
			"out vec2 f_points[8];\n"
			"flat out int f_count;\n"
			"out float f_radius;\n"
			"out float f_thickness;\n"

			"void main() {\n"
				"f_position = v_localPosition;\n"
				"f_color = color;\n"

				"f_radius = radius;\n"
				"f_count = point_count;\n"

				"f_points[0] = points12.xy;\n"
				"f_points[1] = points12.zw;\n"
				"f_points[2] = points34.xy;\n"
				"f_points[3] = points34.zw;\n"
				"f_points[4] = points56.xy;\n"
				"f_points[5] = points56.zw;\n"
				"f_points[6] = points78.xy;\n"
				"f_points[7] = points78.zw;\n"

				// Compute polygon AABB
				"vec2 lower = f_points[0];\n"
				"vec2 upper = f_points[0];\n"
				"for (int i = 1; i < point_count; ++i) {\n"
					"lower = min(lower, f_points[i]);\n"
					"upper = max(upper, f_points[i]);\n"
				"}\n"

				"vec2 center = 0.5 * (lower + upper);\n"
				"vec2 width = upper - lower;\n"
				"float maxWidth = max(width.x, width.y);\n"

				"float scale = f_radius + 0.5 * maxWidth;\n"
				"float invScale = 1.0 / scale;\n"

				// Shift and scale polygon points so they fit in 2x2 quad
				"for (int i = 0; i < point_count; ++i)\n"
					"f_points[i] = invScale * (f_points[i] - center);\n"

				// Scale radius as well
				"f_radius = invScale * f_radius;\n"

				// resolution.y = pixelScale * scale
				"f_thickness = 3.0f / (pixelScale * scale);\n"

				// scale up and transform quad to fit polygon
				"float x = transform.x;\n"
				"float y = transform.y;\n"
				"float c = transform.z;\n"
				"float s = transform.w;\n"
				"vec2 p = vec2(scale * v_localPosition.x, scale * v_localPosition.y) + center;\n"
				"p = vec2((c * p.x - s * p.y) + x, (s * p.x + c * p.y) + y);\n"
				"gl_Position = projection * vec4(p, 0.0f, 1.0f);\n"
			"}\n";

		const char* fs = 
			"#version 330\n"

			"in vec2 f_position;\n"
			"in vec2 f_points[8];\n"
			"flat in int f_count;\n"
			"in float f_radius;\n"
			"in vec4 f_color;\n"
			"in float f_thickness;\n"

			"out vec4 fragColor;\n"

			// https://en.wikipedia.org/wiki/Alpha_compositing
			"vec4 blend_colors(vec4 front, vec4 back) {\n"
				"vec3 cSrc = front.rgb;\n"
				"float alphaSrc = front.a;\n"
				"vec3 cDst = back.rgb;\n"
				"float alphaDst = back.a;\n"

				"vec3 cOut = cSrc * alphaSrc + cDst * alphaDst * (1.0 - alphaSrc);\n"
				"float alphaOut = alphaSrc + alphaDst * (1.0 - alphaSrc);\n"

				// remove alpha from rgb
				"cOut = cOut / alphaOut;\n"

				"return vec4(cOut, alphaOut);\n"
			"}\n"

			"float cross2d(in vec2 v1, in vec2 v2)\n"
				"{ return v1.x * v2.y - v1.y * v2.x; }\n"

			// Signed distance function for convex polygon
			"float sdConvexPolygon(in vec2 p, in vec2[8] v, in int count) {\n"
				// Initial squared distance
				"float d = dot(p - v[0], p - v[0]);\n"

				// Consider query point inside to start
				"float side = -1.0;\n"
				"int j = count - 1;\n"
				"for (int i = 0; i < count; ++i) {\n"
					// Distance to a polygon edge
					"vec2 e = v[i] - v[j];\n"
					"vec2 w = p - v[j];\n"
					"float we = dot(w, e);\n"
					"vec2 b = w - e * clamp(we / dot(e, e), 0.0, 1.0);\n"
					"float bb = dot(b, b);\n"

					// Track smallest distance
					"if (bb < d)\n"
						"d = bb;\n"

					// If the query point is outside any edge then it is outside the entire polygon.
					// This depends on the CCW winding order of points.
					"float s = cross2d(w, e);\n"
					"if (s >= 0.0)\n"
						"side = 1.0;\n"

					"j = i;\n"
				"}\n"

				"return side * sqrt(d);\n"
			"}\n"

			"void main() {\n"
				"vec4 borderColor = f_color;\n"
				"vec4 fillColor = 0.6f * borderColor;\n"

				"float dw = sdConvexPolygon(f_position, f_points, f_count);\n"
        
        /*
				// Initial squared distance
        "{"
          "float d = dot(f_position - f_points[0], f_position - f_points[0]);\n"

          // Consider query point inside to start
          "float side = -1.0;\n"
          "int j = f_count - 1;\n"
          "for (int i = 0; i < f_count; ++i) {\n"
            // Distance to a polygon edge
            "vec2 e = f_points[i] - f_points[j];\n"
            "vec2 w = f_position - f_points[j];\n"
            "float we = dot(w, e);\n"
            "vec2 b = w - e * clamp(we / dot(e, e), 0.0, 1.0);\n"
            "float bb = dot(b, b);\n"

            // Track smallest distance
            "if (bb < d)\n"
              "d = bb;\n"

            // If the query point is outside any edge then it is outside the entire polygon.
            // This depends on the CCW winding order of points.
            "float s = cross2d(w, e);\n"
            "if (s >= 0.0)\n"
              "side = 1.0;\n"

            "j = i;\n"
          "}\n"
				  "dw = side * sqrt(d);\n"
        "}"*/

				"float d = abs(dw - f_radius);\n"

				// roll the fill alpha down at the border
				"vec4 back = vec4(fillColor.rgb, fillColor.a * smoothstep(f_radius + f_thickness, f_radius, dw));\n"

				// roll the border alpha down from 1 to 0 across the border thickness
				"vec4 front = vec4(borderColor.rgb, smoothstep(f_thickness, 0.0f, d));\n"

				"fragColor = blend_colors(front, back);\n"
				// todo debugging
				// float resy = 3.0f / f_thickness;

				// if (resy < 539.9f) {
				//     fragColor = vec4(1, 0, 0, 1);
				// }
				// else if (resy > 540.1f) {
				//     fragColor = vec4(0, 1, 0, 1);
				// }
				// else {
				//     fragColor = vec4(0, 0, 1, 1);
				// }
			"}\n";

		JGFX::ShaderProgram sh = { vs, fs };

		using Circle::buff;
	}

	void Init() {
		Point::Init();
		Line::Init();
		Circle::Init();
	}

	void DrawCircle(b2Vec2 center, float radius, b2HexColor color, void* context) {
		rgb converted_color = rgb{ *(uint32*)&color << 8 };
		converted_color.a = 255;

		RenderedData::Circle::sh.SetUniform("projection", LLJ2D::curr_pv);
		RenderedData::Circle::sh.SetUniform("pixelScale", RenderedData::Circle::circle_pixel_scale);

		RenderedData::Circle::sh.SetUniform("position", (pos2df32)JPhys::ConvertToP2D(center));
		RenderedData::Circle::sh.SetUniform("radius", radius);
		RenderedData::Circle::sh.SetUniform("color", (glm::vec4)converted_color);

		JGFX::Draw(RenderedData::Circle::buff, JGFX::NULL_TXT, RenderedData::Circle::sh);
	}
	
	void DrawPoint(b2Vec2 p, float size, b2HexColor color, void* context) {
		rgb converted_color = rgb{ *(uint32*)&color << 8 };
		converted_color.a = 255;

		RenderedData::Point::point_sh.SetUniform("projection", LLJ2D::curr_pv);
		RenderedData::Point::point_sh.SetUniform("pos", (pos2df32)JPhys::ConvertToP2D(p));
		RenderedData::Point::point_sh.SetUniform("size", size);
		RenderedData::Point::point_sh.SetUniform("color", (glm::vec4)converted_color);

		glEnable(GL_PROGRAM_POINT_SIZE);
		{
			LLJGFX::Internal::UnbindBuffers();
			glBindVertexArray(RenderedData::Point::vb.handle().handle);
			glUseProgram(RenderedData::Point::point_sh.handle().data->gpu_handle);

			glDrawArrays(GL_POINTS, 0, 1);

			glBindVertexArray(0);
			LLJGFX::Internal::RebindBoundShader();
		}
		glDisable(GL_PROGRAM_POINT_SIZE);
	}
	void DrawPolygon(const b2Vec2* vertices, int vertexCount, b2HexColor color, void* context) {
		const rgb c_color = rgb{ (uint32)((color << 8) + 0x000000ff) };

		b2Vec2 p1 = vertices[vertexCount - 1];
		for (int i = 0; i < vertexCount; ++i) {
			b2Vec2 p2 = vertices[i];

			RenderedData::Line::DrawLines({ {.pos = *(glm::vec2*)&p1, .color = c_color}, {.pos = *(glm::vec2*)&p2, .color = c_color} });
			//m_lines->AddLine(p1, p2, color);
			p1 = p2;
		}
	}
	void DrawSegment(b2Vec2 p1, b2Vec2 p2, b2HexColor color, void* context) { 
		const rgb c_color = rgb{ (uint32)((color << 8) + 0x000000ff) };
		RenderedData::Line::DrawLines({ {.pos = *(glm::vec2*)&p1, .color = c_color}, {.pos = *(glm::vec2*)&p2, .color = c_color} });
	}
	void DrawSolidCapsule(b2Vec2 p1, b2Vec2 p2, float radius, b2HexColor color, void* context) {
		rgb converted_color = rgb{ *(uint32*)&color << 8 };
		converted_color.a = 255;

		//taken from box2d code
		b2Vec2 d = p2 - p1;
		float length = b2Length(d);
		if (length < 0.001f) {
			printf("WARNING: sample app: capsule too short!\n");
			return;
		}

		b2Vec2 axis = { d.x / length, d.y / length };
		b2Transform transform;
		transform.p = 0.5f * (p1 + p2);
		transform.q.c = axis.x;
		transform.q.s = axis.y;
		//end borrow

		RenderedData::SolidCapsule::sh.SetUniform("projection", LLJ2D::curr_pv);
		RenderedData::SolidCapsule::sh.SetUniform("pixelScale", RenderedData::Circle::circle_pixel_scale);

		RenderedData::SolidCapsule::sh.SetUniform("transform", *(glm::vec4*)&transform);
		RenderedData::SolidCapsule::sh.SetUniform("radius", radius);
		RenderedData::SolidCapsule::sh.SetUniform("length", length);
		RenderedData::SolidCapsule::sh.SetUniform("color", (glm::vec4)converted_color);

		JGFX::Draw(RenderedData::SolidCapsule::buff, JGFX::NULL_TXT, RenderedData::SolidCapsule::sh);
	}
	void DrawSolidCircle(b2Transform transform, float radius, b2HexColor color, void* context) {
		rgb converted_color = rgb{ *(uint32*)&color << 8 };
		converted_color.a = 255;

		RenderedData::SolidCircle::sh.SetUniform("projection", LLJ2D::curr_pv);
		RenderedData::SolidCircle::sh.SetUniform("pixelScale", RenderedData::Circle::circle_pixel_scale);

		RenderedData::SolidCircle::sh.SetUniform("transform", *(glm::vec4*)&transform);
		RenderedData::SolidCircle::sh.SetUniform("radius", radius);
		RenderedData::SolidCircle::sh.SetUniform("color", (glm::vec4)converted_color);

		JGFX::Draw(RenderedData::SolidCircle::buff, JGFX::NULL_TXT, RenderedData::SolidCircle::sh);
	}
	void DrawSolidPolygon(b2Transform transform, const b2Vec2* vertices, int vertex_count, float radius, b2HexColor color, void* context) {
		vertex_count = vertex_count > 8 ? 8 : vertex_count;

		rgb converted_color = rgb{ *(uint32*)&color << 8 };
		converted_color.a = 255;

		RenderedData::SolidPolygon::sh.SetUniform("projection", LLJ2D::curr_pv);
    fmt::println("{}", RenderedData::Circle::circle_pixel_scale);
		RenderedData::SolidPolygon::sh.SetUniform<float>("pixelScale", RenderedData::Circle::circle_pixel_scale);

		RenderedData::SolidPolygon::sh.SetUniform("transform", *(glm::vec4*)&transform);
		RenderedData::SolidPolygon::sh.SetUniform("radius", radius);
		RenderedData::SolidPolygon::sh.SetUniform<glm::vec4>("color", (glm::vec4)converted_color);
		RenderedData::SolidPolygon::sh.SetUniform("point_count", vertex_count);
    
    //glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS); 
    //glDebugMessageCallback(GLDebugMessageCallback, nullptr);
		//b2Vec2* ps = &data.p1;
		{
			int i = 0;
			for (i = 0; i < vertex_count / 2; i++) {
				RenderedData::SolidPolygon::sh.SetUniform(fmt::format("points{}{}", i * 2 + 1, (i + 1) * 2), glm::vec4(*(glm::vec2*)&vertices[i * 2], *(glm::vec2*)&vertices[i * 2 + 1]));
			}

			//i++;
			if(vertex_count % 2)
				RenderedData::SolidPolygon::sh.SetUniform(fmt::format("points{}{}", i * 2 + 1, (i + 1) * 2), glm::vec4(*(glm::vec2*)&vertices[i * 2], glm::vec2{ 0, 0 }));
		}

		JGFX::Draw(RenderedData::SolidPolygon::buff, JGFX::NULL_TXT, RenderedData::SolidPolygon::sh);
	}
	void DrawString(b2Vec2 p, const char* s, b2HexColor color, void* context) {
		fmt::println("Box2d says (at {} {}): {}", p.x, p.y, s);
	}
	void DrawTransform(b2Transform transform, void* context) {
		const float k_axisScale = 0.2f;
		b2Vec2 p1 = transform.p;

		b2Vec2 p2 = b2MulAdd(p1, k_axisScale, b2Rot_GetXAxis(transform.q));
		{
			const rgb color = rgb{ (uint32)((b2_colorRed << 8) + 0x000000ff) };
			RenderedData::Line::DrawLines({ {.pos = *(glm::vec2*)&p1, .color = color}, {.pos = *(glm::vec2*)&p2, .color = color} });
		}
		p2 = b2MulAdd(p1, k_axisScale, b2Rot_GetYAxis(transform.q));
		{
			const rgb color = rgb{ (uint32)((b2_colorGreen << 8) + 0x000000ff) };
			RenderedData::Line::DrawLines({ {.pos = *(glm::vec2*)&p1, .color = color}, {.pos = *(glm::vec2*)&p2, .color = color} });
		}
	}

	b2AABB bounds = { { -FLT_MAX, -FLT_MAX }, { FLT_MAX, FLT_MAX } };
	b2DebugDraw debug_draw = {
		.DrawPolygonFcn = DrawPolygon,
		.DrawSolidPolygonFcn = DrawSolidPolygon,
		.DrawCircleFcn =DrawCircle,
		.DrawSolidCircleFcn = DrawSolidCircle,
		.DrawSolidCapsuleFcn = DrawSolidCapsule,
		.DrawSegmentFcn = DrawSegment,
		.DrawTransformFcn = DrawTransform,
		.DrawPointFcn = DrawPoint,
		.DrawStringFcn = DrawString,

		.drawingBounds = bounds,
		.useDrawingBounds = false,

		.drawShapes = true,
		.drawJoints = true,
		.drawJointExtras = true,
		.drawBounds = false,
		.drawMass = false,
		.drawBodyNames = false,
		.drawContacts = true,
		.drawGraphColors = true,
		.drawContactNormals = false,
		.drawContactImpulses = false,
		.drawContactFeatures = false,
		.drawFrictionImpulses = false,
		.drawIslands = false,
		.context = nullptr
	};
}
/*
void DrawPolygonFcn( const b2Vec2* vertices, int vertexCount, b2HexColor color, void* context ){
	static_cast<Draw*>( context )->DrawPolygon( vertices, vertexCount, color );
}

void DrawSolidPolygonFcn( b2Transform transform, const b2Vec2* vertices, int vertexCount, float radius, b2HexColor color,
						  void* context ){
	static_cast<Draw*>( context )->DrawSolidPolygon( transform, vertices, vertexCount, radius, color );
}

void DrawCircleFcn( b2Vec2 center, float radius, b2HexColor color, void* context ){
	static_cast<Draw*>( context )->DrawCircle( center, radius, color );
}

void DrawSolidCircleFcn( b2Transform transform, float radius, b2HexColor color, void* context ){
	static_cast<Draw*>( context )->DrawSolidCircle( transform, b2Vec2_zero, radius, color );
}

void DrawCapsuleFcn( b2Vec2 p1, b2Vec2 p2, float radius, b2HexColor color, void* context ){
	static_cast<Draw*>( context )->DrawCapsule( p1, p2, radius, color );
}

void DrawSolidCapsuleFcn( b2Vec2 p1, b2Vec2 p2, float radius, b2HexColor color, void* context ){
	static_cast<Draw*>( context )->DrawSolidCapsule( p1, p2, radius, color );
}

void DrawSegmentFcn( b2Vec2 p1, b2Vec2 p2, b2HexColor color, void* context ){
	static_cast<Draw*>( context )->DrawSegment( p1, p2, color );
}

void DrawTransformFcn( b2Transform transform, void* context ){
	static_cast<Draw*>( context )->DrawTransform( transform );
}

void DrawPointFcn( b2Vec2 p, float size, b2HexColor color, void* context ){
	static_cast<Draw*>( context )->DrawPoint( p, size, color );
}

void DrawStringFcn( b2Vec2 p, const char* s, void* context ){
	static_cast<Draw*>( context )->DrawString( p, s );
}



// This class implements Box2D debug drawing callbacks
class Draw {
public:
	Draw();
	~Draw();

	void Create();
	void Destroy();

	void DrawPolygon(const b2Vec2* vertices, int32_t vertexCount, b2HexColor color);
	void DrawSolidPolygon(b2Transform transform, const b2Vec2* vertices, int32_t vertexCount, float radius, b2HexColor color);

	void DrawCircle(b2Vec2 center, float radius, b2HexColor color);
	void DrawSolidCircle(b2Transform transform, b2Vec2 center, float radius, b2HexColor color);

	void DrawCapsule(b2Vec2 p1, b2Vec2 p2, float radius, b2HexColor color);
	void DrawSolidCapsule(b2Vec2 p1, b2Vec2 p2, float radius, b2HexColor color);

	void DrawSegment(b2Vec2 p1, b2Vec2 p2, b2HexColor color);

	void DrawTransform(b2Transform transform);

	void DrawPoint(b2Vec2 p, float size, b2HexColor color);

	void DrawString(int x, int y, const char* string, ...);

	void DrawString(b2Vec2 p, const char* string, ...);

	void DrawAABB(b2AABB aabb, b2HexColor color);

	void Flush();
	void DrawBackground();

	bool m_showUI;
	struct GLBackground* m_background;
	struct GLPoints* m_points;
	struct GLLines* m_lines;
	struct GLTriangles* m_triangles;
	struct GLCircles* m_circles;
	struct GLSolidCircles* m_solidCircles;
	struct GLSolidCapsules* m_solidCapsules;
	struct GLSolidPolygons* m_solidPolygons;
	b2DebugDraw m_debugDraw;
};



Draw::Draw(){
	m_showUI = true;
	m_points = nullptr;
	m_lines = nullptr;
	m_triangles = nullptr;
	m_circles = nullptr;
	m_solidCircles = nullptr;
	m_solidCapsules = nullptr;
	m_solidPolygons = nullptr;
	m_debugDraw = {};
}

Draw::~Draw(){
	assert( m_points == nullptr );
	assert( m_lines == nullptr );
	assert( m_triangles == nullptr );
	assert( m_circles == nullptr );
	assert( m_solidCircles == nullptr );
	assert( m_solidCapsules == nullptr );
	assert( m_solidPolygons == nullptr );
}

void Draw::Create(){
	//m_background = new GLBackground;
	//m_background->Create();
	m_points = new GLPoints;
	m_points->Create();
	m_lines = new GLLines;
	m_lines->Create();
	m_triangles = new GLTriangles;
	m_triangles->Create();
	m_circles = new GLCircles;
	m_circles->Create();
	m_solidCircles = new GLSolidCircles;
	m_solidCircles->Create();
	m_solidCapsules = new GLSolidCapsules;
	m_solidCapsules->Create();
	m_solidPolygons = new GLSolidPolygons;
	m_solidPolygons->Create();

	b2AABB bounds = { { -FLT_MAX, -FLT_MAX }, { FLT_MAX, FLT_MAX } };

	m_debugDraw = { DrawPolygonFcn,
					DrawSolidPolygonFcn,
					DrawCircleFcn,
					DrawSolidCircleFcn,
					DrawCapsuleFcn,
					DrawSolidCapsuleFcn,
					DrawSegmentFcn,
					DrawTransformFcn,
					DrawPointFcn,
					DrawStringFcn,
					bounds,
					false, // drawUsingBounds
					true,  // shapes
					true,  // joints
					false, // joint extras
					false, // aabbs
					false, // mass
					false, // contacts
					false, // colors
					false, // normals
					false, // impulse
					false, // friction
					this };
}

void Draw::Destroy(){
	m_background->Destroy();
	delete m_background;
	m_background = nullptr;

	m_points->Destroy();
	delete m_points;
	m_points = nullptr;

	m_lines->Destroy();
	delete m_lines;
	m_lines = nullptr;

	m_triangles->Destroy();
	delete m_triangles;
	m_triangles = nullptr;

	m_circles->Destroy();
	delete m_circles;
	m_circles = nullptr;

	m_solidCircles->Destroy();
	delete m_solidCircles;
	m_solidCircles = nullptr;

	m_solidCapsules->Destroy();
	delete m_solidCapsules;
	m_solidCapsules = nullptr;

	m_solidPolygons->Destroy();
	delete m_solidPolygons;
	m_solidPolygons = nullptr;
}

void Draw::DrawPolygon( const b2Vec2* vertices, int vertexCount, b2HexColor color ){
	b2Vec2 p1 = vertices[vertexCount - 1];
	for ( int i = 0; i < vertexCount; ++i ){
		b2Vec2 p2 = vertices[i];
		m_lines->AddLine( p1, p2, color );
		p1 = p2;
	}
}

void Draw::DrawSolidPolygon( b2Transform transform, const b2Vec2* vertices, int vertexCount, float radius, b2HexColor color ){
	m_solidPolygons->AddPolygon( transform, vertices, vertexCount, radius, color );
}

void Draw::DrawCircle( b2Vec2 center, float radius, b2HexColor color ){
	m_circles->AddCircle( center, radius, color );
}

void Draw::DrawSolidCircle( b2Transform transform, b2Vec2 center, float radius, b2HexColor color ){
	transform.p = b2TransformPoint( transform, center );
	m_solidCircles->AddCircle( transform, radius, color );
}

// todo this is not used
void Draw::DrawCapsule( b2Vec2 p1, b2Vec2 p2, float radius, b2HexColor color ){
	float length;
	b2Vec2 axis = b2GetLengthAndNormalize( &length, b2Sub( p2, p1 ) );

	if ( length == 0.0f ){
		DrawCircle( p1, radius, color );
	}

	const float k_segments = 16.0f;
	const float k_increment = b2_pi / k_segments;
	float sinInc = sinf( k_increment );
	float cosInc = cosf( k_increment );

	b2Vec2 r1 = { -axis.y, axis.x };
	b2Vec2 v1 = b2MulAdd( p1, radius, r1 );
	b2Vec2 a = v1;
	for ( int i = 0; i < k_segments; ++i ){
		// Perform rotation to avoid additional trigonometry.
		b2Vec2 r2;
		r2.x = cosInc * r1.x - sinInc * r1.y;
		r2.y = sinInc * r1.x + cosInc * r1.y;
		b2Vec2 v2 = b2MulAdd( p1, radius, r2 );
		m_lines->AddLine( v1, v2, color );
		r1 = r2;
		v1 = v2;
	}
	b2Vec2 b = v1;

	r1 = { axis.y, -axis.x };
	v1 = b2MulAdd( p2, radius, r1 );
	b2Vec2 c = v1;
	for ( int i = 0; i < k_segments; ++i ){
		// Perform rotation to avoid additional trigonometry.
		b2Vec2 r2;
		r2.x = cosInc * r1.x - sinInc * r1.y;
		r2.y = sinInc * r1.x + cosInc * r1.y;
		b2Vec2 v2 = b2MulAdd( p2, radius, r2 );
		m_lines->AddLine( v1, v2, color );
		r1 = r2;
		v1 = v2;
	}
	b2Vec2 d = v1;

	m_lines->AddLine( a, d, color );
	m_lines->AddLine( b, c, color );
	m_lines->AddLine( p1, p2, color );
}

void Draw::DrawSolidCapsule( b2Vec2 p1, b2Vec2 p2, float radius, b2HexColor color ){
	m_solidCapsules->AddCapsule( p1, p2, radius, color );
}

void Draw::DrawSegment( b2Vec2 p1, b2Vec2 p2, b2HexColor color ){
	m_lines->AddLine( p1, p2, color );
}

void Draw::DrawTransform( b2Transform transform ){
	const float k_axisScale = 0.2f;
	b2Vec2 p1 = transform.p;

	b2Vec2 p2 = b2MulAdd( p1, k_axisScale, b2Rot_GetXAxis( transform.q ) );
	m_lines->AddLine( p1, p2, b2_colorRed );

	p2 = b2MulAdd( p1, k_axisScale, b2Rot_GetYAxis( transform.q ) );
	m_lines->AddLine( p1, p2, b2_colorGreen );
}

void Draw::DrawPoint( b2Vec2 p, float size, b2HexColor color ){
	m_points->AddPoint( p, size, color );
}

void Draw::DrawString( int x, int y, const char* string, ... ) {
	// if (m_showUI == false)
	//{
	//	return;
	// }

	va_list arg;
	va_start( arg, string );
	ImGui::Begin( "Overlay", nullptr,
				  ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_AlwaysAutoResize |
					  ImGuiWindowFlags_NoScrollbar );
	ImGui::SetCursorPos( ImVec2( float( x ), float( y ) ) );
	ImGui::TextColoredV( ImColor( 230, 153, 153, 255 ), string, arg );
	ImGui::End();
	va_end( arg );
}

void Draw::DrawString( b2Vec2 p, const char* string, ... ){
	b2Vec2 ps = g_camera.ConvertWorldToScreen( p );

	va_list arg;
	va_start( arg, string );
	ImGui::Begin( "Overlay", nullptr,
				  ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_AlwaysAutoResize |
					  ImGuiWindowFlags_NoScrollbar );
	ImGui::SetCursorPos( ImVec2( ps.x, ps.y ) );
	ImGui::TextColoredV( ImColor( 230, 230, 230, 255 ), string, arg );
	ImGui::End();
	va_end( arg );
}

void Draw::DrawAABB( b2AABB aabb, b2HexColor c ) {
	b2Vec2 p1 = aabb.lowerBound;
	b2Vec2 p2 = { aabb.upperBound.x, aabb.lowerBound.y };
	b2Vec2 p3 = aabb.upperBound;
	b2Vec2 p4 = { aabb.lowerBound.x, aabb.upperBound.y };

	m_lines->AddLine( p1, p2, c );
	m_lines->AddLine( p2, p3, c );
	m_lines->AddLine( p3, p4, c );
	m_lines->AddLine( p4, p1, c );
}

void Draw::Flush() {
	m_solidCircles->Flush();
	m_solidCapsules->Flush();
	m_solidPolygons->Flush();
	m_triangles->Flush();
	m_circles->Flush();
	m_lines->Flush();
	m_points->Flush();
	CheckErrorGL();
}*/
