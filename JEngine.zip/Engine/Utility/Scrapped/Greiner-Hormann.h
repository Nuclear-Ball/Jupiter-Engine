#include <JGFX/JGFX.h>

namespace GreinerHormann {
	struct Vertex {
		pos2df32 pos;
		Vertex* next;
		Vertex* prev;
		Vertex* next_poly;
		bool intersect;
		bool entry_exit;
		Vertex* neighbor;
		fl32 alpha;
	};

	struct Polygon {
		std::vector<Vertex> vertices;
	};

	bool Intersect(pos2df32 p1, pos2df32 p2, pos2df32 q1, pos2df32 q2, fl32* alpha_p, fl32* alpha_q) {
		pos2df32 q_normal = { q2.y - q1.y, q1.x - q2.x };
		fl32 p1_wec = glm::dot(q_normal, p1 - q1);
		fl32 p2_wec = glm::dot(q_normal, p2 - q1);

		if (p1_wec * p2_wec <= 0) {
			pos2df32 p_normal = { p2.y - p1.y, p1.x - p2.x };

			fl32 q1_wec = glm::dot(p_normal, q1 - p1);
			fl32 q2_wec = glm::dot(p_normal, q2 - p1);

			if (q1_wec * q2_wec <= 0) {
				*alpha_p = p1_wec / (p1_wec - p2_wec);
				*alpha_q = q1_wec / (q1_wec - q2_wec);

				return true;
			}
		}
		return false;
	}

	void PhaseOne(Polygon& p1, Polygon& p2) {
		assert(p1.vertices.size() >= 3);
		assert(p2.vertices.size() >= 3);

		for (int p1_i = 0; p1_i < p1.vertices.size(); p1_i++) {
			for (int p2_i = 0; p2_i < p2.vertices.size(); p2_i++) {

				fl32 alpha_p = 0;
				fl32 alpha_q = 0;

				bool do_intersect = Intersect(p1.vertices[p1_i].pos, p1.vertices[p1_i + 1].pos, p2.vertices[p2_i].pos, p2.vertices[p2_i + 1].pos, &alpha_p, &alpha_q);


			}
		}
	}
}
namespace Modified {
	enum IntersectionType {                 // types of intersection (detected in the first phase)
		NO_INTERSECTION,
		X_INTERSECTION,
		T_INTERSECTION_Q,
		T_INTERSECTION_P,
		V_INTERSECTION,
		X_OVERLAP,
		T_OVERLAP_Q,
		T_OVERLAP_P,
		V_OVERLAP
	};

	struct Vertex {
		pos2df32 pos;
		Vertex* next;
		Vertex* prev;
		Vertex* next_poly;
		bool intersect;
		bool entry_exit;
		Vertex* neighbor;
		fl32 alpha;
		bool source;
	};
	struct edge {
		Vertex* v1;
		Vertex* v2;
	};

	enum IteratorType {
		SOURCE,
		INTERSECTION,
		CROSSING_INTERSECTION,
		ALL
	};
	class EdgeIterator {
	private:
		class iterator {
		public:
			iterator(Vertex* root, IteratorType IterType) :
				root(root), one(NULL), two(NULL), iterType(IterType)
			{
				if (root == NULL)
					return;

				if (nextEdge() == NULL)           // no source edge found
					root = one = two = NULL;        // -> mark iterator as "end"
			}

			const iterator& operator++() { nextEdge(); return *this; }

			edge operator*() {
				return edge(one, two);
			}

			bool operator!=(const iterator& other) const {
				return (root != other.root) || (one != other.one) || (two != other.two);
			}

		private:
			Vertex* root;
			Vertex* one;
			Vertex* two;
			IteratorType iterType;

			//
			// find the next vertex, starting at curr
			// if iterType is ALL, then it is just the next vertex
			// if iterType is SOURCE, then it is the next source vertex
			//
			Vertex* nextVertex(Vertex* curr) {
				if (curr == NULL)
					return(NULL);

				switch (iterType) {
				case ALL:
					curr = curr->next;
					break;

				case SOURCE:
					do {
						curr = curr->next;
					} while (!curr->source);
					break;
				}

				return(curr);
			}

			//
			// find the next edge
			//
			Vertex* nextEdge() {
				if (root == NULL)                 // empty polygon?
					return (NULL);

				if (one == NULL) {                // find one (source) vertex
					one = root;                     // note: root is always a (source) vertex
					two = nextVertex(one);
					if (two == one)                 // just one (source) vertex
						return(NULL);                 // -> no (source) edges
					return(one);
				}

				if (two == root) {                // back at the root vertex?
					root = one = two = NULL;        // -> mark iterator as "end"
					return(NULL);
				}

				one = two;
				two = nextVertex(one);

				return (one);
			}
		};

	public:
		EdgeIterator() : root(root) {};

		iterator begin() { return iterator(root, iterType); }
		iterator end() { return iterator(NULL, iterType); }

		Vertex* root;
		IteratorType iterType;
	};

	struct Polygon {
		std::vector<Vertex> vertices;

		EdgeIterator& edges(IteratorType iterType) {
			EdgeIterator edge_iter;
			edge_iter.iterType = iterType;
			edge_iter.root = &vertices[0];
			return edge_iter;
		}
	};

	//double Cross(pos2df32 a, pos2df32 b) 
	//	{ return (a.x * b.y - a.y * b.x); }
	inline double A(const pos2df32& P, const pos2df32& Q, const pos2df32& R)
		{ return (Q.x - P.x) * (R.y - P.y) - (Q.y - P.y) * (R.x - P.x); }

	constexpr double EPSILON = 0.0001;

	IntersectionType Intersect(const edge& edgeP, const edge& edgeQ, double& alpha, double& beta) {
		const pos2df32& P1 = edgeP.v1->pos;
		const pos2df32& P2 = edgeP.v2->pos;
		const pos2df32& Q1 = edgeQ.v1->pos;
		const pos2df32& Q2 = edgeQ.v2->pos;

		double AP1 = A(P1, Q1, Q2);
		double AP2 = A(P2, Q1, Q2);

		if (fabs(AP1 - AP2) > EPSILON) {
			// from here: [P1,P2] and [Q1,Q2] are not parallel

			//
			// analyse potential intersection
			//

			double AQ1 = A(Q1, P1, P2);
			double AQ2 = A(Q2, P1, P2);

			// compute alpha and beta
			alpha = AP1 / (AP1 - AP2);
			beta = AQ1 / (AQ1 - AQ2);

			// classify alpha
			bool alpha_is_0 = false;
			bool alpha_in_0_1 = false;

			if ((alpha > EPSILON) && (alpha < 1.0 - EPSILON))
				alpha_in_0_1 = true;
			else
				if (fabs(alpha) <= EPSILON)
					alpha_is_0 = true;

			// classify beta
			bool beta_is_0 = false;
			bool beta_in_0_1 = false;

			if ((beta > EPSILON) && (beta < 1.0 - EPSILON))
				beta_in_0_1 = true;
			else
				if (fabs(beta) <= EPSILON)
					beta_is_0 = true;

			//
				// distinguish intersection types
			//

			if (alpha_in_0_1 && beta_in_0_1)
				return (X_INTERSECTION);

			if (alpha_is_0 && beta_in_0_1)
				return (T_INTERSECTION_Q);

			if (beta_is_0 && alpha_in_0_1)
				return (T_INTERSECTION_P);

			if (alpha_is_0 && beta_is_0)
				return (V_INTERSECTION);
		}
		else
			if (fabs(AP1) < EPSILON) {
				// from here: [P1,P2] and [Q1,Q2] are collinear

				//
				// analyse potential overlap
				//

				pos2df32 dP = P2 - P1;
				pos2df32 dQ = Q2 - Q1;
				pos2df32 PQ = Q1 - P1;

				// compute alpha and beta

				alpha = glm::dot(PQ, dP) / glm::dot(dP, dP);
				beta = -glm::dot(PQ, dQ) / glm::dot(dQ, dQ);

				// classify alpha
				bool alpha_is_0 = false;
				bool alpha_in_0_1 = false;
				bool alpha_not_in_0_1 = false;

				if ((alpha > EPSILON) && (alpha < 1.0 - EPSILON))
					alpha_in_0_1 = true;
				else
					if (fabs(alpha) <= EPSILON)
						alpha_is_0 = true;
					else
						alpha_not_in_0_1 = true;

				// classify beta
				bool beta_is_0 = false;
				bool beta_in_0_1 = false;
				bool beta_not_in_0_1 = false;

				if ((beta > EPSILON) && (beta < 1.0 - EPSILON))
					beta_in_0_1 = true;
				else
					if (fabs(alpha) <= EPSILON)
						beta_is_0 = true;
					else
						beta_not_in_0_1 = true;

				//
					  // distinguish intersection types
				//

				if (alpha_in_0_1 && beta_in_0_1)
					return (X_OVERLAP);

				if (alpha_not_in_0_1 && beta_in_0_1)
					return (T_OVERLAP_Q);

				if (beta_not_in_0_1 && alpha_in_0_1)
					return (T_OVERLAP_P);

				if (alpha_is_0 && beta_is_0)
					return (V_OVERLAP);
			}

		return (NO_INTERSECTION);
	}

	void computeIntersections() {
		//cout << "Computing intersections...\n\n";

		pos2df32 I;
		double alpha;
		double beta;
		Vertex* I_P;
		Vertex* I_Q;

		int count[9] = { 0,0,0,0,0,0,0,0,0 };

		//
		// loop over the source edges of P and Q
		//
		for (polygon& P : PP)
			for (edge edgeP : P.edges(SOURCE))
				for (polygon& Q : QQ)
					for (edge edgeQ : Q.edges(SOURCE)) {
						//
							  // determine intersection or overlap type
						//
						IntersectionType i = intersect(edgeP, edgeQ, alpha, beta);
						count[i]++;

						vertex* P1 = edgeP.one;
						vertex* Q1 = edgeQ.one;

						switch (i) {
							//
							// X-intersection
							//
						case X_INTERSECTION:
							I = (1.0 - alpha) * edgeP.one->p + alpha * edgeP.two->p;
							I_P = new vertex(I, alpha);
							I_Q = new vertex(I, beta);
							insertVertex(I_P, edgeP);
							insertVertex(I_Q, edgeQ);
							link(I_P, I_Q);
							break;

							//
								// X-overlap
								//
						case X_OVERLAP:
							I_Q = new vertex(P1->p, beta);
							insertVertex(I_Q, edgeQ);
							link(P1, I_Q);

							I_P = new vertex(Q1->p, alpha);
							insertVertex(I_P, edgeP);
							link(I_P, Q1);
							break;

							//
							// T-intersection or T_overlap on Q
							//
						case T_INTERSECTION_Q:
						case T_OVERLAP_Q:
							I_Q = new vertex(P1->p, beta);
							insertVertex(I_Q, edgeQ);
							link(P1, I_Q);
							break;

							//
							// T-intersection or T-overlap on P
							//
						case T_INTERSECTION_P:
						case T_OVERLAP_P:
							I_P = new vertex(Q1->p, alpha);
							insertVertex(I_P, edgeP);
							link(I_P, Q1);
							break;

							//
							// V-intersection or V-overlap
							//
						case V_INTERSECTION:
						case V_OVERLAP:
							link(P1, Q1);
							break;
						}
					}

		cout << "... " << count[1] << " non-degenerate and ";
		cout << count[2] + count[3] + count[4] + count[5] + count[6] + count[7] + count[8] << " degenerate intersections found" << endl;
		cout << "       (" << count[2] + count[3] << " T-intersections, ";
		cout << count[4] << " V-intersections,\n        ";
		cout << count[5] << " X-overlaps, ";
		cout << count[6] + count[7] << " T-overlaps, ";
		cout << count[8] << " V-overlaps)" << endl;
		cout << "... " << count[1] + count[5] + count[3] + count[7] << " vertices added to P" << endl;
		cout << "... " << count[1] + count[5] + count[2] + count[6] << " vertices added to Q" << endl;
	}
}