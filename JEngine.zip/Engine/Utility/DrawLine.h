#pragma once
#include <JGFX/JGFX.h>
#include <J2D/J2D.h>

namespace Line {
	JGFX::ShaderProgram flat_sh = {
		LLJ2D::Internal::default_vs,
		"#version 330 core\n"
		"out vec4 FragColor;\n"

		"uniform vec4 color;\n"

		"void main(){\n"
		"    FragColor = color;\n"
		"}"
	};
	JGFX::ShaderProgram circle_sh = { 
		LLJ2D::Internal::default_vs, 
		"#version 330\n"

		"in vec2 TexCoord;\n"

		"uniform vec4 color;\n"
		"uniform float line_thickness;\n"

		"out vec4 FragColor;\n"

		"vec4 blend_colors(vec4 front, vec4 back) {\n"
		"	vec3 cSrc = front.rgb;\n"
		"	float alphaSrc = front.a;\n"
		"	vec3 cDst = back.rgb;\n"
		"	float alphaDst = back.a;\n"

		"	vec3 cOut = cSrc * alphaSrc + cDst * alphaDst * (1.0 - alphaSrc);\n"
		"	float alphaOut = alphaSrc + alphaDst * (1.0 - alphaSrc);\n"
		"	cOut = cOut / alphaOut;\n"

		"	return vec4(cOut, alphaOut);\n"
		"}\n"

		"void main() {\n"
		// radius in unit quad
		"	float radius = 1.0;\n"

		// distance to axis line segment
		//"	vec2 e = vec2(radius, 0);\n"
		//"	vec2 w = f_position;\n"
		//"	float we = dot(w, e);\n"
		//"	vec2 b = w - e * clamp(we / dot(e, e), 0.0, 1.0);\n"
		//"	float da = length(b);\n"

		// distance to circle
		"   vec2 conv_coords = TexCoord * vec2(2.f) - vec2(1);\n" //This is just a workaround, because this shader code is originally taken out of box2d's debug renderer, and it originally was supposed to work with {-1, 1} quads, instead of {0, 1} here

		"	float dw = length(conv_coords) + line_thickness;\n"
		"	float d = abs(dw - radius);\n"

		// union of circle and axis
		//"	float d = min(da, dc);\n"

		"	vec4 border_color = color;\n"
		"	vec4 fill_color = 0.7f * border_color;\n"

		// roll the fill alpha down at the border
		"	vec4 back = vec4(fill_color.rgb, fill_color.a * smoothstep(radius, radius - line_thickness, dw));\n"

		// roll the border alpha down from 1 to 0 across the border thickness
		"	vec4 front = vec4(border_color.rgb, smoothstep(line_thickness, 0.0f, d));\n"

		"	FragColor = blend_colors(front, back);\n"
		"}\n" 
	};


	void DrawSolidCircle(pos2df64 pos, fl32 radius, fl32 border_thickness, rgb color = { 255, 255, 255, 255 }) {
		circle_sh.SetUniform("color", (glm::vec4)color);
		circle_sh.SetUniform("line_thickness", border_thickness / radius);

		J2D::Draw(
			{},
			pos,
			J2D::TransfProps{
				.origin = pos2df64{0.5},
				.scale = pos2df64{radius * 2}
			},
			0.f,
			circle_sh
		);
	}

	void DrawMeshed(pos2df64 start, pos2df64 end, fl32 thickness = 1, rgb color = {255, 255, 255, 255}) {
		const pos2df64 vec = end - start;

		const fl32 angle = acosf(glm::normalize(vec).x) * (vec.y < 0 ? -1 : 1);
		const pos2df64 scale = { glm::length(vec) + thickness, thickness };

		flat_sh.SetUniform("color", (glm::vec4)color);
		J2D::Draw(
			{},
			start, 
			J2D::TransfProps{ 
				.rotation = glm::degrees(angle),
				.origin = pos2df64{thickness / 2.f} / scale, 
				.scale = scale
			}, 
			0.f, 
			flat_sh
		);
	}

	void DrawRect(pos2df64 start, pos2df64 end, fl32 thickness = 1, rgb color = { 255, 255, 255, 255 }) {
		pos2df64 pos1;
		pos2df64 pos2 = start;

		pos1 = pos2, pos2 = { start.x, end.y };
		DrawMeshed(pos1, pos2, thickness, color);

		pos1 = pos2, pos2 = { end.x, end.y };
		DrawMeshed(pos1, pos2, thickness, color);

		pos1 = pos2, pos2 = { end.x, start.y };
		DrawMeshed(pos1, pos2, thickness, color);

		pos1 = pos2, pos2 = { start.x, start.y };
		DrawMeshed(pos1, pos2, thickness, color);
	}
	/*
	
		void Line(pos2d start, pos2d end, int thickness = 1, rgb color = {
			const int ct_x = (end.x - start.x), ct_y = (end.y - start.y);  //������ �������������� ������������ � ��������� � ������ 2� ������ 
			const float l = std::sqrt(std::pow(ct_x, 2) + std::pow(ct_y, 2)); //����������
			const float ct_sin = static_cast<float>(ct_x) / l;  //����� ���� ��� ��������� �������
			constexpr double pi = 3.14159265358979323846;
			const float rotation = std::asinf(ct_sin) * (ct_y >= 0 ? 1 : -1) - (pi / 2) + (ct_y >= 0 ? 0 : pi);  //���� �������� ��������������. ���������� ��� �� ������� ���� ����������� ���������� � ������������.

			const float offset = static_cast<float>(thickness) / 2;

			glm::mat4 model = glm::translate(glm::mat4(1), glm::vec3(static_cast<float>(start.x), static_cast<float>(start.y), 0.0f)); //������� � ������

			//model = glm::translate(model, glm::vec3(offset, offset, 0.0));  //��� �������� ����� ��������
			model = glm::rotate(model, -rotation, glm::vec3(0.0f, 0.0f, 1.0f));	 //���� ��������
			model = glm::translate(model, glm::vec3(-offset, -offset, 0.0));  //����� ������ ��������
			model = glm::scale(model, glm::vec3(l + thickness, static_cast<float>(thickness), 1.0f)); //��� ������������� ������������� ��� ����� �����

			//������
			res.FlatSh().Use();
			res.FlatSh().setMat4("model", model);
			res.FlatSh().setVec4("flat_color", glm::vec4(0.00390625f * static_cast<float>(color.r), 0.00390625f * static_cast<float>(color.g), 0.00390625f * static_cast<float>(color.b), 1.0));

			glBindVertexArray(res.Qd().Handle());
			glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);
		}


		void draw_line(pos2df start, pos2df end, float thickness = 1, rgb color = { 255, 255, 255 }) {
			flat_sh.use();
			const float ct_x = (end.x - start.x), ct_y = (end.y - start.y);
			const float l = sqrt(pow(ct_x, 2) + pow(ct_y, 2));
			const int q_ids[] = { 0, 1, 3, 2 };
			const int quarter = q_ids[(((ct_y < 0) << 1) + (ct_x < 0))];
			const double pi = 3.14159265358979323846;
			const float rotation = (pi / 2) + (asinf(static_cast<float>(ct_x) / l) * (-1.0f * (ct_y >= 0) + 1 * (ct_y < 0)));

			glm::mat4 model = glm::translate(glm::mat4(1), glm::vec3(start.x + ct_x / 2.0f - 0.5f, -(start.y + ct_y / 2.0f + 0.5f), 0.0f));
			model = glm::rotate(model, -rotation, glm::vec3(0.0f, 0.0f, 1.0f));
			model = glm::scale(model, glm::vec3((l + thickness) / 2.0f, static_cast<float>(thickness) / 2.0f, 1.0f));
			flat_sh.setMat4("model", model);
			model = glm::mat4(1);
			flat_sh.setVec4("flat_color", glm::vec4(0.00390625f * static_cast<float>(color.r), 0.00390625f * static_cast<float>(color.g), 0.00390625f * static_cast<float>(color.b), 1.0));
			glBindVertexArray(VAO.VAO);
			glDrawArrays(GL_TRIANGLES, 0, 6);
			txt_sh.use();
		}

	*/
}