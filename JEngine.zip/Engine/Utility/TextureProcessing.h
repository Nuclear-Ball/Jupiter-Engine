#pragma once
#include <vector>
#include <string>
#include <JGFX/JGFX.h>

namespace TextureProcessing {
	struct Cropper {
		pos2du16 pos;
		pos2du16 size;
	};
	
	void MoveTxtElem(std::string& target_texture_data, pos2du16 target_texture_size, pos2du16 target_pos, const std::string& src_texture_data, pos2du16 src_texture_size, pos2du16 src_pos, pos2du16 src_elem_size) {
		assert((target_pos.x + src_elem_size.x) <= target_texture_size.x && (target_pos.y + src_elem_size.y) <= target_texture_size.y); //Must be within range of texture
		assert((src_pos.x + src_elem_size.x) <= src_texture_size.x && (src_pos.y + src_elem_size.y) <= src_texture_size.y);

		assert(target_texture_data.size() == (target_texture_size.x * target_texture_size.y * 4)); //Textures must have a valid size
		assert(src_texture_data.size() == (src_texture_size.x * src_texture_size.y * 4));

		for (int y = 0; y < src_elem_size.y; y++)
			memcpy(&target_texture_data[(target_texture_size.x * (y + target_pos.y) + target_pos.x) * 4], //4 is bytes per pixel
				   &src_texture_data[(src_texture_size.x * (src_pos.y + y) + src_pos.x) * 4],
				   src_elem_size.x * 4);
	}

	std::vector<Cropper> GenerateCroplist(pos2du16 atlas_size, int n, pos2du16 element_size = { 16, 16 }, 
										   pos2du16 start_pos = { 0, 0 }, int horisontal_spacing = 0, 
										   int vertical_spacing = 0) {
		pos2du16 offset = start_pos;
		std::vector<Cropper> croplist;
		croplist.reserve(n);

		for (int i = 0; i < n; i++) {
			if (offset.x + element_size.x <= atlas_size.x && offset.y + element_size.y <= atlas_size.y)
				croplist.push_back({ offset, element_size });

			if ((offset.x + element_size.x + horisontal_spacing + element_size.x <= atlas_size.x) && (offset.y + element_size.y <= atlas_size.y))
				offset.x += (element_size.x + horisontal_spacing);
			else if ((offset.x + element_size.x + horisontal_spacing + element_size.x > atlas_size.x) && (offset.y + element_size.y + vertical_spacing + element_size.y <= atlas_size.y) && (start_pos.x + element_size.x <= atlas_size.x))
				offset.x = start_pos.x, offset.y += (element_size.y + vertical_spacing);
			else break;
		}
		return croplist;
	}

	std::vector<std::string> CropFromCroplist(const std::string& texture_src, pos2du16 atlas_size, const std::vector<Cropper>& croplist) {
		std::vector<std::string> res;
		res.reserve(croplist.size());

		const rgb* src_pixels = (const rgb*)texture_src.data();

		for (const auto& i : croplist) {
			std::string tmp(i.size.x * i.size.y * JGFX::PIXEL_BINARY_SIZE, char(0));

			for (int y = 0; y < i.size.y; y++)
				memcpy(&tmp[(y * i.size.x) * JGFX::PIXEL_BINARY_SIZE], 
					   &src_pixels[(i.pos.y + y) * atlas_size.x + i.pos.x], 
					   i.size.x * JGFX::PIXEL_BINARY_SIZE);
			res.push_back(std::move(tmp));
		}
		return res;
	}
	inline std::vector<std::string> CropFromCroplist(JGFX::Internal::TxtFnArg texture, const std::vector<Cropper>& croplist)
		{ return CropFromCroplist(LLJGFX::Texture::GetData(texture), LLJGFX::Texture::GetSize(texture), croplist); }

	inline std::vector<JGFX::Texture> CropAndLoad(JGFX::Internal::TxtFnArg texture, const std::vector<Cropper>& croplist) {
		auto dat = CropFromCroplist(texture, croplist);
		std::vector<JGFX::Texture> res;
		for (int i = 0; i < croplist.size(); i++)
			res.push_back(JGFX::Texture{ dat[i], croplist[i].size });
		return res;
	}

	pos2df32 TextureCoordsToUv(pos2du16 texture_coords, pos2du16 texture_size) {
		const pos2df32 uv_ratio = pos2df32{ 1.f } / (pos2df32)texture_size;
		return pos2df32{ texture_coords.x, texture_size.y - texture_coords.y } * uv_ratio;
	}

	pos2df32 TextureLocalSizeToUv(pos2du16 local_size, pos2du16 texture_size) {
		const pos2df32 uv_ratio = pos2df32{ 1.f } / (pos2df32)texture_size;
		return (pos2df32)local_size * uv_ratio;
	}
}