#pragma once
#include <box2d/box2d.h>
#include "../LowLevel/Engine.h"

namespace JPhys {
	struct SensorHandleWrap {
		b2ShapeId handle;

		inline bool operator==(const SensorHandleWrap& oth) const {
			return b2StoreShapeId(handle) == b2StoreShapeId(oth.handle);
		}
	};
}

template<>
struct std::hash<JPhys::SensorHandleWrap>{
	std::size_t operator()(const JPhys::SensorHandleWrap& oth) const 
		{ return *(size_t*)&oth.handle; }
};

namespace JPhys {
	std::unordered_map<SensorHandleWrap, std::unordered_map<SensorHandleWrap, int>> active_collisions;

	void UpdateCollisions(b2WorldId world) {
		b2SensorEvents sensor_events = b2World_GetSensorEvents(world);

		for (int i = 0; i < sensor_events.beginCount; i++) {
			b2SensorBeginTouchEvent* begin_touch = sensor_events.beginEvents + i;
			active_collisions[{begin_touch->sensorShapeId}][{begin_touch->visitorShapeId}]++;
			active_collisions[{begin_touch->visitorShapeId}][{begin_touch->sensorShapeId}]++;
		}
		for (int i = 0; i < sensor_events.endCount; i++) {
			b2SensorEndTouchEvent* end_touch = sensor_events.endEvents + i;
			active_collisions[{end_touch->sensorShapeId}][{end_touch->visitorShapeId}]--;
			active_collisions[{end_touch->visitorShapeId}][{end_touch->sensorShapeId}]--;
			
			if (active_collisions[{end_touch->sensorShapeId}][{end_touch->visitorShapeId}] == 0)
				active_collisions[{end_touch->sensorShapeId}].erase({ end_touch->visitorShapeId });
			if (active_collisions[{end_touch->visitorShapeId}][{end_touch->sensorShapeId}] == 0)
				active_collisions[{end_touch->visitorShapeId}].erase({ end_touch->sensorShapeId});
		}
	}

	inline b2Vec2 ConvertToBV(pos2df64 pos) { 
		const pos2df32 tmp = pos;
		return *(b2Vec2*)&tmp; 
	}
	inline pos2df64 ConvertToP2D(b2Vec2 pos) {
		const pos2df32 tmp = { (fl64)((int)(pos.x * 2000.f)) / 2000., (fl64)((int)(pos.y * 2000.f)) / 2000. };
		return (pos2df64)tmp;
	}

	inline fl32 RadFromB2(b2Rot angle)
		{ return b2Rot_GetAngle(angle); }
	inline b2Rot B2FromRad(fl32 angle)
		{ return b2MakeRot(angle); }

	inline fl32 AngleFromB2(b2Rot angle)
		{ return glm::degrees(b2Rot_GetAngle(angle)); }
	inline b2Rot B2FromAngle(fl32 angle)
		{ return b2MakeRot(glm::radians(angle)); }

	inline pos2df64 GetPos(b2BodyId handle) 
		{ return ConvertToP2D(b2Body_GetPosition(handle)); }
	inline fl32 GetRotation(b2BodyId handle)
		{ return AngleFromB2(b2Body_GetRotation(handle)); }
	inline pos2df64 GetLinearVelocity(b2BodyId handle)
		{ return ConvertToP2D(b2Body_GetLinearVelocity(handle)); }
	inline void SetLinearVelocity(b2BodyId handle, pos2df64 velocity)
		{ b2Body_SetLinearVelocity(handle, ConvertToBV(velocity)); }

	inline b2Polygon MakeBoxPolygon(pos2df64 size) 
		{ return b2MakeBox(size.x / 2., size.y / 2.); }

	inline b2Polygon MakeBoxPolygon(pos2df64 size, pos2df64 offset, fl32 angle = 0)
		{ return b2MakeOffsetBox(size.x / 2., size.y / 2., ConvertToBV(offset), b2MakeRot(glm::radians(angle))); }

	inline void ApplyForceToCenter(b2BodyId handle, pos2df64 force, bool wake = true) 
		{ b2Body_ApplyForceToCenter(handle, ConvertToBV(force), wake); }
	inline void ApplyForceToCenterOriented(b2BodyId handle, pos2df64 force, bool wake = true)
		{ ApplyForceToCenter(handle, glm::rotate(force, (fl64)glm::radians(JPhys::GetRotation(handle)))); }
}
