#pragma once
#include "../LowLevel/Scene.h"
#include "../Utility/Phys.h"
#include <box2d/box2d.h>

namespace LLJE {
	namespace PhysScene {
		namespace Component {
			struct Data {
				b2WorldId world = b2_nullWorldId;
				int last_update_frame = 0;
			};

			struct MapIntegrationPreset {
				Data& (*GetSceneData)(Scene::Handle handle) = nullptr;
			};

			namespace Internal {
				std::unordered_map<ScenePreset::Handle, MapIntegrationPreset> presets;
			}
			ScenePreset::Handle IntegratePreset(ScenePreset::Handle parent_preset, const MapIntegrationPreset& preset) {
				assert(ScenePreset::IsValid(parent_preset));
				Internal::presets[parent_preset] = preset;
				return parent_preset;
			}

			void Initialize(Data& dat, b2WorldDef def) {
				dat.world = b2CreateWorld(&def);
			}
			Data Initialize(b2WorldDef def) {
				Data res = { .world = b2CreateWorld(&def) };
				return res;
			}

			void UpdateScene(Data& dat) {
				if (dat.last_update_frame != JGFX::FrameCount()) {
					b2World_Step(dat.world, JGFX::GetDeltaTimeValue(), 8);
					dat.last_update_frame = JGFX::FrameCount();
					JPhys::UpdateCollisions(dat.world);
				}
				dat.last_update_frame = JGFX::FrameCount();
			}
			void Delete(Data& dat) {
				b2DestroyWorld(dat.world);
			}

			b2WorldId GetWorldHandle(Data& dat) {
				return dat.world;
			}
		}

		bool HasThisComponent(ScenePreset::Handle preset) {
			assert(ScenePreset::IsValid(preset));
			return Component::Internal::presets.contains(preset);
		}
		bool HasThisComponent(Scene::Handle scene) {
			assert(Scene::IsValid(scene));
			return Component::Internal::presets.contains(Scene::GetPreset(scene));
		}

		const Component::MapIntegrationPreset& GetPreset(ScenePreset::Handle preset) {
			assert(ScenePreset::IsValid(preset));
			return Component::Internal::presets.find(preset)->second;
		}
		const Component::MapIntegrationPreset& GetPreset(Scene::Handle scene) {
			assert(Scene::IsValid(scene));
			return GetPreset(Scene::GetPreset(scene));
		}

		b2WorldId GetWorldHandle(Scene::Handle handle) {
			assert(HasThisComponent(handle));
			auto& dat = GetPreset(handle).GetSceneData(handle);
			return dat.world;
		}
	}
}