#pragma once
#include <box2d/box2d.h>
#include <JGFX/JGFX.h>
#include "../LowLevel/Engine.h"
//#include "../LowLevel/ChmapImpl.h"
//#include "../Engine/Utility/Phys.h"

namespace JE{
struct ChainShape {
	std::vector<pos2df32> points;
	bool is_loop = false;
};

namespace Mesher {
	//Compare floats while accounting for precision
	inline bool AreTheSame(fl32 a, fl32 b, fl32 epsilon = 0.0001) {
		const fl32 diff = a - b;
		return (diff < epsilon) && (-diff < epsilon);
	}
	inline bool AreTheSame(pos2df32 a, pos2df32 b, fl32 epsilon = 0.0001) {
		return AreTheSame(a.x, b.x, epsilon) && AreTheSame(a.y, b.y, epsilon);
	}

	struct TouchingLineSegments {
		int subj_segment_id = -1;
		int targ_segment_id = -1;

		int subj_start_vertex_id = -1;
		int targ_start_vertex_id = -1;
	};
	inline bool AreCollinear(pos2df32 vec1, pos2df32 vec2) {
		const glm::vec3 cross_product = glm::cross(glm::vec3(vec1, 0), glm::vec3(vec2, 0));
		return AreTheSame(cross_product.x, 0) && AreTheSame(cross_product.y, 0) && AreTheSame(cross_product.z, 0);
	}
	//Should also face the same direction as a line
	bool IsBelongsToLine(pos2df32 l1, pos2df32 l2, pos2df32 point) {
		//Algo:
		//Offset point and l2 by -l1 to form 2 vectors
		//Then check if they are collinear and face in the same direction
		const pos2df32 vec1 = l2 - l1;
		const pos2df32 vec2 = point - l1;

		return AreCollinear(vec1, vec2);
	}
	template<typename T> //Was tested
	void InsertWithOffset(std::vector<T>& to, size_t to_offset, const std::vector<T>& from, size_t from_offset) {
		to.insert(to.begin() + to_offset, from.begin() + from_offset, from.end());
		const size_t first_insertion_end_id = to_offset + (from.size() - from_offset);
		to.insert(to.begin() + first_insertion_end_id, from.begin(), from.begin() + from_offset); //Potential bug here
	}
	template<typename T> //Was tested
	void InsertWithOffsetSize(std::vector<T>& to, size_t to_offset, const std::vector<T>& from, size_t from_offset, size_t from_size) {
		const size_t first_insertion_size = (from_offset + from_size) >= from.size() ? from.size() - from_offset : from_size;
		to.insert(to.begin() + to_offset, from.begin() + from_offset, from.begin() + (from_offset + first_insertion_size));

		if (first_insertion_size != from_size) {
			//const size_t first_insertion_size = from.size() - from_offset;
			const size_t first_insertion_end_id = to_offset + first_insertion_size;
			to.insert(to.begin() + first_insertion_end_id, from.begin(), from.begin() + (from_size - first_insertion_size));
		}
	}

	//TODO: optimize it later
	void AddChainShape(const ChainShape& subj, std::vector<ChainShape>& target_chains) {
		std::vector<TouchingLineSegments> touching;
		//Check all the edges of the segment(it assumes that the segment is a loop)
		for (int subj_vert_id = 0; subj_vert_id < subj.points.size(); subj_vert_id++) {
			const pos2df32 subj_vert1 = subj.points[subj_vert_id];
			const pos2df32 subj_vert2 = subj.points[(subj_vert_id + 1) == subj.points.size() ? 0 : (subj_vert_id + 1)]; //if it reached the end, then loop

			//Then we check it against all of the edges of other, already existing segments(will be called target segments from now on)
			for (int targ_segm_id = 0; targ_segm_id < target_chains.size(); targ_segm_id++) {
				const ChainShape& c_target_segment = target_chains[targ_segm_id];
				for (int targ_vert_id = 0; targ_vert_id < c_target_segment.points.size(); targ_vert_id++) {
					//Actually compare 2 edges

					const pos2df32 targ_vert1 = c_target_segment.points[targ_vert_id];
					const pos2df32 targ_vert2 = c_target_segment.points[(targ_vert_id + 1) == c_target_segment.points.size() ? 0 : (targ_vert_id + 1)]; //if it reached the end, then loop

					//TODO: lines MUST face ONLY in the opposite directions to be recorded
					//Also, lines MUST overlap
					bool is_on_the_same_line = IsBelongsToLine(subj_vert1, subj_vert2, targ_vert1) && IsBelongsToLine(subj_vert1, subj_vert2, targ_vert2);
					bool do_overlap_x = std::min(subj_vert1.x, subj_vert2.x) < std::max(targ_vert1.x, targ_vert2.x)
						&& std::max(subj_vert1.x, subj_vert2.x) > std::min(targ_vert1.x, targ_vert2.x); //min A < max B && max A > min B
					bool do_overlap_y = std::min(subj_vert1.y, subj_vert2.y) < std::max(targ_vert1.y, targ_vert2.y)
						&& std::max(subj_vert1.y, subj_vert2.y) > std::min(targ_vert1.y, targ_vert2.y);

					if (is_on_the_same_line && (do_overlap_x || do_overlap_y)) //The || is to handle degeneracies like for example when the projection on the X axis is 0
						touching.push_back(TouchingLineSegments{ .subj_segment_id = (int)target_chains.size(), .targ_segment_id = targ_segm_id, .subj_start_vertex_id = subj_vert_id, .targ_start_vertex_id = targ_vert_id});
				}
			}
		}//Tested

		//Phase 2: actually combine all the touching segments
		//std::unordered_set<int> modified_segments; //TODO: optimize it later
		target_chains.push_back(std::move(subj));
		for (int touch_elem_id = 0; touch_elem_id < touching.size(); touch_elem_id++) {
			const auto& c_touch_elem = touching[touch_elem_id];

			auto& subj_segment = target_chains[c_touch_elem.subj_segment_id];
			auto& target_segment = target_chains[c_touch_elem.targ_segment_id];

			if (c_touch_elem.targ_segment_id == c_touch_elem.subj_segment_id) {
				//Create a new segment
				//with points from targ_end->subj_start
							//or subj_end->targ_start
				ChainShape new_segm = { .is_loop = true };

				const size_t targ_end_id = ((c_touch_elem.targ_start_vertex_id + 1) == subj_segment.points.size()) ? 0 : (c_touch_elem.targ_start_vertex_id + 1);
				const size_t subj_start = c_touch_elem.subj_start_vertex_id;
				const size_t new_segm_size = ((int)subj_segment.points.size() - (int)targ_end_id + (int)subj_start) % subj_segment.points.size() + 1;
				InsertWithOffsetSize(new_segm.points, 0, subj_segment.points, targ_end_id, new_segm_size); //Tested
				target_chains.push_back(std::move(new_segm));
				const int new_elem_id = target_chains.size() - 1;

				//Creating new elem instead of removing points just to make math work
				ChainShape old_elem;
				const size_t subj_end = ((c_touch_elem.subj_start_vertex_id + 1) == subj_segment.points.size()) ? 0 : (c_touch_elem.subj_start_vertex_id + 1);
				const size_t old_segm_size = subj_segment.points.size() - new_segm_size;
				//from subj_end->targ_start
				InsertWithOffsetSize(old_elem.points, 0, target_chains[c_touch_elem.targ_segment_id].points, subj_end, old_segm_size);
				target_chains[c_touch_elem.targ_segment_id] = std::move(old_elem);

				
				//Update the list
				for (int anoth_t_elem_id = touch_elem_id + 1; anoth_t_elem_id < touching.size(); anoth_t_elem_id++) { //Ill test it later
					auto& elem_to_update = touching[anoth_t_elem_id];

					//Algo to check if points were inside the moved segment:
					//Shift origin of points(including the insertion end), to be insertion start
					//Then compare
					const int new_origin_offset = subj_segment.points.size() - targ_end_id;
					const int shifted_end = (subj_start + new_origin_offset) % subj_segment.points.size();
					{
						//if points were inside of a moved segment
						const int new_shifted_subj_start = (elem_to_update.subj_start_vertex_id + new_origin_offset) % subj_segment.points.size();
						const bool is_subj_start_inside = new_shifted_subj_start <= shifted_end;

						if (is_subj_start_inside) {
							elem_to_update.subj_start_vertex_id = new_shifted_subj_start;
							elem_to_update.subj_segment_id = new_elem_id;
						}
						else {
							//Shift the vertex
							const int old_origin_offset = subj_segment.points.size() - subj_end;
							const int old_shifted_subj_start = (elem_to_update.subj_start_vertex_id + old_origin_offset) % subj_segment.points.size();
							elem_to_update.subj_start_vertex_id = new_shifted_subj_start;
						}
					}

					//Also shift target vertex id if needed
					if (elem_to_update.targ_segment_id == c_touch_elem.subj_segment_id) {
						//if points were inside of a moved segment
						const int new_shifted_targ_start = (elem_to_update.targ_start_vertex_id + new_origin_offset) % subj_segment.points.size();
						const bool is_targ_start_inside = new_shifted_targ_start <= shifted_end;

						if (is_targ_start_inside) {
							elem_to_update.targ_start_vertex_id = new_shifted_targ_start;
							elem_to_update.targ_segment_id = new_elem_id;
						}
						else {
							//Shift the vertex
							const int old_origin_offset = subj_segment.points.size() - subj_end;
							const int old_shifted_subj_start = (elem_to_update.targ_start_vertex_id + old_origin_offset) % subj_segment.points.size();
							elem_to_update.targ_start_vertex_id = new_shifted_targ_start;
						}
					}
				}

				fmt::println("Breakpoint spot");
			}
			else {
				//move the points of the subj segment to the target segment, between touch points, saving the order of points
				//update the touch list after operations

				const size_t targ_start_id = c_touch_elem.targ_start_vertex_id;
				const size_t subj_end_id = ((c_touch_elem.subj_start_vertex_id + 1) == subj_segment.points.size()) ? 0 : (c_touch_elem.subj_start_vertex_id + 1);

				//Attach targ_start->subj_end and targ_end->subj_start
				InsertWithOffset(target_segment.points, c_touch_elem.targ_start_vertex_id + 1, subj_segment.points, subj_end_id);

				//const int new_subj_segment_id = c_touch_elem.targ_segment_id + ((c_touch_elem.targ_segment_id > global_subj_segment_id) ? -1 : 0);

				//Update the list
				for (int anoth_t_elem_id = touch_elem_id + 1; anoth_t_elem_id < touching.size(); anoth_t_elem_id++) {
					auto& elem_to_update = touching[anoth_t_elem_id];

					//if points were after the insertion(on the same segment) - shift ids
					if (elem_to_update.targ_segment_id == c_touch_elem.targ_segment_id && elem_to_update.targ_start_vertex_id > targ_start_id)
						elem_to_update.targ_start_vertex_id += subj_segment.points.size();
					if (elem_to_update.targ_segment_id > c_touch_elem.subj_segment_id) //Account for removing the original subj segment //potential bug here
						elem_to_update.targ_segment_id--;

					//shift subj start id after the merge

					//shift relative to the insertion start
					const size_t insertion_relative_id = (elem_to_update.subj_start_vertex_id + (subj_segment.points.size() - subj_end_id)) % subj_segment.points.size(); //make it so subj_end_id = 0
					elem_to_update.subj_start_vertex_id = c_touch_elem.targ_start_vertex_id + insertion_relative_id + 1;

					if(elem_to_update.subj_segment_id == c_touch_elem.subj_segment_id)
						elem_to_update.subj_segment_id = c_touch_elem.targ_segment_id;

					elem_to_update.subj_segment_id + ((elem_to_update.subj_segment_id > c_touch_elem.subj_segment_id) ? -1 : 0);
				}

				//remove from the list, finishing the merge
				const int old_subj_id = c_touch_elem.subj_segment_id;
				//global_subj_segment_id = c_touch_elem.targ_segment_id + ((c_touch_elem.targ_segment_id > global_subj_segment_id) ? -1 : 0);
				target_chains.erase(target_chains.begin() + old_subj_id);
			}
		}

		//Phase 3: opmimize modified segments(remove unnecesary points)
		for (int c_chain_segment_id = 0; c_chain_segment_id < target_chains.size(); c_chain_segment_id++) {
			ChainShape& c_segm = target_chains[c_chain_segment_id];

			if (c_segm.points.size() < 3) {
				//if points are overlapping - remove elem
				//or also if its just a single point
				if (c_segm.points.size() == 1 || c_segm.points.size() == 0) {
					target_chains.erase(target_chains.begin() + c_chain_segment_id);
					c_chain_segment_id--;
				} else if (c_segm.points.size() == 2 && AreTheSame(c_segm.points[0], c_segm.points[1])) {
					target_chains.erase(target_chains.begin() + c_chain_segment_id);
					c_chain_segment_id--;
				}
				continue;
			}

			//Algo: 
			//  1) pick a base point
			//  2) pick a second point (id = base_p_id + 1)
			//  3) pick a third point (id = base_p_id + 2)
			//  4) if 3 of these points are on the same line
			//		4.1) remove middle point, and make 3rd point 2nd, and pick a new 3rd point and start step 4 again
			//  5) if not
			//		5.1) make second point a starting point and start step 4 again

			int base_point_id = 0;
			do {
				const pos2df32 base_point = c_segm.points[base_point_id];
				int tmp_second_point_id = (base_point_id + 1) >= c_segm.points.size() ? 0 : (base_point_id + 1);
				pos2df32 second_point = c_segm.points[tmp_second_point_id];
				pos2df32 third_point = c_segm.points[(tmp_second_point_id + 1) >= c_segm.points.size() ? 0 : (tmp_second_point_id + 1)];

				while(IsBelongsToLine(base_point, third_point, second_point)){
					c_segm.points.erase(c_segm.points.begin() + tmp_second_point_id);

					tmp_second_point_id = (base_point_id + 1) >= c_segm.points.size() ? 0 : (base_point_id + 1);
					second_point = c_segm.points[tmp_second_point_id];
					third_point = c_segm.points[(tmp_second_point_id + 1) >= c_segm.points.size() ? 0 : (tmp_second_point_id + 1)];
				}

				base_point_id = (base_point_id + 1) >= c_segm.points.size() ? 0 : (base_point_id + 1);
			} while (base_point_id != 0);

			if (c_segm.points.size() == 0 || c_segm.points.size() == 1) {
				target_chains.erase(target_chains.begin() + c_chain_segment_id);
				c_chain_segment_id--;
			}
			//Also if segment does not have points anymore - remove it completely from the list
		}
	}
	void AddChainShape(const ChainShape& src_subj, std::vector<ChainShape>& target_chains, pos2df32 subj_offset) {
		//Translate the segment
		ChainShape subj = src_subj;
		for (auto& i : subj.points)
			i += subj_offset;

		AddChainShape(subj, target_chains);
	}
}
}
