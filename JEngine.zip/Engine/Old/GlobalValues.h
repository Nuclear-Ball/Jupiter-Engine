#pragma once
namespace JE {
	namespace GlobalValues {
		unsigned short frame_counter = 0;
	}
}