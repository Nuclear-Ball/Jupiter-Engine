#pragma once
#include <string>
#include <vector>
#include <unordered_map>

#include "Tilemap.h"
#include "Manager.h"
#include "EngineTexture.h"

#include <JGFX/JGFX.h>
//#include "../Common/Transformations.h"

namespace JE {
	namespace WorldTypes {
		namespace Utils {
			template<typename T> void Resize2dX(std::vector<T>& map, pos2d16 size, short new_x) {
				map.resize(new_x * size.y);

				for (short i = size.y - 1; i >= 0; i--)
					for (short j = size.x - 1; j >= 0; j--)
						std::swap(map[i * new_x + j], map[i * size.x + j]);
			}
		}

		struct Layer {
			bool is_hidden = false;
			float transparency = 1.0f;
			pos2df64 parallax_speed = { 0, 0 };

			//ObjectSystem::ChunkMap objs;
			Tiles::Tilemap tmap;
		};

		struct Room {
			rgb background_color = { 0, 80, 170 };

			AnonymousManager<Layer> layers;
			std::vector<MHandle<Layer>> layer_order;

			//std::unordered_map<unsigned int, Object> objects;
			
			pos2df64 camera_pos = { 0, 0 };
		};

		struct GameResources {
			//AnonymousManager<Tiles::GraphicalTile> tiles;
			//AnonymousManager<
			//Manager<AnimatedSprite> sprites;
		};

		struct Project {
			GameResources global_res;
			AnonymousManager<Room> rooms;

			MHandle<Room> c_room_handle = { nullptr };

			//bool fullscreen = false;
			uint16 screen_height = 256;
		};
	}
}