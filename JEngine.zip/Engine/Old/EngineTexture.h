#pragma once
#include <unordered_map>
#include <JGFX/JGFX.h>
#include "Manager.h"
#include "../Common2d/Transformations.h"
namespace JE{
	struct Sprite {
		MHandle txt_handle;
		Common::TransfProps properties;
		float transparency = 1.f;
	};

	struct Frame : public Sprite{
		float duration = 0;
	};

	class Animation {
	private:
		std::vector<Frame> frames;
	};

	class AnimatedSprite {
	public:
		struct AnimPlayerProperties {
			Handle active_animation_handle = 0;
			Handle current_frame = 0;
			fl32 time_from_the_last_frame = 0.0f;
			bool paused = false;

			void Stop() { *this = {}; }
		};
		Sprite base;
		Manager<Animation> animations;
		AnimPlayerProperties props;

		unsigned int frame_loaded_id = 0; //ID of the frame, in which this sprite was loaded

		Sprite& current_frame() {
			//Play animation
			return base;
		}
	};
}