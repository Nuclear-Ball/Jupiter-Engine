#include <fmt/core.h>
#include <box2d/box2d.h>
#include "Engine/Engine.h"
#include "PSN_Game/Map.h"
#include "PSN_Game/Player.h"

int main() {
	JGFX::Window win = { {600, 600}, "Test" };

	LLJ2D::Init();
	J2D::Cam2D cam = { {600, 600}, {0,0} };

	RenderedData::Init();

	LLJE::Scene::Handle scene = PsnGame::Scene::Make();
	LLJE::Layer::Handle object_layer = PsnGame::MainGameLayer::MakeLayer(scene);

	//----------------------------------PHYSICS---------------------------
	LLJE::Object::Handle player = PsnGame::PlayerObjType::MakePlayer(object_layer, { 0, 5 });

	const JGFX::Texture box = { "../../Engine/box.png", JGFX::TxtFiltMode::NEAREST, JGFX::TxtWrapMode::CLAMP_TO_BORDER };
	b2BodyId ground = b2_nullBodyId;
	const pos2df64 ground_size = { 20, 2 };
	{
		b2BodyDef bodydef = b2DefaultBodyDef();
		bodydef.type = b2_staticBody;
		
		ground = b2CreateBody(PsnGame::Scene::GetPhysHandle(scene), &bodydef);

		b2ShapeDef shape_def = b2DefaultShapeDef();
		shape_def.friction = 0.7;

		b2Polygon box_collision = JPhys::MakeBoxPolygon(ground_size);
		b2CreatePolygonShape(ground, &shape_def, &box_collision);
	}

	JE::ChainShape tile_mesh = { 
		.points = { { 0, 0 }, { 1, 0 }, { 1, 1 }, { 0, 1 } },
		.is_loop = true
	};
	PsnGame::Tile::Handle test = PsnGame::Tile::Make(box.handle(), { tile_mesh });
	PsnGame::MainGameLayer::SetTile(object_layer, test, { 0,1 });
	PsnGame::MainGameLayer::SetTile(object_layer, test, { 1,1 });
	PsnGame::MainGameLayer::SetTile(object_layer, test, { 0,2 });
	
	int subStepCount = 4;
	//---------------------------------PHYSICS END------------------------------------------------

	while (!win.should_close()) {
		JGFX::NewFrame();
		cam.Bind();
		{
			const pos2du16 winsize = win.size();
			const uint16 screen_height = 256;
			const fl64 winsize_screen_ratio = (fl64)winsize.y / (fl64)screen_height;

			const uint16 expected_buffer_size = (uint16)(winsize.x / winsize_screen_ratio);

			if (cam.frm.size().x != expected_buffer_size || cam.frm.size().y != screen_height)
				cam.frm.Resize({ expected_buffer_size, screen_height });
		}
		LLJE::Render(cam, scene);

		//-----------------------------------------------
		{
			cam.Bind();
			J2D::Draw(box, JPhys::GetPos(ground), { JPhys::GetRotation(ground), ground_size, {0.5, 0.5} });
		}
		//---------------------------------------------

		win.SetTitle(std::to_string(JGFX::GetFpsValue()));

		J2D::DisplayFramebuffer(cam.frm, win);

		//Debug draw
		if (glfwGetKey(win.handle().data->win, GLFW_KEY_C)) {
			win.Bind();
			RenderedData::Circle::circle_pixel_scale = J2D::ToMetric(cam.frm.size().y) / (cam.props.scale.y) * 5;
			b2World_Draw(PsnGame::Scene::GetPhysHandle(scene), &RenderedData::debug_draw);
		}
	}
}