#include <fmt/core.h>
#include "Engine/Engine.h"
#include "Cosmonator/Player.h"
#include "Cosmonator/Map.h"
#include "Cosmonator/Resources.h"
#include "Cosmonator/Background.h"
#include <box2d/box2d.h>
#include "Cosmonator/AssemblyParts.h"
#include "Engine/Utility/B2DebugRenderer.h"
#include "GLFW/glfw3.h"
#include "JGFX/Window.h"
#include "box2d/types.h"

//TODO: other todo's in other files
//TODO: orbital view map
//TODO: crafting system
//TODO: orbital simulation(OrbinautEngine)
//TODO: ui system
//TODO: engeneering & blueprints
//TODO: music
//TODO: tech unlocking & fluid simulations
//TODO: factory-like mechanics
//TODO: space stations
//TODO: editor for space stations

int main() {
	JGFX::Window win = { {600, 600}, "Test" };
	LLJ2D::Init();
	RenderedData::Init();
	J2D::Cam2D cam = { {600, 600}, {0,0} };

	LLJE::Scene::Handle scene = Cosmo::Scene::Make({0, -1.15}, { 0, 10, 40, 255 });

	Cosmo::SkyBackground::MakeLayer(scene, Cosmo::space_bg_t.handle(), Cosmo::mask_t.handle(), 0, 1, { 16,16 });
	Cosmo::Background::MakeLayer(scene, Cosmo::bg_far_ts, { 0.9, 0.9 }, J2D::ToMetric({ 0, -48 }));
	Cosmo::Background::MakeLayer(scene, Cosmo::bg_medium_ts, { 0.6, 0.6 }, J2D::ToMetric({ 0, -24 }));
	Cosmo::Background::MakeLayer(scene, Cosmo::bg_close_ts, { 0.3, 0.3 });

	LLJE::Layer::Handle main_layer = Cosmo::MainGameLayer::MakeLayer(scene, Cosmo::main_tset);

	LLJE::Object::Handle player = Cosmo::PlayerObjType::MakePlayer(main_layer, { 0, 15 });
	Cosmo::SceneObj::SmallRock::Make(main_layer, { 2, 10 });
	Cosmo::SceneObj::MediumRock::Make(main_layer, { 3, 10 });
	Cosmo::SceneObj::BigRock::Make(main_layer, { -1, 10 });
	Cosmo::SceneObj::Crater::Make(main_layer, { -3, 10 });

	//glfwSwapInterval(0);

	fl32 avg_fps = JGFX::GetFpsValue();

	auto fuel_tank_blueprint_1 = Cosmo::FuelTank::MakeBlueprint({ .metric_size = {1, 3}, .dry_mass = 5, .capacity = 100 });
	auto fuel_tank_blueprint_2 = Cosmo::FuelTank::MakeBlueprint({ .metric_size = {2, 2.5}, .dry_mass = 5, .capacity = 100 });
	auto engine_blueprint = Cosmo::RocketEngine::MakeBlueprint({ .metric_size = {0.3, 0.5}, .flow_rate = 5, .specific_impulse = 300, .dry_mass = 10 });
     
	auto ft1 = Cosmo::PartObj::Make(main_layer, { 0, 12 }, fuel_tank_blueprint_1);
	auto ft2 = Cosmo::PartObj::Make(main_layer, { 0, 12 }, fuel_tank_blueprint_2);
	auto eng = Cosmo::PartObj::Make(main_layer, {0,8}, engine_blueprint);
	Cosmo::Joint::AttachPart(ft1, { 0, -1.5 }, ft2, { 0, 1.25 });
	Cosmo::Joint::AttachPart(eng, {0, 0.25}, ft2, {0, -1.25});

	//----------------------------------PHYSICS---------------------------
	/*
	const JGFX::Texture player_texture = { "../../../Cosmonator/Player.png", JGFX::TxtFiltMode::NEAREST, JGFX::TxtWrapMode::CLAMP_TO_BORDER };
	Player player;
	{
		b2BodyDef bodydef = b2DefaultBodyDef();
		bodydef.type = b2_dynamicBody;
		bodydef.fixedRotation = true;

		bodydef.position = JPhys::ConvertToBV({ 1, Cosmo::Generation::GetTIleHeight({1,0}) * 0.5 + (J2D::ToMetric(player.size.y)) + 5});//{ (fl32)pos.x, (fl32)pos.y };

		player.phys_handle = b2CreateBody(Cosmo::Phys::bound_world, &bodydef);
		const float radius = (float)player.metric_size.x / 2.f;
		b2Capsule capsule = {{0.f, -(float)(player.metric_size.y / 2. - radius)},
							 {0.f,  (float)(player.metric_size.y / 2. - radius)},
							 radius };

		b2ShapeDef shape_def = b2DefaultShapeDef();
		shape_def.friction = 0.2f;
		b2CreateCapsuleShape(player.phys_handle, &shape_def, &capsule);

		b2Polygon ground_sensor_hitbox = JPhys::MakeBoxPolygon(player.ground_sensor_size, player.ground_sensor_offset, 0);
		b2ShapeDef ground_sensor_def = b2DefaultShapeDef();
		ground_sensor_def.isSensor = true;
		player.ground_sensor_handle = b2CreatePolygonShape(player.phys_handle, &ground_sensor_def, &ground_sensor_hitbox);
		*/
		//b2Body_SetMassData(player.phys_handle, { player.mass, {0,0}, 0/*player.mass*/});
	//}
	/*
	pos2df64 base_rocket_pos = { 0, 15 };

	Cosmo::ProcTempl::Handle engine_templ = Cosmo::ProcTempl::MakeEngine({ 0.5, 1 }, 2, 350, 1);
	Cosmo::Part::PartDef engine_def = { .templ = engine_templ };
	Cosmo::Part::Handle engine = Cosmo::Part::MakePart(engine_def, base_rocket_pos);
	Cosmo::Part::Handle l_engine1 = Cosmo::Part::MakePart(engine_def, base_rocket_pos + pos2df64{ 4, 17 });
	Cosmo::Part::Handle l_engine2 = Cosmo::Part::MakePart(engine_def, base_rocket_pos + pos2df64{ 8, 29 });

	Cosmo::ProcTempl::Handle fuel_tank_templ = Cosmo::ProcTempl::MakeFuelTank({ 2, 1.5 }, 1, 100);
	Cosmo::Part::PartDef fuel_tank_def = { .templ = fuel_tank_templ, .type_specific_data = new Cosmo::Part::FuelTankData{100} };
	Cosmo::Part::Handle fuel_tank = Cosmo::Part::MakePart(fuel_tank_def, base_rocket_pos);

	Cosmo::ProcTempl::Handle fuel_tank_templ2 = Cosmo::ProcTempl::MakeFuelTank({ 3, 2.5 }, 1, 200);
	Cosmo::Part::PartDef fuel_tank_def2 = { .templ = fuel_tank_templ2, .type_specific_data = new Cosmo::Part::FuelTankData{200} };
	Cosmo::Part::Handle fuel_tank2 = Cosmo::Part::MakePart(fuel_tank_def2, base_rocket_pos + pos2df64{ 10, 30 });


	Cosmo::Part::AttachPart(engine, { 0, 0.5 }, fuel_tank, { 0, -0.75 });
	Cosmo::Part::AttachPart(fuel_tank2, { 0, 1.25 }, engine, { 0, -0.5 });
	Cosmo::Part::AttachPart(l_engine1, { 0, 0.5 }, fuel_tank2, { 0.7, -1.25 });
	Cosmo::Part::AttachPart(l_engine2, { 0, 0.5 }, fuel_tank2, { -0.7, -1.25 });

	Cosmo::Part::CacheAssembly(fuel_tank);

	*/
	/*
	{
		Cosmo::Part::assemblies[fuel_tank].is_cache_valid = true;
		Cosmo::Part::assemblies[fuel_tank].trottle = 0.;
		const Cosmo::Part::StageCache cache = { .remaining_fuel = 10 };
		Cosmo::Part::assemblies[fuel_tank].stage_caches = {
			cache//stage #1
		};

		auto& parts = Cosmo::Part::assemblies[fuel_tank].stage_caches[0].parts_of_types;
		parts[Cosmo::ProcTempl::Type::ENGINE] = { engine };
		parts[Cosmo::ProcTempl::Type::FUEL_TANK] = { fuel_tank };
	}*/

	/*
	{
		b2WeldJointDef joint_def = b2DefaultWeldJointDef();
		joint_def.bodyIdA = fuel_tank.data->phys_handle;
		joint_def.bodyIdB = player.phys_handle;

		joint_def.localAnchorA = JPhys::ConvertToBV({0,0.75});
		joint_def.localAnchorB = JPhys::ConvertToBV({0, -0.85});

		joint_def.linearDampingRatio = 1;
		joint_def.angularDampingRatio = 1;

		const auto joint_handle = b2CreateWeldJoint(Cosmo::Phys::bound_world, &joint_def);
	}*/
	
	//int subStepCount = 4;
	//---------------------------------PHYSICS END------------------------------------------------

	while (!win.should_close()) {
		JGFX::NewFrame();
		cam.Bind();
		{
			const pos2du16 winsize = win.size();
			const uint16 screen_height = 256;
			const fl64 winsize_screen_ratio = (fl64)winsize.y / (fl64)screen_height;

			const uint16 expected_buffer_size = (uint16)(winsize.x / winsize_screen_ratio);

			if (cam.frm.size().x != expected_buffer_size || cam.frm.size().y != screen_height)
				cam.frm.Resize({ expected_buffer_size, screen_height });
		}
		LLJE::Render(cam, scene);
		J2D::DisplayFramebuffer(cam.frm, win);
    
    RenderedData::DrawSolidCapsule({0,0}, {1,1}, 1, b2_colorForestGreen, nullptr);
		if (glfwGetKey(win.handle().data->win, GLFW_KEY_C)) {
			win.Bind();
			RenderedData::Circle::circle_pixel_scale = J2D::ToMetric(cam.frm.size().y) / (cam.props.scale.y) * 5;
			b2World_Draw(LLJE::PhysScene::GetWorldHandle(scene), &RenderedData::debug_draw);
		}
		if (glfwGetKey(win.handle().data->win, GLFW_KEY_LEFT_SHIFT)){
			Cosmo::RocketEngine::global_trottle += 0.1 * JGFX::GetDeltaTimeValue();
		}
		if (glfwGetKey(win.handle().data->win, GLFW_KEY_LEFT_CONTROL)){
			Cosmo::RocketEngine::global_trottle += 0.1 * JGFX::GetDeltaTimeValue();
		}

		avg_fps = (avg_fps + JGFX::GetFpsValue()) / 2.f;
		win.SetTitle(fmt::format("FPS: {}", avg_fps));
	}
}
