#include <fmt/core.h>
#include <JGFX/JGFX.h>
#include <box2d/box2d.h>
#include "Editor/Subsystems/ImGuiHelper.h"
#include "Editor/UI_windows.h"
#include "Engine/Engine.h"
#include "PSN_Game/Map.h"
#include "PSN_Game/Player.h"
#include <JSerialUtils.h>

const uint16 editor_version[3] = { 0,1,0 };

int main() {
	//JGFX::Window win = {};
	GuiHelper::Init(Editor::win);
	GuiHelper::InstallFontFromFile(Editor::default_resource_path + "OpenSans-Regular.ttf");

	//ImGui::NewFrame();
	//b2WorldDef world_def = b2DefaultWorldDef();
	//world_def.gravity = { 0, -15 };
	//default_world = b2CreateWorld(&world_def);

	LLJ2D::Init();
	J2D::Cam2D cam = { {600, 600}, {0,0} };

	RenderedData::Init();

	//Editor::Scene::Handle scene = Editor::Scene::Make({ 0, 10, 40, 255 });

	//const JGFX::Texture box = { "../../Engine/box.png", JGFX::TxtFiltMode::NEAREST, JGFX::TxtWrapMode::CLAMP_TO_BORDER };
	//const JGFX::Texture tile_atlas = { "../../tiles.png", JGFX::TxtFiltMode::NEAREST, JGFX::TxtWrapMode::CLAMP_TO_BORDER };
	/*
	JE::ChainShape tile_mesh = {
		.points = { { 0, 0 }, { 1, 0 }, { 1, 1 }, { 0, 1 } },
		.is_loop = true
	};

	Editor::Folder::Handle tileset_save_folder = Editor::Folder::Make("Текстуры тайлов дефолтного тайлсета", Editor::ROOT_FOLDER);
	Editor::Tileset::Handle tset = Editor::Tileset::Make("Idk bro", Editor::ROOT_FOLDER);
	{
		const std::vector<std::string> raw_tile_texture_data = TextureProcessing::CropFromCroplist(
																	tile_atlas, 
																	TextureProcessing::GenerateCroplist(
																		tile_atlas.size(),
																		34
																	)
																);

		for (const auto& i : raw_tile_texture_data) {
			Editor::Tile::Make(
					Editor::Texture::Make(LLJGFX::Texture::Make(i, { 16,16 }), "somerandomahhtxt", tileset_save_folder),
					{ tile_mesh }, 
					tset
			);
		}
	}
	//LLJE::Layer::Handle tile_layer = Editor::Map::MakeLayer(scene);
	*/
	int subStepCount = 8;
	//bool is_editing = true;

	//Editor::active_layer = tile_layer;
	//auto scene = Editor::SceneFile::Make(rgb{ 0, 10, 40, 255 }, "Scene", Editor::ROOT_FOLDER);;

	const auto default_viewport = Editor::Viewport::Open(Editor::File::NULL_FILE);
	const auto default_tile_palette = Editor::TilePalette::Open(Editor::File::NULL_FILE);
	const auto default_file_explorer = Editor::FileExplorer::Open(Editor::ROOT_FOLDER);
	const auto default_scene_layer_editor = Editor::SceneLayerEditor::Open(Editor::File::NULL_FILE);

	JSerial::TemplateSet tmp = { 
		{
			.name = "Version", 
			.fields = {
				{.name = "major", .type = JSerial::NumericType(JSerial::TypeEnum::INT16)},
				{.name = "minor", .type = JSerial::NumericType(JSerial::TypeEnum::INT16)},
				{.name = "patch", .type = JSerial::NumericType(JSerial::TypeEnum::INT16)}
			}
		},
		{
			.name = "Project",
			.fields = {
				{.name = "version", .type = JSerial::Struct("Version")},
				{.name = "filesystem", .type = JSerial::Struct("FilesystemStruct")}
			}
		}
	};
	Editor::FilesystemSerialization::IntegrateFilesystemSerializationTemplates(tmp);
	JSerial::CompiledTemplateSet comp_teml = JSerial::CompileTemplates(tmp);

	//std::string test_serialized_string = "";

	while (!Editor::win.should_close()) {
		JGFX::NewFrame();
		JGFX::Clear({});
		GuiHelper::StartFrame();

		Editor::blink_color = (std::sin(JGFX::GetTime() * 5.) + 1) / 4.f;

		ImGuiID dock_node = ImGui::GetID("Dock node");
		ImGui::DockSpaceOverViewport(dock_node);

		static bool first_time = true;
		if (first_time) {
			ImGui::DockBuilderRemoveNode(dock_node);
			ImGui::DockBuilderAddNode(dock_node, ImGuiDockNodeFlags_DockSpace);

			ImGui::DockBuilderSetNodeSize(dock_node, ImGui::GetMainViewport()->Size);
			ImGui::DockBuilderGetCentralNode(dock_node);

			ImGuiID dock_id_left = ImGui::DockBuilderSplitNode(dock_node, ImGuiDir_Left, 0.34f, nullptr, &dock_node);
			ImGuiID dock_id_right = ImGui::DockBuilderSplitNode(dock_node, ImGuiDir_Right, 0.3f, nullptr, &dock_node);
			ImGuiID dock_id_bottom = ImGui::DockBuilderSplitNode(dock_node, ImGuiDir_Down, 0.4f, nullptr, &dock_node);

			ImGui::DockBuilderDockWindow(Editor::Window::GetName(default_viewport).c_str(), dock_node);
			ImGui::DockBuilderDockWindow(Editor::Window::GetName(default_file_explorer).c_str(), dock_id_bottom);
			ImGui::DockBuilderDockWindow(Editor::Window::GetName(default_tile_palette).c_str(), dock_id_left);
			ImGui::DockBuilderDockWindow(Editor::Window::GetName(default_scene_layer_editor).c_str(), dock_id_right);

			ImGui::DockBuilderFinish(dock_node);

			first_time = false;
		}

		if (ImGui::BeginMainMenuBar()) {
			if (ImGui::BeginMenu("Файл")) {
				if (ImGui::MenuItem("Создать новый")) {
					Editor::File::Delete(Editor::ROOT_FOLDER);
					Editor::ROOT_FOLDER = Editor::Folder::MakeRootFolder();
				}
				if (ImGui::MenuItem("Сохранить как")) {
					nfdu8char_t* out_path;
					nfdu8filteritem_t filters[1] = { { "Проект движка \"Юпитер\"", "jupiterproj" } };
					nfdsavedialogu8args_t args = {};
					args.defaultName = "Без имени";
					args.filterList = filters;
					args.filterCount = 1;
					nfdresult_t result = NFD_SaveDialogU8_With(&out_path, &args);
					if (result == NFD_OKAY) {
						JSerial::SerializedStruct version = JSerial::SerializeStruct("Version", comp_teml, 
							JSerial::Field{ "major", editor_version[0] }, 
							JSerial::Field{ "minor", editor_version[1] }, 
							JSerial::Field{ "patch", (uint16)editor_version[2] }
						);
						auto dat = Editor::FilesystemSerialization::SerializeFileSystem(Editor::ROOT_FOLDER, comp_teml);
						JSerial::SerializedStruct main_struct = JSerial::SerializeStruct("Project", comp_teml, JSerial::Field{ "version", version }, JSerial::Field{ "filesystem", dat });
						auto doc = JSerial::CreateDocument(comp_teml, main_struct);
						//test_serialized_string = doc;

						JSerial::Utilities::SaveFile(out_path, doc);
						NFD_FreePath(out_path);
					}
					else if (result != NFD_CANCEL)
						fmt::println("Error: {}", NFD_GetError());
					//auto doc = JSerial::CreateDocument(comp_teml, dat);

					//Editor::File::Delete(Editor::ROOT_FOLDER);
					
					//auto parsed = JSerial::ParseDocument(doc);
					//auto main_struct = JSerial::GetRootStructure(parsed);
					//Editor::ROOT_FOLDER = Editor::FilesystemSerialization::DeserializeFilesystem(main_struct, parsed);//Editor::Folder::MakeRootFolder();
					//auto parsed_texture_files = JSerial::Deserialize<std::vector<JSerial::ParsedStruct>>(main_struct, parsed, "Texture");
					//auto parsed_file_data = JSerial::Deserialize<JSerial::ParsedStruct>(parsed_texture_files[0], parsed, "file_data");

					//auto txt_data = JSerial::Deserialize<std::string>(parsed_file_data, parsed, "binary_data");

					//fmt::print("Breakpoint spot");
				}
				if (ImGui::MenuItem("Открыть")) {
					nfdu8char_t* out_path;
					nfdu8filteritem_t filters[1] = { { "Проект движка \"Юпитер\"", "jupiterproj" } };
					nfdopendialogu8args_t args = {};
					args.filterList = filters;
					args.filterCount = 1;
					nfdresult_t result = NFD_OpenDialogU8_With(&out_path, &args);
					if (result == NFD_OKAY) {
						auto raw_data = JSerial::Utilities::ReadFile(out_path);
						auto parsed_doc = JSerial::ParseDocument(raw_data);
						auto project_struct = JSerial::GetRootStructure(parsed_doc);

						auto parsed_version = JSerial::Deserialize<JSerial::ParsedStruct>(project_struct, parsed_doc, "version");
						auto d_major = JSerial::Deserialize<uint16>(parsed_version, parsed_doc, "major");
						auto d_minor = JSerial::Deserialize<uint16>(parsed_version, parsed_doc, "minor");

						if (d_major == editor_version[0] && d_minor == editor_version[1]) {
							JSerial::ParsedStruct filesystem_struct = JSerial::Deserialize<JSerial::ParsedStruct>(project_struct, parsed_doc, "filesystem");
							auto new_root = Editor::FilesystemSerialization::DeserializeFilesystem(filesystem_struct, parsed_doc);

							Editor::File::Delete(Editor::ROOT_FOLDER);
							Editor::ROOT_FOLDER = new_root;
						}
						else 
							Editor::ErrorModal::Open(
								fmt::format("Выбранный файл несовместим с выбранной версией редактора \n(Требуется версия {}.{}.X, в то время как версия редактора {}.{}.{})\n\nКонвертируйте файл проекта при помощи специального инструмента", 
									d_major, d_minor, editor_version[0], editor_version[1], editor_version[2]), 
								"Несовместимая версия файла"
							);
						NFD_FreePath(out_path);
					}
					else if (result != NFD_CANCEL)
						fmt::println("Error: {}", NFD_GetError());
				}
				ImGui::EndMenu();
			}
			if (ImGui::BeginMenu("Открыть окно")) {
				if (ImGui::MenuItem("Файловый менеджер"))
					Editor::FileExplorer::Open(Editor::ROOT_FOLDER);
				if (ImGui::MenuItem("Тайловую палитру"))
					Editor::TilePalette::Open(Editor::Tileset::NULL_TSET);
				if (ImGui::MenuItem("Вьюпорт"))
					Editor::Viewport::Open(Editor::SceneFile::NULL_FILE);

				ImGui::EndMenu();
			}
			ImGui::EndMainMenuBar();
		}

		/*
		//---------------------------------------
		if (!is_editing) {
			b2World_Step(default_world, JGFX::GetDeltaTimeValue(), subStepCount);
			cam.center_pos = LLJE::Object::GetPos(player);
			JPhys::UpdateCollisions(default_world);
		}
		if (glfwGetKey(glfwGetCurrentContext(), GLFW_KEY_P)) {
			is_editing = false;
			PlayerObjType::SetPosition(player, { 0, 5 });
			Editor::Map::TransferData(PsnGame::Map::FromLayer(game_tile_layer), Editor::Map::FromLayer(tile_layer));
			PsnGame::Map::SetTile(PsnGame::Map::FromLayer(game_tile_layer), test, { 0,0 });
		}
		if (glfwGetKey(glfwGetCurrentContext(), GLFW_KEY_L)) {
			is_editing = true;
			PlayerObjType::SetPosition(player, { 0, 5 });
		}*/
		//---------------------------------------
		//static bool test_wait = true;
		//if (test_wait) {
		//	if (Editor::Example::CallbackModal::Modal()) {
		//		fmt::println("NO WAAYYY, IT WORRRKED!!!");
		//		test_wait = 0;
		//	}
		//}
		Editor::WindowSystem::UpdateAllWindows();
		//ImGui::ShowDemoWindow();
		//Editor::SliceTexture(Editor::txt);
		//win.SetTitle(fmt::format("Фпс: {}", JGFX::GetFpsValue()));

		GuiHelper::EndFrame();
	}
}