//#include "Engine/LowLevel/Engine.h"
//#include "Engine/LowLevel/ChmapImpl.h"
#include "PSN_Game/Map.h"
#include "Engine/Subsystems/Mesher.h"

int main() {
	
	JE::ChainShape subj = {
		.points = {
			{0,0},
			{1,0},
			{1,1},
			{0,1},
			//{0,0.5}
		},
		.is_loop = true
	};

	JE::ChainShape target = {
		.points = {
			{0,0}, // {0,2}________ {2,2}
			{1,0}, //     |       |
			{1,1}, //     |{1,1}__|
			{2,1}, //     |_____|   {2,1}
			{2,2}, // {0,0}  {1,0}
			{0,2}  //
		},
		.is_loop = true
	};  

	std::vector<JE::ChainShape> polys = { target };

	JE::Mesher::AddChainShape(subj, polys, { 1,0 });
	
	//Insert with offset test:
	//std::vector<int> dest = { 1,2,3,4,5,6 };
	//std::vector<int> src = { 71,72,73,74,75 };

	//PsnGame::Mesher::InsertWithOffsetSize(dest, 2, src, 1, src.size());

	fmt::println("Breakpoint spot");

	/*JGFX::Window win = {{600, 600}, "Test"};
	J2D::Cam2D cam = { {256, 256}, {0,0} };
	LLJ2D::Init();

	LLJE::Scene::Handle scene = LLJE::Scene::Make();

	LLJE::Tilemap::Handle tmap = LLJE::Tilemap::Make();
	LLJE::Tile::Handle tile = LLJE::Tile::Make(LLJGFX::Texture::Make("../../Engine/box.png"));
	LLJE::Tilemap::SetTile(tmap, tile, { 0,0 });
	LLJE::Tilemap::SetTile(tmap, tile, { 1,0 });
	LLJE::Tilemap::SetTile(tmap, tile, { 0,1 });
	LLJE::Layer::Handle layer = LLJE::Layer::Make(LLJE::Tilemap::ToChmap(tmap));
	LLJE::Scene::AddLayerToBack(scene, layer);

	while (!win.should_close()) {
		JGFX::NewFrame();

		LLJE::Render(cam, scene);

		J2D::DisplayFramebuffer(cam.frm, win);
	}*/
}