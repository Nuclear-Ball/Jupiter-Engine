#pragma once
#include <JGFX/JGFX.h>
#include <box2d/box2d.h>

namespace Cosmo {
#ifdef NDEBUG
	const std::string psngame_res_loc = "PSN_Game/";
	const std::string cosmo_res_loc = "Cosmonator/";
#else
	const std::string psngame_res_loc = "../../PSN_Game/";
	const std::string cosmo_res_loc = "../../Cosmonator/Assets/";
//#else
	//const std::string psngame_res_loc = "../PSN_Game/";
	//const std::string cosmo_res_loc = "../Cosmonator/Assets/";
//#endif
#endif
}
