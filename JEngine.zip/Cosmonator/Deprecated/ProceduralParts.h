#pragma once
#include <box2d/box2d.h>
#include "../Engine/LowLevel/Engine.h"
#include <stack>

namespace Cosmo {
	fl64 global_trottle_percent = 1;

	namespace ProcTempl {
		JGFX::Texture nozzle = { "../../../Cosmonator/Nozzle.png" };
		JGFX::Texture fuel_tank = { "../../../Cosmonator/FuelTank.png" };

		enum class Type {
			FUEL_TANK,
			ENGINE,
			DECOUPLER,
			SEALED_MODULE,
			

			SUBPART
		};

		struct FuelTankData {
			fl64 capacity = 0;         //In liters
			//std::vector<TankSegment> segments;
		};
		struct EngineData {
			fl64 specific_impulse = 0;
			//fl64 max_thrust = 0;       //in newtons
			fl64 flow_rate = 0;        //in liters per second
			//fl64 specific_impulse = 0; //in seconds
		};

		struct Data {
			pos2df64 bounding_box_size = { 0, 0 };
			JGFX::Texture texture;
			//Mesh::Handle mesh;

			Type type = Type::FUEL_TANK;
			void* type_specific_data = nullptr;
			fl64 dry_mass = 0; //in kg
			//std::vector<Node> template_nodes;
		};

		namespace Internal {
			const ProcTempl::Data DEFAULT = {};
			JE::AnonymousManager<ProcTempl::Data> manager;
		}

		typedef JE::MHandle<ProcTempl::Data> Handle;
		const Handle NULL_TEMPLATE = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		namespace Internal {
			inline void Validate(Handle handle) {
#ifndef NDEBUG
				if (!IsValid(handle))
					throw std::runtime_error("Requested template does not exists");
#endif
			}
			inline Data& GetTemplate(Handle handle) {
				Validate(handle);
				return manager[handle];
			}
			inline const Data& GetRoTemplate(Handle handle)
				{ return IsValid(handle) ? manager[handle] : DEFAULT; }
		}

		Handle Make(const Data& dat = {}) { return Internal::manager.Add(dat); }
		Handle MakeEngine(pos2df64 size, fl64 mass, fl64 specific_impulse, fl64 flow_rate = 0) 
			{ return Make({ size, nozzle, Type::ENGINE, new EngineData{ specific_impulse, flow_rate}, mass }); }
		Handle MakeFuelTank(pos2df64 size, fl64 mass, fl64 capacity) 
			{ return Make({ size, fuel_tank, Type::FUEL_TANK, new FuelTankData{ capacity }, mass }); }
		//Data& GetEditableData(Handle handle) { return Internal::GetTemplate(handle); }
		const Data& GetData(Handle handle) { return Internal::GetRoTemplate(handle); }

		void Delete(Handle handle) {
			delete Internal::GetTemplate(handle).type_specific_data;
			Internal::manager.Remove(handle);
		}
	}

	namespace Part {
		struct FuelTankData {
			fl64 amount_of_fuel = 0; //must be less than a capacity in a template
		};
		struct EngineData {
			bool is_active = false;
		};

		namespace Internal {
			struct Data;

			struct Joint {
				JE::MHandle<Data> part = { nullptr };
				b2JointId phys_handle = b2_nullJointId;
			};

			struct Data {
				b2BodyId phys_handle = b2_nullBodyId;

				ProcTempl::Handle bound_template = ProcTempl::NULL_TEMPLATE;
				//std::vector<Node> nodes;
				//Template::Handle base_template;

				//std::vector<PartLink> attached_parts;
				void* type_specific_data = nullptr;
				Joint attached_to = {};

				std::vector<JE::MHandle<Data>> attached_parts;
				//std::unordered_set<JE::MHandle<Data>> attached_parts;
				//Data* attached_to = nullptr;

				//fl32 quality = 0; //0 = worst quality(will instantly explode), 1 = best quality
			};

			const Data DEFAULT = {};
			JE::AnonymousManager<Data> manager;
		}

		typedef JE::MHandle<Internal::Data> Handle;
		const Handle NULL_PART = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }
		namespace Internal {
			inline void Validate(Handle handle) {
#ifndef NDEBUG
				if (!IsValid(handle))
					throw std::runtime_error("Requested template does not exists");
#endif
			}
			inline Data& GetData(Handle handle) {
				Validate(handle);
				return manager[handle];
			}
			inline const Data& GetRoData(Handle handle)
				{ return IsValid(handle) ? manager[handle] : DEFAULT; }
		}

		struct StageCache {
			std::unordered_map<ProcTempl::Type, std::vector<Handle>> parts_of_types;
			fl64 remaining_fuel = 0;
		};
		struct HeadData {
			Handle head_part = NULL_PART;

			std::vector<StageCache> stage_caches;
			bool is_cache_valid = false;
			//Assembly params
			fl32 trottle = 0;
		};
		std::unordered_map<Handle, HeadData> assemblies;

		struct PartDef {
			ProcTempl::Handle templ = ProcTempl::NULL_TEMPLATE;
			void* type_specific_data = nullptr;
			//fl32 quality = 0;
		};

		Handle MakePart(const PartDef& def, pos2df64 pos = { 0, 0 }) {
			Internal::Data dat = { .bound_template     = def.templ, 
								   .type_specific_data = def.type_specific_data };

			const auto& templ = ProcTempl::GetData(dat.bound_template);

			b2BodyDef bodydef = b2DefaultBodyDef();
			bodydef.type = b2_dynamicBody;

			bodydef.position = JPhys::ConvertToBV(pos);//{ (fl32)pos.x, (fl32)pos.y };

			dat.phys_handle = b2CreateBody(Cosmo::Phys::bound_world, &bodydef);

			b2Polygon collision_box = JPhys::MakeBoxPolygon(templ.bounding_box_size);
			b2ShapeDef collision_box_def = b2DefaultShapeDef();
			collision_box_def.restitution = 0;
			b2CreatePolygonShape(dat.phys_handle, &collision_box_def, &collision_box);

			b2Body_SetMassData(dat.phys_handle, { .mass = (fl32)templ.dry_mass, 
												  .center = {0,0}, 
												  .rotationalInertia = (fl32)(templ.dry_mass * (templ.bounding_box_size.x * templ.bounding_box_size.y)) });

			Handle handle = Internal::manager.Add(dat);
			assemblies.insert({ handle, {handle} });
			return handle;
		}
		Handle MakeEngine(ProcTempl::Handle templ) {
			return MakePart({ .templ = templ, 
							  .type_specific_data = new EngineData{}});
		}
		Handle MakeFuelTank(ProcTempl::Handle templ, fl64 fuel_amount) {
			return MakePart({ .templ = templ, 
							  .type_specific_data = new FuelTankData{fuel_amount}});
		}

		Internal::Data& GetEditableData(Handle handle)
			{ return Internal::GetData(handle); }
		const Internal::Data& GetData(Handle handle)
			{ return Internal::GetRoData(handle); }

		Handle FindHead(Handle handle) {
			Handle head = handle;
			Handle next_node = NULL_PART;
			do {
				const auto& head_dat = Internal::GetRoData(head);
				next_node = head_dat.attached_to.part;
				if (next_node != NULL_PART)
					head = next_node;
			} while (next_node != NULL_PART);

			return head;
		}

		void CacheAssembly(Handle head){
			auto& assembly_data = assemblies.find(head)->second;
			if (assembly_data.is_cache_valid)
				return;

			assembly_data.stage_caches.clear();
			assembly_data.stage_caches.push_back({});

			auto& head_data = Internal::GetData(head);
			auto& head_template = ProcTempl::GetData(head_data.bound_template);
				
			std::stack<int> c_branch_ids;
			c_branch_ids.push(0);
			if (head_template.type == ProcTempl::Type::FUEL_TANK)
				assembly_data.stage_caches[0].remaining_fuel += (*(FuelTankData*)head_data.type_specific_data).amount_of_fuel;
			assembly_data.stage_caches[0].parts_of_types[ProcTempl::GetData(head_data.bound_template).type].push_back(head);

			//c_branch_ids.push(0);

			Handle c_leaf = head;

			while (true) {
				auto& leaf_data = Internal::GetData(c_leaf);
				auto& leaf_template = ProcTempl::GetData(leaf_data.bound_template);

				if (leaf_data.attached_parts.size()) { //If we could go deeper
					c_leaf = leaf_data.attached_parts[c_branch_ids.top()];
					auto& new_leaf_data = Internal::GetData(c_leaf);
					auto& new_leaf_template = ProcTempl::GetData(new_leaf_data.bound_template);

					if (new_leaf_template.type == ProcTempl::Type::FUEL_TANK)
						assembly_data.stage_caches[0].remaining_fuel += (*(FuelTankData*)new_leaf_data.type_specific_data).amount_of_fuel;
					assembly_data.stage_caches[0].parts_of_types[new_leaf_template.type].push_back(c_leaf);
					c_branch_ids.push(0);
				}
				else { //Climb out
					do {
						c_branch_ids.pop();
						c_branch_ids.top()++;
						c_leaf = Internal::GetData(c_leaf).attached_to.part;

						auto& new_leaf_data = Internal::GetData(c_leaf);
						if (c_branch_ids.top() < (new_leaf_data.attached_parts.size()) || c_branch_ids.size() == 1)
							break;
						//int a = 0;
					} while (1);
					if (c_branch_ids.size() == 1)
						break;
				}
			}
			assembly_data.is_cache_valid = true;
			{
				//��������:
				// ���������:
				// -���� ��������, ��������� ����
				//    -��������� ����
				// -�����:
				//    -�������� �� ���� �������, ����� ����� ����� ������� ������� � ������ �����
				//    -���� ��������� �� ��������� ��������, �� ������� �� �����
			}
			/*
			do {
				auto& leaf_data = Internal::GetData(c_leaf);
				auto& leaf_template = ProcTempl::GetData(leaf_data.bound_template);
				assembly_data.stage_caches[0].parts_of_types[leaf_template.type].push_back(c_leaf);

				if (leaf_data.attached_parts.size()) { //If we could go deeper
					c_leaf = leaf_data.attached_parts[0];
					c_branch_ids.push(0);
				}
				else {
					do { //Try to climb to where there are leafs left
						if (leaf_data.attached_to.part != NULL_PART) {
							c_branch_ids.pop();
							c_branch_ids.top()++;
							c_leaf = leaf_data.attached_to.part;
						}
						else return;



						auto& new_data = Internal::GetData(c_leaf);
					} while ((Internal::GetData(c_leaf).attached_parts.size() - 1) > c_branch_ids.top() && (Internal::GetData(c_leaf).attached_to.part != NULL_PART));
				}


			} while (1);*/
		}

		void UpdateAssembly(Handle head){
			//std::stack<std::unordered_map<Handle, HeadData>::iterator> c_branch_ids;
			auto& assembly_data = assemblies.find(head)->second;

			if (!assembly_data.is_cache_valid)
				CacheAssembly(head);//return; //-------------------------TODO: cache stages
			
			for (auto& c_stage : assembly_data.stage_caches) {
				const fl64 old_fuel_level = c_stage.remaining_fuel;
				fl64 spent_fuel = 0;

				if (c_stage.remaining_fuel > 0) {
					for (auto& c_engine_handle : c_stage.parts_of_types[ProcTempl::Type::ENGINE]) {
						auto& c_eng_dat = GetEditableData(c_engine_handle);
						auto& c_template = ProcTempl::GetData(c_eng_dat.bound_template);
						auto& c_eng_template = *(ProcTempl::EngineData*)c_template.type_specific_data;
						
						fl64 fuel_going_to_be_spent = c_eng_template.flow_rate * JGFX::GetDeltaTimeValue() * assembly_data.trottle;
						if (c_stage.remaining_fuel - fuel_going_to_be_spent >= 0) {
							c_stage.remaining_fuel -= fuel_going_to_be_spent;
							spent_fuel += fuel_going_to_be_spent;

							JPhys::ApplyForceToCenterOriented(c_eng_dat.phys_handle, pos2df64{ 0, (c_eng_template.specific_impulse * c_eng_template.flow_rate * 9.8) * assembly_data.trottle });
						}
					}
				}
				for (auto& c_fuel_tank_handle : c_stage.parts_of_types[ProcTempl::Type::FUEL_TANK]) {
					auto& c_dat = GetEditableData(c_fuel_tank_handle);
					auto& c_ft_dat = *(FuelTankData*)c_dat.type_specific_data;
					auto& c_template = ProcTempl::GetData(c_dat.bound_template);

					c_ft_dat.amount_of_fuel -= (c_ft_dat.amount_of_fuel / old_fuel_level * spent_fuel);

					b2Body_SetMassData(c_dat.phys_handle, { .mass = (fl32)(c_template.dry_mass + c_ft_dat.amount_of_fuel), 
															.center = {0,0}, 
															.rotationalInertia = (fl32)c_ft_dat.amount_of_fuel });
				}
			}
			//go down and update parts
		}

		bool AttachPart(Handle base, pos2df64 base_joint_pos, Handle to, pos2df64 to_joint_pos) {
			auto& base_dat = Internal::GetData(base);
			auto& to_dat = Internal::GetData(to);

			if (base_dat.attached_to.part != NULL_PART || base_dat.attached_to.part == to)
				return false;

			b2WeldJointDef joint_def = b2DefaultWeldJointDef();
			joint_def.bodyIdA = base_dat.phys_handle;
			joint_def.bodyIdB = to_dat.phys_handle;

			joint_def.angularDampingRatio = 1;
			joint_def.linearDampingRatio = 1;
			joint_def.linearHertz = 0;
			joint_def.angularHertz = 0;

			joint_def.localAnchorA = JPhys::ConvertToBV(base_joint_pos);
			joint_def.localAnchorB = JPhys::ConvertToBV(to_joint_pos);

			const auto joint_handle = b2CreateWeldJoint(Cosmo::Phys::bound_world, &joint_def);

			base_dat.attached_to = { .part = to, 
									 .phys_handle = joint_handle };
			to_dat.attached_parts.push_back(base);

			assemblies.erase(base);
			assemblies[FindHead(to)].is_cache_valid = false;
			
			return true;
		}
		bool DetachPart(Handle handle) {
			auto& dat = Internal::GetData(handle);
			if (dat.attached_to.part == NULL_PART)
				return false;

			b2DestroyJoint(dat.attached_to.phys_handle);

			//Remove references from the parent part
			auto& att_dat = Internal::GetData(dat.attached_to.part);
			for (int i = 0; i < att_dat.attached_parts.size(); i++) {
				if (att_dat.attached_parts[i] == handle) {
					std::swap(att_dat.attached_parts[i], att_dat.attached_parts.back());
					att_dat.attached_parts.pop_back();
					break;
				}
			}

			Handle assembly_head = FindHead(handle);
			assemblies[assembly_head].is_cache_valid = false;

			dat.attached_to.part = NULL_PART;
			
			assemblies.insert({ handle, {handle} });

			return true;
		}

		void DrawPart(Handle handle) {
			const auto& dat = Internal::GetRoData(handle);
			const auto& part_template = ProcTempl::GetData(dat.bound_template);
			J2D::Draw(part_template.texture, JPhys::GetPos(dat.phys_handle), { JPhys::GetRotation(dat.phys_handle),  part_template.bounding_box_size / J2D::ToMetric(part_template.texture.size()), J2D::ToMetric(part_template.texture.size()) / 2. });
		}

		void DrawAssembly(Handle head) {
			const auto& assembly_data = assemblies.find(head)->second;

			if (!assembly_data.is_cache_valid)
				CacheAssembly(head); //-------------------------TODO: cache stages

			for (const auto& c_stage : assembly_data.stage_caches) {
				for (const auto& c_part_type : c_stage.parts_of_types) {
					for (const auto& c_part_handle : c_part_type.second)
						DrawPart(c_part_handle);
				}
			}
		}
		void DrawAllAssemblies() {
			for (const auto& c_asm : assemblies)
				DrawAssembly(c_asm.first);
		}
	}
}