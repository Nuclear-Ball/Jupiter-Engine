#pragma once
#include "../Engine/Utility/TextureProcessing.h"
#include "../Engine/LowLevel/Tilemap.h"
#include <JGFX/JGFX.h>
#include <PerlinNoise.hpp>
#include <box2d/box2d.h>
#include "Phys.h"

inline constexpr bool ApproximatelyEqual(double a, double b, double epsilon = 0.001)
	{ return ((a - b) < epsilon) && ((b - a) < epsilon); }

namespace Cosmo {
	namespace Generation {
		siv::PerlinNoise rng{ 4801 };

		inline int32 GetTIleHeight(pos2d64 tile_pos) {
			return rng.octave1D_01(tile_pos.x / 20.0, 5) * 15;
		}
	}

	namespace HG {
		//Upper left: |UL|, Upper right: |UR| 
		//Lower left: |LL|, Lower right: |LR|
		//|UL|  |UR|  |LL|  |LR|

		constexpr inline uint8 GetTileId(bool upper_left, bool upper_right, bool lower_left, bool lower_right) {
			return upper_left + (upper_right << 1) + (lower_left << 2) + (lower_right << 3);
		}

		struct CollisionSegments {
			//tile types 
			//           //segments 
			//					    //points
			std::vector<std::vector<std::vector<pos2df64>>> chain_collision_segments;
		};
		CollisionSegments default_collisions = { {
			{},                                  //|__|  |__|  |__|  |__|
			{{{ 0, 0.25 },   { 0.25, 0.5 }}},    //|UL|  |__|  |__|  |__|
			{{{ 0.25, 0.5 }, { 0.5,  0.25 }}},   //|__|  |UR|  |__|  |__|
			{{{ 0, 0.25 },   { 0.5,  0.25 }}},   //|UL|  |UR|  |__|  |__|
			{{{ 0.25, 0 },   { 0,    0.25 }}},   //|__|  |__|  |LL|  |__|
			{{{ 0.25, 0 },   { 0.25, 0.5 } }},   //|UL|  |__|  |LL|  |__|
			{{{ 0.25, 0.5 }, { 0,    0.25 } },
			 {{ 0.25, 0 },   { 0.5,  0.25 }}},   //|__|  |UR|  |LL|  |__|
			{{{ 0.25, 0 },   { 0.5,  0.25 }}},   //|UL|  |UR|  |LL|  |__|

			{{{ 0.5, 0.25 }, { 0.25, 0 }   }},   //|__|  |__|  |__|  |LR|
			{{{ 0, 0.25 },   { 0.25, 0 }    },
			 {{ 0.5, 0.25 }, { 0.25, 0.5 } }},   //|UL|  |__|  |__|  |LR|
			{{{ 0.25, 0.5 }, { 0.25, 0 }  }},    //|__|  |UR|  |__|  |LR|
			{{{ 0, 0.25 },   { 0.25,  0 }  }},   //|UL|  |UR|  |__|  |LR|
			{{{ 0.5, 0.25 }, { 0,    0.25 }}},   //|__|  |__|  |LL|  |LR|
			{{{ 0.5, 0.25 }, { 0.25, 0.5 } }},   //|UL|  |__|  |LL|  |LR|
			{{{ 0.25, 0.5 }, { 0, 0.25 }   }},   //|__|  |UR|  |LL|  |LR|
			{},									 //|UL|  |UR|  |LL|  |__|
		} };

		struct TilesetData {
			std::array<JGFX::Texture, 16> tiles;
			//|__|  |__|  |__|  |__|
			//|UL|  |__|  |__|  |__|
			//|__|  |UR|  |__|  |__|
			//|UL|  |UR|  |__|  |__|
			//|__|  |__|  |LL|  |__|
			//|UL|  |__|  |LL|  |__|
			//|__|  |UR|  |LL|  |__|
			//|UL|  |UR|  |LL|  |__|
			//|__|  |__|  |__|  |LR|
			//|UL|  |__|  |__|  |LR|
			//|__|  |UR|  |__|  |LR|
			//|UL|  |UR|  |__|  |LR|
			//|__|  |__|  |LL|  |LR|
			//|UL|  |__|  |LL|  |LR|
			//|__|  |UR|  |LL|  |LR|
			//|UL|  |UR|  |LL|  |LR|

			const JGFX::Texture& GetTile(bool upper_left, bool upper_right, bool lower_left, bool lower_right) const {
				return tiles[GetTileId(upper_left, upper_right, lower_left, lower_right)];
			}
		};

		TilesetData TsetFromAtlas(JGFX::Internal::TxtFnArg atlas, pos2du16 element_size) {
			const auto& croplist = TextureProcessing::GenerateCroplist(LLJGFX::Texture::GetSize(atlas), 16, element_size);
			const auto& sliced_textures = TextureProcessing::CropFromCroplist(atlas, croplist);
			Cosmo::HG::TilesetData tset = {};
			for (int i = 0; i < 16; i++)
				tset.tiles[i].SetData(sliced_textures[i], element_size);

			return tset;
			//Cosmo::HG::Handle tset_handle = Cosmo::HG::Make(tset);
		}
		const TilesetData DEFAULT_TSET = {};
	}
	namespace Internal {
		JE::AnonymousManager<HG::TilesetData> hg_tsets;
		//PlanetTiles::HalfGridTileset
	}
	namespace HG {
		typedef JE::MHandle<TilesetData> Handle;
		Handle NULL_TSET = { nullptr };
		bool IsValid(Handle handle) { return Internal::hg_tsets.DoesExists(handle); }
	}
	namespace Internal {
		inline void CheckHGTS_Validity(HG::Handle handle) {
#ifndef NDEBUG
			if (!HG::IsValid(handle))
				throw std::runtime_error("Requested mesh does not exists");
#endif
		}
		inline HG::TilesetData& GetHGTS(HG::Handle handle) {
			Internal::CheckHGTS_Validity(handle);
			return hg_tsets[handle];
		}
		inline const HG::TilesetData& GetRoHGTS(HG::Handle handle)
		{
			return handle == HG::NULL_TSET ? HG::DEFAULT_TSET : hg_tsets[handle];
		}
	}
	namespace HG {
		const TilesetData& GetTileset(Handle handle)
			{ return Internal::GetRoHGTS(handle); }
		TilesetData& GetEditableTileset(Handle handle)
			{ return Internal::GetHGTS(handle); }
		void SetTileset(Handle handle, const TilesetData& tset)
			{ Internal::GetHGTS(handle) = tset; }

		void Copy(Handle to, Handle from)
			{ Internal::GetHGTS(to) = Internal::GetRoHGTS(from); }
		Handle Make(const TilesetData& tset = {})
			{ return Internal::hg_tsets.Add(tset); }
		void Delete(Handle handle)
			{ Internal::hg_tsets.Remove(handle); }
	}

	namespace Phys {
		namespace Definitions {
			b2WorldDef MakeWorldDef(pos2df64 gravity) {
				b2WorldDef def = b2DefaultWorldDef();
				def.gravity = JPhys::ConvertToBV(gravity);
				return def;
			}
			b2WorldDef world_def = MakeWorldDef({ 0.0, -1.2 });

			b2BodyDef MakePlanetSurfBodyDef(pos2df64 pos) {
				b2BodyDef def = b2DefaultBodyDef();
				def.type = b2_staticBody;
				def.position = JPhys::ConvertToBV(pos);
				return def;
			}
		}
		const b2WorldId main_world = b2CreateWorld(&Definitions::world_def);
		b2WorldId bound_world = main_world;
	}

	namespace Internal {
		struct HG_TypeSafetyDummy {};

		struct HG_TileRef {
			HG::Handle handle = HG::NULL_TSET;
			uint8 tile_id = 0;
		};
		struct CosmoTmapData {
			HG::Handle base_tset = HG::NULL_TSET;
		};

		struct ChunkData {
			HG::Handle* tiles = nullptr;

			b2BodyId phys_body = b2_nullBodyId;
			std::vector<b2ChainId> chain_handles;
			//b2ChainId bound_chain_handle = b2_nullChainId;

			LLJE::Renderer::LLDrawListData chain_verts;
		};
	}
	namespace PlSurf { //Default tilemap system
		namespace Functions {
			void ChunkConstructor(LLJE::GenericTilemap::FuncTK::ChunkData& dat,
								const LLJE::GenericTilemap::FuncTK::ChunkMetadata& metadata) {

				const pos2du16 chunk_size = LLJE::GenericTilemap::FuncTK::GetChunkSize(metadata.map);
				dat.data = new Internal::ChunkData{};
				Internal::ChunkData& c_dat = *(Internal::ChunkData*)dat.data;


				c_dat.tiles = (HG::Handle*)malloc(sizeof(HG::Handle) * chunk_size.x * chunk_size.y);
				memset(c_dat.tiles, 0, sizeof(HG::Handle) * chunk_size.x * chunk_size.y);

				const Internal::CosmoTmapData& tmap_dat = *(Internal::CosmoTmapData*)LLJE::GenericTilemap::GetAdditionalData(metadata.map);
				const pos2d64 base_chunk_pos = LLJE::GenericTilemap::Convert::TileFromChunk(metadata.pos, chunk_size);
				for (int x = 0; x < chunk_size.x; x++) {
					const int32 row_height = Generation::GetTIleHeight(base_chunk_pos + pos2d64{ x, 0 });
					for (int y = 0; y < chunk_size.y; y++)
						c_dat.tiles[y * chunk_size.x + x] = (y + base_chunk_pos.y <= row_height) ? tmap_dat.base_tset : HG::NULL_TSET;
				}

				const pos2df64 grid_size = LLJE::GenericTilemap::GetGridSize(metadata.map);
				const pos2df64 chunk_metric_pos = LLJE::GenericTilemap::Convert::MetricFromTile(LLJE::GenericTilemap::Convert::TileFromChunk(metadata.pos, chunk_size), grid_size);
				const auto tmp = Phys::Definitions::MakePlanetSurfBodyDef(chunk_metric_pos);
				c_dat.phys_body = b2CreateBody(Phys::bound_world, &tmp);

				c_dat.chain_verts.transforms = LLJ2D::TransfBuff::Make();
			}
			void ChunkCopier(LLJE::GenericTilemap::FuncTK::ChunkData& to, const LLJE::GenericTilemap::FuncTK::ChunkData& from,
							const LLJE::GenericTilemap::FuncTK::ChunkMetadata& to_metadata,
							const LLJE::GenericTilemap::FuncTK::ChunkMetadata& from_metadata) {

				throw std::runtime_error("Chunk copying is not allowed!"); //because of the phys objects
				/*
				const pos2du16 chunk_size = LLJE::GenericTilemap::FuncTK::GetChunkSize(from_metadata.map);
				Internal::ChunkData& c_to_dat = *(Internal::ChunkData*)to.data;
				const Internal::ChunkData& c_from_dat = *(const Internal::ChunkData*)from.data;


				//TODO: copy physic objects
				memcpy(c_to_dat.tiles, c_from_dat.tiles, sizeof(HG::Handle) * chunk_size.x * chunk_size.y);

				for (auto& i : to.cached_draw_lists) {
					LLJ2D::TransfBuff::Delete(i.transforms);
					delete (Internal::HG_TileRef*)i.additional_data;
				}
				to.cached_draw_lists.resize(from.cached_draw_lists.size());
				for (int i = 0; i < from.cached_draw_lists.size(); i++)
					to.cached_draw_lists[i] = { LLJ2D::TransfBuff::Make(from.cached_draw_lists[i].transforms),
												new Internal::HG_TileRef{*(Internal::HG_TileRef*)from.cached_draw_lists[i].additional_data} };
				*/
			}
			void ChunkDeleter(LLJE::GenericTilemap::FuncTK::ChunkData& dat,
							  const LLJE::GenericTilemap::FuncTK::ChunkMetadata& metadata) {

				Internal::ChunkData& c_dat = *(Internal::ChunkData*)dat.data;
				
				free(c_dat.tiles);
				b2DestroyBody(c_dat.phys_body);
				LLJ2D::TransfBuff::Delete(c_dat.chain_verts.transforms);

				delete (Internal::ChunkData*)dat.data;

				for (auto& i : dat.cached_draw_lists) {
					LLJ2D::TransfBuff::Delete(i.transforms);
					delete (Internal::HG_TileRef*)i.additional_data;
				}
			}

			void TileSetter(LLJE::GenericTilemap::FuncTK::TmapFunctorHandle map, pos2d32 chunk_pos, pos2du32 local_tile_pos, const void* tile_data, size_t tile_data_type_hash, const void* additional_data) {
#ifndef NDEBUG
				if (tile_data_type_hash != typeid(HG::Handle).hash_code())
					throw std::runtime_error("Invalid type of tile: supposed to be LLJE::Tile::Handle, but is something else");
#endif
				if (!LLJE::GenericTilemap::FuncTK::DoesChunkExists(map, chunk_pos))
					LLJE::GenericTilemap::FuncTK::MakeChunk(map, chunk_pos);

				LLJE::GenericTilemap::FuncTK::ChunkData& c_chunk = LLJE::GenericTilemap::FuncTK::GetChunk(map, chunk_pos);
				Internal::ChunkData& c_dat = *(Internal::ChunkData*)c_chunk.data;

				c_dat.tiles[LLJE::GenericTilemap::FuncTK::GetChunkSize(map).x * local_tile_pos.y + local_tile_pos.x] = *((HG::Handle*)tile_data);

				if (local_tile_pos.x == 0)
					LLJE::GenericTilemap::FuncTK::InvalidateChunkCache(map, chunk_pos - pos2d32{ 1, 0 });
				if (local_tile_pos.y == 0)
					LLJE::GenericTilemap::FuncTK::InvalidateChunkCache(map, chunk_pos - pos2d32{ 0, 1 });
				if (local_tile_pos.x == 0 && local_tile_pos.y == 0)
					LLJE::GenericTilemap::FuncTK::InvalidateChunkCache(map, chunk_pos - pos2d32{ 1, 1 });
			}
			const void* TileGetter(LLJE::GenericTilemap::FuncTK::TmapFunctorHandle map, pos2d32 chunk_pos, pos2du32 local_tile_pos, size_t tile_data_type_hash) {
#ifndef NDEBUG
				if (tile_data_type_hash != typeid(HG::Handle).hash_code())
					throw std::runtime_error("Invalid type of tile: supposed to be LLJE::Tile::Handle, but is something else");
#endif
				if (!LLJE::GenericTilemap::FuncTK::DoesChunkExists(map, chunk_pos))
					LLJE::GenericTilemap::FuncTK::MakeChunk(map, chunk_pos);

				const LLJE::GenericTilemap::FuncTK::ChunkData& c_chunk = LLJE::GenericTilemap::FuncTK::GetRoChunk(map, chunk_pos);
				Internal::ChunkData& c_dat = *(Internal::ChunkData*)c_chunk.data;

				return (const void*)&c_dat.tiles[16 * local_tile_pos.y + local_tile_pos.x];
			}

			std::vector<LLJE::Renderer::LLDrawListData> ConvertIrDrawList(const std::vector<LLJE::GenericTilemap::FuncTK::IrDrawListElement>& ir_cache) {
				std::vector<LLJE::Renderer::LLDrawListData> res;
				res.reserve(ir_cache.size());

				for (const auto& i : ir_cache) {
					const Internal::HG_TileRef& c_tile = *(Internal::HG_TileRef*)i.additional_data;
					const auto& tile_txt = HG::GetTileset(c_tile.handle).tiles[c_tile.tile_id];

					res.push_back({ i.transforms, tile_txt.handle(), J2D::TransfProps{}.MakeMatrix(tile_txt.size()), 0.f});
				}

				return res;
			}
			std::vector<LLJE::Renderer::LLDrawListData> ChunkCacher(LLJE::GenericTilemap::FuncTK::TmapFunctorHandle map, pos2d32 pos) {
				if (!LLJE::GenericTilemap::FuncTK::DoesChunkExists(map, pos))
					LLJE::GenericTilemap::FuncTK::MakeChunk(map, pos);

				LLJE::GenericTilemap::FuncTK::ChunkData& c_chunk = LLJE::GenericTilemap::FuncTK::GetChunk(map, pos);
				Internal::ChunkData& c_dat = *(Internal::ChunkData*)c_chunk.data;

				if (LLJE::GenericTilemap::FuncTK::IsCacheValid(map, pos)) {
					auto tmp = ConvertIrDrawList(c_chunk.cached_draw_lists);
					//tmp.push_back(c_dat.chain_verts);
					return tmp;
				}


				//cache chunk
				const pos2du16 chunk_size = LLJE::GenericTilemap::FuncTK::GetChunkSize(map);
				const pos2df64 grid_size = LLJE::GenericTilemap::GetGridSize(map);
				
				std::unordered_map<HG::Handle, std::array<std::vector<glm::mat4>, 16>> tmp_cache;
				std::vector<std::vector<pos2df64>> chain_segments;

				const pos2d64 chunk_tile_pos = LLJE::GenericTilemap::Convert::TileFromChunk(pos, chunk_size);

				for (int y = 0; y < chunk_size.y; y++) {
					for (int x = 0; x < chunk_size.x; x++) {
						std::array<pos2du16, 4> tile_points_offsets = {
							pos2du16{0, 1}, //UL
							pos2du16{1, 1}, //UR
							pos2du16{0, 0}, //LL
							pos2du16{1, 0}  //LR
						};

						std::array<HG::Handle, 4> tset_tiles;
						for (int i = 0; i < 4; i++) {
							const pos2du16 loc_tile_pos = pos2du16{ x, y } + tile_points_offsets[i];
							if (loc_tile_pos.x >= chunk_size.x || loc_tile_pos.y >= chunk_size.y)
								tset_tiles[i] = LLJE::GenericTilemap::GetValue<HG::Handle>(map, chunk_tile_pos + (pos2d64)loc_tile_pos);
							else tset_tiles[i] = c_dat.tiles[chunk_size.x * loc_tile_pos.y + loc_tile_pos.x];
						}

						HG::Handle base_tile = HG::NULL_TSET;
						for (auto& i : tset_tiles) {
							if (i != HG::NULL_TSET) {
								base_tile = i;
								break;
							}
						}
						if (base_tile != HG::NULL_TSET) {
							const bool upper_left  = tset_tiles[0] != HG::NULL_TSET;
							const bool upper_right = tset_tiles[1] != HG::NULL_TSET;
							const bool lower_left  = tset_tiles[2] != HG::NULL_TSET;
							const bool lower_right = tset_tiles[3] != HG::NULL_TSET;

							const int c_tile_id = HG::GetTileId(upper_left, upper_right, lower_left, lower_right);
							const pos2df64 tile_pos = { x * grid_size.x + (grid_size.x * 0.5), y * grid_size.y + (grid_size.y * 0.5) };

							tmp_cache[base_tile][c_tile_id].push_back(
										glm::translate(glm::mat4(1), { tile_pos, 0.f }));

							//Collision mesher
							{
								const auto& c_template = HG::default_collisions.chain_collision_segments[c_tile_id];

								for (auto c_template_chain : c_template) {
									for (pos2df64& c_point : c_template_chain)
										c_point += tile_pos;

									int match_begin = -1;
									int match_end = -1;
									//std::vector<int> matches; //max possible size is 2
									for (int c_e_chain_id = 0; c_e_chain_id < chain_segments.size(); c_e_chain_id++) {//auto& c_existing_chain : chain_segments
										auto& c_existing_chain = chain_segments[c_e_chain_id];
										if (c_template_chain[0] == c_existing_chain.back())
											match_begin = c_e_chain_id;
										else if(c_template_chain.back() == c_existing_chain[0])
											match_end = c_e_chain_id;
									}
									int seg_count = (int)(match_begin != -1) + (int)(match_end != -1);
									if (seg_count) {
										//Biased to select Begin Point Match if possible
										auto& first_match = match_begin != -1 ? chain_segments[match_begin] : chain_segments[match_end];
										bool is_first_match_begin = match_begin != -1;

										{
											//auto c_iter = (c_template_chain[0] == first_match.back()) ? first_match.end() : first_match.begin();
											first_match.erase(is_first_match_begin ? (first_match.end() - 1) : first_match.begin());
											first_match.insert(is_first_match_begin ? (first_match.end()) : first_match.begin(), c_template_chain.begin(), c_template_chain.end());
										}

										if(seg_count > 1) {
											//The other segment will always be the end one, because of the First Segment selection bias
											const auto& oth_match_chain = chain_segments[match_end]; 

											first_match.erase(first_match.end() - 1);
											first_match.insert(first_match.end(), oth_match_chain.begin(), oth_match_chain.end());
											
											
											chain_segments.erase(chain_segments.begin() + match_end);
										}
									}
									else
										chain_segments.push_back(c_template_chain);
								}
							}
						}
					}
				}

				//Converting to the standart draw list format
				for (const auto& i : c_chunk.cached_draw_lists) {
					delete (Internal::HG_TileRef*)i.additional_data;
					LLJ2D::TransfBuff::Delete(i.transforms);
				}
				c_chunk.cached_draw_lists.clear();
				c_chunk.cached_draw_lists.reserve(tmp_cache.size());

				for (const auto& i : tmp_cache) {
					if (i.first != HG::NULL_TSET) {
						for (int c_subtile_id = 0; c_subtile_id < 16; c_subtile_id++) {
							if (i.second[c_subtile_id].size())
								c_chunk.cached_draw_lists.push_back({ LLJ2D::TransfBuff::Make(i.second[c_subtile_id], {}), 
																		new Internal::HG_TileRef{i.first, (uint8)c_subtile_id} });
						}
					}
				}

				//Setting phys mesh
				{
					for (auto& i : c_dat.chain_handles)
						b2DestroyChain(i);
					c_dat.chain_handles.clear();
					c_dat.chain_handles.reserve(chain_segments.size());

					std::vector<glm::mat4> point_transforms;

					for (auto& i : chain_segments) {
						b2ChainDef chain_def = b2DefaultChainDef();
						chain_def.friction = 1;
						chain_def.isLoop = false;

						std::vector<pos2df32> tmp;
						tmp.reserve(i.size());
						for (auto c_point : i)
							tmp.push_back(c_point);
						tmp.push_back(tmp.back());
						tmp.insert(tmp.begin(), tmp[0]);
						
						chain_def.points = (b2Vec2*)tmp.data();
						chain_def.count = tmp.size();

						c_dat.chain_handles.push_back(b2CreateChain(c_dat.phys_body, &chain_def));
						
						//Visual markers offsets
						for (const auto& c_point : i)
							point_transforms.push_back(glm::translate(glm::mat4(1), { c_point, 0.f }));
					}
					//LLJ2D::TransfBuff::SetData(c_dat.chain_verts.transforms, point_transforms);
					//c_dat.chain_verts = { c_dat.chain_verts.transforms, marker.handle(), J2D::TransfProps{ 0, {1,1}, J2D::ToMetric(marker.size()) / 2.}.MakeMatrix(marker.size()) };
				}
				
				c_chunk.is_cache_valid = true;

				auto tmp = ConvertIrDrawList(c_chunk.cached_draw_lists);
				//tmp.push_back(c_dat.chain_verts);
				return tmp;
			}

			const LLJE::GenericTilemap::FuncTK::TilemapFuncPreset PRESET = { ChunkConstructor, ChunkDeleter, ChunkCopier, TileSetter, TileGetter , ChunkCacher };
		}

		typedef JE::MHandle<Internal::HG_TypeSafetyDummy> Handle;
		const Handle NULL_HGTMAP = { nullptr };

		inline LLJE::GenericTilemap::Handle GetGenericTmapHandle(Handle handle)
			{ return { (LLJE::Internal::TilemapData*)handle.data }; }
		inline Handle CastGenericHandleToThisHandle(LLJE::GenericTilemap::Handle generic_handle)
			{ return { (Internal::HG_TypeSafetyDummy*)generic_handle.data }; }

		void SetGridSize(Handle handle, pos2df64 size)
			{ LLJE::GenericTilemap::SetGridSize(GetGenericTmapHandle(handle), size); }
		pos2df64 GetGridSize(Handle handle)
			{ return LLJE::GenericTilemap::GetGridSize(GetGenericTmapHandle(handle)); }

		inline bool IsValid(Handle handle)
			{ return LLJE::GenericTilemap::IsValid(GetGenericTmapHandle(handle)); }

		inline void SetTile(Handle handle, HG::Handle tile, pos2d64 pos)
			{ LLJE::GenericTilemap::SetValue(GetGenericTmapHandle(handle), pos, tile); }
		inline HG::Handle GetTile(Handle handle, pos2d64 pos)
			{ return LLJE::GenericTilemap::GetValue<HG::Handle>(GetGenericTmapHandle(handle), pos); }

		inline const Internal::CosmoTmapData& GetTmapData(Handle handle) 
			{ return *(const Internal::CosmoTmapData*)LLJE::GenericTilemap::GetAdditionalData(GetGenericTmapHandle(handle)); }
		inline Internal::CosmoTmapData& GetEditableTmapData(Handle handle)
			{ return *(Internal::CosmoTmapData*)LLJE::GenericTilemap::GetAdditionalData(GetGenericTmapHandle(handle)); }
		inline void SetTmapData(Handle handle, const Internal::CosmoTmapData& dat) 
			{ *(Internal::CosmoTmapData*)LLJE::GenericTilemap::GetAdditionalData(GetGenericTmapHandle(handle)) = dat; }

		inline void Copy(Handle to, Handle from){ 
			LLJE::GenericTilemap::Copy(GetGenericTmapHandle(to), GetGenericTmapHandle(from)); 
			SetTmapData(to, GetTmapData(from));
		}

		inline Handle Make(pos2df64 grid_size = { 1,1 }, pos2du16 chunk_size = { 16,16 }, HG::Handle base_tset = HG::NULL_TSET)
			{ return { (Internal::HG_TypeSafetyDummy*)LLJE::GenericTilemap::Make(grid_size, chunk_size, Functions::PRESET, new Internal::CosmoTmapData{base_tset}).data}; }
		inline Handle Make(Handle from) { 
			Handle handle = { (Internal::HG_TypeSafetyDummy*)LLJE::GenericTilemap::Make(GetGenericTmapHandle(from)).data }; 
			LLJE::GenericTilemap::SetAdditionalData(GetGenericTmapHandle(handle),
				new Internal::CosmoTmapData{ *(Internal::CosmoTmapData*)LLJE::GenericTilemap::GetAdditionalData(GetGenericTmapHandle(handle)) });
		}

		inline void Delete(Handle handle) { 
			delete (Internal::CosmoTmapData*)LLJE::GenericTilemap::GetAdditionalData(GetGenericTmapHandle(handle));
			LLJE::GenericTilemap::Delete(GetGenericTmapHandle(handle)); 
		}
	}

	//namespace PlanetSurfaceMap {

	//}
}