#pragma once
#include "../Engine/Engine.h"
#include <JGFX/JGFX.h>
#include <box2d/box2d.h>
#include "Global.h"

//TODO: fix physics
namespace Cosmo {
	namespace SceneObj {
		namespace GenericRockFunc {
			struct ObjectData {
				b2BodyId phys_handle = b2_nullBodyId;
			};

			::pos2df64 GetPosition(LLJE::Object::Handle instance)
				{ return LLJE::RoundToPixels(JPhys::GetPos(LLJE::Object::GetData<ObjectData>(instance).phys_handle)); }

			void Destroy(LLJE::Object::Handle instance) {
				auto& dat = LLJE::Object::GetData<ObjectData>(instance);
				b2DestroyBody(dat.phys_handle);

				delete (ObjectData*)LLJE::Object::GetDataPtr(instance);
			}

			LLJE::Object::Handle Make(LLJE::Layer::Handle target_layer, ::pos2df64 pos, fl32 mass, pos2df32 size, LLJE::Prefab::Handle prefab) {
				ObjectData* p_data = new ObjectData{};
				{
					b2BodyDef bodydef = b2DefaultBodyDef();
					bodydef.type = b2_dynamicBody;
					bodydef.fixedRotation = false;
					bodydef.position = { (fl32)pos.x, (fl32)pos.y };

					p_data->phys_handle = b2CreateBody(LLJE::PhysScene::GetWorldHandle(LLJE::Layer::GetParentScene(target_layer)), &bodydef);

					b2ShapeDef shape_def = b2DefaultShapeDef();
					shape_def.material.friction = 2.f;
					b2Polygon hitbox = JPhys::MakeBoxPolygon(size);

					b2CreatePolygonShape(p_data->phys_handle, &shape_def, &hitbox);

					b2Body_SetMassData(p_data->phys_handle, { mass, {0,0}, mass * 2 });
				}

				return LLJE::Object::Make(target_layer, prefab, p_data);
			}
		}
		namespace SmallRock {
			namespace Constants {
				const fl32 MASS = 25;
				JGFX::Texture txt = { cosmo_res_loc + "SmallRock.png" };
			}

			using GenericRockFunc::ObjectData;
			namespace Func {
				void Update(LLJE::Object::Handle instance, const LLJE::EngineContext& ctx) {
					auto& dat = LLJE::Object::GetData<ObjectData>(instance);
					LLJE::DrawSprite(Constants::txt, LLJE::Object::GetPos(instance), ctx, { JPhys::GetRotation(dat.phys_handle), {1, 1}, J2D::ToMetric(Constants::txt.size() / (uint16)2) });
				}
			}

			LLJE::Prefab::Handle prefab = LLJE::Prefab::Make({ .Destroy = GenericRockFunc::Destroy, .Update = Func::Update, .GetPosition = GenericRockFunc::GetPosition });

			bool CanBeSpawned(pos2d32 tile_pos, int32(*GetHeight)(int x)) {
				return GetHeight(tile_pos.x - 1) == GetHeight(tile_pos.x) && GetHeight(tile_pos.x) == GetHeight(tile_pos.x + 1) && GetHeight(tile_pos.x) == tile_pos.y;
			}

			LLJE::Object::Handle Make(LLJE::Layer::Handle target_layer, ::pos2df64 pos) 
				{ return GenericRockFunc::Make(target_layer, pos, Constants::MASS, J2D::ToMetric(Constants::txt.size()), prefab); }
		}
		namespace MediumRock {
			namespace Constants {
				const fl32 MASS = 50;
				JGFX::Texture txt = { cosmo_res_loc + "MediumRock.png" };
			}

			using GenericRockFunc::ObjectData;
			namespace Func {
				void Update(LLJE::Object::Handle instance, const LLJE::EngineContext& ctx) {
					auto& dat = LLJE::Object::GetData<ObjectData>(instance);
					LLJE::DrawSprite(Constants::txt, LLJE::Object::GetPos(instance), ctx, { JPhys::GetRotation(dat.phys_handle), {1, 1}, J2D::ToMetric(Constants::txt.size() / (uint16)2) });
				}
			}

			LLJE::Prefab::Handle prefab = LLJE::Prefab::Make({ .Destroy = GenericRockFunc::Destroy, .Update = Func::Update, .GetPosition = GenericRockFunc::GetPosition });

			LLJE::Object::Handle Make(LLJE::Layer::Handle target_layer, ::pos2df64 pos) 
				{ return GenericRockFunc::Make(target_layer, pos, Constants::MASS, J2D::ToMetric(Constants::txt.size()), prefab); }
		}
		namespace BigRock {
			namespace Constants {
				const fl32 MASS = 200;
				JGFX::Texture txt = { cosmo_res_loc + "BigRock.png" };
			}

			using GenericRockFunc::ObjectData;
			namespace Func {
				void Update(LLJE::Object::Handle instance, const LLJE::EngineContext& ctx) {
					auto& dat = LLJE::Object::GetData<ObjectData>(instance);
					LLJE::DrawSprite(Constants::txt, LLJE::Object::GetPos(instance), ctx, { JPhys::GetRotation(dat.phys_handle), {1, 1}, J2D::ToMetric(Constants::txt.size() / (uint16)2) });
				}
			}

			LLJE::Prefab::Handle prefab = LLJE::Prefab::Make({ .Destroy = GenericRockFunc::Destroy, .Update = Func::Update, .GetPosition = GenericRockFunc::GetPosition });

			LLJE::Object::Handle Make(LLJE::Layer::Handle target_layer, ::pos2df64 pos) 
				{ return GenericRockFunc::Make(target_layer, pos, Constants::MASS, J2D::ToMetric(Constants::txt.size()), prefab); }
		}
		namespace Crater {
			namespace Constants {
				const fl32 MASS = 200;
				JGFX::Texture txt = { cosmo_res_loc + "Crater.png" };
			}
			struct ObjectData {
				b2BodyId phys_handle = b2_nullBodyId;
			};
			namespace Func {
				::pos2df64 GetPosition(LLJE::Object::Handle instance)
				{
					return LLJE::RoundToPixels(JPhys::GetPos(LLJE::Object::GetData<ObjectData>(instance).phys_handle));
				}

				void Destroy(LLJE::Object::Handle instance) {
					auto& dat = LLJE::Object::GetData<ObjectData>(instance);
					b2DestroyBody(dat.phys_handle);

					delete (ObjectData*)LLJE::Object::GetDataPtr(instance);
				}
				void Update(LLJE::Object::Handle instance, const LLJE::EngineContext& ctx) {
					auto& dat = LLJE::Object::GetData<ObjectData>(instance);
					LLJE::DrawSprite(Constants::txt, LLJE::Object::GetPos(instance), ctx, { JPhys::GetRotation(dat.phys_handle), {1, 1}, J2D::ToMetric(Constants::txt.size() / (uint16)2) + J2D::ToMetric({0, 2}) });
				}
			}
			LLJE::Prefab::Handle prefab = LLJE::Prefab::Make({ .Destroy = Func::Destroy, .Update = Func::Update, .GetPosition = Func::GetPosition });

			LLJE::Object::Handle Make(LLJE::Layer::Handle target_layer, ::pos2df64 pos) {
				ObjectData* p_data = new ObjectData{};
				{
					b2BodyDef bodydef = b2DefaultBodyDef();
					bodydef.type = b2_dynamicBody;
					bodydef.fixedRotation = false;
					bodydef.position = { (fl32)pos.x, (fl32)pos.y };

					p_data->phys_handle = b2CreateBody(LLJE::PhysScene::GetWorldHandle(LLJE::Layer::GetParentScene(target_layer)), &bodydef);

					b2ShapeDef shape_def = b2DefaultShapeDef();
					shape_def.material.friction = 2.f;

					b2Polygon hitbox = JPhys::MakeBoxPolygon(J2D::ToMetric(Constants::txt.size()));

					b2CreatePolygonShape(p_data->phys_handle, &shape_def, &hitbox);

					b2Body_SetMassData(p_data->phys_handle, { Constants::MASS, {0,0}, 0 });
				}

				return LLJE::Object::Make(target_layer, prefab, p_data);
			}
		}
	}
}
