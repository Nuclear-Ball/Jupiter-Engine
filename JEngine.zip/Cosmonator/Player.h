#pragma once
#include "../Engine/Engine.h"
#include <JGFX/JGFX.h>
#include <box2d/box2d.h>
#include "Global.h"
#include "Map.h"

namespace Cosmo {
	//TODO: improve animations: walk, sprint, jump, object picking
	//TODO: ability to pick up objects
	//TODO: inventory system
	//TODO: alility to mine terrain
	//TODO: interract with objects by right clicking with a mouse
	//TODO: clamp player movement to ground
	//TODO: stuff like coyote timer and key buffering
	//TODO: extended camera(like in Sonic CD)

	namespace PlayerObjType {
		Anim::WalkCycleAnimator::Clip LoadWalkCycle(const std::string& path, pos2du16 frame_size, int amount, fl32 distance_per_cycle) {
			LLJGFX::Texture::Handle atlas = LLJGFX::Texture::Make(path);

			const std::vector<std::string> raw_txts = TextureProcessing::CropFromCroplist(atlas, TextureProcessing::GenerateCroplist(LLJGFX::Texture::GetSize(atlas), amount, frame_size));

			Anim::WalkCycleAnimator::Clip res = {.meters_per_cycle = distance_per_cycle};
			res.frames.reserve(raw_txts.size());

			for (const auto& i : raw_txts)
				res.frames.push_back({i, frame_size});
			LLJGFX::Texture::Delete(atlas);

			return res;
		}
		Anim::LinearRepeatingAnimator::Clip LoadLinearAnimation(const std::string& path, pos2du16 frame_size, int amount, fl32 duration) {
			LLJGFX::Texture::Handle atlas = LLJGFX::Texture::Make(path);

			const std::vector<std::string> raw_txts = TextureProcessing::CropFromCroplist(atlas, TextureProcessing::GenerateCroplist(LLJGFX::Texture::GetSize(atlas), amount, frame_size));

			Anim::LinearRepeatingAnimator::Clip res;
			res.frames.reserve(raw_txts.size());

			for (const auto& i : raw_txts)
				res.frames.push_back({ .frame = { i, frame_size }, .duration = duration });
			LLJGFX::Texture::Delete(atlas);

			return res;
		}

		namespace PlayerConstants {
			const float MASS = 80;

			const JGFX::Texture player_texture = { cosmo_res_loc + "Player.png", JGFX::TxtFiltMode::NEAREST, JGFX::TxtWrapMode::CLAMP_TO_BORDER };
			const pos2d32 size = { 10, 27 };
			const ::pos2df64 metric_size = J2D::ToMetric(size);

			Anim::WalkCycleAnimator::Clip sprint = LoadWalkCycle(cosmo_res_loc + "PlayerSprint.png", { 32,32 }, 8, J2D::ToMetric(40));
			Anim::WalkCycleAnimator::Clip walk = LoadWalkCycle(cosmo_res_loc + "PlayerWalk.png", { 32,32 }, 8, J2D::ToMetric(24));
			Anim::LinearRepeatingAnimator::Clip idle = LoadLinearAnimation(psngame_res_loc + "PixelM_idle.png", { 32,32 }, 6, 0.09);

			const ::pos2df64 ground_sensor_size = { 0.5, 0.3 };
			const ::pos2df64 ground_sensor_offset = { 0, -(metric_size.y / 2.f - 0.05) };

			const fl64 MAX_WALKING_SPEED = 2;
			const fl64 MAX_SPRINT_SPEED = 4;
			const fl64 ACCEL = 16;
			const fl32 JUMP_FORCE = 300;
		}

		struct ObjectData {
			b2BodyId phys_handle = b2_nullBodyId;
			b2ShapeId ground_sensor_handle = b2_nullShapeId;
			b2ShapeId capsule_handle = b2_nullShapeId;
			int ground_sensor_touch_contacts = 0;

			bool is_facing_right = false;

			Anim::WalkCycleAnimator::State walk_cycle_state;
			Anim::WalkCycleAnimator::State sprint_cycle_state;
			Anim::LinearRepeatingAnimator::State idle_anim_state;

			bool was_jump_in_prev_frame = false;
		};

		namespace Func{
			::pos2df64 GetPosition(LLJE::Object::Handle instance) 
				{ return J2D::ToMetric(glm::round(J2D::ToPixels(JPhys::GetPos(LLJE::Object::GetData<ObjectData>(instance).phys_handle)))) + pos2df64{0.001}; }

			void Destroy(LLJE::Object::Handle instance) {
				auto& dat = LLJE::Object::GetData<ObjectData>(instance);
				b2DestroyBody(dat.phys_handle);

				delete (ObjectData*)LLJE::Object::GetDataPtr(instance);
			}

			void Update(LLJE::Object::Handle instance, const LLJE::EngineContext& ctx) {
				auto& dat = LLJE::Object::GetData<ObjectData>(instance);

				{
					std::vector<b2ContactData> contacts(b2Shape_GetContactCapacity(dat.capsule_handle));
					b2Shape_GetContactData(dat.capsule_handle, contacts.data(), (int)contacts.size());
					//TODO: make so ground is detected ONLY from bottom contacts
					dat.ground_sensor_touch_contacts = contacts.size();
					//for(auto& i : contacts){ 
					//}
				}
				//const int touch_contacts = JPhys::active_collisions[{dat.ground_sensor_handle}].size();

				auto c_win = glfwGetCurrentContext();
				const bool sprint = glfwGetKey(c_win, GLFW_KEY_LEFT_SHIFT);

				const ::pos2df64 player_speed = glm::abs(JPhys::GetLinearVelocity(dat.phys_handle));

				if (glfwGetKey(c_win, GLFW_KEY_D)) {
					dat.is_facing_right = true;

					if (player_speed.x < (sprint ? PlayerConstants::MAX_SPRINT_SPEED : PlayerConstants::MAX_WALKING_SPEED)) {
						const ::pos2df64 movement_direction = { 1, 0 };
						const pos2df32 force = PlayerConstants::ACCEL * movement_direction * (fl64)PlayerConstants::MASS;

						JPhys::ApplyForceToCenterOriented(dat.phys_handle, force);
					}
				}
				if (glfwGetKey(c_win, GLFW_KEY_A)) {
					dat.is_facing_right = false;

					if (player_speed.x < (sprint ? PlayerConstants::MAX_SPRINT_SPEED : PlayerConstants::MAX_WALKING_SPEED)) {
						const ::pos2df64 movement_direction = { -1, 0 };
						const pos2df32 force = PlayerConstants::ACCEL * movement_direction * (fl64)PlayerConstants::MASS;

						JPhys::ApplyForceToCenterOriented(dat.phys_handle, force);
					}
				}
				//fmt::println("Touch contacts: {}", dat.ground_sensor_touch_contacts);
				if (glfwGetKey(c_win, GLFW_KEY_SPACE) && dat.ground_sensor_touch_contacts) {
					if (!dat.was_jump_in_prev_frame) {
						b2Body_ApplyLinearImpulseToCenter(dat.phys_handle, { 0, PlayerConstants::JUMP_FORCE }, true);
					}
					dat.was_jump_in_prev_frame = true;
				}
				else {
					//if (was_jump_in_prev_frame) {
					//	pos2df64 player_speed = JPhys::GetLinearVelocity(player.phys_handle);
					//	b2Body_SetLinearVelocity(player.phys_handle, { (fl32)player_speed.x, 0 });
					//}

					dat.was_jump_in_prev_frame = false;
				}
				const fl64 normalized_speed = std::abs(player_speed.x);


				//----------------Animations-----------------
				LLJGFX::Texture::Handle frm = { nullptr };
				if (!dat.ground_sensor_touch_contacts) {
					frm = PlayerConstants::player_texture.handle();//Temporary
				}
				else if (normalized_speed >= 2.5)
					frm = Anim::WalkCycleAnimator::Animate(PlayerConstants::sprint, dat.sprint_cycle_state, normalized_speed).handle();
				else if (normalized_speed >= 0.5)
					frm = Anim::WalkCycleAnimator::Animate(PlayerConstants::walk, dat.walk_cycle_state, normalized_speed).handle();
				else
					frm = PlayerConstants::player_texture.handle();

				//auto& frm = normalized_speed >= 0.5 ? Anim::WalkCycleAnimator::Animate(PlayerConstants::walk, dat.walk_cycle_state, normalized_speed) : PlayerConstants::player_texture;//Anim::LinearRepeatingAnimator::Animate(PlayerConstants::idle, dat.idle_anim_state).frame; //JE::Anim::GetCurrentFrame(dat.state, player_speed.x);

				LLJE::DrawSprite(frm, LLJE::Object::GetPos(instance), ctx, { JPhys::GetRotation(dat.phys_handle), { dat.is_facing_right ? 1 : -1, 1}, J2D::ToMetric({16,13}) });
			}
		}

		LLJE::Prefab::Handle player_prefab = Scene::Internal::player_obj_test = LLJE::Prefab::Make({ .Destroy = Func::Destroy, .Update = Func::Update, .GetPosition = Func::GetPosition });

		LLJE::Object::Handle MakePlayer(LLJE::Layer::Handle target_layer, ::pos2df64 pos) { 
			assert(MainGameLayer::IsTypeValid(target_layer));

			ObjectData* p_data = new ObjectData{};
			{
				b2BodyDef bodydef = b2DefaultBodyDef();
				bodydef.type = b2_dynamicBody;
				bodydef.fixedRotation = true;
				bodydef.position = { (fl32)pos.x, (fl32)pos.y };

				p_data->phys_handle = b2CreateBody(LLJE::PhysScene::GetWorldHandle(LLJE::Layer::GetParentScene(target_layer)), &bodydef);

				const float radius = (float)PlayerConstants::metric_size.x / 2.f;
				b2Capsule capsule = { {0.f, -(float)(PlayerConstants::metric_size.y / 2. - radius)},
									  {0.f,  (float)(PlayerConstants::metric_size.y / 2. - radius)},
									 radius };

				b2ShapeDef shape_def = b2DefaultShapeDef();
				shape_def.material.friction = 0.2f;
				p_data->capsule_handle = b2CreateCapsuleShape(p_data->phys_handle, &shape_def, &capsule);

				b2Polygon ground_sensor_hitbox = JPhys::MakeBoxPolygon(PlayerConstants::ground_sensor_size, PlayerConstants::ground_sensor_offset, 0);
				b2ShapeDef ground_sensor_def = b2DefaultShapeDef();
				ground_sensor_def.isSensor = true;
				p_data->ground_sensor_handle = b2CreatePolygonShape(p_data->phys_handle, &ground_sensor_def, &ground_sensor_hitbox);

				b2Body_SetMassData(p_data->phys_handle, { PlayerConstants::MASS, {0,0}, 0/*player.mass*/ });
			}

			return LLJE::Object::Make(target_layer, player_prefab, p_data); 
		}
		void SetPosition(LLJE::Object::Handle obj, pos2d64 pos) {
			auto& dat = LLJE::Object::GetData<ObjectData>(obj);
			b2Body_SetTransform(dat.phys_handle, JPhys::ConvertToBV(pos), JPhys::B2FromAngle(0));
		}
	}
}
