#pragma once
#include "../Engine/Engine.h"
#include <stack>
#include "Global.h"
#include "JGFX/Window.h"
#include "box2d/collision.h"
#include "box2d/id.h"

namespace Cosmo {
	//Structure:
	// 1) Part type template - defines the behaviour of a part type, uses data from blueprint and part to render it
	// 2)  |- Blueprint - part definition data based on type template
	// 3)       |- Part - object with a part template and a part of assembly
	// 4) Assembly - common info about all parts in an assembled spacecraft

	namespace PartTypeTemplate {
		struct Data {
			void (*Draw)(LLJE::Object::Handle part, const LLJE::EngineContext& ctx) = nullptr;
			void(*Update)(LLJE::Object::Handle part) = nullptr;
			void(*Cache)(LLJE::Object::Handle part) = nullptr; //Cache is stored in the part itself

			void(*MakeObjectData)(LLJE::Object::Handle raw_part) = nullptr;
			void(*DeleteObjectData)(LLJE::Object::Handle part) = nullptr;
			void(*DeleteBlueprintData)(void* type_specific_data) = nullptr;
		};

		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}

		typedef JE::MHandle<Data> Handle;
		const Handle NULL_TEMPLATE = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		Handle Make(const Data& dat = {}) { return Internal::manager.Add(dat); }
		const Data& GetData(Handle handle) { return Internal::manager[handle]; }

		void Delete(Handle handle) {
			if (IsValid(handle))
				Internal::manager.Remove(handle);
		}
	}
	namespace Blueprint {
		JGFX::Texture nozzle = { "../../../Cosmonator/Nozzle.png" };
		JGFX::Texture fuel_tank = { "../../../Cosmonator/FuelTank.png" };

		struct Data {
			PartTypeTemplate::Handle type;
			
			void* type_specific_data = nullptr;
		};

		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}

		typedef JE::MHandle<Data> Handle;
		const Handle NULL_TEMPLATE = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		Handle Make(const Data& dat = {}) 
			{ return Internal::manager.Add(dat); }
		Data& GetRawData(Handle handle) { return Internal::manager[handle]; }
		template<typename T> T& GetData(Handle handle) { return *(T*)Internal::manager[handle].type_specific_data; }
		PartTypeTemplate::Handle GetType(Handle handle) { return Internal::manager[handle].type; }

		void Delete(Handle handle) {
			if (IsValid(handle)) {
				auto& dat = Internal::manager[handle];
				PartTypeTemplate::GetData(dat.type).DeleteBlueprintData(dat.type_specific_data);
				Internal::manager.Remove(handle);
			}
		}
	}

	namespace Assembly {
		struct Data {
			LLJE::Object::Handle head_part;

			size_t update_frame = 0;
			bool is_cache_valid = false;

			//std::unordered_set<LLJE::Object::Handle> all_cached_parts; //Replaced with Assembly::Iterate()
			//std::unordered_map<PartType::Handle, void*> part_type_cache;
		};

		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}

		typedef JE::MHandle<Data> Handle;
		Handle NULL_ASSEMBLY = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		Data& GetData(Handle handle) {
			return Internal::manager[handle];
		}

		void Update(Handle handle);
		void Cache(Handle handle);

		Handle Make(LLJE::Object::Handle head_part) {
			return Internal::manager.Add({ .head_part = head_part });
		}
		void Delete(Handle handle) {
			Internal::manager.Remove(handle);
		}
	}

	namespace Joint{
		struct Data;
		typedef JE::MHandle<Data> Handle;
		Handle NULL_ASSEMBLY = { nullptr };

		void Detach(Handle handle);
	}
	namespace PartObj {
		namespace Constants {
			JGFX::Texture nozzle = { cosmo_res_loc + "Nozzle.png" };
			
		}
		struct ObjectData {
			b2BodyId phys_handle = b2_nullBodyId;

			Assembly::Handle parent_assembly; //When it should be created: when part itself was created, or when the part is unlinked
			Blueprint::Handle blueprint;

			LLJE::Object::Handle internal_attached_to = LLJE::Object::NULL_OBJECT;
			std::unordered_map<LLJE::Object::Handle, Joint::Handle> internal_attached_parts;
			std::unordered_set<Joint::Handle> internal_links;
			//std::unordered_map<LLJE::Object::Handle, std::unordered_set<Joint::Handle>> internal_part_links;
			//std::unordered_map<LLJE::Object::Handle, std::vector<Joint::Handle>> read_only_joints;

			void* type_specific_data = nullptr;
			//std::vector<Joint::Handle> connected_predefined_joints;
			//fl32 quality = 0; //0 = worst quality(will instantly explode), 1 = best quality
		};
		ObjectData& GetData(LLJE::Object::Handle handle) 
			{ return LLJE::Object::GetData<ObjectData>(handle); }

		namespace Func {
			::pos2df64 GetPosition(LLJE::Object::Handle instance)
				{return LLJE::RoundToPixels(JPhys::GetPos(LLJE::Object::GetData<ObjectData>(instance).phys_handle));}

			void Destroy(LLJE::Object::Handle instance) {
				auto& dat = LLJE::Object::GetData<ObjectData>(instance);

				auto tmp_attached_parts = dat.internal_attached_parts; //It must be copied in order to work
				for (auto& i : tmp_attached_parts) 
					Joint::Detach(i.second); //Detach child parts
				
				if (dat.internal_attached_to != LLJE::Object::NULL_OBJECT)
					Joint::Detach(GetData(dat.internal_attached_to).internal_attached_parts[instance]);
				
				PartTypeTemplate::GetData(Blueprint::GetType(dat.blueprint)).DeleteObjectData(instance);
				b2DestroyBody(dat.phys_handle);
				Assembly::Delete(dat.parent_assembly); //When detached, it only has an assembly with a single part

				delete (ObjectData*)LLJE::Object::GetDataPtr(instance);
			}
			void Update(LLJE::Object::Handle instance, const LLJE::EngineContext& ctx) {
				auto& dat = LLJE::Object::GetData<ObjectData>(instance);

				Assembly::Update(dat.parent_assembly);
				PartTypeTemplate::GetData(Blueprint::GetType(dat.blueprint)).Draw(instance, ctx);
			}
		}
		LLJE::Prefab::Handle prefab = LLJE::Prefab::Make({ 
			.Destroy = Func::Destroy,
			.GetPosition = Func::GetPosition,
			.Update = Func::Update, 
		});


		LLJE::Object::Handle Make(LLJE::Layer::Handle target_layer, ::pos2df64 pos, Blueprint::Handle blueprint) {
			ObjectData* p_data = new ObjectData{ .blueprint = blueprint };
			{
				b2BodyDef bodydef = b2DefaultBodyDef();
				bodydef.type = b2_dynamicBody;
				bodydef.fixedRotation = false;
				bodydef.position = { (fl32)pos.x, (fl32)pos.y };

				p_data->phys_handle = b2CreateBody(LLJE::PhysScene::GetWorldHandle(LLJE::Layer::GetParentScene(target_layer)), &bodydef);
			}
			LLJE::Object::Handle handle = LLJE::Object::Make(target_layer, prefab, p_data);
			PartTypeTemplate::GetData(Blueprint::GetType(blueprint)).MakeObjectData(handle);
			p_data->parent_assembly = Assembly::Make(handle);

			return handle;
		}

		template<typename T> T& GetPartData(LLJE::Object::Handle handle)
			{ return *(T*)LLJE::Object::GetData<ObjectData>(handle).type_specific_data; }
	}
	namespace Blueprint{
		Data& GetRawData(LLJE::Object::Handle handle){ return Internal::manager[PartObj::GetData(handle).blueprint]; }
		template<typename T> T& GetData(LLJE::Object::Handle handle){ return *(T*)GetRawData(handle).type_specific_data; }
		PartTypeTemplate::Handle GetType(LLJE::Object::Handle handle){ return GetRawData(handle).type; }
	}
	namespace Assembly{
		//TODO: debug this
		void Iterate(LLJE::Object::Handle head_part, void(*Func)(LLJE::Object::Handle handle, void* context), void* context){	
			auto& head_dat = PartObj::GetData(head_part);

			std::stack<std::unordered_map<LLJE::Object::Handle, Joint::Handle>::iterator> c_branch_ids;
			c_branch_ids.push(head_dat.internal_attached_parts.begin());
			LLJE::Object::Handle c_leaf = head_part;

			//--function call for the head, because it wont be called anywhere else
			Func(c_leaf, context);
			//---------------------------------------------------------------------
			while (true) {
				auto& leaf_data = PartObj::GetData(c_leaf);

				if (leaf_data.internal_attached_parts.size()) { //If we could go deeper
					c_leaf = c_branch_ids.top()->first;
					//--Actual function call
					Func(c_leaf, context);
					//----------------------
					auto& new_leaf_data = PartObj::GetData(c_leaf);
					c_branch_ids.push(new_leaf_data.internal_attached_parts.begin());
				}
				else { //Climb out
					if (leaf_data.internal_attached_to == LLJE::Object::NULL_OBJECT)
						break;
					do {
						c_branch_ids.pop();
						c_branch_ids.top()++;
						c_leaf = leaf_data.internal_attached_to;

						auto& new_leaf_data = PartObj::GetData(c_leaf);
						if (c_branch_ids.top() != new_leaf_data.internal_attached_parts.end() || c_branch_ids.size() == 1) //Stop climbing if there is more to explore or if hit the top of the tree
							break;
						//int a = 0;
					} while (1);
					if (c_branch_ids.size() == 1)
						break;
				}
			}
		}
		void Iterate(Handle assembly, void (*Func)(LLJE::Object::Handle, void*), void *context)
			{ Iterate(Assembly::GetData(assembly).head_part, Func, context); }

		void TurnIntoHead(LLJE::Object::Handle part){
			//Recursive
			auto& dat = LLJE::Object::GetData<PartObj::ObjectData>(part);
			if(dat.internal_attached_to == LLJE::Object::NULL_OBJECT) return; //If its already head

			auto& parent_dat = LLJE::Object::GetData<PartObj::ObjectData>(dat.internal_attached_to);

			if(parent_dat.internal_attached_to != LLJE::Object::NULL_OBJECT)
				TurnIntoHead(dat.internal_attached_to);

			//TODO: it wouldn't work properly with links
			//TODO: make it so it would be solved iteratively instead of recursion
			dat.internal_attached_parts.insert({dat.internal_attached_to, parent_dat.internal_attached_parts[part]});
			parent_dat.internal_attached_parts.erase(part);
			parent_dat.internal_attached_to = part;
			//TODO (IDK): it should also invalidate the assembly
		}
	}

	namespace Joint{
		struct Data {
			LLJE::Object::Handle part1 = LLJE::Object::NULL_OBJECT;
			LLJE::Object::Handle part2 = LLJE::Object::NULL_OBJECT;

			b2JointId phys_joint_handle = b2_nullJointId;

			//int predefined_joint_id_1 = -1; //Both of them must be either a value or NULL (-1), and at the same time, since regular weld joints cannot be attached to predefined joints
			//int predefined_joint_id_2 = -1; //value of -1 also means that this is a regular radial weld joint
		};

		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }


		bool IsLink(Handle handle) { return PartObj::GetData(Internal::manager[handle].part1).internal_links.contains(handle); }

		Handle AttachPart(LLJE::Object::Handle part1, pos2df64 part1_joint_pos, LLJE::Object::Handle part2, pos2df64 part2_joint_pos) {
			auto& p1_dat = PartObj::GetData(part1);
			auto& p2_dat = PartObj::GetData(part2);

			b2WeldJointDef joint_def = b2DefaultWeldJointDef();
			joint_def.bodyIdA = p1_dat.phys_handle;
			joint_def.bodyIdB = p2_dat.phys_handle;

			joint_def.angularDampingRatio = 1;
			joint_def.linearDampingRatio = 1;
			joint_def.linearHertz = 0;
			joint_def.angularHertz = 0;

			joint_def.localAnchorA = JPhys::ConvertToBV(part1_joint_pos);
			joint_def.localAnchorB = JPhys::ConvertToBV(part2_joint_pos);

			b2JointId phys_joint_handle = b2CreateWeldJoint(LLJE::PhysScene::GetWorldHandle(LLJE::Object::GetParentScene(part1)), &joint_def);

			Data joint_data = { 
				.part1 = part1, 
				.part2 = part2, 
				.phys_joint_handle = phys_joint_handle 
			};
			Handle handle = Internal::manager.Add(joint_data);

			if(p1_dat.parent_assembly != p2_dat.parent_assembly){
				//make a link
				p1_dat.internal_links.insert(handle);
				p2_dat.internal_links.insert(handle);
			}
			else{
				//Merge 2 assemblies
				auto old_assembly = p1_dat.parent_assembly;
				Assembly::TurnIntoHead(part1);
				Assembly::Iterate(
					part1, 
					[](LLJE::Object::Handle part, void* new_asm){  
						PartObj::GetData(part).parent_assembly = *(Assembly::Handle*)new_asm;
					}, 
					&p2_dat.parent_assembly
				);
				Assembly::Delete(old_assembly);

				p1_dat.internal_attached_to = part2;
				p2_dat.internal_attached_parts[part1] = handle;
			}
			Assembly::GetData(p2_dat.parent_assembly).is_cache_valid = false;
			return handle;
		}
		void Detach(Handle handle) {
			//Terminology: 
			//  branch - connection between parts in the hierarchy
			//  link - connection between different parts without respect to the hierarchy
			//If breaking a branch, try to promote one of the links to be a branch
			auto& joint_dat = Internal::manager[handle];

			//Shortcuts
			auto& part1 = joint_dat.part1;
			auto& part2 = joint_dat.part2;

			LLJE::Object::Handle from;
			LLJE::Object::Handle to;

			auto& p1_dat = PartObj::GetData(part1);
			auto& p2_dat = PartObj::GetData(part2);

			//assert(p1_dat.attached_parts.contains(part2) || p2_dat.attached_parts.contains(part1));
			if (p1_dat.internal_attached_parts.contains(part2)) {
				from = part1;
				to = part2;
			}
			else {
				from = part2;
				to = part1;
			}
			auto& from_dat = PartObj::GetData(from);
			auto& to_dat = PartObj::GetData(to);

			b2DestroyJoint(Internal::manager[from_dat.internal_attached_parts[to]].phys_joint_handle);
			
			to_dat.parent_assembly = Assembly::Make(to);
			Assembly::Iterate(
				to,
				[](LLJE::Object::Handle part, void* new_asm){
					PartObj::GetData(part).parent_assembly = *(Assembly::Handle*)new_asm;
				},
				&to_dat.parent_assembly
			);
		}
	}
	//TODO: automatically update oject chunk positions when updating assembly
	//TODO: AABB part loading in chunk
	//(CANCELLED): When being attached, part must be moved to node (NOT SURE, because it can potentially clip the part trought ground)
	//TODO: safety fixes
	//TODO JOINT API:
		//(DONE): handles for individual joints
		//PRIORITY TODO: different types of joints
		//PRIORITY TODO: predefined joints
	//PRIORITY TODO: fuel line API
	//PRIORITY TODO: allow links between different branches in a part tree
	//(CANCELLED): part type cache categories 
	//(CANCELLED): assembly merge and separate events
	//(PARTIALLY DONE): part types like engine and etc
	//TODO: parts must load physics in chunks
	//TODO: part destructability
	//TODO: draft system and convertion to blueprints
	namespace Assembly {
		void Cache(Handle handle) {
			Iterate(
				handle,
				[](LLJE::Object::Handle part, void*){	
					PartTypeTemplate::GetData(Blueprint::GetType(part)).Cache(part);
				},
				nullptr
			);
			Internal::manager[handle].is_cache_valid = true;
		}
		void Update(Handle handle) {
			auto& assembly_dat = Internal::manager[handle];
			if (assembly_dat.update_frame == JGFX::FrameCount())
				return;
			if (!assembly_dat.is_cache_valid)
				Cache(handle);
			
			Iterate(
				handle,
				[](LLJE::Object::Handle part, void*){
					PartTypeTemplate::GetData(Blueprint::GetType(part)).Update(part);
				},
				nullptr
			);

			assembly_dat.update_frame = JGFX::FrameCount();
		}
	}




///////////////////////////////////PARTS///////////////////////////////////////////////////////
	namespace FuelTank {
		namespace Constants {
			JGFX::Texture fuel_tank = { cosmo_res_loc + "FuelTank.png" };
			fl64 tmp_mass = 200;
		}
		struct BlueprintData {
			fl32 dry_mass;
			fl32 capacity;
			pos2df64 metric_size;
		};
		struct ObjectFuelTankData {
			fl32 fuel_level; //In liters/kilograms
		};

		PartTypeTemplate::Handle preset = PartTypeTemplate::Make({
			.Draw = [](LLJE::Object::Handle part, const LLJE::EngineContext& ctx) {
				const BlueprintData& dat = Blueprint::GetData<BlueprintData>(part);
				LLJE::DrawSpriteMetric(Constants::fuel_tank, dat.metric_size, LLJE::Object::GetPos(part), ctx, { JPhys::GetRotation(PartObj::GetData(part).phys_handle), {1, 1}, dat.metric_size / 2. });
			},
			.Update = [](LLJE::Object::Handle part) {
				//It wouldnt be needed, because fuel line API will handle changing mass automatically
				auto& deb = PartObj::GetData(part);
				const fl32 new_mass = PartObj::GetPartData<ObjectFuelTankData>(part).fuel_level 
													+ Blueprint::GetData<BlueprintData>(part).dry_mass; 
				b2Body_SetMassData(PartObj::GetData(part).phys_handle, b2MassData{new_mass, {0,0}, new_mass}); 
				//TODO: accurate calculation of rotational inertia
				//TODO: center of mass calculation
				//TODO: ONLY set mass if needed
			},
			.Cache = [](LLJE::Object::Handle part){
				
			},	
			.MakeObjectData = [](LLJE::Object::Handle part) {
				auto& part_dat = PartObj::GetData(part);
				auto& bp_dat = Blueprint::GetData<BlueprintData>(part);
				
				{
					b2ShapeDef shape_def = b2DefaultShapeDef();
					shape_def.material.friction = 2.f;

					b2Polygon hitbox = JPhys::MakeBoxPolygon(bp_dat.metric_size);
					b2CreatePolygonShape(part_dat.phys_handle, &shape_def, &hitbox);

					b2Body_SetMassData(part_dat.phys_handle, { bp_dat.dry_mass, {0,0}, bp_dat.dry_mass * 2.f });
				}

				//Debug: fills the tank, so its full
				part_dat.type_specific_data = new ObjectFuelTankData{.fuel_level = bp_dat.capacity};
			},
		});

		Blueprint::Handle MakeBlueprint(const BlueprintData& dat) {
			BlueprintData* p_dat = new BlueprintData{ dat };
			return Blueprint::Make({ .type = preset,.type_specific_data = p_dat});
		}
	}
	namespace RocketEngine {
		fl32 global_trottle = 0; //This is temporary and only for debugging purposes
		namespace Constants {
			JGFX::Texture tmp = { cosmo_res_loc + "Nozzle.png" };
		}
		struct BlueprintData {
			fl32 dry_mass = 0;
			fl32 specific_impulse = 0;
			fl32 flow_rate = 0;
			pos2df64 metric_size = {0,0}; //TODO: this will be replaced with 3d mesh model
		};
		struct PartData {
			fl32 trottle;
			LLJE::Object::Handle cached_src_fuel_tank = LLJE::Object::NULL_OBJECT; //TODO: rework fuel system
			//LLJE::Object::Handle cached_control_part; //It will sync local trottle value with the one in the control part
		};

		PartTypeTemplate::Handle preset = PartTypeTemplate::Make({
			.Draw = [](LLJE::Object::Handle part, const LLJE::EngineContext& ctx) {
				const BlueprintData& dat = Blueprint::GetData<BlueprintData>(part);
				LLJE::DrawSpriteMetric(Constants::tmp, dat.metric_size, LLJE::Object::GetPos(part), ctx, { JPhys::GetRotation(PartObj::GetData(part).phys_handle), {1, 1}, dat.metric_size / 2. });
			},
			//TODO: fuel line api:
			//It consists of:
			//Cache
			//And functions to interract with fuel line, such as fl32 Drain(fl32 requested_amount) - returns how much fuel was ACTUALLY drained 
			.Update = [](LLJE::Object::Handle part) {
				auto& blueprint_data = Blueprint::GetData<BlueprintData>(part);
				auto& inner_part_data = PartObj::GetPartData<PartData>(part);
				inner_part_data.trottle = global_trottle; //Debug
				auto& part_data = PartObj::GetData(part);

				//TODO: fetch trottle value from control part
				//As a temporary solution there is a global trottle variable

				const fl32 trottled_flow_rate = blueprint_data.flow_rate * inner_part_data.trottle; //Will also drain the same amount from fuel tanks
					
				//Drain fuel
				const fl32 requested_fuel = trottled_flow_rate * JGFX::GetDeltaTimeValue();
				fl32 actually_drained_fuel = 0;
				if(LLJE::Object::IsValid(inner_part_data.cached_src_fuel_tank)){
					//---Code below will be replaced in the future with the fuel line API---
					auto& tank_fuel = PartObj::GetPartData<FuelTank::ObjectFuelTankData>(inner_part_data.cached_src_fuel_tank).fuel_level;
					if(tank_fuel >= requested_fuel) 
						tank_fuel -= requested_fuel, actually_drained_fuel = requested_fuel;
					else actually_drained_fuel = tank_fuel, tank_fuel = 0;
				}

				//Debug
				//actually_drained_fuel = requested_fuel;

				//Apply thrust
				//Requested fuel must be > 0 to be applied, because division by 0 will break everything
				if(!JE::Mesher::AreTheSame(requested_fuel, 0, 0.001)){
					//It depends on how much fuel was actually drained
					const fl32 thrust = blueprint_data.specific_impulse * trottled_flow_rate * (actually_drained_fuel / requested_fuel);
					JPhys::ApplyForceToCenterOriented(part_data.phys_handle, pos2df64{0, thrust}, true); //TODO: debug this, possible issues with angle
				}
			},
			.Cache = [](LLJE::Object::Handle part){
				//TODO: when the fuel line api will be ready, it should cache a fuel line	instead of manual fuel tank search
				auto& pdat = PartObj::GetData(part);
				
				//It must clean the cache first
				(*(PartData*)pdat.type_specific_data).cached_src_fuel_tank = LLJE::Object::NULL_OBJECT;

				if(LLJE::Object::IsValid(pdat.internal_attached_to)){
					if(Blueprint::GetType(pdat.internal_attached_to) == FuelTank::preset)
						(*(PartData*)pdat.type_specific_data).cached_src_fuel_tank = pdat.internal_attached_to;
				}
			},	
			.MakeObjectData = [](LLJE::Object::Handle part) {
				auto& part_dat = PartObj::GetData(part);
				part_dat.type_specific_data = new PartData{};

				auto& bp_dat = Blueprint::GetData<BlueprintData>(part);
				
				{
					b2ShapeDef shape_def = b2DefaultShapeDef();
					shape_def.material.friction = 2.f;

					b2Polygon hitbox = JPhys::MakeBoxPolygon(bp_dat.metric_size);
					b2CreatePolygonShape(part_dat.phys_handle, &shape_def, &hitbox);

					b2Body_SetMassData(part_dat.phys_handle, { bp_dat.dry_mass, {0,0}, bp_dat.dry_mass * 2.f });
				}
			},
			.DeleteObjectData = [](LLJE::Object::Handle part)
				{ delete (PartData*)PartObj::GetData(part).type_specific_data; }
		});

		Blueprint::Handle MakeBlueprint(const BlueprintData& dat) {
			BlueprintData* p_dat = new BlueprintData{ dat };
			return Blueprint::Make({.type_specific_data = p_dat, .type = preset});
		}
	}
	/*
	namespace Part {
		struct FuelTankData {
			fl64 amount_of_fuel = 0; //must be less than a capacity in a template
		};
		struct EngineData {
			bool is_active = false;
		};

		namespace Internal {
			struct Data;

			struct Joint {
				JE::MHandle<Data> part = { nullptr };
				b2JointId phys_handle = b2_nullJointId;
			};

			struct Data {
				b2BodyId phys_handle = b2_nullBodyId;

				Blueprint::Handle bound_template = Blueprint::NULL_TEMPLATE;
				//std::vector<Node> nodes;
				//Template::Handle base_template;

				//std::vector<PartLink> attached_parts;
				void* type_specific_data = nullptr;
				Joint attached_to = {};

				std::vector<JE::MHandle<Data>> attached_parts;
				//std::unordered_set<JE::MHandle<Data>> attached_parts;
				//Data* attached_to = nullptr;

				//fl32 quality = 0; //0 = worst quality(will instantly explode), 1 = best quality
			};

			const Data DEFAULT = {};
			JE::AnonymousManager<Data> manager;
		}

		typedef JE::MHandle<Internal::Data> Handle;
		const Handle NULL_PART = { nullptr };
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		struct StageCache {
			std::unordered_map<Blueprint::Type, std::vector<Handle>> parts_of_types;
			fl64 remaining_fuel = 0;
		};
		struct HeadData {
			Handle head_part = NULL_PART;

			std::vector<StageCache> stage_caches;
			bool is_cache_valid = false;
			//Assembly params
			fl32 trottle = 0;
		};
		std::unordered_map<Handle, HeadData> assemblies;

		struct PartDef {
			Blueprint::Handle templ = Blueprint::NULL_TEMPLATE;
			void* type_specific_data = nullptr;
			//fl32 quality = 0;
		};

		Handle MakePart(LLJE::Layer::Handle target_layer, const PartDef& def, pos2df64 pos = { 0, 0 }) {
			Internal::Data dat = { .bound_template     = def.templ, 
								   .type_specific_data = def.type_specific_data };

			const auto& templ = Blueprint::GetData(dat.bound_template);

			b2BodyDef bodydef = b2DefaultBodyDef();
			bodydef.type = b2_dynamicBody;

			bodydef.position = JPhys::ConvertToBV(pos);//{ (fl32)pos.x, (fl32)pos.y };

			dat.phys_handle = b2CreateBody(LLJE::PhysScene::GetWorldHandle(LLJE::Layer::GetParentScene(target_layer)), &bodydef);

			b2Polygon collision_box = JPhys::MakeBoxPolygon(templ.bounding_box_size);
			b2ShapeDef collision_box_def = b2DefaultShapeDef();
			collision_box_def.restitution = 0;
			b2CreatePolygonShape(dat.phys_handle, &collision_box_def, &collision_box);

			b2Body_SetMassData(dat.phys_handle, { .mass = (fl32)templ.dry_mass, 
												  .center = {0,0}, 
												  .rotationalInertia = (fl32)(templ.dry_mass * (templ.bounding_box_size.x * templ.bounding_box_size.y)) });

			Handle handle = Internal::manager.Add(dat);
			assemblies.insert({ handle, {handle} });


			return handle;
		}
		Handle MakeEngine(Blueprint::Handle templ) {
			return MakePart({ .templ = templ, 
							  .type_specific_data = new EngineData{}});
		}
		Handle MakeFuelTank(Blueprint::Handle templ, fl64 fuel_amount) {
			return MakePart({ .templ = templ, 
							  .type_specific_data = new FuelTankData{fuel_amount}});
		}

		Internal::Data& GetEditableData(Handle handle)
			{ return Internal::GetData(handle); }
		const Internal::Data& GetData(Handle handle)
			{ return Internal::GetRoData(handle); }

		Handle FindHead(Handle handle) {
			Handle head = handle;
			Handle next_node = NULL_PART;
			do {
				const auto& head_dat = Internal::GetRoData(head);
				next_node = head_dat.attached_to.part;
				if (next_node != NULL_PART)
					head = next_node;
			} while (next_node != NULL_PART);

			return head;
		}

		void CacheAssembly(Handle head){
			auto& assembly_data = assemblies.find(head)->second;
			if (assembly_data.is_cache_valid)
				return;

			assembly_data.stage_caches.clear();
			assembly_data.stage_caches.push_back({});

			auto& head_data = Internal::GetData(head);
			auto& head_template = Blueprint::GetData(head_data.bound_template);
				
			std::stack<int> c_branch_ids;
			c_branch_ids.push(0);
			if (head_template.type == Blueprint::Type::FUEL_TANK)
				assembly_data.stage_caches[0].remaining_fuel += (*(FuelTankData*)head_data.type_specific_data).amount_of_fuel;
			assembly_data.stage_caches[0].parts_of_types[Blueprint::GetData(head_data.bound_template).type].push_back(head);

			//c_branch_ids.push(0);

			Handle c_leaf = head;

			while (true) {
				auto& leaf_data = Internal::GetData(c_leaf);
				auto& leaf_template = Blueprint::GetData(leaf_data.bound_template);

				if (leaf_data.attached_parts.size()) { //If we could go deeper
					c_leaf = leaf_data.attached_parts[c_branch_ids.top()];
					auto& new_leaf_data = Internal::GetData(c_leaf);
					auto& new_leaf_template = Blueprint::GetData(new_leaf_data.bound_template);

					if (new_leaf_template.type == Blueprint::Type::FUEL_TANK)
						assembly_data.stage_caches[0].remaining_fuel += (*(FuelTankData*)new_leaf_data.type_specific_data).amount_of_fuel;
					assembly_data.stage_caches[0].parts_of_types[new_leaf_template.type].push_back(c_leaf);
					c_branch_ids.push(0);
				}
				else { //Climb out
					do {
						c_branch_ids.pop();
						c_branch_ids.top()++;
						c_leaf = Internal::GetData(c_leaf).attached_to.part;

						auto& new_leaf_data = Internal::GetData(c_leaf);
						if (c_branch_ids.top() < (new_leaf_data.attached_parts.size()) || c_branch_ids.size() == 1)
							break;
						//int a = 0;
					} while (1);
					if (c_branch_ids.size() == 1)
						break;
				}
			}
			assembly_data.is_cache_valid = true;
			{
				//��������:
				// ���������:
				// -���� ��������, ��������� ����
				//    -��������� ����
				// -�����:
				//    -�������� �� ���� �������, ����� ����� ����� ������� ������� � ������ �����
				//    -���� ��������� �� ��������� ��������, �� ������� �� �����
			}*/
			/*
			do {
				auto& leaf_data = Internal::GetData(c_leaf);
				auto& leaf_template = ProcTempl::GetData(leaf_data.bound_template);
				assembly_data.stage_caches[0].parts_of_types[leaf_template.type].push_back(c_leaf);

				if (leaf_data.attached_parts.size()) { //If we could go deeper
					c_leaf = leaf_data.attached_parts[0];
					c_branch_ids.push(0);
				}
				else {
					do { //Try to climb to where there are leafs left
						if (leaf_data.attached_to.part != NULL_PART) {
							c_branch_ids.pop();
							c_branch_ids.top()++;
							c_leaf = leaf_data.attached_to.part;
						}
						else return;



						auto& new_data = Internal::GetData(c_leaf);
					} while ((Internal::GetData(c_leaf).attached_parts.size() - 1) > c_branch_ids.top() && (Internal::GetData(c_leaf).attached_to.part != NULL_PART));
				}


			} while (1);*//*
		}

		void UpdateAssembly(Handle head){
			//std::stack<std::unordered_map<Handle, HeadData>::iterator> c_branch_ids;
			auto& assembly_data = assemblies.find(head)->second;

			if (!assembly_data.is_cache_valid)
				CacheAssembly(head);//return; //-------------------------TODO: cache stages
			
			for (auto& c_stage : assembly_data.stage_caches) {
				const fl64 old_fuel_level = c_stage.remaining_fuel;
				fl64 spent_fuel = 0;

				if (c_stage.remaining_fuel > 0) {
					for (auto& c_engine_handle : c_stage.parts_of_types[Blueprint::Type::ENGINE]) {
						auto& c_eng_dat = GetEditableData(c_engine_handle);
						auto& c_template = Blueprint::GetData(c_eng_dat.bound_template);
						auto& c_eng_template = *(Blueprint::EngineData*)c_template.type_specific_data;
						
						fl64 fuel_going_to_be_spent = c_eng_template.flow_rate * JGFX::GetDeltaTimeValue() * assembly_data.trottle;
						if (c_stage.remaining_fuel - fuel_going_to_be_spent >= 0) {
							c_stage.remaining_fuel -= fuel_going_to_be_spent;
							spent_fuel += fuel_going_to_be_spent;

							JPhys::ApplyForceToCenterOriented(c_eng_dat.phys_handle, pos2df64{ 0, (c_eng_template.specific_impulse * c_eng_template.flow_rate * 9.8) * assembly_data.trottle });
						}
					}
				}
				for (auto& c_fuel_tank_handle : c_stage.parts_of_types[Blueprint::Type::FUEL_TANK]) {
					auto& c_dat = GetEditableData(c_fuel_tank_handle);
					auto& c_ft_dat = *(FuelTankData*)c_dat.type_specific_data;
					auto& c_template = Blueprint::GetData(c_dat.bound_template);

					c_ft_dat.amount_of_fuel -= (c_ft_dat.amount_of_fuel / old_fuel_level * spent_fuel);

					b2Body_SetMassData(c_dat.phys_handle, { .mass = (fl32)(c_template.dry_mass + c_ft_dat.amount_of_fuel), 
															.center = {0,0}, 
															.rotationalInertia = (fl32)c_ft_dat.amount_of_fuel });
				}
			}
			//go down and update parts
		}

		bool AttachPart(Handle base, pos2df64 base_joint_pos, Handle to, pos2df64 to_joint_pos) {
			auto& base_dat = Internal::GetData(base);
			auto& to_dat = Internal::GetData(to);

			if (base_dat.attached_to.part != NULL_PART || base_dat.attached_to.part == to)
				return false;

			b2WeldJointDef joint_def = b2DefaultWeldJointDef();
			joint_def.bodyIdA = base_dat.phys_handle;
			joint_def.bodyIdB = to_dat.phys_handle;

			joint_def.angularDampingRatio = 1;
			joint_def.linearDampingRatio = 1;
			joint_def.linearHertz = 0;
			joint_def.angularHertz = 0;

			joint_def.localAnchorA = JPhys::ConvertToBV(base_joint_pos);
			joint_def.localAnchorB = JPhys::ConvertToBV(to_joint_pos);

			const auto joint_handle = b2CreateWeldJoint(Cosmo::Phys::bound_world, &joint_def);

			base_dat.attached_to = { .part = to, 
									 .phys_handle = joint_handle };
			to_dat.attached_parts.push_back(base);

			assemblies.erase(base);
			assemblies[FindHead(to)].is_cache_valid = false;
			
			return true;
		}
		bool DetachPart(Handle handle) {
			auto& dat = Internal::GetData(handle);
			if (dat.attached_to.part == NULL_PART)
				return false;

			b2DestroyJoint(dat.attached_to.phys_handle);

			//Remove references from the parent part
			auto& att_dat = Internal::GetData(dat.attached_to.part);
			for (int i = 0; i < att_dat.attached_parts.size(); i++) {
				if (att_dat.attached_parts[i] == handle) {
					std::swap(att_dat.attached_parts[i], att_dat.attached_parts.back());
					att_dat.attached_parts.pop_back();
					break;
				}
			}

			Handle assembly_head = FindHead(handle);
			assemblies[assembly_head].is_cache_valid = false;

			dat.attached_to.part = NULL_PART;
			
			assemblies.insert({ handle, {handle} });

			return true;
		}

		void DrawPart(Handle handle) {
			const auto& dat = Internal::GetRoData(handle);
			const auto& part_template = Blueprint::GetData(dat.bound_template);
			J2D::Draw(part_template.texture, JPhys::GetPos(dat.phys_handle), { JPhys::GetRotation(dat.phys_handle),  part_template.bounding_box_size / J2D::ToMetric(part_template.texture.size()), J2D::ToMetric(part_template.texture.size()) / 2. });
		}

		void DrawAssembly(Handle head) {
			const auto& assembly_data = assemblies.find(head)->second;

			if (!assembly_data.is_cache_valid)
				CacheAssembly(head); //-------------------------TODO: cache stages

			for (const auto& c_stage : assembly_data.stage_caches) {
				for (const auto& c_part_type : c_stage.parts_of_types) {
					for (const auto& c_part_handle : c_part_type.second)
						DrawPart(c_part_handle);
				}
			}
		}
		void DrawAllAssemblies() {
			for (const auto& c_asm : assemblies)
				DrawAssembly(c_asm.first);
		}*/
	//}
}
