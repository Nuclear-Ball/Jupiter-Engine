#pragma once
#include <JGFX/JGFX.h>
#include "../Engine/Engine.h"
#include <box2d/box2d.h>
#include <unordered_set>
#include <PerlinNoise.hpp>
#include "SceneObjects.h"

//TODO: fix scene object generation
namespace Cosmo {
namespace Generation {
	siv::PerlinNoise rng{ 4801 };

	inline int32 GetTileHeight(int tile_pos) {
		return rng.octave1D_01(tile_pos / 30.0, 5) * 15;
	}
}

//TODO: rework this
namespace DGTS {
	constexpr pos2du16 TILE_SIZE = { 8, 8 };
	//Upper left: |UL|, Upper right: |UR| 
	//Lower left: |LL|, Lower right: |LR|
	//|UL|  |UR|  |LL|  |LR|

	constexpr inline uint8 GetTileId(bool upper_left, bool upper_right, bool lower_left, bool lower_right) {
		return upper_left + (upper_right << 1) + (lower_left << 2) + (lower_right << 3);
	}

	struct CollisionSegments {
		//tile types 
		//           //segments 
		//					    //points
		std::vector<std::vector<std::vector<::pos2df32>>> chain_collision_segments;
	};
	CollisionSegments default_collisions = { {
		{},                                  //|__|  |__|  |__|  |__|
		{{{ 0, 0.25 },   { 0.25, 0.5 }}},    //|UL|  |__|  |__|  |__|
		{{{ 0.25, 0.5 }, { 0.5,  0.25 }}},   //|__|  |UR|  |__|  |__|
		{{{ 0, 0.25 },   { 0.5,  0.25 }}},   //|UL|  |UR|  |__|  |__|
		{{{ 0.25, 0 },   { 0,    0.25 }}},   //|__|  |__|  |LL|  |__|
		{{{ 0.25, 0 },   { 0.25, 0.5 } }},   //|UL|  |__|  |LL|  |__|
		{{{ 0.25, 0.5 }, { 0,    0.25 } },
		 {{ 0.25, 0 },   { 0.5,  0.25 }}},   //|__|  |UR|  |LL|  |__|
		{{{ 0.25, 0 },   { 0.5,  0.25 }}},   //|UL|  |UR|  |LL|  |__|

		{{{ 0.5, 0.25 }, { 0.25, 0 }   }},   //|__|  |__|  |__|  |LR|
		{{{ 0, 0.25 },   { 0.25, 0 }    },
		 {{ 0.5, 0.25 }, { 0.25, 0.5 } }},   //|UL|  |__|  |__|  |LR|
		{{{ 0.25, 0.5 }, { 0.25, 0 }  }},    //|__|  |UR|  |__|  |LR|
		{{{ 0, 0.25 },   { 0.25,  0 }  }},   //|UL|  |UR|  |__|  |LR|
		{{{ 0.5, 0.25 }, { 0,    0.25 }}},   //|__|  |__|  |LL|  |LR|
		{{{ 0.5, 0.25 }, { 0.25, 0.5 } }},   //|UL|  |__|  |LL|  |LR|
		{{{ 0.25, 0.5 }, { 0, 0.25 }   }},   //|__|  |UR|  |LL|  |LR|
		{},									 //|UL|  |UR|  |LL|  |__|
	} };

	struct TileVariantDef {
		JGFX::Texture atlas;
		std::array<pos2du16, 16> tile_offsets;
		fl32 propability = 0;
	};
	TileVariantDef MakeTileVarDef(JGFX::Internal::TxtFnArg atlas, fl32 propability = 0) { //Propability of 0 means it will be deduced automatically during tset compilation
		const auto atlas_size = LLJGFX::Texture::GetSize(atlas);
		const auto& croplist = TextureProcessing::GenerateCroplist(atlas_size, 16, TILE_SIZE);
		assert(croplist.size() == 16); //If error occured, 16 is default tile count for dual grid tilesets

		TileVariantDef tset = {};
		for (int i = 0; i < 16; i++) {
			auto& c_cropp = croplist[i];
			tset.tile_offsets[i] = c_cropp.pos;
		}
		tset.atlas = atlas;

		assert(propability >= 0.f && propability <= 1);
		tset.propability = propability;

		return tset;
	}

	struct TileVariantData {
		std::array<pos2df32, 16> offsets;
		fl32 propability = 1;
	};
	struct DGTS_Data {
		JGFX::Texture atlas;
		std::vector<TileVariantData> tile_variants;
	};

	DGTS_Data MakeDgtsData(const std::vector<TileVariantDef>& tile_variants_defs) {
		const uint16 total_tile_count = 16 * tile_variants_defs.size();
		pos2du16 tile_count_for_sides = {0, 0};
		{
			const fl32 tiles_per_side = std::sqrt(total_tile_count);
			const uint16 converted_tiles_per_side = std::round(tiles_per_side);
			const uint16 new_tile_count = converted_tiles_per_side * converted_tiles_per_side;

			tile_count_for_sides = pos2du16{ converted_tiles_per_side };
			if (new_tile_count < total_tile_count)
				tile_count_for_sides.y += std::floor((fl32)(total_tile_count - new_tile_count) / (fl32)converted_tiles_per_side);
		}

		DGTS_Data res;
		res.tile_variants.reserve(tile_variants_defs.size());

		int tiles_moved = 0;
		fl32 full_propability = 0.f;
		int amount_of_variants_without_propability = 0;

		const pos2du16 output_txt_size = tile_count_for_sides * TILE_SIZE;
		std::string output_txt_data = std::string(output_txt_size.x * output_txt_size.y * 4, (char)0);
		for (int c_tvar_id = 0; c_tvar_id < tile_variants_defs.size(); c_tvar_id++) {
			res.tile_variants.push_back({});

			const auto& c_src_tvar = tile_variants_defs[c_tvar_id];
			auto& c_out_tvar = res.tile_variants[c_tvar_id];
			const std::string src_atlas_data = c_src_tvar.atlas.Dump();
			for (int c_tile_id = 0; c_tile_id < c_src_tvar.tile_offsets.size(); c_tile_id++) {
				
				//move to a new atlas and modify tile offsets
				const pos2du16 new_tile_pos = pos2du16{ tiles_moved % tile_count_for_sides.x, tiles_moved / tile_count_for_sides.x } * TILE_SIZE;
				TextureProcessing::MoveTxtElem(output_txt_data, output_txt_size, new_tile_pos, src_atlas_data, c_src_tvar.atlas.size(), c_src_tvar.tile_offsets[c_tile_id], TILE_SIZE);
				c_out_tvar.offsets[c_tile_id] = TextureProcessing::TextureCoordsToUv(new_tile_pos, output_txt_size);

				tiles_moved++;
			}

			assert(c_src_tvar.propability >= 0.f && c_src_tvar.propability <= 1);
			c_out_tvar.propability = c_src_tvar.propability;
			full_propability += c_src_tvar.propability;
			assert((full_propability + 0.0001) <= 1); //0.0001 is to account for floating point precision error
			amount_of_variants_without_propability += (int)(c_src_tvar.propability == 0.f); //Casting bool to int 
		}

		assert(((1.f - full_propability) >= (1.f - 0.0001f)) != (amount_of_variants_without_propability == 0)); //If there is no variants without propability and full propability does not match, this is an error //And also there is no contradiction, because the invalid propability is eliminated earlier in the code
		const fl32 propability_for_zero_elems = (1 - full_propability) / (fl32)amount_of_variants_without_propability;

		for (auto& i : res.tile_variants)
			if (i.propability == 0.f) i.propability = propability_for_zero_elems;

		res.atlas.SetData(output_txt_data, output_txt_size);

		return res;
	}
	/*
	struct TilesetData {
		JGFX::Texture atlas;
		std::array<pos2df32, 16> tile_offsets;
		pos2df32 uv_element_size;
		//|__|  |__|  |__|  |__|
		//|UL|  |__|  |__|  |__|
		//|__|  |UR|  |__|  |__|
		//|UL|  |UR|  |__|  |__|
		//|__|  |__|  |LL|  |__|
		//|UL|  |__|  |LL|  |__|
		//|__|  |UR|  |LL|  |__|
		//|UL|  |UR|  |LL|  |__|
		//|__|  |__|  |__|  |LR|
		//|UL|  |__|  |__|  |LR|
		//|__|  |UR|  |__|  |LR|
		//|UL|  |UR|  |__|  |LR|
		//|__|  |__|  |LL|  |LR|
		//|UL|  |__|  |LL|  |LR|
		//|__|  |UR|  |LL|  |LR|
		//|UL|  |UR|  |LL|  |LR|

		inline const pos2df32& GetTileOffset(bool upper_left, bool upper_right, bool lower_left, bool lower_right) const 
			{ return tile_offsets[GetTileId(upper_left, upper_right, lower_left, lower_right)]; }
	};

	TilesetData TsetFromAtlas(JGFX::Internal::TxtFnArg atlas) {
		const auto atlas_size = LLJGFX::Texture::GetSize(atlas);
		const auto& croplist = TextureProcessing::GenerateCroplist(atlas_size, 16, TILE_SIZE);

		const pos2df32 UV_RATIO = pos2df32{ 1.f } / (pos2df32)atlas_size;
		Cosmo::DGTS::TilesetData tset = {};
		for (int i = 0; i < 16; i++) {
			auto& c_cropp = croplist[i];
			tset.tile_offsets[i] = pos2df32{ c_cropp.pos.x, atlas_size.y - (c_cropp.pos.y + c_cropp.size.y) } *UV_RATIO;
		}
			//tset.tiles[i].SetData(sliced_textures[i], element_size);
		tset.uv_element_size = (pos2df32)TILE_SIZE * UV_RATIO;
		tset.atlas = atlas;

		return tset;
		//Cosmo::HG::Handle tset_handle = Cosmo::HG::Make(tset);
	}
	const TilesetData DEFAULT_TSET = {};
	*/
	namespace Internal {
		JE::AnonymousManager<DGTS_Data> manager;
	}

	typedef JE::MHandle<DGTS_Data> Handle;
	Handle NULL_TSET = { nullptr };
	bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }
	
	const DGTS_Data& GetRawTilesetData(Handle handle){ 
		assert(IsValid(handle));
		return Internal::manager[handle]; 
	}
	LLJGFX::Texture::Handle GetAtlas(Handle handle) {
		assert(IsValid(handle));
		return Internal::manager[handle].atlas.handle();
	}
	pos2du16 GetAtlasSize(Handle handle) {
		assert(IsValid(handle));
		return Internal::manager[handle].atlas.size();
	}
	pos2df32 GetTileAtlasOffset(Handle handle, int tile_variant_id, uint8 tile_id) {
		assert(IsValid(handle));
		assert(tile_id < 16);

		return Internal::manager[handle].tile_variants[tile_variant_id].offsets[tile_id];
	}
	pos2df32 PickTileOffset(Handle handle, pos2d32 tile_seed_pos, uint8 precomputed_tile_id) {
		assert(IsValid(handle));
		assert(precomputed_tile_id < 16);

		const auto& tset_dat = Internal::manager[handle];

		// will generate [0,1)
		fl32 random_number = 0;
		{
			size_t pos_hash = std::hash<pos2d32>{}(tile_seed_pos);
			std::mt19937_64 rng_seed(pos_hash);
			std::uniform_int_distribution<size_t> dist_seed(0, SIZE_MAX);

			std::mt19937_64 rng(dist_seed(rng_seed) * pos_hash);
			std::uniform_real_distribution<fl32> unif(0, 1);

			random_number = unif(rng);
		}

		for (int i = 0; i < tset_dat.tile_variants.size(); i++) {
			const auto& c_tvar = tset_dat.tile_variants[i];

			if (random_number < c_tvar.propability)
				return c_tvar.offsets[precomputed_tile_id];
			else 
				random_number -= c_tvar.propability;
		}
		assert(0); //If the number wasn't picked - error
		return { 0,0 };
	}

	Handle Make(const DGTS_Data& tset = {})
		{ return Internal::manager.Add(tset); }
	Handle Make(const std::vector<TileVariantDef>& tile_variants_defs) {
		return Make(MakeDgtsData(tile_variants_defs));
	}
	void Delete(Handle handle)
		{ Internal::manager.Remove(handle); }
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	namespace Scene {
	namespace Internal {
		struct Data {
			LLJE::Object::Handle player_obj = LLJE::Object::NULL_OBJECT;
			LLJE::PhysScene::Component::Data phys_data;
		};
		LLJE::Prefab::Handle player_obj_test = LLJE::Prefab::NULL_PREFAB;
		LLJE::ScenePreset::Handle compare_handle = LLJE::ScenePreset::NULL_PRESET;
	}

	typedef LLJE::Scene::Handle Handle;
	const Handle NULL_SCENE = { nullptr };

	inline bool IsTypeValid(Handle handle) {
		assert(LLJE::Scene::IsValid(handle));
		return LLJE::Scene::GetPreset(handle) == Internal::compare_handle;
	}

	Internal::Data& GetDataUnsafe(Handle handle) {
		assert(IsTypeValid(handle));
		return LLJE::Scene::Advanced::GetAdditionalData<Internal::Data>(handle);
	}
	}
	//TODO: support for different tilesets in the same tmap merging with dual grid system
	//TODO: unload old chunks
	//TODO: chunk saving and loading
	//TODO: biomes
	//TODO: (IDK) cave generation
	//TODO: collision mesher optimisation
	//TODO: surface object placement generation
	//TODO: looping chunks (like a planet should do)
	//TODO: when generating graphics cache, do not generate new chunks around the border(basically old function of getting tile generates a chunk if its not there, instead it should call the tile generation func, like GenerateTile(x, y) )
	//TODO: daynight cycle
	//TODO: physics dynamic origin shifting(to avoid floating point precision loss)

	namespace MainGameLayer {
	namespace Internal {
		LLJE::LayerPreset::Handle compare_handle = LLJE::LayerPreset::NULL_PRESET;
		const std::string je_vertex_shader_source =
			"#version 330 core\n"

			"layout(location = 0) in vec2 v_pos;\n"
			"layout(location = 1) in vec2 v_uv;\n"

			"uniform mat4 precomputed_matrix;"

			"out vec2 TexCoord;\n"

			"void main(){\n"
			"    gl_Position = precomputed_matrix * vec4(v_pos, 0.0, 1.0);\n"
			"    TexCoord = v_uv;\n"
			"}";
		const std::string je_fragment_shader_source = 
			"#version 330 core\n"

			"out vec4 FragColor;\n"
			"in vec2 TexCoord;\n"

			"uniform sampler2D ourTexture;\n"

			"void main(){\n"
			"    FragColor = texture(ourTexture, vec2(TexCoord.x, 1.f - TexCoord.y));\n"
			"}";
		LLJ2D::Shader2D::Handle tmap_shader = LLJ2D::Shader2D::Make(je_vertex_shader_source, je_fragment_shader_source);

		struct IrDrawListElement {
			//LLJ2D::TransfBuff::Handle transforms = LLJ2D::TransfBuff::NULL_TBUFF;
			JGFX::VertexCollection mesh;
			DGTS::Handle tile = DGTS::NULL_TSET;
		};
		struct ChunkData {
			DGTS::Handle* tiles;

			b2BodyId phys_handle = b2_nullBodyId;
			std::vector<b2ChainId> collision_meshes;

			//std::vector<JGFX::VertexCollection> cached_mesh;
			std::vector<IrDrawListElement> cached_draw_list;
			std::vector<JE::ChainShape> cached_collision_mesh;

			int cache_ver = 0;

			LLJE::GenericObjMap::ChunkData obj_dat = {};
		};
		struct Data {
			//::pos2df64 grid_size;
			pos2du16 tiles_in_chunk;
			DGTS::Handle base_tset;

			int curr_global_version = 0;

			LLJE::Chunksystem::ChunkMapData<ChunkData> chmap; //It was made as a pointers, because the struct itself is quite heavy 
			LLJE::GenericObjMap::ObjectmapData obj_dat;
		};
	}

	typedef LLJE::Layer::Handle Handle;
	const Handle NULL_TMAP = { nullptr };
		
	inline bool IsTypeValid(LLJE::Layer::Handle handle) {
		assert(LLJE::Layer::IsValid(handle));
		return LLJE::Layer::GetPreset(handle) == Internal::compare_handle;
	}
	inline bool IsValid(Handle handle)
		{ return LLJE::Layer::IsValid(handle); }
	pos2du16 GetChunkSize(Handle handle) { 
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle).tiles_in_chunk; 
	}
	
	const Internal::Data& GetData(Handle handle) {
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle);
	}

	namespace Functions {
		void MakeChunk(LLJE::Layer::Handle map, pos2d32 pos, Internal::ChunkData& c_chunk, void*) {
			const pos2du16 chunk_size = GetChunkSize(map); 
			//const ::pos2df64 grid_size = GetGridSize(map);

			c_chunk.tiles = (DGTS::Handle*)malloc(sizeof(DGTS::Handle) * chunk_size.x * chunk_size.y);
			memset(c_chunk.tiles, 0, sizeof(DGTS::Handle) * chunk_size.x * chunk_size.y);


			const Internal::Data& tmap_dat = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(map);
			const pos2d64 base_chunk_pos = LLJE::Convert::TileFromChunk(pos, chunk_size);
			for (int x = 0; x < chunk_size.x; x++) {
				const int32 row_height = Generation::GetTileHeight(base_chunk_pos.x + x);
				for (int y = 0; y < chunk_size.y; y++)
					c_chunk.tiles[y * chunk_size.x + x] = (y + base_chunk_pos.y <= row_height) ? tmap_dat.base_tset : DGTS::NULL_TSET;
			}

			/*
			//Spawning objects
			for (int x = 0; x < chunk_size.x; x++) {
				const int32 row_height = Generation::GetTileHeight(base_chunk_pos.x + x);

				pos2d32 placement_pos = { base_chunk_pos.x + x, row_height };
				if ((row_height > base_chunk_pos.y && row_height < base_chunk_pos.y + chunk_size.y) && SceneObj::SmallRock::CanBeSpawned(placement_pos, Generation::GetTileHeight)) {
					SceneObj::SmallRock::Make(map, LLJE::Convert::MetricFromTile(placement_pos + pos2d32{0, 2}, J2D::ToMetric(DGTS::TILE_SIZE)));
					x += 3;
				}
			}
			*/

			auto& scene_dat = LLJE::Scene::Advanced::GetAdditionalData<Scene::Internal::Data>(LLJE::Layer::GetParentScene(map));
			{
				b2BodyDef def = b2DefaultBodyDef();
				def.type = b2_staticBody;
				def.position = JPhys::ConvertToBV(LLJE::Convert::MetricFromChunk(pos, J2D::ToMetric(DGTS::TILE_SIZE) * (::pos2df64)chunk_size));
				c_chunk.phys_handle = b2CreateBody(LLJE::PhysScene::Component::GetWorldHandle(scene_dat.phys_data), &def);
			}
			//fmt::println("Chunk at pos {} {} was created", pos.x, pos.y);
			c_chunk.cache_ver = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(map).curr_global_version - 1;
		}
		void DeleteChunk(LLJE::Layer::Handle map, pos2d32 pos, Internal::ChunkData& c_chunk, void* = nullptr) {
			free(c_chunk.tiles);
			b2DestroyBody(c_chunk.phys_handle);

			LLJE::GenericObjMap::DestroyChunk(map, pos);
		}
		const JGFX::VertexLayout chunk_vertex_layout = {
			JGFX::VertexAttribute{0, JGFX::AttribType::FL32, 2},//pos
			JGFX::VertexAttribute{1, JGFX::AttribType::FL32, 2},//uv
		};
		struct ChunkMeshVertex {
			pos2df32 pos;
			pos2df32 uv;
		};
		const std::vector<ChunkMeshVertex> template_tile_mesh = {
				{{0, 0}, {0, 1}}, // bottom left
				{{0, 1}, {0, 0}}, // top left
				{{1, 1}, {1, 0}}, // top right
				{{1, 0}, {1, 1}}, // bottom right
		};
		const std::vector<uint32> template_tile_indices = {
				0, 1, 2,  // first Triangle
				0, 2, 3   // second Triangle
		};

		struct TmpChunkCache {
			std::vector<ChunkMeshVertex> mesh;
			std::vector<uint32> indexing_data;
		};

		void CacheChunk(Internal::Data& map_dat, Internal::ChunkData& chunk_dat, LLJE::Layer::Handle layer, pos2d32 chunk_pos);

		void TileChunkUpdater(LLJE::Layer::Handle map, pos2d32 pos, const LLJE::EngineContext& ctx, void*) {
			Internal::Data& c_map = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(map);
			if (!LLJE::Chunksystem::DoesChunkExists(c_map.chmap, pos)) LLJE::Chunksystem::MakeChunk<Internal::ChunkData, MakeChunk>(c_map.chmap, map, pos);

			Internal::ChunkData& c_chunk = LLJE::Chunksystem::GetChunk(c_map.chmap, pos);
			if (c_chunk.cache_ver != c_map.curr_global_version)
				CacheChunk(c_map, c_chunk, map, pos);

			const glm::mat4 chunk_pv = (glm::mat4)glm::translate<double>(ctx.layer_pv, {(::pos2df64)pos * LLJE::Chunksystem::GetMetricChunkSize(c_map.chmap), 0});
			LLJGFX::ShaderProgram::SetUniform(Internal::tmap_shader, "precomputed_matrix", chunk_pv);
			for (auto& i : c_chunk.cached_draw_list)
				JGFX::Draw(i.mesh, DGTS::GetRawTilesetData(i.tile).atlas, Internal::tmap_shader);

			if (glfwGetKey(glfwGetCurrentContext(), GLFW_KEY_H)) {
				LLJ2D::curr_pv = chunk_pv;
				Line::DrawRect({ 0,0 }, c_map.chmap.metric_chunk_size, J2D::ToMetric(1), {255, 255, 0, 255});
			}
		}
		void ObjectChunkUpdater(LLJE::Layer::Handle map, pos2d32 pos, const LLJE::EngineContext& ctx, void*) {
			LLJE::GenericObjMap::UpdateChunk(map, pos, ctx);
		}

		void UpdateLayer(LLJE::Layer::Handle map, const LLJE::EngineContext& ctx) {
			auto& layer_data = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(map);
			LLJE::Chunksystem::UpdateAndRenderChunks<Internal::ChunkData, TileChunkUpdater>(layer_data.chmap, map, ctx);
			LLJE::Chunksystem::UpdateAndRenderChunks<Internal::ChunkData, ObjectChunkUpdater>(layer_data.chmap, map, ctx);
		}
		void Destroy(LLJE::Layer::Handle handle) {
			auto& layer_data = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle);
			LLJE::Chunksystem::Clear<Internal::ChunkData, Functions::DeleteChunk>(layer_data.chmap, handle);
			delete (Internal::Data*)LLJE::Layer::Advanced::GetAdditionalData(handle);
		}
	}
	const LLJE::LayerPreset::Handle preset = LLJE::ObjectSys::LinkPreset(
		Internal::compare_handle = LLJE::LayerPreset::Make({ .UpdateLayer = Functions::UpdateLayer, .GetLayerTransformationMatrix = [](LLJE::Layer::Handle, ::pos2df64) {return glm::dmat4(1); }, .DeleteLayerData = Functions::Destroy }),
		LLJE::ObjectSys::MapIntegrationPreset{
			.GetMapData = [](LLJE::Layer::Handle layer) -> LLJE::GenericObjMap::ObjectmapData& { return LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(layer).obj_dat; },
			.GetChunkData = [](LLJE::Layer::Handle layer, pos2d32 pos) -> LLJE::GenericObjMap::ChunkData& { return LLJE::Chunksystem::GetChunk(LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(layer).chmap, pos).obj_dat; },
			.MakeChunk = [](LLJE::Layer::Handle layer, pos2d32 pos)->LLJE::GenericObjMap::ChunkData& { return LLJE::Chunksystem::MakeChunk<Internal::ChunkData, Functions::MakeChunk>(LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(layer).chmap, layer, pos, nullptr).obj_dat; },
			.DoesChunkExists = [](LLJE::Layer::Handle layer, pos2d32 pos) { return LLJE::Chunksystem::DoesChunkExists(LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(layer).chmap, pos); },
			.GetMetricChunkSize = [](LLJE::Layer::Handle layer) { return LLJE::Chunksystem::GetMetricChunkSize(LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(layer).chmap); },

			.notify_callbacks = {
				.AddObject = [](LLJE::Object::Handle obj) {
					if (LLJE::Object::GetPrefab(obj) == Scene::Internal::player_obj_test) {
						auto& scene_data = Scene::GetDataUnsafe(LLJE::Object::GetParentScene(obj));
						assert(!LLJE::Object::IsValid(scene_data.player_obj)); //Ensures that there could be only 1 player object

						scene_data.player_obj = obj;
					}
					//if the obj is player
				},
				.RemoveObject = [](LLJE::Object::Handle obj) {
					if (LLJE::Object::GetPrefab(obj) == Scene::Internal::player_obj_test) {
						auto& scene_data = Scene::GetDataUnsafe(LLJE::Object::GetParentScene(obj));
						scene_data.player_obj = LLJE::Object::NULL_OBJECT;
					}
					//if the obj is player
				}
			}
		}
	);

	inline void SetTile(Handle handle, DGTS::Handle tile, pos2d64 pos) {
		assert(IsValid(handle));
		assert(IsTypeValid(handle));

		const pos2du16 chunk_size = GetChunkSize(handle);
		const pos2d32 chunk_pos = LLJE::Convert::ChunkFromTile(pos, chunk_size);
		const pos2du16 local_tile_pos = LLJE::Convert::LocalTileFromGlobalTile(pos, chunk_size);

		auto layer_data = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle);
		if (!LLJE::Chunksystem::DoesChunkExists(layer_data.chmap, chunk_pos))
			LLJE::Chunksystem::MakeChunk<Internal::ChunkData, Functions::MakeChunk>(layer_data.chmap, handle, chunk_pos);
		Internal::ChunkData& c_chunk = LLJE::Chunksystem::GetChunk(layer_data.chmap, chunk_pos);

		c_chunk.tiles[chunk_size.x * local_tile_pos.y + local_tile_pos.x] = tile;
		c_chunk.cache_ver = layer_data.curr_global_version - 1;

		//Potential bug here
		if (local_tile_pos.x == 0 && LLJE::Chunksystem::DoesChunkExists(layer_data.chmap, chunk_pos - pos2d32{ 1, 0 }))
			LLJE::Chunksystem::GetChunk(layer_data.chmap, chunk_pos - pos2d32{ 1, 0 }).cache_ver = layer_data.curr_global_version - 1;
		if (local_tile_pos.y == 0 && LLJE::Chunksystem::DoesChunkExists(layer_data.chmap, chunk_pos - pos2d32{ 0, 1 }))
			LLJE::Chunksystem::GetChunk(layer_data.chmap, chunk_pos - pos2d32{ 0, 1 }).cache_ver = layer_data.curr_global_version - 1;
		if (local_tile_pos.x == 0 && local_tile_pos.y == 0 && LLJE::Chunksystem::DoesChunkExists(layer_data.chmap, chunk_pos - pos2d32{ 1, 1 }))
			LLJE::Chunksystem::GetChunk(layer_data.chmap, chunk_pos - pos2d32{ 1, 1 }).cache_ver = layer_data.curr_global_version - 1;
	}
	inline DGTS::Handle GetTile(Handle handle, pos2d64 pos) {
		assert(IsValid(handle));
		assert(IsTypeValid(handle));

		const pos2du16 chunk_size = GetChunkSize(handle);
		const pos2d32 chunk_pos = LLJE::Convert::ChunkFromTile(pos, chunk_size);
		const pos2du16 local_tile_pos = LLJE::Convert::LocalTileFromGlobalTile(pos, chunk_size);

		auto& layer_data = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle);
		if (!LLJE::Chunksystem::DoesChunkExists(layer_data.chmap, chunk_pos))
			LLJE::Chunksystem::MakeChunk<Internal::ChunkData, Functions::MakeChunk>(layer_data.chmap, handle, chunk_pos);

		const Internal::ChunkData& c_chunk = LLJE::Chunksystem::GetChunk(layer_data.chmap, chunk_pos);

		return c_chunk.tiles[chunk_size.x * local_tile_pos.y + local_tile_pos.x];
	}
	namespace Functions {
		void CacheChunk(Internal::Data& map_dat, Internal::ChunkData& chunk_dat, LLJE::Layer::Handle layer, pos2d32 chunk_pos) {
			const pos2du16& chunk_size = map_dat.tiles_in_chunk;
			const pos2df32 grid_size = J2D::ToMetric(DGTS::TILE_SIZE);

			std::unordered_map<DGTS::Handle, TmpChunkCache> tmp_cache;
			std::vector<JE::ChainShape> chain_segments;

			const pos2d32 chunk_tile_pos = LLJE::Convert::TileFromChunk(chunk_pos, chunk_size);

			for (int y = 0; y < chunk_size.y; y++) {
				for (int x = 0; x < chunk_size.x; x++) {
					const pos2d32 c_tile_global_pos = chunk_tile_pos + pos2d32{x, y};

					const std::array<pos2du16, 4> tile_points_offsets = {
							pos2du16{0, 1}, //UL
							pos2du16{1, 1}, //UR
							pos2du16{0, 0}, //LL
							pos2du16{1, 0}  //LR
					};

					std::array<DGTS::Handle, 4> tset_tiles;
					for (int i = 0; i < 4; i++) {
						const pos2du16 loc_tile_pos = pos2du16{ x, y } + tile_points_offsets[i];
						if (loc_tile_pos.x >= chunk_size.x || loc_tile_pos.y >= chunk_size.y)
							tset_tiles[i] = GetTile(layer, chunk_tile_pos + (pos2d32)loc_tile_pos);
						else tset_tiles[i] = chunk_dat.tiles[chunk_size.x * loc_tile_pos.y + loc_tile_pos.x];
					}

					DGTS::Handle base_tile = DGTS::NULL_TSET;
					for (auto& i : tset_tiles) {
						if (i != DGTS::NULL_TSET) {
							base_tile = i;
							break;
						}
					}
					if (base_tile != DGTS::NULL_TSET) {
						const bool upper_left = tset_tiles[0] != DGTS::NULL_TSET;
						const bool upper_right = tset_tiles[1] != DGTS::NULL_TSET;
						const bool lower_left = tset_tiles[2] != DGTS::NULL_TSET;
						const bool lower_right = tset_tiles[3] != DGTS::NULL_TSET;

						const int c_tile_id = DGTS::GetTileId(upper_left, upper_right, lower_left, lower_right);
						const pos2df32 metric_tile_pos = { x * grid_size.x + (grid_size.x * 0.5), y * grid_size.y + (grid_size.y * 0.5) };

						auto& c_mesh = tmp_cache[base_tile];
						const uint32 tile_start_vertex_id = c_mesh.mesh.size();

						//fmt::println("{}", TextureProcessing::TextureCoordsToUv(DGTS::TILE_SIZE, DGTS::GetAtlasSize(base_tile)).x);
						for (auto& i : template_tile_mesh) //Vertex data
							c_mesh.mesh.push_back({
								.pos = (i.pos * grid_size) + metric_tile_pos,
								.uv = DGTS::PickTileOffset(base_tile, c_tile_global_pos, DGTS::GetTileId(upper_left, upper_right, lower_left, lower_right)) + (i.uv * TextureProcessing::TextureLocalSizeToUv(DGTS::TILE_SIZE, DGTS::GetAtlasSize(base_tile)) * pos2df32{1, -1})
							});
						for (auto& i : template_tile_indices) //Indexing data
							c_mesh.indexing_data.push_back(i + tile_start_vertex_id);

						//Collision mesher
						{
							const auto& c_template = DGTS::default_collisions.chain_collision_segments[c_tile_id];

							for (auto c_template_chain : c_template) {
								for (pos2df32& c_point : c_template_chain)
									c_point += metric_tile_pos;

								int match_begin = -1;
								int match_end = -1;
								//std::vector<int> matches; //max possible size is 2
								for (int c_e_chain_id = 0; c_e_chain_id < chain_segments.size(); c_e_chain_id++) {//auto& c_existing_chain : chain_segments
									auto& c_existing_chain = chain_segments[c_e_chain_id];
									if (c_template_chain[0] == c_existing_chain.points.back())
										match_begin = c_e_chain_id;
									else if (c_template_chain.back() == c_existing_chain.points[0])
										match_end = c_e_chain_id;
								}
								int seg_count = (int)(match_begin != -1) + (int)(match_end != -1);
								if (seg_count) {
									//Biased to select Begin Point Match if possible
									auto& first_match = match_begin != -1 ? chain_segments[match_begin].points : chain_segments[match_end].points;
									bool is_first_match_begin = match_begin != -1;

									{
										first_match.erase(is_first_match_begin ? (first_match.end() - 1) : first_match.begin());
										first_match.insert(is_first_match_begin ? (first_match.end()) : first_match.begin(), c_template_chain.begin(), c_template_chain.end());
									}

									if (seg_count > 1) {
										//The other segment will always be the end one, because of the First Segment selection bias
										const auto& oth_match_chain = chain_segments[match_end].points;

										first_match.erase(first_match.end() - 1);
										first_match.insert(first_match.end(), oth_match_chain.begin(), oth_match_chain.end());


										chain_segments.erase(chain_segments.begin() + match_end);
									}
								}
								else
									chain_segments.push_back({ .points = c_template_chain });
							}
						}
					}
				}
			}

			chunk_dat.cached_draw_list.clear();
			for (const auto& [tile, c_mesh] : tmp_cache) {
				chunk_dat.cached_draw_list.push_back(Internal::IrDrawListElement{ .mesh = JGFX::VertexCollection(), .tile = tile});
				//chunk_dat.cached_draw_list.back().mesh.bound_buffers = {}; //PLEASE WORK!!!!
				chunk_dat.cached_draw_list.back().mesh.AddBuffer(JGFX::VertexBuffer{ c_mesh.mesh, chunk_vertex_layout }, "mesh");
				chunk_dat.cached_draw_list.back().mesh.SetIndexingData(c_mesh.indexing_data);
			}
			//auto test = chunk_dat.cached_draw_list[0].mesh["mesh"].data<ChunkMeshVertex>();
			
			{
				for (const auto& i : chunk_dat.collision_meshes)
					b2DestroyChain(i);
				chunk_dat.collision_meshes.clear();
				chunk_dat.collision_meshes.reserve(chain_segments.size());

				//chain is implicitly longer than 1
				for (auto& i : chain_segments) {
					b2ChainDef chain_def = b2DefaultChainDef();

					b2SurfaceMaterial chain_material = b2DefaultSurfaceMaterial();
					chain_def.materials = &chain_material;
					chain_def.materialCount = 1;
          chain_def.enableSensorEvents = true;

					chain_def.isLoop = i.is_loop;

					//TODO: fix this, this is temporary
					i.points.push_back(i.points.back());
					i.points.insert(i.points.begin(), i.points[0]);

					chain_def.points = (b2Vec2*)i.points.data();
					chain_def.count = i.points.size();

					chunk_dat.collision_meshes.push_back(b2CreateChain(chunk_dat.phys_handle, &chain_def));
				}
			}
			chunk_dat.cache_ver = map_dat.curr_global_version;
		}
	}

	inline LLJE::Layer::Handle MakeLayer(LLJE::Scene::Handle scene, DGTS::Handle base_tset, LLJE::Layer::SceneInsertionDirection direction = LLJE::Layer::BACK, int insertion_id = 0, 
				pos2du16 chunk_size = {16,16}) {
		Internal::Data* tmp_dat = new Internal::Data{ 
			.tiles_in_chunk = chunk_size, 
			.chmap = {
				.metric_chunk_size = J2D::ToMetric(DGTS::TILE_SIZE) * (::pos2df64)chunk_size, 
				//.upper_view_range_extension = -J2D::ToMetric(DGTS::TILE_SIZE), 
				.lower_view_range_extension = J2D::ToMetric(DGTS::TILE_SIZE)
			}, 
			.base_tset = base_tset
		};
		return LLJE::Layer::Make(
			preset,
			scene,
			direction,
			insertion_id,
			tmp_dat
		); 
	}
	inline void Delete(Handle handle) 
		{ LLJE::Layer::Delete(handle); }
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	namespace Scene {
	namespace Functions {
		void DeleteSceneData(Scene::Handle scene) {
			auto& data = LLJE::Scene::Advanced::GetAdditionalData<Internal::Data>(scene);
			LLJE::PhysScene::Component::Delete(data.phys_data);
			delete (Internal::Data*)LLJE::Scene::Advanced::GetAdditionalDataPtr(scene);
		}

		void AddLayer(LLJE::Scene::Handle scene, LLJE::Layer::Handle layer) {
			//assert(LLJE::Layer::GetPreset(layer) == MainGameLayer::Internal::compare_handle);
		}

		void Update(Scene::Handle scene, J2D::Cam2D& camera, void*, size_t) {
			auto& data = LLJE::Scene::Advanced::GetAdditionalData<Internal::Data>(scene);

			LLJE::PhysScene::Component::UpdateScene(data.phys_data);
			
			if (LLJE::Object::IsValid(data.player_obj))
				camera.center_pos = LLJE::Object::GetPos(data.player_obj);
		}
	}
	const LLJE::ScenePreset::Handle preset = Internal::compare_handle = LLJE::PhysScene::Component::IntegratePreset(
		LLJE::ScenePreset::Make({ 
			.AddLayer = Functions::AddLayer, 
			.DeleteSceneData = Functions::DeleteSceneData, 
			.UpdateScene = Functions::Update 
		}), 
		{ 
			.GetSceneData = [](LLJE::Scene::Handle handle)->LLJE::PhysScene::Component::Data& { return LLJE::Scene::Advanced::GetAdditionalData<Internal::Data>(handle).phys_data; } 
		}
	);// , Functions::ChmapCopier);
	/*
	b2WorldId GetPhysHandle(Handle handle) {
		assert(IsTypeValid(handle));
		return LLJE::Scene::Advanced::GetAdditionalData<Internal::Data>(handle).world;
	}*/
	/*
	inline void TurnInto(Scene::Handle scene) { 
		assert(LLJE::Scene::IsValid(scene));
		const auto& layer_list = LLJE::Scene::ListLayers(scene);
		for (const auto& i : layer_list)
			assert(MainGameLayer::IsTypeValid(i));



		b2WorldDef def = b2DefaultWorldDef();
		def.gravity = { 0, -13.8 };
		Internal::Data init_dat = { .world = b2CreateWorld(&def) };
		LLJE::Scene::Advanced::SetPreset(scene, preset, &init_dat);
	}*/

	//void Copy(LLJE::Scene::Handle to, Scene::Handle from) {
	//	assert(IsTypeValid(from));

	//	LLJE::Scene::ClearLayerList(to);
	//	TurnInto(to);


	//	const auto& src_layers = LLJE::Scene::ListLayers(from);
	//	for (const auto& i : src_layers)
	//		MainGameLayer::MakeLayer(i, to);


		/*
		When needed, put here code for copying scene data
		*/

	//	LLJE::Scene::SetBackgroundColor(to, LLJE::Scene::GetBackgroundColor(from));
	//}

	inline Handle Make(pos2df32 gravity, rgb color = LLJE::Scene::Internal::DEFAULT_BACKGROUND_COLOR) {
		b2WorldDef def = b2DefaultWorldDef();
		def.gravity = { gravity.x, gravity.y };
		Internal::Data* init_dat = new Internal::Data{ .phys_data = LLJE::PhysScene::Component::Initialize(def) };

		return LLJE::Scene::Make(color, preset, init_dat);  
	}
	//inline Handle Make(Handle from) {
	//	Handle handle = LLJE::Scene::Make();
	//	Copy(handle, from);
	//	return handle;
	//}
	} //Namespace Scene
}
