#pragma once
#include <JGFX/JGFX.h>
#include "../Engine/Engine.h"
#include <box2d/box2d.h>
#include <unordered_set>
#include <PerlinNoise.hpp>

namespace Cosmo {
	namespace BackgroundTS {
	struct BgSegment {
		JGFX::Texture txt;
		//fl32 propability = 0.f;
	};
	struct Data {
		std::vector<BgSegment> top_segments;
		std::vector<BgSegment> bottom_segments;
	};

	namespace Internal {
		JE::AnonymousManager<Data> manager;
	}

	
	typedef JE::MHandle<Data> Handle;
	Handle NULL_TSET = { nullptr };
	bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }
	
	const Data& GetRawTilesetData(Handle handle){ 
		assert(IsValid(handle));
		return Internal::manager[handle]; 
	}

	namespace Internal {
		LLJGFX::Texture::Handle PickSegment(const std::vector<BgSegment>& segments, pos2d32 chunk_seed_pos) {
			if (segments.size() == 0)
				return { nullptr };

			fl32 random_number = 0;
			{
				size_t pos_hash = std::hash<pos2d32>{}(chunk_seed_pos);
				std::mt19937_64 rng_seed(pos_hash);
				std::uniform_int_distribution<size_t> dist_seed(0, SIZE_MAX);

				std::mt19937_64 rng(dist_seed(rng_seed) * pos_hash);
				std::uniform_real_distribution<fl32> unif(0, 1);

				random_number = unif(rng);
			}

			for (int i = 0; i < segments.size(); i++) {
				const auto& c_svar = segments[i];
				const fl32 propability = 1.f / segments.size();

				if (random_number < propability)
					return c_svar.txt.handle();
				else
					random_number -= propability;
			}
			assert(0); //If the number wasn't picked - error
			return { nullptr };
		}
	}
	LLJGFX::Texture::Handle PickBottomSegment(Handle handle, pos2d32 chunk_seed_pos) {
		assert(IsValid(handle));

		const auto& tset_dat = Internal::manager[handle];
		return Internal::PickSegment(tset_dat.bottom_segments, chunk_seed_pos);
	}
	LLJGFX::Texture::Handle PickTopSegment(Handle handle, pos2d32 chunk_seed_pos) {
		assert(IsValid(handle));

		const auto& tset_dat = Internal::manager[handle];
		return Internal::PickSegment(tset_dat.top_segments, chunk_seed_pos);
	}


	Handle Make(const Data& tset = {}) { 
		return Internal::manager.Add(tset); 
	}
	void Delete(Handle handle)
		{ Internal::manager.Remove(handle); }
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	namespace Background {
	namespace Internal {
		LLJE::LayerPreset::Handle compare_handle = LLJE::LayerPreset::NULL_PRESET;
		struct ChunkData {
			LLJGFX::Texture::Handle cached_bg_segment;
		};
		struct Data {
			BackgroundTS::Handle bg_segments;
			LLJE::Chunksystem::ChunkMapData<ChunkData> chmap; //It was made as a pointers, because the struct itself is quite heavy 
			pos2df32 parallax_speed;
			pos2df32 local_metric_offset;
		};
	}

	typedef LLJE::Layer::Handle Handle;
	const Handle NULL_TMAP = { nullptr };
		
	inline bool IsTypeValid(LLJE::Layer::Handle handle) {
		assert(LLJE::Layer::IsValid(handle));
		return LLJE::Layer::GetPreset(handle) == Internal::compare_handle;
	}
	inline bool IsValid(Handle handle)
		{ return LLJE::Layer::IsValid(handle); }
	pos2df64 GetChunkSize(Handle handle) { 
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle).chmap.metric_chunk_size; 
	}
	
	const Internal::Data& GetData(Handle handle) {
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle);
	}

	namespace Functions {
		void MakeChunk(LLJE::Layer::Handle map, pos2d32 pos, Internal::ChunkData& c_chunk, void* dat = nullptr) {
			const Internal::Data& tmap_dat = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(map);
			c_chunk.cached_bg_segment = pos.y == 0 ? BackgroundTS::PickTopSegment(tmap_dat.bg_segments, pos) : pos.y < 0 ? BackgroundTS::PickBottomSegment(tmap_dat.bg_segments, pos) : LLJGFX::Texture::Handle{ nullptr };
		}
		void DeleteChunk(LLJE::Layer::Handle map, pos2d32 pos, Internal::ChunkData& c_chunk, void* = nullptr) {} //Dont do anything

		void TileChunkUpdater(LLJE::Layer::Handle map, pos2d32 pos, const LLJE::EngineContext& ctx, void*) {
			Internal::Data& c_map = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(map);
			if (!LLJE::Chunksystem::DoesChunkExists(c_map.chmap, pos)) LLJE::Chunksystem::MakeChunk<Internal::ChunkData, MakeChunk>(c_map.chmap, map, pos);

			Internal::ChunkData& c_chunk = LLJE::Chunksystem::GetChunk(c_map.chmap, pos);
			LLJE::DrawSpriteMetric(c_chunk.cached_bg_segment, c_map.chmap.metric_chunk_size, LLJE::Convert::MetricFromChunk(pos, c_map.chmap.metric_chunk_size), ctx);
		}
		void ObjectChunkUpdater(LLJE::Layer::Handle map, pos2d32 pos, const LLJE::EngineContext& ctx, void*) {
			LLJE::GenericObjMap::UpdateChunk(map, pos, ctx);
		}

		void UpdateLayer(LLJE::Layer::Handle map, const LLJE::EngineContext& ctx) {
			auto& layer_data = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(map);
			LLJE::Chunksystem::UpdateAndRenderChunks<Internal::ChunkData, TileChunkUpdater>(layer_data.chmap, map, ctx);
			//LLJE::Chunksystem::UpdateAndRenderChunks<Internal::ChunkData, ObjectChunkUpdater>(layer_data.chmap, map, ctx);
		}
		void Destroy(LLJE::Layer::Handle handle) {
			auto& layer_data = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle);
			LLJE::Chunksystem::Clear<Internal::ChunkData, Functions::DeleteChunk>(layer_data.chmap, handle);
			delete (Internal::Data*)LLJE::Layer::Advanced::GetAdditionalData(handle);
		}
	}
	const LLJE::LayerPreset::Handle preset = Internal::compare_handle = LLJE::LayerPreset::Make({ 
		.UpdateLayer = Functions::UpdateLayer, 
		.GetLayerTransformationMatrix = [](LLJE::Layer::Handle layer, ::pos2df64 camera_pos) {
			const auto& dat = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(layer);
			return J2D::TransfProps{}.MakeMatrix(
				glm::translate<fl64>(glm::dmat4(1), { LLJE::RoundToPixels({(pos2df64)dat.local_metric_offset + (camera_pos * (pos2df64)dat.parallax_speed)}), 0. })
			);
		}, 
		.DeleteLayerData = Functions::Destroy 
	});

	inline LLJE::Layer::Handle MakeLayer(LLJE::Scene::Handle scene, BackgroundTS::Handle base_tset, pos2df32 parallax_speed, pos2df32 local_offset = {0, 0}, pos2df32 grid_size = {32, 32}, LLJE::Layer::SceneInsertionDirection direction = LLJE::Layer::BACK, int insertion_id = 0) {
		Internal::Data* tmp_dat = new Internal::Data{ 
			.bg_segments = base_tset,
			.chmap = {
				.metric_chunk_size = grid_size
			},
			.parallax_speed = parallax_speed,
			.local_metric_offset = local_offset
		};
		return LLJE::Layer::Make(
			preset,
			scene,
			direction,
			insertion_id,
			tmp_dat
		); 
	}
	}

	namespace SkyBackground {
	namespace Internal {
		LLJE::LayerPreset::Handle compare_handle = LLJE::LayerPreset::NULL_PRESET;
		struct ChunkData {
			//LLJGFX::Texture::Handle cached_bg_segment;
		};
		struct Data {
			LLJGFX::Texture::Handle stars_texture;
			LLJGFX::Texture::Handle sky_atmosphere_texture;
			fl32 atmosphere_height;
			fl32 surface_height;
			//BackgroundTS::Handle bg_segments;
			LLJE::Chunksystem::ChunkMapData<ChunkData> chmap; //It was made as a pointers, because the struct itself is quite heavy 
			//pos2df32 parallax_speed;
			//pos2df32 local_metric_offset;
		};
	}

	typedef LLJE::Layer::Handle Handle;
	const Handle NULL_TMAP = { nullptr };
		
	inline bool IsTypeValid(LLJE::Layer::Handle handle) {
		assert(LLJE::Layer::IsValid(handle));
		return LLJE::Layer::GetPreset(handle) == Internal::compare_handle;
	}
	inline bool IsValid(Handle handle)
		{ return LLJE::Layer::IsValid(handle); }
	pos2df64 GetChunkSize(Handle handle) { 
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle).chmap.metric_chunk_size; 
	}
	
	const Internal::Data& GetData(Handle handle) {
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle);
	}

	namespace Functions {
		void MakeChunk(LLJE::Layer::Handle map, pos2d32 pos, Internal::ChunkData& c_chunk, void* dat = nullptr) {} //Dont do anything
		void DeleteChunk(LLJE::Layer::Handle map, pos2d32 pos, Internal::ChunkData& c_chunk, void* = nullptr) {} //Dont do anything

		void TileChunkUpdater(LLJE::Layer::Handle map, pos2d32 pos, const LLJE::EngineContext& ctx, void*) {
			Internal::Data& c_map = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(map);

			const fl64 cam_y = ctx.cam->center_pos.y;
			fl32 sky_transparency = std::clamp((cam_y - c_map.surface_height) / (c_map.atmosphere_height - c_map.surface_height), 0., 1.);

			LLJE::DrawSpriteMetric(c_map.stars_texture, c_map.chmap.metric_chunk_size, LLJE::Convert::MetricFromChunk(pos, c_map.chmap.metric_chunk_size), ctx);
			LLJE::DrawSpriteMetric(c_map.sky_atmosphere_texture, c_map.chmap.metric_chunk_size, LLJE::Convert::MetricFromChunk(pos, c_map.chmap.metric_chunk_size), ctx, {}, sky_transparency);
		}
		void ObjectChunkUpdater(LLJE::Layer::Handle map, pos2d32 pos, const LLJE::EngineContext& ctx, void*) {
			LLJE::GenericObjMap::UpdateChunk(map, pos, ctx);
		}

		void UpdateLayer(LLJE::Layer::Handle map, const LLJE::EngineContext& ctx) {
			auto& layer_data = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(map);
			LLJE::Chunksystem::UpdateAndRenderChunks<Internal::ChunkData, TileChunkUpdater>(layer_data.chmap, map, ctx);
		}
		void Destroy(LLJE::Layer::Handle handle) {
			auto& layer_data = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(handle);
			LLJE::Chunksystem::Clear<Internal::ChunkData, Functions::DeleteChunk>(layer_data.chmap, handle);
			delete (Internal::Data*)LLJE::Layer::Advanced::GetAdditionalData(handle);
		}
	}
	const LLJE::LayerPreset::Handle preset = Internal::compare_handle = LLJE::LayerPreset::Make({ 
		.UpdateLayer = Functions::UpdateLayer, 
		.GetLayerTransformationMatrix = [](LLJE::Layer::Handle layer, ::pos2df64 camera_pos) {
			const auto& dat = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::Data>(layer);
			return J2D::TransfProps{}.MakeMatrix(
				glm::translate<fl64>(glm::dmat4(1), { (camera_pos + dat.chmap.metric_chunk_size / 2.), 0. })
			);
		}, 
		.DeleteLayerData = Functions::Destroy 
	});

	inline LLJE::Layer::Handle MakeLayer(LLJE::Scene::Handle scene, LLJGFX::Texture::Handle stars_txt, LLJGFX::Texture::Handle atmosphere_txt, fl32 surface_height, fl32 atmosphere_height, pos2df32 grid_size = {32, 32}, LLJE::Layer::SceneInsertionDirection direction = LLJE::Layer::BACK, int insertion_id = 0) {
		Internal::Data* tmp_dat = new Internal::Data{ 
			.stars_texture = stars_txt,
			.sky_atmosphere_texture = atmosphere_txt,
			.atmosphere_height = atmosphere_height,
			.surface_height = surface_height,
			.chmap = {
				.metric_chunk_size = grid_size
			},
		};
		return LLJE::Layer::Make(
			preset,
			scene,
			direction,
			insertion_id,
			tmp_dat
		); 
	}
	}
}