#pragma once
#include "../Engine/Engine.h"
#include "Background.h"
#include "Global.h"
//#include "CosmonatorTmaps.h"

namespace Cosmo {
	Cosmo::DGTS::Handle main_tset = Cosmo::DGTS::Make({ 
		Cosmo::DGTS::MakeTileVarDef(LLJGFX::Texture::Make(cosmo_res_loc + "Atlas.png")), 
		Cosmo::DGTS::MakeTileVarDef(LLJGFX::Texture::Make(cosmo_res_loc + "Atlas2.png")), 
		Cosmo::DGTS::MakeTileVarDef(LLJGFX::Texture::Make(cosmo_res_loc + "Atlas3.png")) 
	});

	JGFX::ShaderProgram default_shader = {
		//--------Vertex shader
		"#version 330 core\n"

		"layout(location = 0) in vec2 v_pos;\n"
		"layout(location = 1) in vec2 v_uv;\n"

		"uniform mat4 precomputed_matrix;"

		"out vec2 TexCoord;\n"

		"void main(){\n"
		"    gl_Position = precomputed_matrix * vec4(v_pos, 0.0, 1.0);\n"
		"    TexCoord = v_uv;\n"
		"}",

		//-------Fragment shader
		"#version 330 core\n"

		"out vec4 FragColor;\n"
		"in vec2 TexCoord;\n"

		"uniform sampler2D ourTexture;\n"

		"void main(){\n"
		"    FragColor = texture(ourTexture, vec2(TexCoord.x, 1.f - TexCoord.y));\n"
		"}"
	};

	Cosmo::BackgroundTS::Handle bg_far_ts = Cosmo::BackgroundTS::Make({
		.top_segments = {
			{.txt = JGFX::Texture{cosmo_res_loc + "PlanetBgFar.png"}}
		},
		.bottom_segments = {
			{.txt = JGFX::Texture{cosmo_res_loc + "Gray.png"}}
		}
	});
	Cosmo::BackgroundTS::Handle bg_medium_ts = Cosmo::BackgroundTS::Make({
		.top_segments = {
			{.txt = JGFX::Texture{cosmo_res_loc + "PlanetBgClose.png"}}
		}
	});
	Cosmo::BackgroundTS::Handle bg_close_ts = Cosmo::BackgroundTS::Make({
		.top_segments = {
			{.txt = JGFX::Texture{cosmo_res_loc + "PlanetBgSuperClose.png"}}
		}
	});
	JGFX::Texture space_bg_t = { cosmo_res_loc + "Space.png" };
	JGFX::Texture mask_t = { cosmo_res_loc + "SurfaceMask.png" };
	//LLJE::Tile::Handle planet_bg_far_t = LLJE::Tile::Make(LLJGFX::Texture::Make("../../../Cosmonator/PlanetBgFar.png"));
	//LLJE::Tile::Handle planet_bg_close_t = LLJE::Tile::Make(LLJGFX::Texture::Make("../../../Cosmonator/PlanetBgClose.png"));
	//LLJE::Tile::Handle planet_bg_super_close_t = LLJE::Tile::Make(LLJGFX::Texture::Make("../../../Cosmonator/PlanetBgSuperClose.png"));
	//LLJE::Tile::Handle gray_filler = LLJE::Tile::Make(LLJGFX::Texture::Make("../../../Cosmonator/Gray.png"));

	/*LLJE::Tile::Handle LineSelector(const LLJE::BackgroundTmap::BgElemPool& pool, LLJE::BackgroundTmap::Handle map, pos2d64 pos) {
		if (!pool.segments.size())
			return LLJE::Tile::NULL_TILE;

		if (pos.y == 0) {
			return pool.segments[0];
		}
		else if (pos.y < 0) return gray_filler;
	}

	inline LLJE::Layer::Handle MakeBG(LLJE::Tile::Handle base_tile, pos2df64 parallax_speed = {0, 0}, pos2df64 base_offset = {0,0}) {
		LLJE::BackgroundTmap::Handle bg = LLJE::BackgroundTmap::Make(base_tile, { 1,1 }, { {base_tile}, Cosmo::LineSelector });
		return LLJE::Layer::Make(LLJE::BackgroundTmap::GetGenericTmapHandle(bg), parallax_speed, {}, base_offset);
	}*/
}
