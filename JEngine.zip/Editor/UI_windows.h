#pragma once
#include "../Engine/Engine.h"
#include "Subsystems/ImGuiHelper.h"

#include "../PSN_Game/Global.h"
//#include "../PSN_Game/Map.h"
//#include "../PSN_Game/Player.h"
#include "EngSubsysImpl/Map.h"
#include "../Engine/Utility/DrawLine.h"
#include "Resources/Resources.h"
#include "Subsystems/FilesystemBase.h"
#include "TextureFileType.h"
#include "Subsystems/WindowManagementSystem.h"
#include <stack>
#include "EditorGlobals.h"

namespace Editor {
	//File::Handle test = Folder::Make("Папка тест1", ROOT_FOLDER);
	//File::Handle test2 = Folder::Make("Тест 2", ROOT_FOLDER);
	//File::Handle inner = Folder::Make("Вложенная папка тест 3", test);
	//File::Handle inner2 = Folder::Make("Папка 4", test);
	//File::Handle txt = Texture::Make(LLJGFX::Texture::Make("../../Editor/DebugTxt.png"), "Текстура", ROOT_FOLDER);
}
#include "Windows/ExampleWindows.h"
#include "Windows/Viewport.h"
#include "Windows/TilePalette.h"
#include "Windows/FileExplorer.h"
#include "Windows/TextureSlicer.h"
#include "Windows/SceneLayerEditor.h"
#include "Windows/Misc.h"
#include "SceneFileType.h"
