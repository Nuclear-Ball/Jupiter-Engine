#pragma once
#include "../Subsystems/WindowManagementSystem.h"
#include "../Subsystems/ImGuiHelper.h"

#include "../EngSubsysImpl/Map.h"
#include "FileExplorer.h"
#include "Viewport.h"

namespace Editor {
	namespace CollisionMeshEditor {

		void DrawChainShape(const JE::ChainShape& chain, LLJGFX::Texture::Handle framebuffer, rgb color) {
			//const pos2df64 metric_fb_size = J2D::ToMetric(LLJGFX::Texture::GetSize(framebuffer));

			//LLJ2D::curr_pv = glm::ortho(0., metric_fb_size.x, 0., metric_fb_size.y, -10., 10.);

			for (int i = 0; i < chain.points.size(); i++) {

			}
		}
		struct ChainData {
			JGFX::Texture thumbnail;
			JE::ChainShape chain;
		};
		struct CollisionEditorState {
			//File::Handle opened_texture;
			J2D::MetricCam2D cam = { {300, 300}, J2D::ToMetric({64, 64}) };
			JGFX::Texture polygon_thumbnail_framebuffer;
			//J2D::Cam2D polygon_thumbnail_cam = { {10, 10} };

			std::vector<ChainData> polygons;
			std::vector<JGFX::Texture> polygon_thumbnails;
			int selected_polygon = -1;
			int selected_point = -1;
		};
		CollisionEditorState InitializeState(const std::vector<JE::ChainShape>& polygons) {
			std::vector<ChainData> res;
			for (auto& i : polygons)
				res.push_back({ .chain = i });
			return { .polygons = res };
		}

		bool EditCollisionMesh(std::vector<JE::ChainShape>& dest, const std::vector<JE::ChainShape>& initial_value, LLJGFX::Texture::Handle base_txt, CollisionEditorState& state) {
			const ImGuiStyle& STYLE = ImGui::GetStyle();
			const auto c_txt_size = LLJGFX::Texture::GetSize(base_txt);
			const auto c_txt_metric_size = J2D::ToMetric(c_txt_size);
			J2D::MetricCam2D& cam = state.cam;
			auto& polys = state.polygons;
			auto& selected_polygon = state.selected_polygon;
			auto& selected_point = state.selected_point;

			ImGui::OpenPopup("Редактировать физический меш", ImGuiPopupFlags_NoReopen); //Must be placed here, otherwise it for some unknown reason wouldnt work
			ImGui::SetNextWindowSize({ 400, 500 }, ImGuiCond_Once);
			bool is_opened = true;
			bool confirm = false;
			if (ImGui::BeginPopupModal("Редактировать физический меш", &is_opened)) {

				static ImVec2 previous_window_size = ImGui::GetContentRegionAvail();
				const auto window_size = ImGui::GetContentRegionAvail();
				static ImVec2 previous_top_bar_size = { 0, 400 };

				if (window_size.y != previous_window_size.y) {
					const fl32 size_diff = previous_window_size.y - window_size.y;
					ImGui::SetNextWindowSize({ 0, previous_top_bar_size.y - size_diff / 2.f });
				}
				previous_window_size = window_size;

				ImGui::BeginChild("Upper area", { 0, 400 }, ImGuiChildFlags_ResizeY); //Main child
				previous_top_bar_size = ImGui::GetContentRegionAvail();
				//------------------------------------------------------------------------------SIDE BAR-------------------------------------------------------------------
				{
					const int POLYGON_SELECTABLE_SIZE = 50;
					const int SLICER_THUMBNAIIL_SIZE = 45;
					const fl32 SLICER_INNER_PADDING = (fl32)(POLYGON_SELECTABLE_SIZE - SLICER_THUMBNAIIL_SIZE) / 2.f;
					const pos2df32 UV_RATIO = pos2df32{ 1.f } / (pos2df32)c_txt_size;

					ImGui::BeginChild("Side bar", { 160, 0 }, ImGuiChildFlags_ResizeX | ImGuiChildFlags_NavFlattened, ImGuiWindowFlags_NoScrollbar);
					ImGui::BeginChild("Slicers", { 0, -(POLYGON_SELECTABLE_SIZE + STYLE.ItemSpacing.y) }, ImGuiChildFlags_NavFlattened);
					for (int i = 0; i < polys.size(); i++) {
						if (ImGui::Selectable(fmt::format("##slicer{}", i).c_str(), i == selected_polygon, 0, { ImGui::GetContentRegionAvail().x, POLYGON_SELECTABLE_SIZE })) {
							selected_polygon = i;
							selected_point = -1;
						}
						if (ImGui::BeginPopupContextItem(fmt::format("##slicer menu{}", i).c_str())) {
							if (ImGui::MenuItem("Удалить")) {
								polys.erase(polys.begin() + i);
								selected_polygon = selected_polygon >= i ? selected_polygon - 1 : selected_polygon;
							}
							ImGui::EndPopup();
						}
						//TODO: implement swapping
						/*
						if (ImGui::IsItemActive() && !ImGui::IsItemHovered()) {
							int next = i + (ImGui::GetMouseDragDelta().y >= 0 ? 1 : -1);

							if (next >= 0 && next < slice_list.size()) {
								std::swap(slice_list[next], slice_list[i]);
								ImGui::ResetMouseDragDelta();
							}
						}*/

						if (i < polys.size()) { //The "if" is to prevent program from crashing after deleting an element
							const ImVec2 next_slicer_pos = ImGui::GetCursorPos();
							ImGui::SetCursorPosY(ImGui::GetCursorPosY() - (POLYGON_SELECTABLE_SIZE + STYLE.ItemSpacing.y)); //must clip inside of a selectable

							ImGui::SetCursorPosX(ImGui::GetCursorPosX() + SLICER_INNER_PADDING);
							ImGui::SetCursorPosY(ImGui::GetCursorPosY() + SLICER_INNER_PADDING);
							const auto thumbnail_start_pos = ImGui::GetCursorPos();

							auto& c_polygon_data = polys[i];
							const auto& c_polygon = polys[i].chain;
							static J2D::MetricCam2D thumbnail_renderer = { {SLICER_THUMBNAIIL_SIZE, SLICER_THUMBNAIIL_SIZE}, {1,1} };
							{
								const fl64 line_thickness = J2D::ToMetric(3) * (c_txt_metric_size.x > c_txt_metric_size.y ? c_txt_metric_size.x : c_txt_metric_size.y) / J2D::ToMetric(SLICER_THUMBNAIIL_SIZE);
								thumbnail_renderer.metric_size = pos2df64{ (c_txt_metric_size.x > c_txt_metric_size.y ? c_txt_metric_size.x : c_txt_metric_size.y) + line_thickness * 2 }; 
								thumbnail_renderer.center_pos = c_txt_metric_size / pos2df64{ 2. };

								//Render it
								thumbnail_renderer.Bind();
								JGFX::Clear({ 0,0,0,0 });
								for (int c_point_id = 0; c_point_id < c_polygon.points.size(); c_point_id++) {
									pos2df64 point_1 = (pos2df64)c_polygon.points[c_point_id];
									pos2df64 point_2 = (pos2df64)c_polygon.points[c_point_id + 1 <= c_polygon.points.size() - 1 ? c_point_id + 1 : 0];

									uint8 transparency = uint8((blink_color + 0.25f) / rgb_ratio);
									Line::DrawMeshed(point_1, point_2, line_thickness, rgb{ 30, 150, 50, 255 });
									Line::DrawMeshed(point_1, point_2, J2D::ToMetric(0.125) / cam.props.scale.x, rgb{ 50, 200, 70, 255 });
								}
								win.Bind();
								c_polygon_data.thumbnail = thumbnail_renderer.frm;
							}

							ImGui::Image((ImTextureID)c_polygon_data.thumbnail.handle().data->texture_gpu_handle, {SLICER_THUMBNAIIL_SIZE, SLICER_THUMBNAIIL_SIZE}, {0,1}, {1,0});
							ImGui::SameLine();

							const ImVec2 text_start_pos = { ImGui::GetCursorPosX(), thumbnail_start_pos.y };
							ImGui::SetCursorPos(text_start_pos);
							ImGui::Text(fmt::format("Сегмент {}", i).c_str());
							ImGui::SetCursorPos({ text_start_pos.x, text_start_pos.y + ImGui::GetTextLineHeight() + STYLE.ItemSpacing.y });
							ImGui::Text(fmt::format("Точек: {}", c_polygon.points.size()).c_str());
							ImGui::SetCursorPos(next_slicer_pos);
						}
						ImGui::Separator();
					}
					ImGui::EndChild();

					const fl32 button_width = ImGui::GetContentRegionAvail().x;//(ImGui::GetContentRegionAvail().x + STYLE.ItemSpacing.x) / 2.f;
					if (ImGui::Button("Добавить", { button_width, POLYGON_SELECTABLE_SIZE })) {
						polys.push_back({ .chain = JE::ChainShape{.points = {{0, 0}, {c_txt_metric_size.x, 0}, {c_txt_metric_size.x, c_txt_metric_size.y}, {0, c_txt_metric_size.y}}, .is_loop = true } });
						selected_polygon = polys.size() - 1;
					}
					//ImGui::SameLine();
					//if (ImGui::Button("Очистить", { button_width, POLYGON_SELECTABLE_SIZE })) {
					//	polys.clear();
					//	selected_polygon = -1;
					//}
					ImGui::EndChild();
					ImGui::SameLine();
					ImGui::SetCursorPosX(ImGui::GetCursorPosX() - STYLE.ItemSpacing.x);
					ImGui::SeparatorEx(ImGuiSeparatorFlags_Vertical);
					ImGui::SameLine();
				}


				{
					//--------------------DRAWING---------------------------

					//--------------------------------UI Viewport---------------------------
					ImVec2 viewport_ui_size = ImGui::GetContentRegionAvail();
					viewport_ui_size = { viewport_ui_size.x <= 0 ? 1 : viewport_ui_size.x, viewport_ui_size.y <= 0 ? 1 : viewport_ui_size.y };

					if (cam.size() != pos2du16{ viewport_ui_size.x, viewport_ui_size.y })
						cam.frm.Resize(pos2du16{ viewport_ui_size.x, viewport_ui_size.y });

					const ImVec2 start_cursor_pos = ImGui::GetCursorPos();

					const fl32 circle_radius = J2D::ToMetric(1) / cam.props.scale.x;
					{
						cam.Bind();
						JGFX::Clear({});
						J2D::Draw(base_txt, { 0, 0 });

						for (int c_polygon_id = 0; c_polygon_id < polys.size(); c_polygon_id++) {
							const auto& c_polygon = polys[c_polygon_id].chain;

							for (int i = 0; i < c_polygon.points.size(); i++) {
								pos2df64 point_1 = (pos2df64)c_polygon.points[i];
								pos2df64 point_2 = (pos2df64)c_polygon.points[i + 1 <= c_polygon.points.size() - 1 ? i + 1 : 0];

								uint8 transparency = uint8((blink_color + 0.25f) / rgb_ratio);
								Line::DrawMeshed(point_1, point_2, J2D::ToMetric(0.5) / cam.props.scale.x, c_polygon_id == selected_polygon ? rgb{50, 200, 70, transparency } : rgb{70, 70, 70, transparency });
								Line::DrawMeshed(point_1, point_2, J2D::ToMetric(0.125) / cam.props.scale.x, c_polygon_id == selected_polygon ? rgb{ 50, 200, 70, 255 } : rgb{ 130, 130, 130, 255 });
							}
						}

						if (selected_polygon != -1) {
							const auto& c_polygon = polys[selected_polygon].chain;
							for(int i = 0; i < c_polygon.points.size(); i++)
								Line::DrawSolidCircle(c_polygon.points[i], circle_radius, J2D::ToMetric(0.25) / cam.props.scale.x, rgb{ (uint8)(i == selected_point ? 200 : 50), 200, 70, 255 });
						}
						win.Bind();
					}



					//Min size = img size
					cam.metric_size = c_txt_size.x < c_txt_size.y ? J2D::ToMetric({ viewport_ui_size.x * ((fl32)c_txt_size.y / viewport_ui_size.y), c_txt_size.y }) : J2D::ToMetric({ c_txt_size.x, viewport_ui_size.y * ((fl32)c_txt_size.x / viewport_ui_size.x) });
					{
						ImGui::Image((ImTextureID)cam.frm.handle().data->texture_gpu_handle, viewport_ui_size, { 0,1 }, { 1,0 });
						ImGui::SetCursorPos(start_cursor_pos);

						ImGui::InvisibleButton("##dummy_invisible_button", { (fl32)viewport_ui_size.x, (fl32)viewport_ui_size.y });
						ImGui::SetItemUsingMouseWheel(); //prevent the rest of the window from scrolling when hovered
					}
					bool was_viewport_hovered = ImGui::IsItemHovered();
					const fl64 winsize_screen_ratio = (fl64)viewport_ui_size.y / J2D::ToPixels(cam.metric_size.y);


					//----------------------------------Viewport input-----------------------------
					static bool is_holding_camera = false;
					static bool is_holding_point = false;

					//-------------------------------------------------------------------------------------------------MAIN INPUT BLOCK-----------------------------------------------------
					if (Internal::default_io->MousePos.x != -FLT_MAX && (was_viewport_hovered || is_holding_camera || is_holding_point)) {
						const auto r_drag = ImGui::GetMouseDragDelta(1); //Camera drag code MUST be made through the ImGui drag api, otherwise it becomes very glitchy(this means when dragging, camera starts very rapidly bouncing between 2 positions)
						const pos2df64 r_drag_scsp = (pos2df64)(J2D::ToMetric({ -r_drag.x, -r_drag.y })) / winsize_screen_ratio + J2D::ToMetric(J2D::ToPixels(cam.metric_size)) / pos2df64{ 2. }; //SCSP means screen space
						const pos2df64 r_drag_glsp = cam.ScreenCoordsToAbs(r_drag_scsp) - cam.center_pos;
						static pos2df64 camera_hold_start_pos = {};

						if (Internal::default_io->MouseClicked[1]) //This is to make camera control way more precise
							is_holding_camera = true, camera_hold_start_pos = cam.center_pos;

						if (is_holding_camera)
							cam.center_pos = camera_hold_start_pos + r_drag_glsp; // cam.ScreenCoordsToAbs(r_drag_scsp);

						const pos2df64 mouse_screen_coords = (pos2df64)(J2D::ToMetric(Gui::GetMousePosInsideWidget(start_cursor_pos))) / winsize_screen_ratio;
						const pos2df64 global_mouse_pos = cam.ScreenCoordsToAbs(mouse_screen_coords);
						//Cam zooming
						if (Internal::default_io->MouseWheel) {
							const double zoom_add = 0.1 * Internal::default_io->MouseWheel;

							cam.props.scale += pos2df64{ zoom_add * cam.props.scale };

							if (cam.props.scale.x < 0.8)
								cam.props.scale = pos2df64{ 0.8 };

							const pos2df64 new_global_mspos = cam.ScreenCoordsToAbs(mouse_screen_coords);
							cam.center_pos += (global_mouse_pos - new_global_mspos);
						}

						//TODO: Also have so the camera cannot be moved past the boundaries of a texture


						static pos2df64 l_drag_start_pos = {}; if (Internal::default_io->MouseClicked[0]) l_drag_start_pos = global_mouse_pos;
						const pos2df64 l_drag_glsp = global_mouse_pos - l_drag_start_pos;
						//const pos2du16 l_drag_imsp = Convert::ToImageCoords(l_drag_glsp, c_txt_size) - Convert::ToImageCoords({ 0, 0 }, c_txt_size);
						static pos2df64 item_hold_start_pos = {};
						//-----------------------------------------Slicer & edge selection---------------------------------------------

						if (selected_polygon != -1) {
							const auto& c_polygon = polys[selected_polygon].chain;
							bool was_selected_anything = false;
							for (int i = 0; i < c_polygon.points.size(); i++) {
								if (glm::length(global_mouse_pos - (pos2df64)c_polygon.points[i]) < circle_radius) {
									ImGui::SetMouseCursor(ImGuiMouseCursor_ResizeAll);

									if (Internal::default_io->MouseClicked[0]) {
										selected_point = i;
										is_holding_point = true;
										was_selected_anything = true;
										item_hold_start_pos = c_polygon.points[i];
									}
								}
								if (Internal::default_io->MouseClicked[0] && !was_selected_anything)
									selected_point = -1;
							}
						}
						if (is_holding_point) {
							auto& c_point = polys[selected_polygon].chain.points[selected_point];
							c_point = (pos2df32)(item_hold_start_pos + l_drag_glsp);

							//must find the last pos that makes sence
							if (c_point.x > c_txt_metric_size.x || c_point.x < 0.f)
								c_point.x = (l_drag_glsp.x < 0) ? 0 : c_txt_metric_size.x;
							if (c_point.y > c_txt_metric_size.y || c_point.y < 0.f)
								c_point.y = (l_drag_glsp.y < 0) ? 0 : c_txt_metric_size.y;
						}
					}

					//-------------------Cursor selection-----------------------
					{
						if (is_holding_camera || is_holding_point)
							ImGui::SetMouseCursor(ImGuiMouseCursor_ResizeAll);
					}

					if (Internal::default_io->MouseReleased[0])
						is_holding_point = false;
					if (Internal::default_io->MouseReleased[1])
						is_holding_camera = false;
				}
				ImGui::EndChild();
				ImGui::SetCursorPosY(ImGui::GetCursorPosY() - STYLE.ItemSpacing.y);
				ImGui::SeparatorEx(ImGuiSeparatorFlags_Horizontal, 0.5f);

				//------------------------------------------------------------------------------------------------LOWER SECTION--------------------------------------------------------------
				ImGui::BeginChild("tabs region", { 0,  -(ImGui::GetTextLineHeightWithSpacing() + STYLE.ItemSpacing.y + STYLE.WindowPadding.y) });
				if (ImGui::BeginTabBar("actions")) {
					//Интерфейс
					if (ImGui::BeginTabItem("Точки")) {
						if (selected_polygon != -1) {
							auto& c_polygon = polys[selected_polygon].chain;

							for (int i = 0; i < c_polygon.points.size(); i++) {
								if (ImGui::Selectable(fmt::format("Точка {}", i).c_str(), selected_point == i))
									selected_point = i;
								if (ImGui::BeginPopupContextItem()) {
									if (ImGui::MenuItem("Удалить") && c_polygon.points.size() > 4) { //4 points is minimum because of box2d's stupid restriction(yes, including even loop shapes)
										c_polygon.points.erase(c_polygon.points.begin() + i);
										if (selected_point > i) selected_point--;
										else if (selected_point == i) selected_point = -1;
									}
									ImGui::EndPopup();
								}
								ImGui::Separator();
								if (ImGui::SmallButton(fmt::format("Добавить##{}", i).c_str())) {
									const pos2df64 point_1 = c_polygon.points[i];
									const pos2df64 point_2 = c_polygon.points[i + 1 >= c_polygon.points.size() - 1 ? 0 : i + 1];

									c_polygon.points.insert(c_polygon.points.begin() + i + 1, (point_1 + point_2) / pos2df64{2.});

									selected_point = i;
								}
								ImGui::Separator();
							}
						}
						ImGui::EndTabItem();
					}
					if (ImGui::BeginTabItem("Параметры")) {
						if (selected_point != -1 && selected_polygon != -1) {
							ImGui::Text("Позиция:");
							auto& c_polygon = polys[selected_polygon].chain;
							auto& c_point = c_polygon.points[selected_point];

							//pos2d32 pos_adapter = c_slicer.pos;
							ImGui::PushItemWidth((ImGui::GetContentRegionAvail().x - STYLE.ItemSpacing.x) / 2);
							ImGui::DragFloat("##elemsize_x", &c_point.x, 0.03f / cam.props.scale.x, 0, J2D::ToMetric(c_txt_size.x), "x: %.3f");
							ImGui::SameLine();
							ImGui::DragFloat("##elemsize_y", &c_point.y, 0.03f / cam.props.scale.x, 0, J2D::ToMetric(c_txt_size.y), "y: %.3f");
							ImGui::PopItemWidth();
						}
						ImGui::EndTabItem();
					}
					ImGui::EndTabBar();
				}
				ImGui::EndChild();

				ImGui::Separator();
				if (ImGui::Button("Подтвердить")) {
					confirm = true;
					is_opened = false;
					ImGui::CloseCurrentPopup();
				}
				ImGui::SameLine();

				if (ImGui::Button("Отмена")) {
					is_opened = false;
					ImGui::CloseCurrentPopup();
				}

				//----------------------------------------------------SHORTCUTS--------------------------------------------------------------------
				if (ImGui::Shortcut(ImGuiKey_Delete) && selected_polygon != -1) {
					polys.erase(polys.begin() + selected_polygon);
					selected_polygon--;
				}
				ImGui::EndPopup();
			}
			if (!is_opened) {
				if (confirm) {
					dest = {};
					dest.reserve(polys.size());
					for (auto& i : polys)
						dest.push_back(i.chain);

					//dest = state.polygons;
				}
				else 
					dest = initial_value;
			}
			return is_opened;
		}
	}

	namespace TilePalette {
		namespace Func {
			struct TileEditState {
				bool is_texture_open_waiting = false;
				bool is_mesh_edit_waiting = false;

				Tile::Data tile_dat;
			};

			enum class TileAddStage {
				NONE,
				SELECT_FILES,
				EDIT_PRESETS
			};

			struct Data {
				Tileset::Handle tset;
				
				bool open_tset_wait = false;
				FileExplorer::State file_opener_state;

				Tile::Handle tile_to_move = Tile::NULL_TILE;
				//bool add_tiles_wait = false;
				TileAddStage tile_add_stage = TileAddStage::NONE;
				std::vector<Tile::Data> tiles_to_add;
				int selected_tile_to_add_id = 0;

				Tile::Handle tile_to_edit = Tile::NULL_TILE;
				TileEditState tile_edit_state;

				CollisionMeshEditor::CollisionEditorState collision_editor_state;
			};

			std::string GetName(Window::Handle window) {
				return fmt::format("Тайловая палитра##{}", (void*)window.data);
			}

			void Open(Window::Handle raw_window, void* data) {
				Window::GetData(raw_window).data = new Data{ *(Data*)data };
			}
			bool Update(Window::Handle window) {
				const ImGuiStyle& STYLE = ImGui::GetStyle();
				Data& dat = *(Data*)Window::GetData(window).data;

				const int TILE_ELEMENT_SIZE = 50; //in pixels
				Tile::Handle& res = selected_tile;

				bool is_open = true;
				if (ImGui::Begin(Func::GetName(window).c_str(), &is_open)) {
					

					//Opening a different tileset
					{
						ImGui::Text(fmt::format("Тайлсет: \"{}\"", File::IsValid(dat.tset) ? File::GetName(dat.tset) : "").c_str());
						ImGui::SameLine();
						if (ImGui::Button("Открыть")) {
							dat.open_tset_wait = true;
							FileExplorer::InitializeState(File::IsValid(dat.tset) ? File::GetParentFolder(dat.tset) : FileExplorer::FileInternal::last_opened_folder);
						}

						if (dat.open_tset_wait) {
							static Tileset::Handle dest = Tileset::NULL_TSET;

							if (FileExplorer::SelectFile(dest, dat.file_opener_state, { Tileset::FILETYPE_TYPE_PRESET })) {
								if (File::IsValid(dest))
									dat.tset = dest;
								dat.open_tset_wait = false;
							}
						}
					}
					
					if (!File::IsValid(dat.tset))
						ImGui::Text("Для начала работы выберите тайлсет");
					else {
						const auto& tset_data = Tileset::GetData(dat.tset);
						const fl32 button_height = 50;
						ImGui::BeginChild("tiles", { 0, -(button_height + STYLE.ItemSpacing.y * 2.f) }, 0, ImGuiWindowFlags_AlwaysVerticalScrollbar);

						const pos2d32 window_size = Gui::GetWindowAvailableSpace();
						const int ELEMENT_SPACING = 4;
						int tiles_per_line = window_size.x / (TILE_ELEMENT_SIZE + ELEMENT_SPACING) + (window_size.x % (TILE_ELEMENT_SIZE + ELEMENT_SPACING)) / TILE_ELEMENT_SIZE;
						tiles_per_line = tiles_per_line == 0 ? 1 : tiles_per_line;
						const int local_tile_size = (window_size.x - ELEMENT_SPACING * tiles_per_line) / tiles_per_line;

						ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, 0));
						ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(ELEMENT_SPACING, ELEMENT_SPACING));

						for (int c_tset_tile_id = 0; c_tset_tile_id < tset_data.tiles.size(); c_tset_tile_id++) {
							Tile::Handle c_tile = tset_data.tiles[c_tset_tile_id];

							const bool is_tile_selected = c_tile == selected_tile;
							if (is_tile_selected) {
								const fl32 brightness_add = 0.2 * std::sin(JGFX::GetTime() * 5.);
								ImGui::PushStyleColor(ImGuiCol_Button, (ImVec4)ImColor::HSV(1 / 7.0f, 0.6f, 0.6f - brightness_add));
								ImGui::PushStyleColor(ImGuiCol_ButtonHovered, (ImVec4)ImColor::HSV(1 / 7.0f, 0.7f, 0.7f - brightness_add));
								ImGui::PushStyleColor(ImGuiCol_ButtonActive, (ImVec4)ImColor::HSV(1 / 7.0f, 0.8f, 0.8f - brightness_add));
							}
							//Выбор тайла
							bool was_hovered = Gui::IsHoveredPreTest(ImVec2(local_tile_size, local_tile_size), fmt::format("{}", c_tset_tile_id).c_str());
							if (
								Gui::PaddedImageButton(
									std::to_string(c_tset_tile_id).c_str(),
									Texture::GetTexture(Tile::GetData(c_tile).texture),
									ImVec2(local_tile_size, local_tile_size),
									ImVec2(0, 0), ImVec2(1, 1), ImVec4(0, 0, 0, 0),
									ImVec4(1, 1, 1, c_tile == selected_tile ? 0.5 : (1 - (0.3 * was_hovered)))
								)
								)
								res = c_tile;

							if (is_tile_selected)
								ImGui::PopStyleColor(3);
							//TODO: implement dragging to reorder tiles in normal way
							//This is a temporary solution, will be changed later(i hope)
							//Can be done by changing flags in ImGui::IsItemHovered()
							{
								if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_None)) {
									ImGui::SetDragDropPayload(fmt::format("Tile DND{}", (void*)window.data).c_str(), &c_tset_tile_id, sizeof(int));
									ImGui::Text("Переместить тайл");
									ImGui::EndDragDropSource();
								}
								if (ImGui::BeginDragDropTarget()) {
									if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload(fmt::format("Tile DND{}", (void*)window.data).c_str())) {
										int transmitted_tile_id = *(int*)(payload->Data);

										fmt::println("Swap: dragged tile: {}, target tile: {}", transmitted_tile_id, c_tset_tile_id);
										Tileset::SwapTiles(dat.tset, c_tset_tile_id, transmitted_tile_id);
									}
									ImGui::EndDragDropTarget();
								}
							}
							if (ImGui::BeginPopupContextItem()) {
								if (ImGui::MenuItem("Переместить в другой тайлсет")) {
									dat.tile_to_move = c_tile;
									dat.file_opener_state = FileExplorer::InitializeState(File::GetParentFolder(dat.tset));
								}
								if (ImGui::MenuItem("Редактировать")) {
									dat.tile_to_edit = c_tile;
									dat.tile_edit_state.tile_dat = Tile::GetData(c_tile);
								}
								ImGui::Separator();
								if (ImGui::MenuItem("Удалить"))
									Tile::Delete(c_tile);
								ImGui::EndPopup();
							}

							//Если тайл не последний в строке, то он должен быть вместе с остальными
							if ((c_tset_tile_id + 1) % tiles_per_line != 0 && c_tset_tile_id < tset_data.tiles.size() - 1)
								ImGui::SameLine();
						}
						ImGui::PopStyleVar(); //Frame padding & item spacing
						ImGui::PopStyleVar();

						if (Tile::IsValid(dat.tile_to_move)) {
							static Tileset::Handle dest = Tileset::NULL_TSET;

							const bool state = FileExplorer::SelectFile(dest, dat.file_opener_state, { Tileset::FILETYPE_TYPE_PRESET });
							if (state) {
								if (File::IsValid(dest))
									Tile::MoveToTileset(dat.tile_to_move, dest);
								dat.tile_to_move = Tile::NULL_TILE;
							}
						}

						//TODO: improve in the future
						if (Tile::IsValid(dat.tile_to_edit)) {
							ImGui::OpenPopup("Редактировать шаблон тайла", ImGuiPopupFlags_NoReopen);

							bool is_opened = true;
							if (ImGui::BeginPopupModal("Редактировать шаблон тайла", &is_opened)) {
								const ImVec2 modal_winsize = ImGui::GetContentRegionAvail();
								auto& tile_data = dat.tile_edit_state.tile_dat;

								const fl32 top_bar_size = ImGui::GetTextLineHeight() + STYLE.FramePadding.y * 2;
								static ImVec2 bottom_bar_size = { 10, 10 };
								const auto txt_size = LLJGFX::Texture::GetSize(Texture::GetTexture(tile_data.texture));
								const pos2df64 metric_texture_size = J2D::ToMetric(txt_size);
								{
									ImGui::Text(fmt::format("Текстура: \"{}\"", File::GetName(tile_data.texture)).c_str());
									ImGui::SameLine();
									if (ImGui::Button("Открыть")) {
										dat.tile_edit_state.is_texture_open_waiting = true;
										dat.file_opener_state = FileExplorer::InitializeState(File::GetParentFolder(tile_data.texture));
									}
									if (dat.tile_edit_state.is_texture_open_waiting) {
										static Texture::Handle dest = Texture::NULL_TEXTURE;

										const bool state = FileExplorer::SelectFile(dest, dat.file_opener_state, { Texture::TEXTURE_FILETYPE_TYPE_PRESET });
										if (state) {
											if (File::IsValid(dest))
												tile_data.texture = dest;
											dat.tile_edit_state.is_texture_open_waiting = false;
										}
									}
									ImGui::Image((ImTextureID)Texture::GetTexture(tile_data.texture).data->texture_gpu_handle, { modal_winsize.x, modal_winsize.y - bottom_bar_size.y - STYLE.ItemSpacing.y - top_bar_size });
								}
								auto bottom_bar_start = ImGui::GetCursorPos();
								ImGui::Text(fmt::format("Размер: {}x{} пикс. ({}x{} м.)", txt_size.x, txt_size.y, metric_texture_size.x, metric_texture_size.y).c_str());

								ImGui::Separator();
								if (ImGui::Button("Редактировать меш коллизии")) {
									dat.tile_edit_state.is_mesh_edit_waiting = true;
									dat.collision_editor_state = CollisionMeshEditor::InitializeState(tile_data.colission_mesh);
									//TODO
								}
								ImGui::Separator();
								if (dat.tile_edit_state.is_mesh_edit_waiting) {
									static std::vector<JE::ChainShape> dest = {};

									const bool state = CollisionMeshEditor::EditCollisionMesh(dest, tile_data.colission_mesh, Texture::GetTexture(tile_data.texture), dat.collision_editor_state);
									if (!state) {
										tile_data.colission_mesh = dest;
										dat.tile_edit_state.is_mesh_edit_waiting = false;
									}
								}

								if (ImGui::Button("Подтвердить")) {
									ImGui::CloseCurrentPopup();
									Tile::GetTexture(dat.tile_to_edit) = tile_data.texture;
									Tile::GetCollisionMesh(dat.tile_to_edit) = tile_data.colission_mesh;
									is_opened = false;
								}
								ImGui::SameLine();
								if (ImGui::Button("Отмена")) {
									ImGui::CloseCurrentPopup();
									is_opened = false;
								}
								auto bottom_bar_end = ImGui::GetCursorPos();
								bottom_bar_size = bottom_bar_end - bottom_bar_start;

								ImGui::EndPopup();
							}
							if (!is_opened)
								dat.tile_to_edit = Tile::NULL_TILE;
						}

						ImGui::EndChild();

						ImGui::Separator();
						//Загрузка новых тайлов
						if (ImGui::Button("Добавить", ImVec2(ImGui::GetContentRegionAvail().x, button_height))) {
							dat.tile_add_stage = TileAddStage::SELECT_FILES;
							dat.file_opener_state = FileExplorer::InitializeState(File::GetParentFolder(dat.tset));
						}
						switch (dat.tile_add_stage) {
						case TileAddStage::SELECT_FILES: {
							static std::unordered_set<Tileset::Handle> dest = {};

							const bool state = FileExplorer::SelectFiles(dest, dat.file_opener_state, { Texture::TEXTURE_FILETYPE_TYPE_PRESET });
							if (state) {
								if (dest.size()) {
									dat.tiles_to_add.clear();
									dat.tiles_to_add.reserve(dest.size());

									for (const auto& i : dest)
										dat.tiles_to_add.push_back({ .texture = i });

									dat.tile_add_stage = TileAddStage::EDIT_PRESETS;
									dest.clear();
								}
								else dat.tile_add_stage = TileAddStage::NONE;
							}
						} break;
						case TileAddStage::EDIT_PRESETS: {
							//TODO: Improve in the future
							ImGui::OpenPopup("Тайлы к добавлению");
							bool is_open = true;
							bool confirm = false;
							ImGui::SetNextWindowSize({ 300, 400 }, ImGuiCond_Once);
							if (ImGui::BeginPopupModal("Тайлы к добавлению")) {
								const auto modal_size = ImGui::GetContentRegionAvail();
								static ImVec2 bottom_bar_size = { 10, 10 };

								ImGui::Image((ImTextureID)Texture::GetTexture(dat.tiles_to_add[dat.selected_tile_to_add_id].texture).data->texture_gpu_handle, { modal_size.x, modal_size.y - bottom_bar_size.y });

								auto bottom_bar_start = ImGui::GetCursorPos();
								const fl32 button_width = (modal_size.x - STYLE.ItemSpacing.x) / 2;
								{
									bool disable_prev = dat.selected_tile_to_add_id == 0; //Must be done because the value can change, and imgui will throw an error because the EndDisabled() wouldnt be called then
									if (disable_prev)
										ImGui::BeginDisabled();
									if (ImGui::Button("Предыдущий", { button_width, 0 }))
										dat.selected_tile_to_add_id--;
									if (disable_prev)
										ImGui::EndDisabled();
									ImGui::SameLine();

									bool disable_next = dat.selected_tile_to_add_id == dat.tiles_to_add.size() - 1;
									if (disable_next)
										ImGui::BeginDisabled();
									if (ImGui::Button("Следующий", { button_width, 0 }))
										dat.selected_tile_to_add_id++;
									if (disable_next)
										ImGui::EndDisabled();
								}
								ImGui::Text(fmt::format("Тайл {}/{}", dat.selected_tile_to_add_id + 1, dat.tiles_to_add.size()).c_str());
								//ImGui::Button("Показать меш коллизии");
								//if (ImGui::IsItemActive()) {
									//TODO: Show collision mesh
								//}
								ImGui::SameLine();
								if (ImGui::Button("Редактировать меш коллизии")) {
									//TODO: Edit window
								}

								ImGui::Separator();
								if (ImGui::Button("Подтвердить")) {
									ImGui::CloseCurrentPopup();
									is_open = false;
									confirm = true;
								}
								ImGui::SameLine();
								if (ImGui::Button("Отмена")) {
									ImGui::CloseCurrentPopup();
									is_open = false;
									confirm = false;
								}
								auto bottom_bar_end = ImGui::GetCursorPos();

								bottom_bar_size = bottom_bar_end - bottom_bar_start;
								ImGui::EndPopup();
							}
							if (!is_open) {
								if (confirm) {
									for (const auto& i : dat.tiles_to_add)
										Tile::Make(i.texture, i.colission_mesh, dat.tset);
								}
								dat.tiles_to_add.clear();
								dat.tile_add_stage = TileAddStage::NONE;
							}
						} break;
						}
					}
				}
				bool was_active = ImGui::IsWindowFocused();
				ImGui::End();

				if (!is_open)
					Window::Close(window);
				return was_active;
			}

			void Close(Window::Handle window) {
				delete (Data*)Window::GetData(window).data;
			}

			WindowTemplate::Handle templ = WindowTemplate::Make({ .Open = Open, .Update = Update, .Close = Close, .GetName = GetName });
		}
		Window::Handle Open(Tileset::Handle tset) {
			const Func::Data tmp = { .tset = tset };
			Window::Handle win = Window::Open(Func::templ, (void*)&tmp);
			return win;
		}
		void SetTset(Window::Handle handle, Tileset::Handle tset) {
			(*(Func::Data*)Window::GetData(handle).data).tset = tset;
		}

		namespace Func {
			bool init_dummy =
				((FileType::Data&)FileType::GetData(Tileset::FILETYPE_TYPE_PRESET)).OpenFile = [](File::Handle file) {
					auto win = WindowSystem::GetLastActiveWindowByType(templ);

					if (win == Window::NULL_WINDOW)
						TilePalette::Open(file);
					else
						SetTset(win, file);
				};
		}
	}
}