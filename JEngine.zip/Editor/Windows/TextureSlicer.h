#pragma once
#include "../TextureFileType.h"
#include "../EditorGlobals.h"
#include "../Subsystems/WindowManagementSystem.h"

namespace Editor {
	namespace Slicer {
		namespace SlicerInternal {
			
			bool InRange(fl64 lower_bound, fl64 number_to_test, fl64 upper_bound) {
				return number_to_test <= upper_bound && number_to_test >= lower_bound;
			}
			bool InRange(pos2df64 lower_bound, pos2df64 number_to_test, pos2df64 upper_bound) {
				return InRange(lower_bound.x, number_to_test.x, upper_bound.x) && InRange(lower_bound.y, number_to_test.y, upper_bound.y);
			}
		}//

		namespace Func {
			struct Data {
				File::Handle opened_texture;
				J2D::MetricCam2D cam = { {300, 300}, J2D::ToMetric({64, 64}) };

				//Список областей разрезки
				std::vector<TextureProcessing::Cropper> slice_list;

				int selected_slicer = -1;

				int number_of_elements_to_generate = 0;
				pos2d32 selected_elem_size = { 16, 16 };
				pos2d32 selected_elem_spacing = { 0,0 };
			};

			std::string GetName(Window::Handle window) {
				return "Разрезка текстур";
			}

			void Open(Window::Handle raw_window, void* data) {
				Window::GetData(raw_window).data = new Data{ *(Data*)data };
			}
			bool Update(Window::Handle window) {
				bool was_focused = false;

				auto& dat = *(Data*)Window::GetData(window).data;

				const ImGuiStyle& STYLE = ImGui::GetStyle();
				const LLJGFX::Texture::Handle src_txt = Texture::GetTexture(dat.opened_texture);
				const auto c_txt_size = LLJGFX::Texture::GetSize(src_txt);
				J2D::MetricCam2D& cam = dat.cam;

				//Список областей разрезки
				std::vector<TextureProcessing::Cropper>& slice_list = dat.slice_list;

				int& selected_slicer = dat.selected_slicer;

				int& number_of_elements_to_generate = dat.number_of_elements_to_generate;
				pos2d32& selected_elem_size = dat.selected_elem_size;
				pos2d32& selected_elem_spacing = dat.selected_elem_spacing; //This refs are to not rewrite all the code below after the integration(all of this was marked "static" before)

				ImGui::OpenPopup(Func::GetName(window).c_str(), ImGuiPopupFlags_NoReopen); //Must be placed here, otherwise it for some unknown reason wouldnt work
				ImGui::SetNextWindowSize({ 400, 500 }, ImGuiCond_Once);
				bool is_opened = true;
				if (ImGui::BeginPopupModal(Func::GetName(window).c_str())) {

					static ImVec2 previous_window_size = ImGui::GetContentRegionAvail();
					const auto window_size = ImGui::GetContentRegionAvail();
					static ImVec2 previous_top_bar_size = { 0, 400 };

					if (window_size.y != previous_window_size.y) {
						const fl32 size_diff = previous_window_size.y - window_size.y;
						ImGui::SetNextWindowSize({ 0, previous_top_bar_size.y - size_diff / 2.f });
					}
					previous_window_size = window_size;

					ImGui::BeginChild("Upper area", { 0, 400 }, ImGuiChildFlags_ResizeY); //Main child
					previous_top_bar_size = ImGui::GetContentRegionAvail();
					//------------------------------------------------------------------------------SIDE BAR-------------------------------------------------------------------
					{
						const int SLICER_SELECTABLE_SIZE = 50;
						const int SLICER_THUMBNAIIL_SIZE = 45;
						const fl32 SLICER_INNER_PADDING = (fl32)(SLICER_SELECTABLE_SIZE - SLICER_THUMBNAIIL_SIZE) / 2.f;
						const pos2df32 UV_RATIO = pos2df32{ 1.f } / (pos2df32)c_txt_size;

						ImGui::BeginChild("Side bar", { 160, 0 }, ImGuiChildFlags_ResizeX | ImGuiChildFlags_NavFlattened, ImGuiWindowFlags_NoScrollbar);
						ImGui::BeginChild("Slicers", { 0, -(SLICER_SELECTABLE_SIZE + STYLE.ItemSpacing.y) }, ImGuiChildFlags_NavFlattened);
						for (int i = 0; i < slice_list.size(); i++) {
							if (ImGui::Selectable(fmt::format("##slicer{}", i).c_str(), i == selected_slicer, 0, { ImGui::GetContentRegionAvail().x, SLICER_SELECTABLE_SIZE }))
								selected_slicer = i;
							if (ImGui::BeginPopupContextItem(fmt::format("##slicer menu{}", i).c_str())) {
								if (ImGui::MenuItem("Удалить")) {
									slice_list.erase(slice_list.begin() + i);
									selected_slicer = selected_slicer >= i ? selected_slicer - 1 : selected_slicer;
								}
								ImGui::EndPopup();
							}
							//TODO: implement swapping
							/*
							if (ImGui::IsItemActive() && !ImGui::IsItemHovered()) {
								int next = i + (ImGui::GetMouseDragDelta().y >= 0 ? 1 : -1);

								if (next >= 0 && next < slice_list.size()) {
									std::swap(slice_list[next], slice_list[i]);
									ImGui::ResetMouseDragDelta();
								}
							}*/

							if (i < slice_list.size()) { //The "if" is to prevent program from crashing after deleting an element
								const ImVec2 next_slicer_pos = ImGui::GetCursorPos();
								ImGui::SetCursorPosY(ImGui::GetCursorPosY() - (SLICER_SELECTABLE_SIZE + STYLE.ItemSpacing.y)); //must clip inside of a selectable

								ImGui::SetCursorPosX(ImGui::GetCursorPosX() + SLICER_INNER_PADDING);
								ImGui::SetCursorPosY(ImGui::GetCursorPosY() + SLICER_INNER_PADDING);
								const auto thumbnail_start_pos = ImGui::GetCursorPos();

								const auto& c_slicer = slice_list[i];
								const ImVec2 ui_thumbnail_size = c_slicer.size.x > c_slicer.size.y ?
									ImVec2{ (fl32)SLICER_THUMBNAIIL_SIZE, ((fl32)SLICER_THUMBNAIIL_SIZE / (fl32)c_slicer.size.x) * (fl32)c_slicer.size.y }
								: ImVec2{ ((fl32)SLICER_THUMBNAIIL_SIZE / (fl32)c_slicer.size.y) * (fl32)c_slicer.size.x, (fl32)SLICER_THUMBNAIIL_SIZE };
								const ImVec2 thumbnail_padding = { (SLICER_THUMBNAIIL_SIZE - ui_thumbnail_size.x) / 2.f, (SLICER_THUMBNAIIL_SIZE - ui_thumbnail_size.y) / 2.f };

								ImGui::SetCursorPosX(ImGui::GetCursorPosX() + thumbnail_padding.x);
								ImGui::SetCursorPosY(ImGui::GetCursorPosY() + thumbnail_padding.y);


								const ImVec2 selection_uv1 = {
									(fl32)c_slicer.pos.x * UV_RATIO.x,
									(fl32)c_slicer.pos.y * UV_RATIO.y
								};
								const ImVec2 selection_uv2 = {
									(fl32)(c_slicer.pos.x + c_slicer.size.x) * UV_RATIO.x,
									(fl32)(c_slicer.pos.y + c_slicer.size.y) * UV_RATIO.y
								};

								ImGui::Image((ImTextureID)src_txt.data->texture_gpu_handle, ui_thumbnail_size, selection_uv1, selection_uv2);
								ImGui::SameLine();

								const ImVec2 text_start_pos = { ImGui::GetCursorPosX() + thumbnail_padding.x, thumbnail_start_pos.y };
								ImGui::SetCursorPos(text_start_pos);
								ImGui::Text(fmt::format("Размер: {}, {}", c_slicer.size.x, c_slicer.size.y).c_str());
								ImGui::SetCursorPos({ text_start_pos.x, text_start_pos.y + ImGui::GetTextLineHeight() + STYLE.ItemSpacing.y });
								ImGui::Text(fmt::format("Позиция: {}, {}", c_slicer.pos.x, c_slicer.pos.y).c_str());
								ImGui::SetCursorPos(next_slicer_pos);
							}
							ImGui::Separator();
						}
						ImGui::EndChild();

						const fl32 button_width = (ImGui::GetContentRegionAvail().x + STYLE.ItemSpacing.x) / 2.f;
						if (ImGui::Button("Добавить", { button_width, SLICER_SELECTABLE_SIZE })) {
							slice_list.push_back({ .pos = {0, 0}, .size = selected_elem_size });
							selected_slicer = slice_list.size() - 1;
						}
						ImGui::SameLine();
						if (ImGui::Button("Очистить", { button_width, SLICER_SELECTABLE_SIZE })) {
							slice_list.clear();
							selected_slicer = -1;
						}
						ImGui::EndChild();
						ImGui::SameLine();
						ImGui::SetCursorPosX(ImGui::GetCursorPosX() - STYLE.ItemSpacing.x);
						ImGui::SeparatorEx(ImGuiSeparatorFlags_Vertical);
						ImGui::SameLine();
					}


					{
						//--------------------DRAWING---------------------------

						//--------------------------------UI Viewport---------------------------
						ImVec2 viewport_ui_size = ImGui::GetContentRegionAvail();
						viewport_ui_size = { viewport_ui_size.x <= 0 ? 1 : viewport_ui_size.x, viewport_ui_size.y <= 0 ? 1 : viewport_ui_size.y };

						if (cam.size() != pos2du16{ viewport_ui_size.x, viewport_ui_size.y })
							cam.frm.Resize(pos2du16{ viewport_ui_size.x, viewport_ui_size.y });

						const ImVec2 start_cursor_pos = ImGui::GetCursorPos();

						{
							cam.Bind();
							JGFX::Clear({});
							J2D::Draw(src_txt, { 0, 0 });

							for (int i = 0; i < slice_list.size(); i++) {
								const auto& c_slice_elem = slice_list[i];
								const pos2df64 conv_start = Convert::FromImageCoords(c_slice_elem.pos, LLJGFX::Texture::GetSize(src_txt)) + J2D::ToMetric(pos2df64{ 0.5, -0.5 });
								const pos2df64 conv_end = Convert::FromImageCoords(c_slice_elem.pos + c_slice_elem.size - pos2du16{ 1,1 }, LLJGFX::Texture::GetSize(src_txt)) + J2D::ToMetric(pos2df64{ 0.5, -0.5 });

								Line::DrawRect(conv_start, conv_end, J2D::ToMetric(1), (rgb)glm::vec4(1.f, 1.f, i == selected_slicer ? 0.f : 1.f, blink_color + 0.25));
							}
							win.Bind();
						}



						//Min size = img size
						cam.metric_size = c_txt_size.x < c_txt_size.y ? J2D::ToMetric({ viewport_ui_size.x * ((fl32)c_txt_size.y / viewport_ui_size.y), c_txt_size.y }) : J2D::ToMetric({ c_txt_size.x, viewport_ui_size.y * ((fl32)c_txt_size.x / viewport_ui_size.x) });
						{
							ImGui::Image((ImTextureID)cam.frm.handle().data->texture_gpu_handle, viewport_ui_size, { 0,1 }, { 1,0 });
							ImGui::SetCursorPos(start_cursor_pos);

							ImGui::InvisibleButton("##dummy_invisible_button", { (fl32)viewport_ui_size.x, (fl32)viewport_ui_size.y });
							ImGui::SetItemUsingMouseWheel(); //prevent the rest of the window from scrolling when hovered
						}
						bool was_viewport_hovered = ImGui::IsItemHovered();
						const fl64 winsize_screen_ratio = (fl64)viewport_ui_size.y / J2D::ToPixels(cam.metric_size.y);


						//----------------------------------Viewport input-----------------------------
						static bool is_holding_camera = false;
						static bool is_holding_item = false;
						static uint8 selected_edges = 0;
						uint8 hovered_edges = 0;

						// __1__   //0 = 1000 00
						//|     |  //1 = 0100 01
						//0     2  //2 = 0010 10
						//|     |  //3 = 0001 11
						// --3--
						//-------------------------------------------------------------------------------------------------MAIN INPUT BLOCK-----------------------------------------------------
						if (Internal::default_io->MousePos.x != -FLT_MAX && (was_viewport_hovered || is_holding_camera || selected_edges || is_holding_item)) {
							const auto r_drag = ImGui::GetMouseDragDelta(1); //Camera drag code MUST be made through the ImGui drag api, otherwise it becomes very glitchy(this means when dragging, camera starts very rapidly bouncing between 2 positions)
							const pos2df64 r_drag_scsp = (pos2df64)(J2D::ToMetric({ -r_drag.x, -r_drag.y })) / winsize_screen_ratio + J2D::ToMetric(J2D::ToPixels(cam.metric_size)) / pos2df64{ 2. }; //SCSP means screen space
							const pos2df64 r_drag_glsp = cam.ScreenCoordsToAbs(r_drag_scsp) - cam.center_pos;
							static pos2df64 camera_hold_start_pos = {};

							if (Internal::default_io->MouseClicked[1]) //This is to make camera control way more precise
								is_holding_camera = true, camera_hold_start_pos = cam.center_pos;

							if (is_holding_camera)
								cam.center_pos = camera_hold_start_pos + r_drag_glsp; // cam.ScreenCoordsToAbs(r_drag_scsp);

							const pos2df64 mouse_screen_coords = (pos2df64)(J2D::ToMetric(Gui::GetMousePosInsideWidget(start_cursor_pos))) / winsize_screen_ratio;
							const pos2df64 global_mouse_pos = cam.ScreenCoordsToAbs(mouse_screen_coords);
							const pos2du16 image_mouse_pos = Convert::ToImageCoords(global_mouse_pos, LLJGFX::Texture::GetSize(src_txt));
							//Cam zooming
							if (Internal::default_io->MouseWheel) {
								const double zoom_add = 0.1 * Internal::default_io->MouseWheel;

								cam.props.scale += pos2df64{ zoom_add * cam.props.scale };

								if (cam.props.scale.x < 1.)
									cam.props.scale = pos2df64{ 1. };

								const pos2df64 new_global_mspos = cam.ScreenCoordsToAbs(mouse_screen_coords);
								cam.center_pos += (global_mouse_pos - new_global_mspos);
							}

							//TODO: Also have so the camera cannot be moved past the boundaries of a texture


							static pos2df64 l_drag_start_pos = {}; if (Internal::default_io->MouseClicked[0]) l_drag_start_pos = global_mouse_pos;
							const pos2df64 l_drag_glsp = global_mouse_pos - l_drag_start_pos;
							const pos2du16 l_drag_imsp = Convert::ToImageCoords(l_drag_glsp, c_txt_size) - Convert::ToImageCoords({ 0, 0 }, c_txt_size);
							static pos2du16 item_hold_start_pos = {};
							//-----------------------------------------Slicer & edge selection---------------------------------------------
							{
								bool was_selected_anything = false;
								for (int i = 0; i < slice_list.size(); i++) {
									const auto& c_slicer = slice_list[i];

									// __1__
									//|     |
									//0     2
									//|     |
									// --3--
									const std::array<bool(*)(const TextureProcessing::Cropper&, pos2du16), 4> EdgePredicartes = {
										[](const TextureProcessing::Cropper& c_slicer, pos2du16 pixel_pos)-> bool
											{ return pixel_pos.x == c_slicer.pos.x && SlicerInternal::InRange(c_slicer.pos.y, pixel_pos.y, c_slicer.pos.y + c_slicer.size.y - 1);  }, //Vertical min (Edge 0)
										[](const TextureProcessing::Cropper& c_slicer, pos2du16 pixel_pos)-> bool
											{ return SlicerInternal::InRange(c_slicer.pos.x, pixel_pos.x, c_slicer.pos.x + c_slicer.size.x - 1) && pixel_pos.y == c_slicer.pos.y;  }, //Horizontal min (Edge 1)
										[](const TextureProcessing::Cropper& c_slicer, pos2du16 pixel_pos)-> bool
											{ return pixel_pos.x == c_slicer.pos.x + c_slicer.size.x - 1 && SlicerInternal::InRange(c_slicer.pos.y, pixel_pos.y, c_slicer.pos.y + c_slicer.size.y - 1);  }, //Vertical max (Edge 2)
										[](const TextureProcessing::Cropper& c_slicer, pos2du16 pixel_pos)-> bool
											{ return SlicerInternal::InRange(c_slicer.pos.x, pixel_pos.x, c_slicer.pos.x + c_slicer.size.x - 1) && pixel_pos.y == (c_slicer.pos.y + c_slicer.size.y - 1);  } //Horizontal max (Edge 3)
									};

									if (SlicerInternal::InRange(c_slicer.pos, image_mouse_pos, (c_slicer.pos + c_slicer.size) - pos2du16{ 1 })) {
										uint8 slicer_hovered_edges = 0;
										for (int c_edge = 0; c_edge < 4; c_edge++) {
											bool tmp_edge = EdgePredicartes[c_edge](c_slicer, image_mouse_pos);
											slicer_hovered_edges += (tmp_edge << c_edge);
										}
										hovered_edges = slicer_hovered_edges ? slicer_hovered_edges : hovered_edges; //Prevent selection stacking

										//if edge is found - break from the loop
										if (Internal::default_io->MouseClicked[0] && hovered_edges == 0)
											selected_slicer = i, is_holding_item = true, item_hold_start_pos = c_slicer.pos, was_selected_anything = true;
										else if (slicer_hovered_edges && Internal::default_io->MouseClicked[0]) {
											selected_slicer = i, is_holding_item = false, selected_edges = slicer_hovered_edges, was_selected_anything = true;
											break; //Must break, so slicer and edge wouldnt be selected at the same time
										}
									}
								}
								if (!was_selected_anything && Internal::default_io->MouseClicked[0]) selected_slicer = -1;
							}

							//-----------------------------------------Slicer & edge dragging
							{
								if (is_holding_item) {
									auto& c_slicer = slice_list[selected_slicer];
									c_slicer.pos = item_hold_start_pos + l_drag_imsp;

									//must find the last pos that makes sence
									if (((int)c_slicer.pos.x + c_slicer.size.x) > c_txt_size.x) //Must be casted, because all negative numbers are really large, larger than the texture size, and this is a way of detecting them
										c_slicer.pos.x = (l_drag_glsp.x < 0) ? 0 : c_txt_size.x - c_slicer.size.x;
									if (((int)c_slicer.pos.y + c_slicer.size.y) > c_txt_size.y)
										c_slicer.pos.y = (l_drag_glsp.y < 0) ? c_txt_size.y - c_slicer.size.y : 0; //This is in opposite order because Y-axis is inverted
								}
								if (selected_edges) {
									auto& c_slicer = slice_list[selected_slicer];

									// __1__
									//|     |
									//0     2
									//|     |
									// --3--
									std::array<void(*)(TextureProcessing::Cropper&, pos2du16, pos2du16), 4> EdgeResizers = {
										[](TextureProcessing::Cropper& c_slicer, pos2du16 image_mouse_pos, pos2du16 c_txt_size)->void {
											//For edge 0
											const pos2du16 old_slicer_pos = c_slicer.pos;
											const uint16 old_opposite_side_pos = c_slicer.pos.x + c_slicer.size.x - 1;
											c_slicer.pos.x = image_mouse_pos.x;
											c_slicer.size.x = c_slicer.size.x + (old_slicer_pos.x - c_slicer.pos.x);

											if ((int16)c_slicer.pos.x < 0) {
												c_slicer.pos.x = 0;
												c_slicer.size.x = old_opposite_side_pos + 1;
											}
											else if ((int16)c_slicer.size.x < 2) {
												c_slicer.size.x = 2;
												c_slicer.pos.x = old_opposite_side_pos - 1;
											}
										},
										[](TextureProcessing::Cropper& c_slicer, pos2du16 image_mouse_pos, pos2du16 c_txt_size)->void {
											//For edge 1
											const pos2du16 old_slicer_pos = c_slicer.pos;
											const uint16 old_opposite_side_pos = c_slicer.pos.y + c_slicer.size.y - 1;
											c_slicer.pos.y = image_mouse_pos.y;
											c_slicer.size.y = c_slicer.size.y + (old_slicer_pos.y - c_slicer.pos.y);

											if ((int16)c_slicer.pos.y < 0) {
												c_slicer.pos.y = 0;
												c_slicer.size.y = old_opposite_side_pos + 1;
											}
											else if ((int16)c_slicer.size.y < 2) {
												c_slicer.size.y = 2;
												c_slicer.pos.y = old_opposite_side_pos - 1;
											}
										},
										[](TextureProcessing::Cropper& c_slicer, pos2du16 image_mouse_pos, pos2du16 c_txt_size)->void {
											//For edge 2
											c_slicer.size.x = image_mouse_pos.x - c_slicer.pos.x + 1;

											if ((int16)c_slicer.size.x < 2)
												c_slicer.size.x = 2;
											else if (c_slicer.pos.x + c_slicer.size.x > c_txt_size.x)
												c_slicer.size.x = c_txt_size.x - c_slicer.pos.x;
										},
										[](TextureProcessing::Cropper& c_slicer, pos2du16 image_mouse_pos, pos2du16 c_txt_size)->void {
											//For edge 3
											c_slicer.size.y = image_mouse_pos.y - c_slicer.pos.y + 1;

											if ((int16)c_slicer.size.y < 2)
												c_slicer.size.y = 2;
											else if (c_slicer.pos.y + c_slicer.size.y > c_txt_size.y)
												c_slicer.size.y = c_txt_size.y - c_slicer.pos.y;
										},
									};

									for (int i = 0; i < 4; i++) {
										if (selected_edges & (0b1 << i))
											EdgeResizers[i](c_slicer, image_mouse_pos, c_txt_size); //This is needed because code for each side of the selection rectangle is different
									}
								}
							}
						}

						//-------------------Cursor selection-----------------------
						{
							const ImGuiMouseCursor edge_cursors[] = {
								ImGuiMouseCursor_None,       //0000
								ImGuiMouseCursor_ResizeEW,   //1000
								ImGuiMouseCursor_ResizeNS,   //0100
								ImGuiMouseCursor_ResizeNWSE, //1100
								ImGuiMouseCursor_ResizeEW,   //0010
									ImGuiMouseCursor_NotAllowed, //1010 //Hovering opposite at the same time is IMPOSSIBLE
								ImGuiMouseCursor_ResizeNESW, //0110
									ImGuiMouseCursor_NotAllowed, //1110 //Hovering opposite at the same time is IMPOSSIBLE
								ImGuiMouseCursor_ResizeNS,   //0001
								ImGuiMouseCursor_ResizeNESW, //1001
									ImGuiMouseCursor_NotAllowed, //0101 //Hovering opposite at the same time is IMPOSSIBLE
									ImGuiMouseCursor_NotAllowed, //1101 //Hovering opposite at the same time is IMPOSSIBLE
								ImGuiMouseCursor_ResizeNWSE, //0011
									ImGuiMouseCursor_NotAllowed, //1011 //Hovering opposite at the same time is IMPOSSIBLE
									ImGuiMouseCursor_NotAllowed, //0111 //Hovering opposite at the same time is IMPOSSIBLE
									ImGuiMouseCursor_NotAllowed, //1111 //Hovering opposite at the same time is IMPOSSIBLE
							};
							if (hovered_edges) //Hovering edge should have lowest priority
								ImGui::SetMouseCursor(edge_cursors[hovered_edges]);
							if (is_holding_camera || is_holding_item)
								ImGui::SetMouseCursor(ImGuiMouseCursor_ResizeAll);
							if (selected_edges) //Selected edges have higher priority
								ImGui::SetMouseCursor(edge_cursors[selected_edges]);
						}


						if (Internal::default_io->MouseReleased[0])
							is_holding_item = false, selected_edges = 0b0000;
						if (Internal::default_io->MouseReleased[1])
							is_holding_camera = false;
					}
					ImGui::EndChild();
					ImGui::SetCursorPosY(ImGui::GetCursorPosY() - STYLE.ItemSpacing.y);
					ImGui::SeparatorEx(ImGuiSeparatorFlags_Horizontal, 0.5f);

					//------------------------------------------------------------------------------------------------LOWER SECTION--------------------------------------------------------------
					ImGui::BeginChild("tabs region", { 0,  -(ImGui::GetTextLineHeightWithSpacing() + STYLE.ItemSpacing.y + STYLE.WindowPadding.y) });
					if (ImGui::BeginTabBar("slice_actions")) {
						//Интерфейс
						if (ImGui::BeginTabItem("Генерация разр. списка")) {
							ImGui::PushItemWidth(ImGui::GetContentRegionAvail().x);
							ImGui::DragInt("##number_of_elements", &number_of_elements_to_generate, 0.1f, 0, 65535, "Число элементов: %d");
							ImGui::PopItemWidth();

							ImGui::Text("Размер генерируемых элементов:");

							ImGui::PushItemWidth((ImGui::GetContentRegionAvail().x - STYLE.ItemSpacing.x) / 2);
							ImGui::DragInt("##elemsize_x", &selected_elem_size.x, 0.1f, 2, c_txt_size.x, "x: %d");
							ImGui::SameLine();
							ImGui::DragInt("##elemsize_y", &selected_elem_size.y, 0.1f, 2, c_txt_size.y, "y: %d");
							ImGui::PopItemWidth();

							ImGui::Text("Отступ между элементами:");

							ImGui::PushItemWidth((ImGui::GetContentRegionAvail().x - STYLE.ItemSpacing.x) / 2);
							ImGui::DragInt("##spacing_x", &selected_elem_spacing.x, 0.1f, 0, c_txt_size.x, "x: %d");
							ImGui::SameLine();
							ImGui::DragInt("##spacing_y", &selected_elem_spacing.y, 0.1f, 0, c_txt_size.y, "y: %d");
							ImGui::PopItemWidth();

							if (ImGui::Button("Сгенерировать список разрезки")) {
								slice_list = TextureProcessing::GenerateCroplist(c_txt_size, number_of_elements_to_generate, selected_elem_size, { 0,0 }, selected_elem_spacing.x, selected_elem_spacing.y);
								selected_slicer = -1;
							}

							ImGui::EndTabItem();
						}
						if (ImGui::BeginTabItem("Выбранный элемент")) {
							if (selected_slicer != -1) {
								auto& c_slicer = slice_list[selected_slicer];
								ImGui::Text("Позиция:");


								pos2d32 pos_adapter = c_slicer.pos;
								ImGui::PushItemWidth((ImGui::GetContentRegionAvail().x - STYLE.ItemSpacing.x) / 2);
								ImGui::DragInt("##elemsize_x", &pos_adapter.x, 0.1f, 0, c_txt_size.x - c_slicer.size.x, "x: %d");
								ImGui::SameLine();
								ImGui::DragInt("##elemsize_y", &pos_adapter.y, 0.1f, 0, c_txt_size.y - c_slicer.size.y, "y: %d");
								ImGui::PopItemWidth();
								c_slicer.pos = pos_adapter;

								ImGui::Text("Размер:");

								pos2d32 size_adapter = c_slicer.size;
								ImGui::PushItemWidth((ImGui::GetContentRegionAvail().x - STYLE.ItemSpacing.x) / 2);
								ImGui::DragInt("##size_x", &size_adapter.x, 0.1f, 2, c_txt_size.x - c_slicer.pos.x, "x: %d");
								ImGui::SameLine();
								ImGui::DragInt("##size_y", &size_adapter.y, 0.1f, 2, c_txt_size.y - c_slicer.pos.y, "y: %d");
								ImGui::PopItemWidth();
								c_slicer.size = size_adapter;

								if (ImGui::Button("Удалить элемент")) {
									slice_list.erase(slice_list.begin() + selected_slicer);
									selected_slicer = -1;
								}
							}

							ImGui::EndTabItem();
						}
						ImGui::EndTabBar();
					}
					ImGui::EndChild();

					ImGui::Separator();
					if (ImGui::Button("Подтвердить")) {
						auto raw = TextureProcessing::CropFromCroplist(src_txt, slice_list);

						for (int i = 0; i < raw.size(); i++)
							Texture::Make(LLJGFX::Texture::Make(raw[i], slice_list[i].size), fmt::format("{} - вырез. {}", File::GetName(dat.opened_texture), i + 1), File::GetParentFolder(dat.opened_texture));

						is_opened = false;
					}
					ImGui::SameLine();

					if (ImGui::Button("Отмена"))
						is_opened = false;

					//----------------------------------------------------SHORTCUTS--------------------------------------------------------------------
					if (ImGui::Shortcut(ImGuiKey_Delete) && selected_slicer != -1) {
						slice_list.erase(slice_list.begin() + selected_slicer);
						selected_slicer--;
					}

					was_focused = ImGui::IsWindowFocused();

					
					if (!is_opened) {
						ImGui::CloseCurrentPopup();
						Window::Close(window);
					}
					ImGui::EndPopup();
					//fmt::println("{}", is_opened);
				}


				return was_focused;
			}

			void Close(Window::Handle window) {
				delete (Data*)Window::GetData(window).data;
			}

			WindowTemplate::Handle templ = WindowTemplate::Make({ .Open = Open, .Update = Update, .Close = Close, .GetName = GetName });
		}
		Window::Handle Open(File::Handle texture_file) {
			Func::Data tmp = { .opened_texture = texture_file };
			tmp.cam.center_pos = J2D::ToMetric(LLJGFX::Texture::GetSize(Texture::GetTexture(texture_file))) / pos2df64{ 2. };
			Window::Handle win = Window::Open(Func::templ, (void*)&tmp);
			Window::Update(win);
			return win;
		}

		namespace SlicerInternal {
			bool init_dummy = 
				((FileType::Data&)FileType::GetData(Texture::TEXTURE_FILETYPE_TYPE_PRESET)).FileContextMenu = [](File::Handle file) {
					if (ImGui::MenuItem("Разрезать текстуру"))
						Slicer::Open(file);
				};
		}
	}
}