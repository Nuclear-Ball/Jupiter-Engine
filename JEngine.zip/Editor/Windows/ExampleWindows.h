#pragma once
#include "../Subsystems/ImGuiHelper.h"
#include "../Subsystems/WindowManagementSystem.h"

namespace Editor {
	namespace Example {
		namespace WindowingApiModal {
			namespace Func {
				struct Data {
				};

				inline std::string GetName(Window::Handle window) {
					return "NameW";
				}

				inline void Open(Window::Handle raw_window, void* data) {
					Window::GetData(raw_window).data = new Data{ *(Data*)data };
				}
				bool Update(Window::Handle window) {
					bool was_focused = false;

					bool is_opened = true;
					ImGui::OpenPopup(Func::GetName(window).c_str(), ImGuiPopupFlags_NoReopen);
					if (ImGui::BeginPopupModal(Func::GetName(window).c_str(), &is_opened)) {


						was_focused = ImGui::IsWindowFocused();
						ImGui::EndPopup();
					}
					if (!is_opened) {
						Window::Close(window);
					}

					return was_focused;
				}

				void Close(Window::Handle window) {
					delete (Data*)Window::GetData(window).data;
				}

				WindowTemplate::Handle templ = WindowTemplate::Make({ .Open = Open, .Update = Update, .Close = Close, .GetName = GetName });
			}
			Window::Handle Open() {
				const Func::Data tmp = {};
				Window::Handle win = Window::Open(Func::templ, (void*)&tmp);
				return win;
			}
		}

		namespace CallbackModal {
			struct State {

			};
			State InitializeState() { 
				return {};
			};

			bool Modal(State& state) { //returns true when closed
				bool is_open = true;
				ImGui::OpenPopup("Name", ImGuiPopupFlags_NoReopen);
				if (ImGui::BeginPopupModal("Name", &is_open)) {
					
					ImGui::EndPopup();
				}
				if (!is_open) {

				}
				return !is_open;
			}
		}

		namespace RegularWindow {
			namespace Func {
				struct Data {
				};

				inline std::string GetName(Window::Handle window) {
					return fmt::format("Name##{}", (void*)window.data);
				}

				inline void Open(Window::Handle raw_window, void* data) {
					Window::GetData(raw_window).data = new Data{ *(Data*)data };
				}
				bool Update(Window::Handle window) {
					bool is_opened = true;
					if (ImGui::Begin(Func::GetName(window).c_str(), &is_opened)) {

						
					}
					bool was_focused = ImGui::IsWindowFocused();
					ImGui::End();

					if (!is_opened) {
						Window::Close(window);
					}
					return was_focused;
				}

				void Close(Window::Handle window) {
					delete (Data*)Window::GetData(window).data;
				}

				WindowTemplate::Handle templ = WindowTemplate::Make({ .Open = Open, .Update = Update, .Close = Close, .GetName = GetName });
			}
			bool IsThisType(Window::Handle handle) {
				assert(Window::IsValid(handle));
				return Window::GetType(handle) == Func::templ;
			}

			Window::Handle Open() {
				const Func::Data tmp = {};
				Window::Handle win = Window::Open(Func::templ, (void*)&tmp);
				return win;
			}
		}
	}
}