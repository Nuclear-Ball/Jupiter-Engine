#pragma once
#include "../Subsystems/FilesystemBase.h"
//#include "../Texture.h"
#include "../Subsystems/WindowManagementSystem.h"
#include "../Subsystems/ImGuiHelper.h"
#include <stack>
#include "Misc.h"
#include "../EditorGlobals.h"

namespace Editor {
	namespace FileExplorer {
		bool IsEqual(const std::unordered_set<FileType::Handle>& a, const std::unordered_set<FileType::Handle>& b) {
			if (a.size() != b.size())
				return false;

			for (const auto& i : a)
				if (!b.contains(i)) return false;
			return true;
		}

		namespace FileInternal {
			Folder::Handle last_opened_folder = ROOT_FOLDER;
			Window::Handle dnd_src_window = Window::NULL_WINDOW;
			std::unordered_set<File::Handle> files_to_drag;

			enum class Sorting {
				NAME,
				CREATION_DATE,
				FILETYPE
			};
			struct CachedFolderContents {
				Folder::Handle cached_folder = Folder::NULL_FOLDER;
				int revision = 0;
				std::vector<File::Handle> sorted_files;
				Sorting applied_sorting = Sorting::NAME;
				bool is_applied_sorting_up = true;
				std::unordered_set<FileType::Handle> filters;
			};
			struct FileSelectionState {
				Folder::Handle base_folder = ROOT_FOLDER;
				FileInternal::Sorting sorting_type = FileInternal::Sorting::NAME;
				bool is_selected_sorting_up = true;

				std::unordered_set<File::Handle> files;
				int last_selected_file_id = 0;

				std::unordered_set<File::Handle> files_to_copy;
				bool is_files_being_moved = false;

				File::Handle rename_target = File::NULL_FILE;
				FileType::Handle file_creation_target = FileType::NULL_FILETYPE;
			};

			void SelectFiles(const std::vector<File::Handle>& sorted_files, std::unordered_set<File::Handle>& previous_selection, int c_element_id, int& last_selected_file_id) {
				const File::Handle c_file = sorted_files[c_element_id];
				if (Internal::default_io->KeyCtrl) {
					if (previous_selection.contains(c_file)) //Must toggle selection
						previous_selection.erase(c_file);
					else
						previous_selection.insert(c_file);
				}
				else if (Internal::default_io->KeyShift) {
					previous_selection.clear();

					for (int file_id = last_selected_file_id; file_id <= c_element_id; file_id++)
						previous_selection.insert(sorted_files[file_id]);
					for (int file_id = last_selected_file_id; file_id >= c_element_id; file_id--) //2 loops for cases wheter i is greater or smaller than the last selected file
						previous_selection.insert(sorted_files[file_id]);
				}
				else if (!Internal::default_io->KeyShift && !Internal::default_io->KeyShift) {
					previous_selection.clear();
					previous_selection.insert(c_file);
				}
				else
					previous_selection.clear();//If pressed both keys, just deselect all, just like how it was made in the windows file explorer

				last_selected_file_id = c_element_id;
			}
			bool CheckForRecursiveness(Folder::Handle selected_folder, const std::unordered_set<File::Handle>& selected_files) {
				bool is_recursive = false;
				Folder::Handle folder_to_check = selected_folder;
				while (!Folder::IsRootFolder(folder_to_check)) {
					is_recursive = is_recursive || selected_files.contains(folder_to_check);
					folder_to_check = File::GetParentFolder(folder_to_check);
				}
				return is_recursive;
			}
			struct FolderWithFormattedName {
				Folder::Handle folder = Folder::NULL_FOLDER;
				std::string formatted_name;
			};

			void ErrorRecursiveFolders() {
				ErrorModal::Open("Внимание: рекурсивные папки невозможны.\n\n(это значит что вы попытались переместить/скопировать \nродительскую папку в её дочернюю папку)", "рекурсия папок");
			}

			void FolderDragTarget(FileSelectionState& selection, Folder::Handle target_folder) {
				if (ImGui::BeginDragDropTarget()) {
					if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("file_drag")) {
						if (Internal::default_io->KeyCtrl) {
							if (!FileInternal::CheckForRecursiveness(target_folder, files_to_drag)) { 
								for (auto& i : files_to_drag)//Its done this way to allow draggin between different windows
									File::TryCopy(target_folder, i);
							}
							else
								ErrorRecursiveFolders();
						}
						else {
							if (!FileInternal::CheckForRecursiveness(target_folder, files_to_drag)) {
								for (auto& i : files_to_drag)
									File::TryMove(target_folder, i);
								files_to_drag.clear();
							}
							else
								ErrorRecursiveFolders();
						}
					}
					ImGui::EndDragDropTarget();
				}
			}

			bool StringCmpLess(const std::string& a, const std::string& b) { return (a.size() < b.size()) || (a.size() == b.size() && a < b); };
			bool StringCmpMore(const std::string& a, const std::string& b) { return (a.size() > b.size()) || (a.size() == b.size() && a > b); };

			std::vector<File::Handle> SortFiles(const std::unordered_set<File::Handle>& unsorted_files, Sorting sorting_to_apply, bool direction_is_up, const std::unordered_set<FileType::Handle>& filters) {
				std::vector<File::Handle> files;
				std::vector<File::Handle> folders;
				std::vector<File::Handle> res;

				files.reserve(unsorted_files.size());
				folders.reserve(unsorted_files.size());

				for (const auto& i : unsorted_files) {
					if (Folder::IsFolder(i))
						folders.push_back(i);
					else if((filters.size() == 0) || filters.contains(File::GetType(i)))
						files.push_back(i);
				}
				//sort folders
				//Folders are always sorted the same way except when sorted by date

				const auto SORT_FILE_BY_NAME = [direction_is_up](File::Handle a, File::Handle b) { return direction_is_up ? StringCmpLess(File::GetName(a), File::GetName(b)) : StringCmpMore(File::GetName(a), File::GetName(b)); };
				const auto SORT_FILE_BY_TYPE = [direction_is_up](File::Handle a, File::Handle b) {
					if (direction_is_up ? StringCmpLess(FileType::GetName(File::GetType(a)), FileType::GetName(File::GetType(b))) : StringCmpMore(FileType::GetName(File::GetType(a)), FileType::GetName(File::GetType(b))))
						return true;
					else if (FileType::GetName(File::GetType(a)) == FileType::GetName(File::GetType(b))) //Secondary sorting
						return direction_is_up ? StringCmpLess(File::GetName(a), File::GetName(b)) : StringCmpMore(File::GetName(a), File::GetName(b));
				};

				//Should always put folders in the beginning
				switch (sorting_to_apply) {
				case FileInternal::Sorting::NAME: {
					std::sort(files.begin(), files.end(), SORT_FILE_BY_NAME);
					std::sort(folders.begin(), folders.end(), SORT_FILE_BY_NAME);
			
					bool files_first = files.size() && folders.size() ? SORT_FILE_BY_NAME(files[0], folders[0]) : false;

					if(files_first)
						res.insert(res.begin(), folders.begin(), folders.end()); //Foders are here is because insertion is in opposite order

					res.insert(res.begin(), files.begin(), files.end());

					if (!files_first)
						res.insert(res.begin(), folders.begin(), folders.end());
				} break;
				case FileInternal::Sorting::FILETYPE: {
					std::sort(files.begin(), files.end(), SORT_FILE_BY_TYPE);
					std::sort(folders.begin(), folders.end(), SORT_FILE_BY_TYPE);
					res.insert(res.begin(), files.begin(), files.end());
					res.insert(res.begin(), folders.begin(), folders.end());
				} break;
				}

				return res;
			}
			void SortingSelectionMenu(Sorting& selected_sorting_type, bool& is_selected_sorting_up) {
				if (ImGui::BeginMenu("Сортировка")) {
					if (ImGui::MenuItem("По имени", nullptr, selected_sorting_type == FileInternal::Sorting::NAME))
						selected_sorting_type = FileInternal::Sorting::NAME;
					if (ImGui::MenuItem("По дате изменения", nullptr, selected_sorting_type == FileInternal::Sorting::CREATION_DATE)) {
					}
					if (ImGui::MenuItem("По типу", nullptr, selected_sorting_type == FileInternal::Sorting::FILETYPE))
						selected_sorting_type = FileInternal::Sorting::FILETYPE;

					ImGui::SeparatorText("Направление:");
					if (ImGui::MenuItem("Вверх", nullptr, is_selected_sorting_up))
						is_selected_sorting_up = true;
					if (ImGui::MenuItem("Вниз", nullptr, !is_selected_sorting_up))
						is_selected_sorting_up = false;
					ImGui::EndMenu();
				}
			}

			void Cut(FileInternal::FileSelectionState& selection) {
				selection.files_to_copy = selection.files;
				selection.is_files_being_moved = true;
			}
			void Copy(FileInternal::FileSelectionState& selection) {
				selection.files_to_copy = selection.files;
				selection.is_files_being_moved = false;
			}
			void Paste(FileInternal::FileSelectionState& selection) {
				selection.files.clear();
				if (!FileInternal::CheckForRecursiveness(selection.base_folder, selection.files_to_copy)) {
					if (selection.is_files_being_moved) {
						for (auto& i : selection.files_to_copy)
							File::TryMove(selection.base_folder, i); //We can not worry about selected folder being changed, since it happens only outside of file listing
						selection.is_files_being_moved = false; //Selection must be cleared after move
						selection.files = selection.files_to_copy;
						selection.files_to_copy.clear();
					}
					else {
						for (auto& i : selection.files_to_copy)
							selection.files.insert(File::TryCopy(selection.base_folder, i));
					}
				}
				else
					ErrorRecursiveFolders();
			}
			void Delete(FileInternal::FileSelectionState& selection) {
				for (auto& i : selection.files) {
					if (selection.files_to_copy.contains(i)) selection.files_to_copy.erase(i);
					File::Delete(i);
				}
				selection.files.clear();
			}

			void Open(FileInternal::FileSelectionState& selection) {
				if (selection.files.size() == 1) {
					const File::Handle selected_file = *selection.files.begin();

					if (Folder::IsFolder(selected_file)) { //Opening a folder
						selection.base_folder = selected_file;
						selection.files.clear();
						last_opened_folder = selected_file;
					}
					else if(FileType::GetData(File::GetType(selected_file)).OpenFile != nullptr){
						FileType::CallOpenFile(File::GetType(selected_file), selected_file);
					}
					selection.files.clear();
				}
			}
			//TODO:
			//  file picker
			//  make it more modular

			
		}

		void FileSelectBase(FileInternal::FileSelectionState& selection, FileInternal::CachedFolderContents& folder_cache, 
				const std::unordered_set<FileType::Handle>& filters, int bottom_bar_size, int button_width, 
				Window::Handle parent_window,
				void(*OpenFn)(FileInternal::FileSelectionState&), 
				void(*MenuSingleFile)(FileInternal::FileSelectionState&), 
				void(*MenuMultipleFiles)(FileInternal::FileSelectionState&) = nullptr) {
			const ImGuiStyle& STYLE = ImGui::GetStyle();
			const auto WINDOW_START_POS = ImGui::GetCursorPos();
			const auto WINSIZE = Gui::GetWindowAvailableSpace();

			if (!File::IsValid(selection.base_folder))
				selection.base_folder = ROOT_FOLDER;

			if (ImGui::BeginMenuBar()) {
				if (ImGui::BeginMenu("Добавить")) {
					for (const auto& [menu_name, file_type] : editor_filesystem_data_types) {
						if (ImGui::MenuItem(menu_name.c_str()))
							selection.file_creation_target = file_type;
					}
					ImGui::EndMenu();
				}
				if (ImGui::MenuItem("Новая папка"))
					selection.file_creation_target = Folder::FOLDER_TYPE_PRESET;
				FileInternal::SortingSelectionMenu(selection.sorting_type, selection.is_selected_sorting_up);
				ImGui::EndMenuBar();
			}
			//Top bar
			{
				const auto WINSIZE = Gui::GetWindowAvailableSpace();
				const ImGuiStyle& STYLE = ImGui::GetStyle();

				const bool is_root = Folder::IsRootFolder(selection.base_folder); //This MUST be a separate variable, because selected folder can change between BeginDisabled() and EndDisabled(), and this will trigger a crash
				if (is_root)
					ImGui::BeginDisabled();
				if (ImGui::ImageButton("#up_arrow", (ImTextureID)UP_ARROW_TEXTURE.handle().data->texture_gpu_handle, { ImGui::GetTextLineHeight(), ImGui::GetTextLineHeight() })) {
					selection.base_folder = File::GetParentFolder(selection.base_folder);
					selection.files.clear();
					FileInternal::last_opened_folder = selection.base_folder;
				}
				if (is_root)
					ImGui::EndDisabled();
				if (!Folder::IsRootFolder(selection.base_folder))
					FileInternal::FolderDragTarget(selection, File::GetParentFolder(selection.base_folder));

				//------------------------------------------FILE BAR------------------------------------------------------------
				ImGui::SameLine();
				ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, { 2, 0 });

				//Iterate until hit the bottom, and calculate line size
				//While saving names to the stack
				const int max_line_length = WINSIZE.x - (ImGui::GetCursorPosX() - WINDOW_START_POS.x);

				std::stack<FileInternal::FolderWithFormattedName> formatted_line_names;
				Folder::Handle c_folder = selection.base_folder;
				int line_width = 0;
				do {
					std::string c_name = fmt::format("{} >", File::GetName(c_folder));
					const auto text_size = ImGui::CalcTextSize(c_name.c_str());
					const int button_size = text_size.x + STYLE.FramePadding.x * 2 + STYLE.ItemSpacing.x;

					if ((line_width + button_size) > max_line_length)
						break;

					formatted_line_names.push({ .folder = c_folder, .formatted_name = std::move(c_name) });
					line_width += button_size;

					c_folder = File::GetParentFolder(c_folder);
				} while (c_folder != Folder::NULL_FOLDER);

				while (formatted_line_names.size()) {
					const Folder::Handle c_folder = formatted_line_names.top().folder;
					if (ImGui::Button(formatted_line_names.top().formatted_name.c_str())) {
						selection.base_folder = c_folder;
						selection.files.clear();
						FileInternal::last_opened_folder = c_folder;
					}
					FileInternal::FolderDragTarget(selection, c_folder);
					formatted_line_names.pop();

					ImGui::SameLine();
				}
				ImGui::PopStyleVar();
				static char buff[32] = "";
				ImGui::BeginDisabled();
				ImGui::InputText("##Test", buff, 32);
				ImGui::EndDisabled();
				ImGui::Separator();
			}
			//-------------------------------BEGIN FILESPACE--------------------------------------------------------------------

			//File sorting
			if (folder_cache.cached_folder != selection.base_folder
				|| folder_cache.revision != Folder::GetRevision(selection.base_folder)
				|| folder_cache.applied_sorting != selection.sorting_type
				|| folder_cache.is_applied_sorting_up != selection.is_selected_sorting_up 
				|| !IsEqual(folder_cache.filters, filters)) {

				folder_cache.sorted_files = SortFiles(Folder::ListFiles(selection.base_folder), selection.sorting_type, selection.is_selected_sorting_up, filters);

				folder_cache.applied_sorting = selection.sorting_type;
				folder_cache.cached_folder = selection.base_folder;
				folder_cache.revision = Folder::GetRevision(selection.base_folder);
				folder_cache.is_applied_sorting_up = selection.is_selected_sorting_up;
				folder_cache.filters = filters;
			}

			ImGui::BeginChild("##file_space", { 0, (fl32)bottom_bar_size });

			bool was_file_menu_open = false;
			const pos2d32 available_space = Gui::GetWindowAvailableSpace();

			const ImVec2 FILE_THUMBNAIL_SIZE = { button_width - STYLE.FramePadding.x * 2, button_width - STYLE.FramePadding.y * 2 };
			int MAX_ELEMENTS_PER_LINE = available_space.x / (button_width + (int)STYLE.ItemSpacing.x) + (available_space.x % (button_width + (int)STYLE.ItemSpacing.x)) / button_width;
			MAX_ELEMENTS_PER_LINE = MAX_ELEMENTS_PER_LINE == 0 ? 1 : MAX_ELEMENTS_PER_LINE;
			const int SPACING_SIZE = (available_space.x - button_width * MAX_ELEMENTS_PER_LINE) / (MAX_ELEMENTS_PER_LINE == 1 ? 1 : (MAX_ELEMENTS_PER_LINE - 1));
			ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(SPACING_SIZE, STYLE.ItemSpacing.y));

			int max_item_height_per_line = 0;
			auto line_start_pos = ImGui::GetCursorPos();

			for (int i = 0; i < folder_cache.sorted_files.size(); i++) {
				const File::Handle c_file = folder_cache.sorted_files[i];
				if (!File::IsValid(c_file))
					continue;
				const std::string& c_filename = File::GetName(c_file);

				const auto text_size = ImGui::CalcTextSize(c_filename.c_str(), nullptr, false, FILE_THUMBNAIL_SIZE.x);
				const auto button_start_cursor_pos = ImGui::GetCursorPos();
				//------------------------------------------------------------------------BUTTON ITSELF
				const auto& file_thumbnail = ImGui::IsRectVisible(FILE_THUMBNAIL_SIZE + STYLE.FramePadding) ? FileType::CallGetFileThumbnail(File::GetType(c_file), c_file) : Folder::Internal::Func::folder_thumbnail;
				if (
					Gui::FileButton(
						button_width, 
						c_filename, 
						file_thumbnail.texture,
						FileType::CallGetTypeIcon(File::GetType(c_file), c_file), 
						selection.files.contains(c_file),
						!(Internal::default_io->KeyCtrl || Internal::default_io->KeyShift || selection.files.contains(c_file)),
						file_thumbnail.uv0, file_thumbnail.uv1
					)
				)
					FileInternal::SelectFiles(folder_cache.sorted_files, selection.files, i, selection.last_selected_file_id);
				if (((i + 1) % MAX_ELEMENTS_PER_LINE) != 0) ImGui::SameLine();
				if (ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left) && ImGui::IsItemHovered()) { //TODO: also register it when clicking the Enter key
					Internal::default_io->ClearInputMouse(); //This line is for stopping file from being automatically selected after double click
					OpenFn(selection);
				}

				//------------------------------------Dragging
				if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_None)) {
					FileInternal::dnd_src_window = parent_window;

					if (!selection.files.contains(c_file))
						FileInternal::SelectFiles(folder_cache.sorted_files, selection.files, i, selection.last_selected_file_id);

					//selection.were_files_dragged = true;
					FileInternal::files_to_drag = selection.files;

					const int dummy = 0;
					ImGui::SetDragDropPayload("file_drag", &dummy, sizeof(bool));
					ImGui::Text(fmt::format("Файлов к {}: {}", Internal::default_io->KeyCtrl ? "копированию" : "перемещению", selection.files.size()).c_str());
					ImGui::EndDragDropSource();
				}
				if (Folder::IsFolder(c_file) && (!selection.files.contains(c_file) || FileInternal::dnd_src_window != parent_window))
					FolderDragTarget(selection, c_file);
				//-----------------------------------Dragging end
				//----------------------------------------------------------------File menu
				if (ImGui::BeginPopupContextItem()) {
					was_file_menu_open = true; //This makes sure that this menu has larger priority than the file explorer menu
					if (!selection.files.contains(c_file)) {
						selection.files.clear();
						selection.files.insert(c_file);
					}

					if (selection.files.size() == 1) {
						MenuSingleFile(selection);
						ImGui::Separator();
						if (ImGui::MenuItem("Копировать", "Ctrl + C"))
							Copy(selection);
						if (ImGui::MenuItem("Вырезать", "Ctrl + X"))
							Cut(selection);
						ImGui::Separator();
						if (ImGui::MenuItem("Переименовать"))
							selection.rename_target = c_file;
						if (ImGui::MenuItem("Удалить", "Del"))
							Delete(selection);

						ImGui::Separator();
						if (ImGui::MenuItem("Свойства")) {
						}
					}
					else if (selection.files.size() > 1) {
						if (MenuMultipleFiles != nullptr)
							MenuMultipleFiles(selection);
						if (ImGui::MenuItem("Копировать", "Ctrl + C"))
							Copy(selection);
						if (ImGui::MenuItem("Вырезать", "Ctrl + X"))
							Cut(selection);
						ImGui::Separator();
						if (ImGui::MenuItem("Удалить", "Del"))
							Delete(selection);
					}

					ImGui::EndPopup();
				}
			}
			ImGui::PopStyleVar();
			ImGui::EndChild();
			if(FileInternal::dnd_src_window != parent_window || Internal::default_io->KeyCtrl)
				FileInternal::FolderDragTarget(selection, selection.base_folder);
			//-------------------------------------------------------------------Shortcuts-------------------------------------------------------------
			if (ImGui::Shortcut(ImGuiMod_Ctrl | ImGuiKey_C))
				Copy(selection);
			if (ImGui::Shortcut(ImGuiMod_Ctrl | ImGuiKey_X))
				Cut(selection);
			if (ImGui::Shortcut(ImGuiMod_Ctrl | ImGuiKey_V))
				Paste(selection);
			if (ImGui::Shortcut(ImGuiKey_Delete))
				Delete(selection);

			if (ImGui::Shortcut(ImGuiMod_Shift | ImGuiKey_Escape))
				selection.files_to_copy.clear(), selection.is_files_being_moved = false;
			//-------------------------------------------------------------------Shortcuts end---------------------------------------------------------
			if (ImGui::IsItemClicked())
				selection.files.clear();
			if (!was_file_menu_open) { //This menu should have less priority than the file menu. If you remove this line, it will be the opposite
				if (ImGui::BeginPopupContextItem()) {
					selection.files.clear();

					if (ImGui::BeginMenu("Добавить")) {
						for (auto& [menu_name, file_type] : editor_filesystem_data_types) {
							if (ImGui::MenuItem(menu_name.c_str()))
								selection.file_creation_target = file_type;
						}
						ImGui::EndMenu();
					}
					if (ImGui::MenuItem("Создать папку"))
						selection.file_creation_target = Folder::FOLDER_TYPE_PRESET;
					ImGui::Separator();
					if (ImGui::MenuItem("Вставить", "Ctrl + V", false, selection.files_to_copy.size()))
						Paste(selection);
					ImGui::Separator();
					FileInternal::SortingSelectionMenu(selection.sorting_type, selection.is_selected_sorting_up);
					ImGui::EndPopup();
				}
			}

			//---------------------------------------------------------Renaming---------------------------------------
			if (File::IsValid(selection.rename_target)) {
				static std::string buff;

				const bool state = Modals::Rename(buff, File::GetName(selection.rename_target));
				if (state) {
					File::Rename(buff, selection.rename_target);
					selection.rename_target = File::NULL_FILE;
				}
			}

			//---------------------------------------------------------Creation---------------------------------------
			if (FileType::IsValid(selection.file_creation_target)) {
				if (FileType::CallCreateFileModal(selection.file_creation_target, selection.base_folder))
					selection.file_creation_target = FileType::NULL_FILETYPE;
			}

			//selection.stopped_dragging = selection.were_dragged_in_the_last_frame && !selection.were_files_dragged;
			//selection.were_dragged_in_the_last_frame = selection.were_files_dragged;
		}

		namespace Func {
			struct Data {
				int button_width = 70;
				FileInternal::FileSelectionState selection = {};
				FileInternal::CachedFolderContents folder_cache;
			};

			std::string GetName(Window::Handle window) {
				return fmt::format("Файлы проекта##{}", (void*)window.data);
			}

			void Open(Window::Handle raw_window, void* data) {
				Window::GetData(raw_window).data = new Data{ *(Data*)data };
			}
			bool Update(Window::Handle window) {
				const ImGuiStyle& STYLE = ImGui::GetStyle();

				auto& dat = *(Data*)Window::GetData(window).data;

				bool is_open = true;
				if (ImGui::Begin(Func::GetName(window).c_str(), &is_open, ImGuiWindowFlags_MenuBar)) {
					FileSelectBase(dat.selection, dat.folder_cache, {}, -(ImGui::GetTextLineHeightWithSpacing() + STYLE.ItemSpacing.y + STYLE.WindowPadding.y), dat.button_width, window, 
						FileInternal::Open, 
						[](FileInternal::FileSelectionState& selection)->void { 
							const auto& filetype = File::GetType(*selection.files.begin());
							if (ImGui::MenuItem("Открыть"))	FileInternal::Open(selection); 
							if (FileType::GetData(filetype).FileContextMenu != nullptr)
								FileType::CallFileContextMenu(filetype, *selection.files.begin());
						}
					);

					//-------------------------------END FILESPACE--------------------------------------------------------------------
					ImGui::Separator();
					ImGui::Text("Размер иконок: ");
					ImGui::SameLine();
					ImGui::PushItemWidth(100);
					ImGui::SliderInt("##file_icon_size", &dat.button_width, 50, 150);
					ImGui::PopItemWidth();
					ImGui::SameLine();

					ImGui::Text(fmt::format("Элементов: {}", (int)dat.folder_cache.sorted_files.size()).c_str());
					ImGui::SameLine();

					if (dat.selection.files.size() - dat.selection.files.contains(dat.selection.base_folder)) {
						ImGui::Text(fmt::format("Выбрано: {}", dat.selection.files.size()).c_str());
						ImGui::SameLine();
					}
					if (dat.selection.files_to_copy.size())
						ImGui::Text(fmt::format("К {}: {} (нажмите Shift + Esc чтобы отменить)", dat.selection.is_files_being_moved ? "перемещению" : "копированию", dat.selection.files_to_copy.size()).c_str());
				}
				bool was_active = ImGui::IsWindowFocused();
				ImGui::End();

				if (!is_open)
					Window::Close(window);

				return was_active;
			}

			void Close(Window::Handle window) {
				delete (Data*)Window::GetData(window).data;
			}

			WindowTemplate::Handle templ = WindowTemplate::Make({ .Open = Open, .Update = Update, .Close = Close, .GetName = GetName });
		}
		Window::Handle Open(const Folder::Handle folder) {
			const Func::Data tmp = { .selection = {.base_folder = folder} };
			Window::Handle win = Window::Open(Func::templ, (void*)&tmp);
			return win;
		}

		namespace FileInternal {
			bool tmp_confirm = false;
		}

		typedef Func::Data State;

		State InitializeState(Folder::Handle base_folder) {
			return { .selection = {.base_folder = base_folder} };
		}

		bool SelectFiles(std::unordered_set<File::Handle>& dest, State& state, const std::unordered_set<FileType::Handle>& filters = {}) {
			const ImGuiStyle& STYLE = ImGui::GetStyle();
			bool is_open = true;
			ImGui::OpenPopup("Выбор файлов", ImGuiPopupFlags_NoReopen);

			auto& dat = state;
			FileInternal::tmp_confirm = false;
			ImGui::SetNextWindowSize({ 400, 300 }, ImGuiCond_Once);
			if (ImGui::BeginPopupModal("Выбор файлов", &is_open, ImGuiWindowFlags_MenuBar)) {
				auto single_fselect_fn =
					[](FileInternal::FileSelectionState& selection)->void {
						const auto& c_file = *selection.files.begin();
						if (Folder::IsFolder(c_file) && (selection.files.size() == 1)) {
							if(ImGui::MenuItem("Открыть"))
								FileInternal::Open(selection);
						}
						else {
							if(ImGui::MenuItem("Выбрать"))
								FileInternal::tmp_confirm = true;
						}
					};

				FileSelectBase(state.selection, dat.folder_cache, filters, -(ImGui::GetTextLineHeightWithSpacing() + STYLE.ItemSpacing.y + STYLE.WindowPadding.y), dat.button_width, Window::NULL_WINDOW,
					[](FileInternal::FileSelectionState& selection) {
						const auto& c_file = *selection.files.begin();
						if (Folder::IsFolder(c_file) && (selection.files.size() == 1))
							FileInternal::Open(selection);
						else
							FileInternal::tmp_confirm = true;
					},
					single_fselect_fn,
					single_fselect_fn
				);

				//Закрытие
				ImGui::Separator();

				bool is_something_else_selected = false;
				for (const auto& i : state.selection.files) {
					if (!filters.contains(File::GetType(i))) {
						is_something_else_selected = true;
						break;
					}
				}

				if (!state.selection.files.size() || is_something_else_selected)
					ImGui::BeginDisabled();
				if (ImGui::Button("Подтвердить")) {
					ImGui::CloseCurrentPopup();
					is_open = false;
					FileInternal::tmp_confirm = true;
				}
				if (!state.selection.files.size() || is_something_else_selected)
					ImGui::EndDisabled();
				ImGui::SameLine();
				if (ImGui::Button("Отмена")) {
					ImGui::CloseCurrentPopup();
					is_open = false;
				}
				ImGui::SameLine();
				ImGui::Text("Размер иконок: ");
				ImGui::SameLine();
				ImGui::PushItemWidth(100);
				ImGui::SliderInt("##file_icon_size", &dat.button_width, 50, 150);
				ImGui::PopItemWidth();
				ImGui::SameLine();

				ImGui::Text(fmt::format("Элементов: {}", dat.folder_cache.sorted_files.size()).c_str());
				ImGui::SameLine();

				if (dat.selection.files.size() - dat.selection.files.contains(dat.selection.base_folder)) {
					ImGui::Text(fmt::format("Выбрано: {}", dat.selection.files.size()).c_str());
					ImGui::SameLine();
				}
				if (dat.selection.files_to_copy.size())
					ImGui::Text(fmt::format("К {}: {} (нажмите Shift + Esc чтобы отменить)", dat.selection.is_files_being_moved ? "перемещению" : "копированию", dat.selection.files_to_copy.size()).c_str());

				ImGui::EndPopup();
			}

			if (FileInternal::tmp_confirm) {
				is_open = false;

				dest.reserve(state.selection.files.size());
				for (auto& i : state.selection.files) {
					if (filters.contains(File::GetType(i))) //this must be done since there are other ways to open folders with that, so we must sanitize the output
						dest.insert(i);
				}
			}

			return !is_open;
		}

		bool SelectFile(File::Handle& dest, Func::Data& state, const std::unordered_set<FileType::Handle>& filters = {}) {
			const ImGuiStyle& STYLE = ImGui::GetStyle();
			bool is_open = true;
			ImGui::OpenPopup("Выбор файлов", ImGuiPopupFlags_NoReopen);

			auto& dat = state;
			FileInternal::tmp_confirm = false;
			
			ImGui::SetNextWindowSize({ 400, 300 }, ImGuiCond_Once);
			if (ImGui::BeginPopupModal("Выбор файлов", &is_open, ImGuiWindowFlags_MenuBar)) {
				FileSelectBase(state.selection, dat.folder_cache, filters, -(ImGui::GetTextLineHeightWithSpacing() + STYLE.ItemSpacing.y + STYLE.WindowPadding.y), dat.button_width, Window::NULL_WINDOW,
					[](FileInternal::FileSelectionState& selection) {
						const auto& c_file = *selection.files.begin();
						if (Folder::IsFolder(c_file))
							FileInternal::Open(selection);
						else
							FileInternal::tmp_confirm = true;
					},
					[](FileInternal::FileSelectionState& selection)->void {
						const auto& c_file = *selection.files.begin();
						if (Folder::IsFolder(c_file)) {
							if (ImGui::MenuItem("Открыть"))
								FileInternal::Open(selection);
						}
						else {
							if (ImGui::MenuItem("Выбрать"))
								FileInternal::tmp_confirm = true;
						}
					}
				);

				//Закрытие
				ImGui::Separator();

				auto c_file_type = state.selection.files.size() ? File::GetType(*state.selection.files.begin()) : FileType::NULL_FILETYPE;
				if (state.selection.files.size() != 1 || !filters.contains(c_file_type))
					ImGui::BeginDisabled();
				if (ImGui::Button("Подтвердить")) {
					ImGui::CloseCurrentPopup();
					is_open = false;
					FileInternal::tmp_confirm = true;
				}
				if (state.selection.files.size() != 1 || !filters.contains(c_file_type))
					ImGui::EndDisabled();
				ImGui::SameLine();
				if (ImGui::Button("Отмена")) {
					ImGui::CloseCurrentPopup();
					dest = File::NULL_FILE;
					is_open = false;
					FileInternal::tmp_confirm = false;
				}
				ImGui::SameLine();
				ImGui::Text("Размер иконок: ");
				ImGui::SameLine();
				ImGui::PushItemWidth(100);
				ImGui::SliderInt("##file_icon_size", &dat.button_width, 50, 150);
				ImGui::PopItemWidth();
				ImGui::SameLine();

				ImGui::Text(fmt::format("Элементов: {}", dat.folder_cache.sorted_files.size()).c_str());
				ImGui::SameLine();

				if (dat.selection.files.size() - dat.selection.files.contains(dat.selection.base_folder)) {
					ImGui::Text(fmt::format("Выбрано: {}", dat.selection.files.size()).c_str());
					ImGui::SameLine();
				}
				if (dat.selection.files_to_copy.size())
					ImGui::Text(fmt::format("К {}: {} (нажмите Shift + Esc чтобы отменить)", dat.selection.is_files_being_moved ? "перемещению" : "копированию", dat.selection.files_to_copy.size()).c_str());

				ImGui::EndPopup();
			}

			if (FileInternal::tmp_confirm) {
				is_open = false;
				
				const auto& c_file = *state.selection.files.begin();

				if (filters.contains(File::GetType(c_file)))
					dest = c_file;
			}

			return !is_open;
		}
	}
}

