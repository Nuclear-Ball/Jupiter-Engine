#pragma once
#include "../../Engine/Engine.h"
#include "../Subsystems/ImGuiHelper.h"
#include "../EngSubsysImpl/Map.h"
#include "../SceneFileType.h"

#include "../Subsystems/WindowManagementSystem.h"
#include "FileExplorer.h"
#include "SceneLayerEditor.h" //Just to include it somewhere

namespace Editor {
	const fl32 DEFAULT_CAM_SPEED = 10;

	//LLJE::Layer::Handle active_layer;
	Tile::Handle selected_tile;

	namespace Viewport {
		namespace Func {
			enum class EditMode {
				TILE
			};

			struct Data {
				J2D::Cam2D cam = { {256, 256} };
				fl32 cam_speed = DEFAULT_CAM_SPEED; //In meters per second
				SceneFile::Handle editing_scene = SceneFile::NULL_FILE;

				JGFX::Texture viewport_framebuffer = JGFX::Texture{ pos2du16{600, 600} };

				EditMode edit_mode = EditMode::TILE;

				bool scene_open_wait = false;
				FileExplorer::State scene_opener_state = {};

				LLJE::Scene::Handle playing_scene = LLJE::Scene::NULL_SCENE;
			};
		}
		void ChangeScene(Window::Handle handle, SceneFile::Handle scene) {
			auto& dat = *(Func::Data*)Window::GetData(handle).data;
			if (File::IsValid(dat.editing_scene))
				SceneFile::GetData(dat.editing_scene).opened_windows--;

			dat.editing_scene = scene;
			if (File::IsValid(dat.editing_scene))
				SceneFile::GetData(dat.editing_scene).opened_windows++;
		}
		namespace Func {
			void Open(Window::Handle raw_window, void* data) {
				Window::GetData(raw_window).data = new Data{ .editing_scene = *(SceneFile::Handle*)data };
				if (File::IsValid(*(SceneFile::Handle*)data))
					SceneFile::GetData(*(SceneFile::Handle*)data).opened_windows++;
			}

			std::string GetName(Window::Handle window) {
				return fmt::format("Вьюпорт##{}", (void*)window.data);
			}

			//This scene is supposed to be editor-only
			bool Update(Editor::Window::Handle window) {
				auto& dat = *(Data*)Window::GetData(window).data;

				bool is_open = true;
				if (ImGui::Begin(Func::GetName(window).c_str(), &is_open)) {
					bool is_playing = play_window == window;

					if (!is_playing) {
						if (ImGui::ImageButton("play_button", (ImTextureID)PLAY_ICON.handle().data->texture_gpu_handle, { ImGui::GetTextLineHeight(), ImGui::GetTextLineHeight() })) {
							play_window = window;
							Tile::Internal::DropConversionTable();

							dat.playing_scene = Scene::ConvertScene(SceneFile::GetScene(dat.editing_scene));
							//Move data to scene
						}
					}
					else {
						if (ImGui::ImageButton("pause_button", (ImTextureID)PAUSE_ICON.handle().data->texture_gpu_handle, { ImGui::GetTextLineHeight(), ImGui::GetTextLineHeight() })) {
							play_window = Window::NULL_WINDOW;
							LLJE::Scene::Delete(dat.playing_scene);
							is_playing = false;
						}
					}

					if (is_playing)
						ImGui::BeginDisabled();
					ImGui::SameLine();
					{
						ImGui::Text(fmt::format("Сцена: \"{}\"", File::IsValid(dat.editing_scene) ? File::GetName(dat.editing_scene) : "").c_str());
						ImGui::SameLine();
						if (ImGui::Button("Открыть")) {
							dat.scene_open_wait = true;
							FileExplorer::InitializeState(File::IsValid(dat.editing_scene) ? File::GetParentFolder(dat.editing_scene) : FileExplorer::FileInternal::last_opened_folder);
						}

						if (dat.scene_open_wait) {
							static SceneFile::Handle dest = SceneFile::NULL_FILE;

							if (FileExplorer::SelectFile(dest, dat.scene_opener_state, { SceneFile::FILETYPE_TYPE_PRESET })) {
								if (File::IsValid(dest))
									ChangeScene(window,dest);
								dat.scene_open_wait = false;
							}
						}
					}
					ImGui::SameLine();
					{
						const char* const mode_strings[] = {
							"Тайловый"
						};
						ImGui::Text("Режим:");
						ImGui::SameLine();
						ImGui::SetNextItemWidth(150);
						ImGui::Combo("##mode selection", (int*)&dat.edit_mode, mode_strings, 1);
					}
					ImGui::Separator();

					if (is_playing)
						ImGui::EndDisabled();
					if (!File::IsValid(dat.editing_scene))
						ImGui::Text("Для продолжения выберите сцену для редактирования");
					else{
						auto& c_cam = dat.cam;//is_editing ? editor_cam : playback_cam;

						const pos2du16 avail_size = Gui::GetWindowAvailableSpace();
						if (dat.viewport_framebuffer.size() != avail_size)
							dat.viewport_framebuffer.Resize(avail_size);

						const uint16 SCREEN_HEIGHT = 256;
						const fl64 winsize_screen_ratio = (fl64)avail_size.y / (fl64)SCREEN_HEIGHT;
						{
							const uint16 expected_buffer_size = (uint16)(avail_size.x / winsize_screen_ratio);

							if (c_cam.frm.size().x != expected_buffer_size || c_cam.frm.size().y != SCREEN_HEIGHT)
								c_cam.frm.Resize({ expected_buffer_size, SCREEN_HEIGHT });
						}

						const auto c_scene = is_playing ? dat.playing_scene : SceneFile::GetScene(dat.editing_scene);
						

						LLJE::Render(c_cam, c_scene);
						J2D::DisplayFramebuffer(c_cam.frm, dat.viewport_framebuffer);

						dat.viewport_framebuffer.Bind();
						LLJ2D::curr_pv = c_cam.MakePV();
						//Debug draw
						const auto c_win = glfwGetCurrentContext();
						if (is_playing) {
							if (glfwGetKey(c_win, GLFW_KEY_C)) {
								RenderedData::Circle::circle_pixel_scale = J2D::ToMetric(c_cam.frm.size().y) / (c_cam.props.scale.y) * 5;
								b2World_Draw(PsnGame::Scene::GetPhysHandle(dat.playing_scene), &RenderedData::debug_draw);
							}
						}
						else {
							auto& scene_file_dat = SceneFile::GetData(dat.editing_scene);
							const auto& layer_list = LLJE::Scene::ListLayers(c_scene);
							//const auto& scene_file_dat = SceneFile::GetData(dat.editing_scene);
							LLJE::Layer::Handle active_layer = scene_file_dat.active_layer >= 0 && scene_file_dat.active_layer < layer_list.size() ? layer_list[scene_file_dat.active_layer] : LLJE::Layer::NULL_LAYER;
							{
								ImVec2 start_pos = ImGui::GetCursorPos();
								const auto size = ImGui::GetContentRegionAvail();
								ImGui::InvisibleButton("will u work?", size.x != 0.f && size.y != 0.f ? size : ImVec2{ 1,1 });
								ImGui::SetCursorPos(start_pos);
							}
							bool was_hovered = ImGui::IsItemHovered();

							if (Internal::default_io->MousePos.x != -FLT_MAX && was_hovered && (active_layer != LLJE::Layer::NULL_LAYER)) {
								{
									auto& scene_dat = Scene::GetDataUnsafe(scene_file_dat.scene);
									scene_dat.cam_for_thumbnail_rendering.center_pos = c_cam.center_pos;
									scene_dat.cam_for_thumbnail_rendering.props = c_cam.props;
								}

								const pos2df64 mouse_screen_coords = (pos2df64)(J2D::ToMetric(Gui::GetMousePosInsideWidget({ Internal::default_io->MousePos.x, Internal::default_io->MousePos.y }, ImGui::GetCursorPos()))) / winsize_screen_ratio;
								const pos2df64 global_mouse_pos = J2D::ScreenCoordsToGlobal(mouse_screen_coords, J2D::ToMetric(SCREEN_HEIGHT), c_cam.MakeViewMatrix());

								const pos2df64 mouse_pos_in_layer = LLJE::Layer::GlobalPosToLayerPos(active_layer, global_mouse_pos, c_cam);

								Editor::Map::Handle c_tmap = active_layer;

								const pos2d64 hovered_tile_pos = LLJE::Convert::TileFromMetric(mouse_pos_in_layer, Editor::Map::GetGridSize(c_tmap));
								if (Internal::default_io->MouseDown[0]) //Left mouse button
									Editor::Map::SetTile(c_tmap, selected_tile, hovered_tile_pos);
								if (Internal::default_io->MouseDown[1]) //Right mouse button (aka eraser)
									Editor::Map::SetTile(c_tmap, Tile::NULL_TILE, hovered_tile_pos);


								if (glfwGetKey(c_win, GLFW_KEY_A))
									dat.cam.center_pos.x -= dat.cam_speed * JGFX::GetDeltaTimeValue() / c_cam.props.scale.x;
								if (glfwGetKey(c_win, GLFW_KEY_D))
									dat.cam.center_pos.x += dat.cam_speed * JGFX::GetDeltaTimeValue() / c_cam.props.scale.x;

								if (glfwGetKey(c_win, GLFW_KEY_W))
									dat.cam.center_pos.y += dat.cam_speed * JGFX::GetDeltaTimeValue() / c_cam.props.scale.x;
								if (glfwGetKey(c_win, GLFW_KEY_S))
									dat.cam.center_pos.y -= dat.cam_speed * JGFX::GetDeltaTimeValue() / c_cam.props.scale.x;

								if (glfwGetKey(c_win, GLFW_KEY_HOME)) {
									dat.cam.center_pos = { 0,0 };
									dat.cam_speed = DEFAULT_CAM_SPEED;
									dat.cam.props.scale = { 1,1 };
								}

								if (glfwGetKey(c_win, GLFW_KEY_LEFT_CONTROL)) {
									dat.cam_speed += Internal::default_io->MouseWheel;
								}
								else {
									//Cam zooming
									if (Internal::default_io->MouseWheel) {
										const double zoom_add = 0.1 * Internal::default_io->MouseWheel * dat.cam.props.scale.x;

										dat.cam.props.scale += pos2df64{ zoom_add };

										//the idea is that: global mspos after == global mspos before
										const pos2df64 new_global_mspos = dat.cam.ScreenCoordsToAbs(mouse_screen_coords);
										dat.cam.center_pos += (global_mouse_pos - new_global_mspos);
									}
								}

								//Also show tile preview
								if (Tile::IsValid(selected_tile)) {
									const auto& tile_data = Tile::GetData(selected_tile);
									const fl32 editor_transparency = blink_color;

									const pos2df64 local_tile_display_pos = LLJE::Convert::MetricFromTile(hovered_tile_pos, Editor::Map::GetGridSize(c_tmap));
									const pos2df64 global_tile_display_pos = LLJE::Layer::LayerPosToGlobalPos(active_layer, local_tile_display_pos, dat.cam);
									J2D::Draw(Texture::GetTexture(tile_data.texture), global_tile_display_pos, {}, editor_transparency);
								}
							}
						}
						ImGui::Image((ImTextureID)(dat.viewport_framebuffer.handle().data->texture_gpu_handle), ImVec2(avail_size.x, avail_size.y), ImVec2(0, 1), ImVec2(1, 0));
						win.Bind();
					}
				}
				bool focus = ImGui::IsWindowFocused();

				if (!is_open)
					Window::Close(window);

				ImGui::End();
				return focus;
			}

			void Close(Window::Handle window) {
				//Make scene not active
				auto& dat = *(Data*)Window::GetData(window).data;
				if (File::IsValid(dat.editing_scene))
					SceneFile::GetData(dat.editing_scene).opened_windows--;

				delete (Data*)Window::GetData(window).data;
			}

			

			WindowTemplate::Handle templ = WindowTemplate::Make({ .Open = Open, .Update = Update, .Close = Close, .GetName = GetName });
		}
		Window::Handle Open(SceneFile::Handle scene) {
			return Window::Open(Func::templ, &scene);
		}
		
		SceneFile::Handle GetScene(Window::Handle handle) {
			return (*(Func::Data*)Window::GetData(handle).data).editing_scene;
		}

		namespace Func {
			bool init_dummy =
				((FileType::Data&)FileType::GetData(SceneFile::FILETYPE_TYPE_PRESET)).OpenFile = [](File::Handle file) {
				auto viewport_win = WindowSystem::GetLastActiveWindowByType(templ);

				if (viewport_win == Window::NULL_WINDOW)
					Viewport::Open(file);
				else
					ChangeScene(viewport_win, file);

				auto layer_editor_win = WindowSystem::GetLastActiveWindowByType(SceneLayerEditor::Func::templ);

				if (layer_editor_win == Window::NULL_WINDOW)
					SceneLayerEditor::Open(file);
				else
					SceneLayerEditor::ChangeScene(layer_editor_win, file);
				};
		}
	}
}