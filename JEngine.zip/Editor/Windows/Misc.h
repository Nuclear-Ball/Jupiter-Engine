#pragma once
#include "../Subsystems/ImGuiHelper.h"
#include "../Subsystems/WindowManagementSystem.h"

namespace Editor {
	namespace ErrorModal {
		namespace Func {
			struct Data {
				std::string message;
				std::string title;
			};

			std::string GetName(Window::Handle window) {
				return fmt::format("Ошибка: {}##{}", (*(Data*)Window::GetData(window).data).title, (void*)window.data);
			}

			void Open(Window::Handle raw_window, void* data) {
				Window::GetData(raw_window).data = new Data{ *(Data*)data };
			}
			bool Update(Window::Handle window) {
				bool was_focused = false;

				bool is_open = true;
				ImGui::OpenPopup(Func::GetName(window).c_str(), ImGuiPopupFlags_NoReopen); //Must be placed here, otherwise it for some unknown reason wouldnt work
				if (ImGui::BeginPopupModal(Func::GetName(window).c_str(), &is_open, ImGuiWindowFlags_AlwaysAutoResize)) {
					ImGui::Text((*(Data*)Window::GetData(window).data).message.c_str());
					ImGui::Separator();
					//Закрытие
					if (ImGui::Button("Ок", { ImGui::GetContentRegionAvail().x, 0 }) || ImGui::Shortcut(ImGuiKey_Enter) || ImGui::Shortcut(ImGuiKey_Escape)) {
						ImGui::CloseCurrentPopup();
						is_open = false;
					}

					was_focused = ImGui::IsWindowFocused();
					ImGui::EndPopup();
				}
				if (!is_open)
					Window::Close(window);

				return was_focused;
			}

			void Close(Window::Handle window) {
				delete (Data*)Window::GetData(window).data;
			}

			WindowTemplate::Handle templ = WindowTemplate::Make({ .Open = Open, .Update = Update, .Close = Close, .GetName = GetName });
		}
		Window::Handle Open(const std::string& message, const std::string& title) {
			const Func::Data tmp = { .message = message, .title = title };
			Window::Handle win = Window::Open(Func::templ, (void*)&tmp);
			Window::Update(win);
			return win;
		}
	}
	namespace Modals {
		bool Rename(std::string& target, const std::string& initial_value, const std::string& title = "Переименовать") {
			//Инициализация
			static bool first_time = true;
			bool focus_text = false;
			if (first_time) {
				first_time = false;
				target = initial_value;
				focus_text = true;
			}

			//Главное окно
			bool is_opened = true;
			ImGui::OpenPopup(title.c_str(), ImGuiPopupFlags_NoReopen);
			if (ImGui::BeginPopupModal(title.c_str(), &is_opened, ImGuiWindowFlags_AlwaysAutoResize)) {
				if (focus_text)
					ImGui::SetKeyboardFocusHere();
				if (ImGui::InputText("##rename_popup_data", &target, ImGuiInputTextFlags_EnterReturnsTrue | ImGuiInputTextFlags_AutoSelectAll) || ImGui::Shortcut(ImGuiKey_Enter)) {
					ImGui::CloseCurrentPopup();
					is_opened = false;
				}
				ImGui::Separator();
				//Закрытие
				if (ImGui::Button("Подтвердить")) {
					ImGui::CloseCurrentPopup();
					is_opened = false;
				}
				ImGui::SameLine();
				//ImGui::SetItemKeyOwner(ImGuiKey_Escape, ImGuiInputFlags_)
				if (ImGui::Button("Отмена")) {
					ImGui::CloseCurrentPopup();
					is_opened = false;
					target = initial_value;
				}
				ImGui::EndPopup();
			}

			//При закрытии
			if (!is_opened)
				first_time = true;

			return !is_opened;
		}
	}
	namespace Convert {
		pos2du16 ToImageCoords(pos2df64 metric_coords, pos2du16 image_size) {
			return pos2df64{ 0, image_size.y } + J2D::ToPixels(
				pos2df64{ metric_coords.x, -metric_coords.y }
			);																			//Converted to the image space coordinates
		}
		pos2df64 FromImageCoords(pos2du16 image_coords, pos2du16 image_size) {
			return J2D::ToMetric(
				pos2df64{ 0, image_size.y } + pos2df64{ image_coords.x, -image_coords.y }
			);																			//Converted to the image space coordinates
		}
	}
}