#pragma once
#include "../Subsystems/ImGuiHelper.h"
#include "../Subsystems/WindowManagementSystem.h"
#include "../EngSubsysImpl/Map.h"
#include "../SceneFileType.h"

namespace Editor {
	namespace SceneLayerEditor {
		namespace Func {
			struct PropertyEditState {
				LLJE::Layer::LayerSettings params;
				std::string name = "Без имени";
				pos2df64 grid_size = { 1,1 };
			};
			bool EditLayerProperties(PropertyEditState& state, bool& confirm) {
				bool is_popup_open = true;
				//bool confirm = false;

				//auto& layer_data = (Map::Internal::TmapData&)Map::GetData(Map::FromLayer(layer));
				//auto& regular_layer_data = LLJE::Layer::GetEditableLayerSettings(layer);

				ImGui::OpenPopup("Параметры слоя", ImGuiPopupFlags_NoReopen);
				if (ImGui::BeginPopupModal("Параметры слоя", &is_popup_open, ImGuiWindowFlags_AlwaysAutoResize)) {
					ImGui::Text("Имя: ");
					ImGui::SameLine();
					ImGui::InputText("##name", &state.name);

					ImGui::Text("Скорость параллакс-скроллинга: ");
					//ImGui::SameLine();
					pos2df32 parallax_adapter = state.params.parallax_speed;
					ImGui::DragFloat2("##parallax_speed", (float*)&parallax_adapter, 0.01);
					state.params.parallax_speed = parallax_adapter;

					ImGui::Text("Прозрачность: ");
					//ImGui::SameLine();
					ImGui::SliderFloat("##transparency", &state.params.transparency, 0, 1, "%3f", ImGuiSliderFlags_AlwaysClamp);

					ImGui::Text("Размер тайловой сетки(в метрах): ");
					//ImGui::SameLine();
					pos2df32 grid_size_adapter = state.grid_size;
					ImGui::DragFloat2("##grid_size", (float*)&grid_size_adapter, 0.01);
					state.grid_size = grid_size_adapter;

					ImGui::Text("Смещение: ");
					pos2df32 offset_adapter = state.params.pos;
					ImGui::DragFloat2("##offset", (float*)&offset_adapter, 0.01);
					state.params.pos = offset_adapter;

					ImGui::Separator();
					if (ImGui::Button("Отмена")) {
						is_popup_open = false;
						ImGui::CloseCurrentPopup();
					}
					ImGui::SameLine();
					if (ImGui::Button("Подтвердить")) {
						confirm = true;
						is_popup_open = false;
						ImGui::CloseCurrentPopup();
					}

					ImGui::EndPopup();
				}
				return !is_popup_open;
			}

			struct Data {
				SceneFile::Handle scene;

				bool open_scene_wait = false;
				FileExplorer::State file_opener_state;

				LLJE::Layer::Handle layer_to_move = LLJE::Layer::NULL_LAYER;
				LLJE::Layer::Handle layer_to_rename = LLJE::Layer::NULL_LAYER;
				LLJE::Layer::Handle property_edit_target = LLJE::Layer::NULL_LAYER;
				PropertyEditState property_edit_state = {};

				bool create_layer_wait = false;
			};
		}
		void ChangeScene(Window::Handle handle, SceneFile::Handle scene) {
			auto& dat = *(Func::Data*)Window::GetData(handle).data;
			dat.scene = scene;
		}
		namespace Func {
			inline std::string GetName(Window::Handle window) {
				return fmt::format("Редактор слоев/сцен##{}", (void*)window.data);
			}

			inline void Open(Window::Handle raw_window, void* data) {
				Window::GetData(raw_window).data = new Data{ *(Data*)data };
			}
			bool Update(Window::Handle window) {
				const ImGuiStyle& STYLE = ImGui::GetStyle();
				Data& dat = *(Data*)Window::GetData(window).data;

				bool is_opened = true;
				if (ImGui::Begin(Func::GetName(window).c_str(), &is_opened)) {

					//Opening a different tileset
					{
						ImGui::Text(fmt::format("Сцена: \"{}\"", File::IsValid(dat.scene) ? File::GetName(dat.scene) : "").c_str());
						ImGui::SameLine();
						if (ImGui::Button("Открыть")) {
							dat.open_scene_wait = true;
							FileExplorer::InitializeState(File::IsValid(dat.scene) ? File::GetParentFolder(dat.scene) : FileExplorer::FileInternal::last_opened_folder);
						}

						if (dat.open_scene_wait) {
							static Tileset::Handle dest = Tileset::NULL_TSET;

							if (FileExplorer::SelectFile(dest, dat.file_opener_state, { SceneFile::FILETYPE_TYPE_PRESET })) {
								if (File::IsValid(dest))
									ChangeScene(window, dest);
								dat.open_scene_wait = false;
							}
						}
					}
					ImGui::Separator();

					if (!File::IsValid(dat.scene))
						ImGui::Text("Для начала работы выберите сцену");
					else {
						if (ImGui::BeginTabBar("idk_main_tab_bar")) {
							if (ImGui::BeginTabItem("Слои")) {
								//const auto& tset_data = Tileset::GetData(dat.scene);
								const fl32 button_height = 50;
								ImGui::BeginChild("layers", { 0, -(button_height + STYLE.ItemSpacing.y * 2.f) }, 0, ImGuiWindowFlags_AlwaysVerticalScrollbar);

								const auto& layers_list = LLJE::Scene::ListLayers(SceneFile::GetScene(dat.scene));
								auto& scene_file_dat = SceneFile::GetData(dat.scene);

								for (int i = 0; i < layers_list.size(); i++) {
									const auto& c_layer = layers_list[i];
									auto& layer_data = (Map::Internal::TmapData&)Map::GetData(c_layer);
									auto& regular_layer_data = LLJE::Layer::GetEditableLayerSettings(c_layer);

									auto thumbnail = Map::GetThumbnail(c_layer);
									if (
										Gui::ImageDoubleTextSelectable(
											ImGui::GetID(fmt::format("{}", (void*)c_layer.data).c_str()), 
											fmt::format("\"{}\"", layer_data.name), 
											regular_layer_data.is_visible ? "" : "(скрыт)",
											thumbnail, LLJGFX::Texture::GetSize(thumbnail),
											{ 0,1 }, { 1,0 }, { 1,1,1, regular_layer_data.is_visible ? 1.f : 0.5f },
											i == scene_file_dat.active_layer)
										) {
										scene_file_dat.active_layer = i;
									}
									if (ImGui::IsItemActive() && !ImGui::IsItemHovered()) {
										int next = i + (ImGui::GetMouseDragDelta().y >= 0 ? 1 : -1);

										if (next >= 0 && next < layers_list.size()) {
											LLJE::Scene::SwapLayers(scene_file_dat.scene, i, next);
											if (scene_file_dat.active_layer == i)
												scene_file_dat.active_layer = next;
											else if (scene_file_dat.active_layer == next)
												scene_file_dat.active_layer = i;
											ImGui::ResetMouseDragDelta();
										}
									}
									if (ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left) && ImGui::IsItemHovered())
										regular_layer_data.is_visible = !regular_layer_data.is_visible;
									if (ImGui::BeginPopupContextItem()) {
										if (ImGui::MenuItem("Изменить параметры слоя")) {
											dat.property_edit_target = c_layer;
											dat.property_edit_state = {
												.name = layer_data.name,
												.params = regular_layer_data,
												.grid_size = layer_data.grid_size
											};
										}
										if (ImGui::MenuItem("Переименовать"))
											dat.layer_to_rename = c_layer;
										ImGui::Separator();
										if (ImGui::MenuItem("Создать дубликат")) {
											const auto& new_layer = Map::MakeLayer(c_layer, scene_file_dat.scene, LLJE::Layer::FRONT, i + 1);
											Map::SetName(new_layer, fmt::format("{} (дубликат)", Map::GetName(new_layer)));
										}
										if (ImGui::MenuItem("Переместить в другую сцену")) {
											dat.layer_to_move = c_layer;
											dat.file_opener_state = FileExplorer::InitializeState(File::GetParentFolder(dat.scene));
										}
										if (ImGui::MenuItem("Удалить")){
											LLJE::Layer::Delete(c_layer);
											scene_file_dat.active_layer = (scene_file_dat.active_layer == i) ? -1 : scene_file_dat.active_layer - (scene_file_dat.active_layer > i ? 1 : 0);
											i--;
										}
										ImGui::EndPopup();
									}

									ImGui::Separator();
								}
								if (LLJE::Layer::IsValid(dat.layer_to_move)) {
									static Tileset::Handle dest = Tileset::NULL_TSET;

									if (FileExplorer::SelectFile(dest, dat.file_opener_state, { SceneFile::FILETYPE_TYPE_PRESET })) {
										if (File::IsValid(dest))
											LLJE::Layer::MoveTo(dat.layer_to_move, SceneFile::GetScene(dest));
										dat.layer_to_move = LLJE::Layer::NULL_LAYER;
									}
								}
								if (LLJE::Layer::IsValid(dat.layer_to_rename)) {
									static std::string dest = "";

									const auto& layer_data = Map::GetData(dat.layer_to_rename);
									if (Modals::Rename(dest, layer_data.name)) {
										Map::SetName(dat.layer_to_rename, dest);
										dat.layer_to_rename = LLJE::Layer::NULL_LAYER;
									}
								}
								if (LLJE::Layer::IsValid(dat.property_edit_target)) {
									bool is_popup_open = true;
									bool confirm = false;

									auto& layer_data = (Map::Internal::TmapData&)Map::GetData(dat.property_edit_target);
									auto& regular_layer_data = LLJE::Layer::GetEditableLayerSettings(dat.property_edit_target);
									auto& state = dat.property_edit_state;

									if (EditLayerProperties(dat.property_edit_state, confirm)) {
										if (confirm) {
											regular_layer_data = state.params;
											layer_data.name = state.name;
											Map::SetGridSize(dat.property_edit_target, state.grid_size);
										}

										dat.property_edit_target = LLJE::Layer::NULL_LAYER;
									}
								}
								if (dat.create_layer_wait) {
									bool confirm = false;
									auto& state = dat.property_edit_state;

									if (EditLayerProperties(dat.property_edit_state, confirm)) {
										if (confirm) {
											Map::MakeLayer(scene_file_dat.scene, LLJE::Layer::BACK, 0, state.name, state.grid_size, { 16,16 }, state.params);
											scene_file_dat.active_layer = layers_list.size() - 1;
										}
										dat.create_layer_wait = false;
									}
								}
								ImGui::EndChild();
								ImGui::Separator();
								//Загрузка новых тайлов
								if (ImGui::Button("Добавить", ImVec2(ImGui::GetContentRegionAvail().x, button_height))) {
									dat.create_layer_wait = true;
									dat.property_edit_state = {};
								}
								ImGui::EndTabItem();
							}
							if (ImGui::BeginTabItem("Сцена")) {
								ImGui::Text("Фоновой цвет:");

								const auto& bg_col = LLJE::Scene::GetBackgroundColor(SceneFile::GetScene(dat.scene));

								auto tmp = (glm::vec4)bg_col;
								//float color_adapter[4] = { (float)bg_col.r, (float)bg_col.g, (float)bg_col.b, (float)bg_col.a };

								ImGui::ColorEdit4("##bg_color", (float*)&tmp);
								LLJE::Scene::SetBackgroundColor(SceneFile::GetScene(dat.scene), rgb{ tmp });

								ImGui::EndTabItem();
							}
							ImGui::EndTabBar();
						}
					}
				}
				bool was_focused = ImGui::IsWindowFocused();
				ImGui::End();

				if (!is_opened) {
					Window::Close(window);
				}
				return was_focused;
			}

			void Close(Window::Handle window) {
				delete (Data*)Window::GetData(window).data;
			}

			WindowTemplate::Handle templ = WindowTemplate::Make({ .Open = Open, .Update = Update, .Close = Close, .GetName = GetName });
		}
		bool IsThisType(Window::Handle handle) {
			assert(Window::IsValid(handle));
			return Window::GetType(handle) == Func::templ;
		}

		Window::Handle Open(SceneFile::Handle scene) {
			const Func::Data tmp = {.scene = scene};
			Window::Handle win = Window::Open(Func::templ, (void*)&tmp);
			return win;
		}
	}
}