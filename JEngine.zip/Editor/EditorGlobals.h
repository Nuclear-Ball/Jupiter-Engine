#pragma once
#include "Subsystems/FilesystemBase.h"
#include "Subsystems/WindowManagementSystem.h"

namespace Editor {
	JGFX::Window win = { {600, 600}, "Редактор движка \"Юпитер\"" };
	Folder::Handle ROOT_FOLDER = Folder::MakeRootFolder();
	float blink_color = 1;
	std::vector<std::pair<std::string, FileType::Handle>> editor_filesystem_data_types;
}