#pragma once
#include <JSerial.h>
#include <JGFX/JGFX.h>

namespace SerializationEssentials {
	JSerial::GenericType Pos2du16 = JSerial::Struct("pos2du16");
	JSerial::GenericType Pos2d16 = JSerial::Struct("pos2d16");
	JSerial::GenericType Pos2du32 = JSerial::Struct("pos2du32");
	JSerial::GenericType Pos2d32 = JSerial::Struct("pos2d32");
	JSerial::GenericType Pos2du64 = JSerial::Struct("pos2du64");
	JSerial::GenericType Pos2d64 = JSerial::Struct("pos2d64");

	JSerial::GenericType Pos2df32 = JSerial::Struct("pos2df32");
	JSerial::GenericType Pos2df64 = JSerial::Struct("pos2df64");

	JSerial::GenericType Rgb = JSerial::Struct("rgb");

	JSerial::TemplateSet templ = {
		{.name = "pos2du16", .fields = {{.name = "x", .type = JSerial::NumericType(JSerial::TypeEnum::INT16)}, {.name = "y", .type = JSerial::NumericType(JSerial::TypeEnum::INT16)}}},
		{.name = "pos2d16", .fields = {{.name = "x", .type = JSerial::NumericType(JSerial::TypeEnum::INT16)}, {.name = "y", .type = JSerial::NumericType(JSerial::TypeEnum::INT16)}}},
		{.name = "pos2du32", .fields = {{.name = "x", .type = JSerial::NumericType(JSerial::TypeEnum::INT32)}, {.name = "y", .type = JSerial::NumericType(JSerial::TypeEnum::INT32)}}},
		{.name = "pos2d32", .fields = {{.name = "x", .type = JSerial::NumericType(JSerial::TypeEnum::INT32)}, {.name = "y", .type = JSerial::NumericType(JSerial::TypeEnum::INT32)}}},
		{.name = "pos2du64", .fields = {{.name = "x", .type = JSerial::NumericType(JSerial::TypeEnum::INT64)}, {.name = "y", .type = JSerial::NumericType(JSerial::TypeEnum::INT64)}}},
		{.name = "pos2d64", .fields = {{.name = "x", .type = JSerial::NumericType(JSerial::TypeEnum::INT64)}, {.name = "y", .type = JSerial::NumericType(JSerial::TypeEnum::INT64)}}},

		{.name = "pos2df32", .fields = {{.name = "x", .type = JSerial::NumericType(JSerial::TypeEnum::FLOAT32)}, {.name = "y", .type = JSerial::NumericType(JSerial::TypeEnum::FLOAT32)}}},
		{.name = "pos2df64", .fields = {{.name = "x", .type = JSerial::NumericType(JSerial::TypeEnum::FLOAT64)}, {.name = "y", .type = JSerial::NumericType(JSerial::TypeEnum::FLOAT64)}}},

		{.name = "rgb", .fields = {{.name = "r", .type = JSerial::NumericType(JSerial::TypeEnum::INT8)}, {.name = "g", .type = JSerial::NumericType(JSerial::TypeEnum::INT8)}, {.name = "b", .type = JSerial::NumericType(JSerial::TypeEnum::INT8)}, {.name = "a", .type = JSerial::NumericType(JSerial::TypeEnum::INT8)}}},
	};

	JSerial::SerializedStruct SerializePos2du16(pos2du16 data, const JSerial::CompiledTemplateSet& templ) 
		{ return JSerial::SerializeStruct("pos2du16", templ, JSerial::Field{ "x", data.x }, JSerial::Field{ "y", data.y }); }
	JSerial::SerializedStruct SerializePos2d16(pos2d16 data, const JSerial::CompiledTemplateSet& templ) 
		{ return JSerial::SerializeStruct("pos2d16", templ, JSerial::Field{ "x", data.x }, JSerial::Field{ "y", data.y }); }

	JSerial::SerializedStruct SerializePos2du32(pos2du32 data, const JSerial::CompiledTemplateSet& templ) 
		{ return JSerial::SerializeStruct("pos2du32", templ, JSerial::Field{ "x", data.x }, JSerial::Field{ "y", data.y }); }
	JSerial::SerializedStruct SerializePos2d32(pos2d32 data, const JSerial::CompiledTemplateSet& templ) 
		{ return JSerial::SerializeStruct("pos2d32", templ, JSerial::Field{ "x", data.x }, JSerial::Field{ "y", data.y }); }

	JSerial::SerializedStruct SerializePos2du64(pos2du64 data, const JSerial::CompiledTemplateSet& templ) 
		{ return JSerial::SerializeStruct("pos2du64", templ, JSerial::Field{ "x", data.x }, JSerial::Field{ "y", data.y }); }
	JSerial::SerializedStruct SerializePos2d64(pos2d64 data, const JSerial::CompiledTemplateSet& templ) 
		{ return JSerial::SerializeStruct("pos2d64", templ, JSerial::Field{ "x", data.x }, JSerial::Field{ "y", data.y }); }


	JSerial::SerializedStruct SerializePos2df32(pos2df32 data, const JSerial::CompiledTemplateSet& templ) 
		{ return JSerial::SerializeStruct("pos2df32", templ, JSerial::Field{ "x", data.x }, JSerial::Field{ "y", data.y }); }
	JSerial::SerializedStruct SerializePos2df64(pos2df64 data, const JSerial::CompiledTemplateSet& templ) 
		{ return JSerial::SerializeStruct("pos2df64", templ, JSerial::Field{ "x", data.x }, JSerial::Field{ "y", data.y }); }

	JSerial::SerializedStruct SerializeRgb(rgb data, const JSerial::CompiledTemplateSet& templ) 
		{ return JSerial::SerializeStruct("rgb", templ, JSerial::Field{ "r", data.r }, JSerial::Field{ "g", data.g }, JSerial::Field{ "b", data.b }, JSerial::Field{ "a", data.a }); }

	////////////////////////////////////////////////////////////////

	pos2du16 DeserializePos2du16(const JSerial::ParsedStruct& data, const JSerial::Document& src) 
		{ return { JSerial::Deserialize<uint16>(data,src, "x"), JSerial::Deserialize<uint16>(data,src, "y") }; }
	pos2d16 DeserializePos2d16(const JSerial::ParsedStruct& data, const JSerial::Document& src) 
		{ return { JSerial::Deserialize<int16>(data,src, "x"), JSerial::Deserialize<int16>(data,src, "y") }; }

	pos2du32 DeserializePos2du32(const JSerial::ParsedStruct& data, const JSerial::Document& src) 
		{ return { JSerial::Deserialize<uint32>(data,src, "x"), JSerial::Deserialize<uint32>(data,src, "y") }; }
	pos2d32 DeserializePos2d32(const JSerial::ParsedStruct& data, const JSerial::Document& src) 
		{ return { JSerial::Deserialize<int32>(data,src, "x"), JSerial::Deserialize<int32>(data,src, "y") }; }

	pos2du64 DeserializePos2du64(const JSerial::ParsedStruct& data, const JSerial::Document& src) 
		{ return { JSerial::Deserialize<uint64>(data,src, "x"), JSerial::Deserialize<uint64>(data,src, "y") }; }
	pos2d64 DeserializePos2d64(const JSerial::ParsedStruct& data, const JSerial::Document& src) 
		{ return { JSerial::Deserialize<int64>(data,src, "x"), JSerial::Deserialize<int64>(data,src, "y") }; }

	pos2df32 DeserializePos2df32(const JSerial::ParsedStruct& data, const JSerial::Document& src) 
		{ return { JSerial::Deserialize<fl32>(data,src, "x"), JSerial::Deserialize<fl32>(data,src, "y") }; }
	pos2df64 DeserializePos2df64(const JSerial::ParsedStruct& data, const JSerial::Document& src) 
		{ return { JSerial::Deserialize<fl64>(data,src, "x"), JSerial::Deserialize<fl64>(data,src, "y") }; }


	rgb DeserializeRgb(const JSerial::ParsedStruct& data, const JSerial::Document& src) 
		{ return { JSerial::Deserialize<uint8>(data,src, "r"), JSerial::Deserialize<uint8>(data,src, "g"), JSerial::Deserialize<uint8>(data,src, "b"), JSerial::Deserialize<uint8>(data,src, "a"), }; }
}