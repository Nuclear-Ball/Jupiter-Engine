﻿#pragma once
#include <JupiterUtils.h>
#include <JSerial.h>
#include <unordered_map>
#include <cassert>
#include <fmt/core.h>
#include "ImGuiHelper.h"
#include "../Resources/Resources.h"
#include "../Windows/Misc.h"

namespace Editor {
	namespace File {
		struct Data;
		typedef JE::MHandle<Data> Handle;
		const Handle NULL_FILE = { nullptr };
	}
	namespace Folder {
		struct Data;
		typedef File::Handle Handle;
		const Handle NULL_FOLDER = { nullptr };

		struct Data {
			std::unordered_set<File::Handle> files;
			std::unordered_set<std::string> cached_names;
			int revision = 0; //Used to determine, whether the cached contents of a folder are still valid
		};
		namespace Internal {
			Data& GetFolderData(void* raw_ptr) {
				return *(Data*)raw_ptr;
			}
			const std::string folder_type_name = "Folder";
		}
	}
	namespace FileType {
		struct Thumbnail {
			LLJGFX::Texture::Handle texture = { nullptr };
			ImVec2 uv0 = { 0,0 };
			ImVec2 uv1 = { 1,1 };
		};

		struct Data {
			//void Open();

			void(*Make)(File::Handle unedited_file, void* data) = nullptr;
			void(*Copy)(File::Handle to, File::Handle from) = nullptr;
			void(*Delete)(File::Handle file) = nullptr;

			JSerial::SerializedStruct(*SerializeFile)(File::Handle file, const JSerial::CompiledTemplateSet& templ, const std::string& internal_struct_name) = nullptr;
			void (*DeserializeFile)(File::Handle raw_file, const JSerial::Document& src, const JSerial::ParsedStruct& file_struct) = nullptr;

			bool(*CreateFileModal)(Folder::Handle to) = nullptr;
			LLJGFX::Texture::Handle(*GetTypeIconTexture)(File::Handle file) = nullptr;
			const Thumbnail&(*GetFileThumbnailTexture)(File::Handle file) = nullptr;
			void(*OpenFile)(File::Handle file);
			void(*FileContextMenu)(File::Handle file);
			void(*Properties)(File::Handle file);

			std::string name;
		};
		typedef JE::MHandle<Data> Handle;
		const Handle NULL_FILETYPE = { nullptr };

		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}
		bool IsValid(Handle handle) 
			{ return Internal::manager.DoesExists(handle); }

		void CallMake(Handle handle, File::Handle unedited_file, void* data) {
			assert(IsValid(handle));
			Internal::manager[handle].Make(unedited_file, data);
		}
		void CallCopy(Handle handle, File::Handle to, File::Handle from) {
			assert(IsValid(handle));
			Internal::manager[handle].Copy(to, from);
		}
		void CallDelete(Handle handle, File::Handle file) {
			assert(IsValid(handle));
			Internal::manager[handle].Delete(file);
		}
		bool CallCreateFileModal(Handle handle, Folder::Handle to) {
			assert(IsValid(handle));
			return Internal::manager[handle].CreateFileModal(to);
		}
		void CallOpenFile(Handle handle, File::Handle file) {
			assert(IsValid(handle));
			return Internal::manager[handle].OpenFile(file);
		}
		void CallFileContextMenu(Handle handle, File::Handle file) {
			assert(IsValid(handle));
			return Internal::manager[handle].FileContextMenu(file);
		}
		JSerial::SerializedStruct CallSerializeFile(Handle handle, File::Handle file, const JSerial::CompiledTemplateSet& templ, const std::string& internal_struct_name) {
			assert(IsValid(handle));
			return Internal::manager[handle].SerializeFile(file, templ, internal_struct_name);
		}
		void CallDeserialize(Handle handle, File::Handle raw_file, const JSerial::Document& src, const JSerial::ParsedStruct& file_struct) {
			assert(IsValid(handle));
			Internal::manager[handle].DeserializeFile(raw_file, src, file_struct);
		}

		const Thumbnail& CallGetFileThumbnail(Handle handle, File::Handle file) {
			assert(IsValid(handle));
			return Internal::manager[handle].GetFileThumbnailTexture(file);
		}
		LLJGFX::Texture::Handle CallGetTypeIcon(Handle handle, File::Handle file) {
			assert(IsValid(handle));
			return Internal::manager[handle].GetTypeIconTexture(file);
		}

		const Data& GetData(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle];
		}
		const std::string& GetName(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].name;
		}

		Handle Make(const Data& data) {
			return Internal::manager.Add(data);
		}
		void Delete(Handle handle) 
			{ Internal::manager.Remove(handle); }
	}
	namespace Folder {
		FileType::Handle FOLDER_TYPE_PRESET = FileType::NULL_FILETYPE;
	}

	namespace FilesystemSerialization {
		namespace Internal {

			//JSerial::StructTemplate templ;

			//Structure:
			//Main filesystem struct
			// |- <FileTypeName>: array
			// |   |-Struct filedata
			// |   |   |-FileHandle
			// |   |   |-Struct <FileTypeName>
			// |   |   |   |- <layout defined by user>
			// |- ...
			// |- <filename>: array
			// |
			// |- RootFolder: folder
			//
			// Struct Folder:
			// |- Files: array<Struct File>
			// |   |- Filename
			// |   |- FileTypeName
			// |   |- FileHandle

			JSerial::StructFieldsTemplate generic_handle_template = { {.name = "id", .type = JSerial::NumericType(JSerial::TypeEnum::INT64)} };
			JSerial::StructFieldsTemplate generic_file_data_template = { {.name = "FileId", .type = JSerial::Struct("FileHandle") } };
		}
		JSerial::InitializationStructTemplate file_handle_template = { .name = "FileHandle", .fields = Internal::generic_handle_template };
		JSerial::GenericType file_handle = JSerial::Struct("FileHandle");

		JSerial::SerializedStruct SerializeFileHandle(File::Handle handle, const JSerial::CompiledTemplateSet& templates) {
			return JSerial::SerializeStruct("FileHandle", templates, JSerial::Field{ "id", (uint64)handle.data });
		}
		File::Handle DeserializeFileHandle(JSerial::ParsedStruct handle_struct, const JSerial::Document& src) {
			return { (decltype(File::Handle::data))JSerial::Deserialize<uint64>(handle_struct, src, "id") };
		}

		namespace Internal{
			JSerial::TemplateSet filesystem_filetypes = {
				file_handle_template,
				{
					.name = "File",
					.fields = {
						{.name = "filename", .type = JSerial::String() },
						{.name = "type", .type = JSerial::String() },
						{.name = "file_id", .type = file_handle }
					}
				}
			};

			JSerial::StructFieldsTemplate folder_serialization_template = {
				{.name = "files", .type = JSerial::Array(JSerial::Struct("File"))}
			};
			struct FileSerializationTemplate {
				JSerial::StructFieldsTemplate root_struct;
				JSerial::TemplateSet oth;
			};
			std::unordered_map<FileType::Handle, FileSerializationTemplate> type_templates;

			namespace Deserialization {
				struct FileForDeserialization {
					FileType::Handle filetype;
					JSerial::ParsedStruct data;
				};
				
				std::unordered_map<std::string, FileType::Handle> filetype_linking_table;
				std::unordered_map<File::Handle, File::Handle> real_file_linking_table; //Key - serialized handle, value - actual existing file
				std::unordered_map<File::Handle, File::Handle> deserialized_files; //Key - serialized handle
				//std::unordered_map<FileType::Handle, std::unordered_map<File::Handle, JSerial::ParsedStruct>> file_data_linking_table;

				std::unordered_map<File::Handle, JSerial::ParsedStruct> file_sources; //Key - serialized_handle
				
			}
		}

		void IntegrateSerialisationTemplate(FileType::Handle handle, const JSerial::StructFieldsTemplate& root_template, const JSerial::TemplateSet& oth_templates) {
			Internal::type_templates[handle] = { .root_struct = root_template, .oth = oth_templates };
		}
		void IntegrateFilesystemSerializationTemplates(JSerial::TemplateSet& target_set) {
			//Insert default types:
			for (const auto& [name, fields] : Internal::filesystem_filetypes.struct_templates)
				target_set.struct_templates[name] = fields;

			JSerial::StructFieldsTemplate filesystem_root_type;
			//Make new types based on filetypes, such as 
			for (auto& [filetype, serialization_template] : Internal::type_templates) {
				const std::string& name = GetName(filetype);

				const std::string file_descriptor_type_name = fmt::format("FileDescriptor<{}>", name);
				const std::string file_data_type_name = fmt::format("FileData<{}>", name);
				target_set.struct_templates[file_data_type_name] = serialization_template.root_struct;
				target_set.struct_templates[file_descriptor_type_name] = { {.name = "file_id", .type = JSerial::Struct("FileHandle")}, {.name = "file_data", .type = JSerial::Struct(file_data_type_name)} };

				for (auto& i : serialization_template.oth.struct_templates)
					target_set.struct_templates[i.first] = i.second;

				filesystem_root_type.fields[name] = JSerial::Array(JSerial::Struct(file_descriptor_type_name));
			}
			filesystem_root_type.fields["root_folder"] = JSerial::Struct(fmt::format("FileDescriptor<{}>", Folder::Internal::folder_type_name));

			target_set.struct_templates["FilesystemStruct"] = filesystem_root_type;
		}
	}

	namespace File {
		struct Data {
			std::string name;
			FileType::Handle type = FileType::NULL_FILETYPE;
			void* data = nullptr;
			Folder::Handle parent_folder = Folder::NULL_FOLDER;
			//Timestamp
		};
		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}

		bool IsValid(Handle handle) 
			{ return Internal::manager.DoesExists(handle); }

		namespace Advanced {
			Data& GetData(Handle handle) {
				assert(IsValid(handle));
				return Internal::manager[handle];
			}
		}
		std::string GetName(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].name;
		}
		FileType::Handle GetType(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].type;
		}
		Folder::Handle GetParentFolder(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].parent_folder;
		}

		std::string Rename(const std::string& new_name, Handle handle) {
			assert(IsValid(handle));
			auto& file_dat = Internal::manager[handle];
			Folder::Handle parent_folder = file_dat.parent_folder;
			assert(IsValid(parent_folder)); //You cannot rename a file if its a root folder

			auto& parent_folder_dat = Folder::Internal::GetFolderData(Internal::manager[parent_folder].data);
			parent_folder_dat.cached_names.erase(file_dat.name);
			parent_folder_dat.revision++;

			//Resolve naming conflicts
			std::string name = new_name;
			for (int n_tries = 1; parent_folder_dat.cached_names.contains(name); n_tries++) 
				name = fmt::format("{} ({})", new_name, n_tries);

			file_dat.name = name;
			parent_folder_dat.cached_names.insert(name);
			return name;
		}
		void Move(Folder::Handle to, Handle handle) {
			assert(IsValid(to));
			assert(Internal::manager[to].type == Folder::FOLDER_TYPE_PRESET); //Must be a folder
			assert(IsValid(handle));
			auto& file_dat = Internal::manager[handle];
			Folder::Handle parent_folder = file_dat.parent_folder;
			assert(IsValid(parent_folder)); //You cannot move a file if it is a root folder

			auto& parent_folder_dat = Folder::Internal::GetFolderData(Internal::manager[parent_folder].data);
			parent_folder_dat.cached_names.erase(file_dat.name);
			parent_folder_dat.files.erase(handle);
			parent_folder_dat.revision++;
			auto& target_folder_dat = Folder::Internal::GetFolderData(Internal::manager[to].data);

			//Resolve naming conflicts
			std::string name = file_dat.name;
			for (int n_tries = 1; target_folder_dat.cached_names.contains(name); n_tries++)
				name = fmt::format("{} ({})", file_dat.name, n_tries);

			file_dat.name = name;
			file_dat.parent_folder = to;
			target_folder_dat.cached_names.insert(name);
			target_folder_dat.files.insert(handle);
			target_folder_dat.revision++;
		}
		void TryMove(Folder::Handle to, Handle handle) {
			if (IsValid(handle))
				Move(to, handle);
		}

		namespace Internal {
			Handle MakeRaw(const std::string& name, Folder::Handle target_folder, FileType::Handle type) {
				assert(FileType::IsValid(type));
				assert(IsValid(target_folder));
				assert(Internal::manager[target_folder].type == Folder::FOLDER_TYPE_PRESET); //Must be a folder
				auto& target_folder_dat = Folder::Internal::GetFolderData(Internal::manager[target_folder].data);

				//Resolve naming conflicts
				std::string save_name = name;
				for (int n_tries = 1; target_folder_dat.cached_names.contains(save_name); n_tries++)
					save_name = fmt::format("{} ({})", name, n_tries);

				Handle handle = Internal::manager.Add(Data{ .name = save_name, .type = type, .parent_folder = target_folder });
				target_folder_dat.files.insert(handle);
				target_folder_dat.cached_names.insert(save_name);
				target_folder_dat.revision++;

				return handle;
			}
		}

		Handle Make(const std::string& name, Folder::Handle target_folder, FileType::Handle type, void* additional_data) {
			Handle handle = Internal::MakeRaw(name, target_folder, type);
			FileType::CallMake(type, handle, additional_data);

			return handle;
		}
		Handle Copy(Folder::Handle to, Handle handle) {
			Handle new_file = Internal::MakeRaw(GetName(handle), to, GetType(handle));
			FileType::CallCopy(GetType(handle), new_file, handle);

			return new_file;
		}
		Handle TryCopy(Folder::Handle to, Handle handle) {
			if (IsValid(handle))
				return Copy(to, handle);
			return NULL_FILE;
		}
		void Delete(Handle handle) {
			if (IsValid(handle)) {
				auto& file_dat = Internal::manager[handle];
				Folder::Handle parent_folder = file_dat.parent_folder;

				FileType::CallDelete(file_dat.type, handle);
				if (IsValid(parent_folder)) { //You cannot rename a file if its a root folder
					auto& parent_folder_dat = Folder::Internal::GetFolderData(Internal::manager[parent_folder].data);
					parent_folder_dat.cached_names.erase(file_dat.name);
					parent_folder_dat.files.erase(handle);
					parent_folder_dat.revision++;
				}
				Internal::manager.Remove(handle);
			}
		}
	}
	namespace Folder {
		namespace Internal {
			namespace Func {
				void Make(File::Handle handle, void*) {
					auto& file_dat = File::Advanced::GetData(handle);
					file_dat.data = new Data{};
				}
				void Copy(File::Handle to, File::Handle from) {
					auto& src_dat = File::Advanced::GetData(from);
					Data& src_folder_dat = Internal::GetFolderData(src_dat.data);

					auto& targ_dat = File::Advanced::GetData(to);
					assert(targ_dat.data == nullptr);
					Data& targ_folder_dat = *(Data*)(targ_dat.data = new Data{});// Internal::GetFolderData(src_dat.data);

					for (auto& i : src_folder_dat.files) {
						auto& child_file_dat = File::Advanced::GetData(i);

						File::Handle new_file = File::Internal::manager.Add(File::Data{ .name = child_file_dat.name, .type = child_file_dat.type, .parent_folder = to });
						targ_folder_dat.files.insert(new_file);
						targ_folder_dat.cached_names.insert(child_file_dat.name);

						FileType::CallCopy(child_file_dat.type, new_file, i);
					}
				}
				void Delete(File::Handle handle) {
					auto& file_dat = File::Advanced::GetData(handle);
					Data& folder_dat = Internal::GetFolderData(file_dat.data);

					for (auto& i : folder_dat.files) {
						auto& child_file_dat = File::Advanced::GetData(i);
						FileType::CallDelete(child_file_dat.type, i);
						File::Internal::manager.Remove(i);
					}
					delete (Data*)file_dat.data;
				}

				bool CreateFolderModal(Handle to);

				const FileType::Thumbnail folder_thumbnail = { .texture = FOLDER_ICON.handle() };
				const FileType::Thumbnail& GetFolderThumbnail(File::Handle) {
					return folder_thumbnail;
				}
				LLJGFX::Texture::Handle GetFolderTypeIcon(File::Handle) {
					return FOLDER_TYPE_ICON.handle();
				}

				std::unordered_map<std::string, std::vector<JSerial::SerializedStruct>> serialized_files;

				JSerial::SerializedStruct SerializeFolder(Folder::Handle folder, const JSerial::CompiledTemplateSet& templ, const std::string& internal_struct_name) {
					std::vector<JSerial::SerializedStruct> folder_serialized_files;

					auto& files = (*(Data*)File::Advanced::GetData(folder).data).files;
					for (const auto& i : files) {
						folder_serialized_files.push_back(JSerial::SerializeStruct("File", templ, 
							JSerial::Field{ "filename", File::GetName(i) }, 
							JSerial::Field{ "type", FileType::GetName(File::GetType(i)) }, 
							JSerial::Field{ "file_id", FilesystemSerialization::SerializeFileHandle(i, templ) }
						));
						if (FileType::GetData(File::GetType(i)).SerializeFile != nullptr) {
							const auto& filetype_name = FileType::GetName(File::GetType(i));
							const std::string file_descriptor_type_name = fmt::format("FileDescriptor<{}>", filetype_name);

							const std::string filetype_data_name = fmt::format("FileData<{}>", filetype_name);
							serialized_files[filetype_name].push_back(JSerial::SerializeStruct(file_descriptor_type_name, templ, 
								JSerial::Field{ "file_id", FilesystemSerialization::SerializeFileHandle(i, templ) }, 
								JSerial::Field{ "file_data", FileType::CallSerializeFile(File::GetType(i), i, templ, filetype_data_name) }
							));
						}
					}

					return JSerial::SerializeStruct(internal_struct_name, templ, JSerial::Field{ "files", folder_serialized_files });
				}
				void DeserializeFolder(File::Handle raw_file, const JSerial::Document& src, const JSerial::ParsedStruct& file_struct) {
					using namespace FilesystemSerialization::Internal::Deserialization;

					auto& file_dat = File::Advanced::GetData(raw_file);
					if (file_dat.data == nullptr)
						file_dat.data = new Data{};

					auto raw_files = JSerial::Deserialize<std::vector<JSerial::ParsedStruct>>(file_struct, src, "files");

					for (auto& i : raw_files) {
						const std::string filename = JSerial::Deserialize<std::string>(i, src, "filename");
						const auto filetype = filetype_linking_table[JSerial::Deserialize<std::string>(i, src, "type")];

						FilesystemSerialization::Internal::Deserialization::filetype_linking_table;
						auto serialized_file_id = FilesystemSerialization::DeserializeFileHandle(JSerial::Deserialize<JSerial::ParsedStruct>(i, src, "file_id"), src);
						bool was_serialized_already = deserialized_files.contains(serialized_file_id);

						File::Handle real_handle = was_serialized_already ? deserialized_files[serialized_file_id] : real_file_linking_table[serialized_file_id];
						File::Move(raw_file, real_handle);
						File::Rename(filename, real_handle);

						if (!was_serialized_already) {
							FileType::CallDeserialize(File::GetType(real_handle), real_handle, src, file_sources[serialized_file_id]);
							deserialized_files[serialized_file_id] = real_handle;
						}
					}
				}
				
				const FileType::Handle tmp_folder_type = (FOLDER_TYPE_PRESET = FileType::Make({.Make = Internal::Func::Make, .Copy = Internal::Func::Copy, .Delete = Internal::Func::Delete, .GetTypeIconTexture = GetFolderTypeIcon, .GetFileThumbnailTexture = GetFolderThumbnail, .SerializeFile = SerializeFolder, .name = folder_type_name, .DeserializeFile = DeserializeFolder }));
			}
		}

		bool IsFolder(Handle handle) 
			{ return File::GetType(handle) == FOLDER_TYPE_PRESET; }
		bool IsRootFolder(Handle handle) { 
			assert(IsFolder(handle));
			return File::Advanced::GetData(handle).parent_folder == NULL_FOLDER; 
		}

		Handle Make(const std::string& name, Handle parent_folder) 
			{ return File::Make(name, parent_folder, FOLDER_TYPE_PRESET, nullptr); }
		Handle MakeRootFolder() {
			Handle handle = File::Internal::manager.Add({ .name = "Корневая папка", .type = FOLDER_TYPE_PRESET});
			FileType::CallMake(FOLDER_TYPE_PRESET, handle, nullptr);
			return handle;
		}

		const std::unordered_set<File::Handle>& ListFiles(Handle handle) { 
			assert(File::IsValid(handle));
			assert(IsFolder(handle));
			return (*(Data*)File::Advanced::GetData(handle).data).files; 
		}
		const std::unordered_set<std::string>& ListFileNames(Handle handle) { 
			assert(File::IsValid(handle));
			assert(IsFolder(handle));
			return (*(Data*)File::Advanced::GetData(handle).data).cached_names; 
		}
		int GetRevision(Handle handle) {
			assert(File::IsValid(handle));
			assert(IsFolder(handle));
			return (*(Data*)File::Advanced::GetData(handle).data).revision;
		}

		namespace Internal {
			bool CreateFolderModal(Handle to) {
				static std::string buff = "";

				bool state = false;
				if (state = Modals::Rename(buff, "Без имени", "Создать папку"))
					Folder::Make(buff, to);
				return state;
			}

			bool InitializeFolderFiletype() {
				((FileType::Data&)FileType::GetData(FOLDER_TYPE_PRESET)).CreateFileModal = CreateFolderModal;
				FilesystemSerialization::IntegrateSerialisationTemplate(FOLDER_TYPE_PRESET, FilesystemSerialization::Internal::folder_serialization_template, {});

				return true;
			}
			bool dummy = InitializeFolderFiletype();
		}
	}
	namespace FilesystemSerialization {
		JSerial::SerializedStruct SerializeFileSystem(Folder::Handle root_folder, const JSerial::CompiledTemplateSet& templ) {
			JSerial::ManuallySerializableStruct filesystem_struct = JSerial::InitializeManuallySerializableStruct("FilesystemStruct", templ);

			JSerial::SerializeField(filesystem_struct, templ, "root_folder", JSerial::SerializeStruct(fmt::format("FileDescriptor<{}>", Folder::Internal::folder_type_name), templ,
				JSerial::Field{"file_id", FilesystemSerialization::SerializeFileHandle(root_folder, templ)}, 
				JSerial::Field{"file_data", FileType::CallSerializeFile(Folder::FOLDER_TYPE_PRESET, root_folder, templ, fmt::format("FileData<{}>", Folder::Internal::folder_type_name))}
			));

			for (auto& [type, dummy] : Internal::type_templates)
				JSerial::SerializeField(filesystem_struct, templ, FileType::GetName(type), Folder::Internal::Func::serialized_files[FileType::GetName(type)]);
			//Internal::type_templates.clear();

			return JSerial::SerializeStruct(templ, filesystem_struct);
		}

		void DeserializeAllFilesOfType(FileType::Handle type, const JSerial::Document& src) {
			using namespace Internal::Deserialization;

			for (auto& i : file_sources) {
				const auto real_handle = real_file_linking_table[i.first];
				if (File::GetType(real_handle) == type && !deserialized_files.contains(i.first)) {
					FileType::CallDeserialize(File::GetType(real_handle), real_handle, src, file_sources[i.first]);
					deserialized_files[i.first] = real_handle;
				}
			}
		}

		Folder::Handle DeserializeFilesystem(const JSerial::ParsedStruct& from, const JSerial::Document& src) {
			using namespace Internal::Deserialization;
			const auto root_folder_struct = JSerial::Deserialize<JSerial::ParsedStruct>(from, src, "root_folder");

			for (const auto& i : Internal::type_templates)
				filetype_linking_table[FileType::GetName(i.first)] = i.first;

			Folder::Handle temporary_linking_folder = Folder::MakeRootFolder();

			for (const auto& c_filetype : filetype_linking_table) {
				auto file_list = JSerial::Deserialize<std::vector<JSerial::ParsedStruct>>(from, src, c_filetype.first);
				for (const auto& c_file : file_list) {
					auto c_file_id = DeserializeFileHandle(JSerial::Deserialize<JSerial::ParsedStruct>(c_file, src, "file_id"), src);

					file_sources[c_file_id] = JSerial::Deserialize<JSerial::ParsedStruct>(c_file, src, "file_data");
					real_file_linking_table[c_file_id] = File::Internal::MakeRaw(fmt::format("file_{}", (void*)c_file_id.data), temporary_linking_folder, c_filetype.second);
				}
			}

			Folder::Handle new_root = Folder::MakeRootFolder();
			auto root_folder_data = JSerial::Deserialize<JSerial::ParsedStruct>(from, src, "root_folder");

			//Deserialize the root folder
			auto root_folder_serialized_handle = DeserializeFileHandle(JSerial::Deserialize<JSerial::ParsedStruct>(root_folder_data, src, "file_id"), src);
			real_file_linking_table[root_folder_serialized_handle] = new_root;
			FileType::CallDeserialize(Folder::FOLDER_TYPE_PRESET, new_root, src, JSerial::Deserialize<JSerial::ParsedStruct>(root_folder_data, src, "file_data"));

			real_file_linking_table.clear();
			deserialized_files.clear();
			filetype_linking_table.clear();
			file_sources.clear();

			return new_root;
			//deserialized_files[serialized_file_id] = real_handle;
		}
	}
}