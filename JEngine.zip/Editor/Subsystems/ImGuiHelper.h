#pragma once
#include <JGFX/JGFX.h>
#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "imgui_internal.h"
#include "imgui_stdlib.h"


namespace Internal{
	ImGuiIO* default_io = nullptr;
}
namespace GuiHelper {
	void Init(const JGFX::Window& win) {
		ImGui::CreateContext();
		Internal::default_io = &ImGui::GetIO();
		Internal::default_io->ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
		Internal::default_io->ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;
		Internal::default_io->ConfigFlags |= ImGuiConfigFlags_DockingEnable;

		Internal::default_io->ConfigWindowsMoveFromTitleBarOnly = true;
		Internal::default_io->IniFilename = nullptr;

		ImGui::StyleColorsDark();
		ImGui_ImplOpenGL3_Init("#version 330");
		ImGui_ImplGlfw_InitForOpenGL(win.handle().data->win, true);
	}

	void StartFrame() {
		ImGui_ImplOpenGL3_NewFrame();
		ImGui_ImplGlfw_NewFrame();
		ImGui::NewFrame();
	}

	void EndFrame() {
		ImGui::Render();
		ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
	}

	void InstallFont(const std::string& font, float size = 20) {
		void* data = malloc(font.size());
		memcpy(data, font.c_str(), font.size());

		Internal::default_io->Fonts->AddFontFromMemoryTTF(data, static_cast<int>(font.size()), size,
			nullptr, Internal::default_io->Fonts->GetGlyphRangesCyrillic());
	}

	void InstallFontFromFile(const std::string& path, float size = 20) {
		Internal::default_io->Fonts->AddFontFromFileTTF(path.c_str(), size, nullptr,
			Internal::default_io->Fonts->GetGlyphRangesCyrillic());
	}
}
namespace Gui{
	bool IsHoveredPreTest(ImVec2 size, const char* pretest_name_id) {
		ImGuiWindow* window = ImGui::GetCurrentWindow();
		if (window->SkipItems)
			return false;

		const ImGuiID id = window->GetID(pretest_name_id);
		const ImRect bb = { window->DC.CursorPos, window->DC.CursorPos + size };
		return ImGui::ItemHoverable(bb, id, 0);
	}
	//Its based on the code inside of ImGui
	void PaddedImage(JGFX::Internal::TxtFnArg txt, pos2du16 txt_size, ImVec2 ui_size, const ImVec2& uv0 = {0,0}, const ImVec2& uv1 = { 1,1 }, ImVec4 tint_color = {1,1,1,1}) {
		ImGuiWindow* window = ImGui::GetCurrentWindow();
		if (window->SkipItems)
			return;

		const ImVec2 ui_txt_size = txt_size.x > txt_size.y ?
			ImVec2{ (fl32)ui_size.x, ((fl32)ui_size.x / (fl32)txt_size.x) * (fl32)txt_size.y }
		: ImVec2{ ((fl32)ui_size.y / (fl32)txt_size.y) * (fl32)txt_size.x, (fl32)ui_size.y };
		const ImVec2 padding = (ui_size - ui_txt_size) / 2.f;

		const ImRect bb = { window->DC.CursorPos, window->DC.CursorPos + ui_size };
		ImGui::ItemSize(bb);
		if (!ImGui::ItemAdd(bb, 0))
			return;
		window->DrawList->AddImage((ImTextureID)(LLJGFX::Texture::IsValid(txt) ? txt.data->texture_gpu_handle : 0), bb.Min + padding, bb.Max - padding, uv0, uv1, ImGui::GetColorU32(tint_color));
	}
	inline void PaddedImage(JGFX::Internal::TxtFnArg txt, ImVec2 ui_size, ImVec2 uv1 = { 0,0 }, ImVec2 uv2 = { 1,1 }, ImVec4 tint_color = { 1,1,1,1 }) {
		PaddedImage(txt, LLJGFX::Texture::IsValid(txt) ? LLJGFX::Texture::GetSize(txt) : pos2du16{ 0 }, ui_size, uv1, uv2, tint_color);
	}

	//Below is just an edited code of ImGui::ImageButton()
	bool PaddedImageButton(const char* str_id, JGFX::Internal::TxtFnArg texture, pos2du16 texture_size, const ImVec2 ui_size, const ImVec2& uv0, const ImVec2& uv1, const ImVec4& bg_col, const ImVec4& tint_col) {
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;
		if (window->SkipItems)
			return false;

		const ImGuiID id = window->GetID(str_id);


		const ImVec2 ui_txt_size = texture_size.x > texture_size.y ?
			ImVec2{ ui_size.x, (ui_size.x / (fl32)texture_size.x) * (fl32)texture_size.y }
		: ImVec2{ (ui_size.y / (fl32)texture_size.y) * (fl32)texture_size.x, ui_size.y };
		const ImVec2 txt_padding = (ui_size - ui_txt_size) / 2.f;

		const ImVec2 padding = g.Style.FramePadding + txt_padding;
		const ImRect bb(window->DC.CursorPos, window->DC.CursorPos + ui_txt_size + padding * 2.0f);
		ImGui::ItemSize(bb);
		if (!ImGui::ItemAdd(bb, id))
			return false;

		bool hovered, held;
		bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, 0);

		// Render
		const ImU32 col = ImGui::GetColorU32((held && hovered) ? ImGuiCol_ButtonActive : hovered ? ImGuiCol_ButtonHovered : ImGuiCol_Button);
		ImGui::RenderNavHighlight(bb, id);
		ImGui::RenderFrame(bb.Min, bb.Max, col, true, ImClamp((float)ImMin(padding.x, padding.y), 0.0f, g.Style.FrameRounding));
		if (bg_col.w > 0.0f)
			window->DrawList->AddRectFilled(bb.Min + padding, bb.Max - padding, ImGui::GetColorU32(bg_col));
		window->DrawList->AddImage((ImTextureID)(LLJGFX::Texture::IsValid(texture) ? texture.data->texture_gpu_handle : 0), bb.Min + padding, bb.Max - padding, uv0, uv1, ImGui::GetColorU32(tint_col));

		return pressed;
	}
	bool PaddedImageButton(const char* str_id, JGFX::Internal::TxtFnArg texture, const ImVec2& ui_size, const ImVec2& uv0, const ImVec2& uv1, const ImVec4& bg_col, const ImVec4& tint_col) {
		return PaddedImageButton(str_id, texture, LLJGFX::Texture::IsValid(texture) ? LLJGFX::Texture::GetSize(texture) : pos2du16{1}, ui_size, uv0, uv1, bg_col, tint_col);
	}

	bool FileButton(fl32 width, const std::string& title, JGFX::Internal::TxtFnArg thumbnail, JGFX::Internal::TxtFnArg filetype_icon, bool selected, bool select_on_click, ImVec2 th_uv0 = {0,0}, ImVec2 th_uv1 = {1,1}, ImVec4 th_tint = ImVec4{1,1,1,1}) {
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;
		if (window->SkipItems)
			return false;

		const ImGuiID id = window->GetID(title.c_str());

		const float inner_width = width - g.Style.FramePadding.x * 2;
		const ImVec2 text_size = ImGui::CalcTextSize(title.c_str(), nullptr, false, inner_width);
		const ImVec2 size = { width, g.Style.FramePadding.y * 2 + inner_width + text_size.y };

		const ImRect bb(window->DC.CursorPos, window->DC.CursorPos + size);
		ImGui::ItemSize(bb);
		if (!ImGui::ItemAdd(bb, id))
			return false;

		bool hovered, held;
		bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, select_on_click ? ImGuiButtonFlags_PressedOnClick : 0);

		if (hovered || selected) {
			const ImU32 col = ImGui::GetColorU32((held && hovered) ? ImGuiCol_HeaderActive : hovered ? ImGuiCol_HeaderHovered : ImGuiCol_Header);
			ImGui::RenderFrame(bb.Min, bb.Max, col, false, 0.0f);
		}
		ImGui::RenderNavHighlight(bb, id);

		//Thumbnail
		const auto txt_size = LLJGFX::Texture::GetSize(thumbnail);
		const ImVec2 ui_txt_size = txt_size.x > txt_size.y ?
			ImVec2{ inner_width, (inner_width / (fl32)txt_size.x) * (fl32)txt_size.y }
		  : ImVec2{ (inner_width / (fl32)txt_size.y) * (fl32)txt_size.x, inner_width };
		const ImVec2 txt_padding = (ImVec2{inner_width, inner_width} - ui_txt_size) / 2.f + g.Style.FramePadding;
		window->DrawList->AddImage((ImTextureID)(LLJGFX::Texture::IsValid(thumbnail) ? thumbnail.data->texture_gpu_handle : 0), bb.Min + txt_padding, bb.Min + txt_padding + ui_txt_size, th_uv0, th_uv1, ImGui::GetColorU32(th_tint));

		//Filetype icon
		const ImVec2 filetype_icon_size = { 20, 20 };
		const ImVec2 icon_pos = { bb.Max.x - filetype_icon_size.x, bb.Min.y };
		window->DrawList->AddImage((ImTextureID)(LLJGFX::Texture::IsValid(filetype_icon) ? filetype_icon.data->texture_gpu_handle : 0), icon_pos, icon_pos + filetype_icon_size, {0,0}, {1,1}, ImGui::GetColorU32(ImVec4{1,1,1,1}));

		//Text
		ImVec2 text_pos = { bb.Min.x + g.Style.FramePadding.x, bb.Min.y + g.Style.FramePadding.y + inner_width };
		ImGui::RenderTextWrapped(text_pos, title.c_str(), &title.back() + 1, inner_width);

		return pressed;
	}

	bool ImageDoubleTextSelectable(ImGuiID id, const std::string& title, const std::string& bottom_text, JGFX::Internal::TxtFnArg texture, pos2du16 txt_size, const ImVec2& uv0 = { 0,0 }, const ImVec2& uv1 = { 1,1 }, const ImVec4& tint_col = {1,1,1,1}, bool is_selected = false, ImGuiSelectableFlags flags = 0, float height = 50) {
		ImGuiWindow* window = ImGui::GetCurrentWindow();
		if (window->SkipItems)
			return false;

		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;
		// Submit label or explicit size to ItemSize(), whereas ItemAdd() will submit a larger/spanning rectangle.
		const char* label = title.c_str();
		//ImGuiID id = window->GetID(label);
		ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);
		ImVec2 size(label_size.x, height);
		ImVec2 pos = window->DC.CursorPos;
		pos.y += window->DC.CurrLineTextBaseOffset;
		ImGui::ItemSize(size, 0.0f);

		// Fill horizontal space
		// We don't support (size < 0.0f) in Selectable() because the ItemSpacing extension would make explicitly right-aligned sizes not visibly match other widgets.
		const bool span_all_columns = (flags & ImGuiSelectableFlags_SpanAllColumns) != 0;
		const float min_x = span_all_columns ? window->ParentWorkRect.Min.x : pos.x;
		const float max_x = span_all_columns ? window->ParentWorkRect.Max.x : window->WorkRect.Max.x;

		size.x = ImMax(label_size.x, max_x - min_x);

		
		// Text stays at the submission position, but bounding box may be extended on both sides
		//const ImVec2 text_min = pos + ImVec2{ style.FramePadding.x + inner_width + style.ItemInnerSpacing.x, 0 };
		//const ImVec2 text_max(min_x + size.x, pos.y + size.y);

		// Selectables are meant to be tightly packed together with no click-gap, so we extend their box to cover spacing between selectable.
		ImRect bb(min_x, pos.y, min_x + size.x, pos.y + height);
		if ((flags & ImGuiSelectableFlags_NoPadWithHalfSpacing) == 0)
		{
			const float spacing_x = span_all_columns ? 0.0f : style.ItemSpacing.x;
			const float spacing_y = style.ItemSpacing.y;
			const float spacing_L = IM_TRUNC(spacing_x * 0.50f);
			const float spacing_U = IM_TRUNC(spacing_y * 0.50f);
			bb.Min.x -= spacing_L;
			bb.Min.y -= spacing_U;
			bb.Max.x += (spacing_x - spacing_L);
			bb.Max.y += (spacing_y - spacing_U);
		}
		//if (g.IO.KeyCtrl) { GetForegroundDrawList()->AddRect(bb.Min, bb.Max, IM_COL32(0, 255, 0, 255)); }

		// Modify ClipRect for the ItemAdd(), faster than doing a PushColumnsBackground/PushTableBackgroundChannel for every Selectable..
		const float backup_clip_rect_min_x = window->ClipRect.Min.x;
		const float backup_clip_rect_max_x = window->ClipRect.Max.x;
		if (span_all_columns)
		{
			window->ClipRect.Min.x = window->ParentWorkRect.Min.x;
			window->ClipRect.Max.x = window->ParentWorkRect.Max.x;
		}

		const bool disabled_item = (flags & ImGuiSelectableFlags_Disabled) != 0;
		const bool item_add = ImGui::ItemAdd(bb, id, NULL, disabled_item ? ImGuiItemFlags_Disabled : ImGuiItemFlags_None);
		if (span_all_columns)
		{
			window->ClipRect.Min.x = backup_clip_rect_min_x;
			window->ClipRect.Max.x = backup_clip_rect_max_x;
		}

		if (!item_add)
			return false;

		const bool disabled_global = (g.CurrentItemFlags & ImGuiItemFlags_Disabled) != 0;
		if (disabled_item && !disabled_global) // Only testing this as an optimization
			ImGui::BeginDisabled();

		// FIXME: We can standardize the behavior of those two, we could also keep the fast path of override ClipRect + full push on render only,
		// which would be advantageous since most selectable are not selected.
		if (span_all_columns)
		{
			if (g.CurrentTable)
				ImGui::TablePushBackgroundChannel();
			else if (window->DC.CurrentColumns)
				ImGui::PushColumnsBackground();
			g.LastItemData.StatusFlags |= ImGuiItemStatusFlags_HasClipRect;
			g.LastItemData.ClipRect = window->ClipRect;
		}

		// We use NoHoldingActiveID on menus so user can click and _hold_ on a menu then drag to browse child entries
		ImGuiButtonFlags button_flags = 0;
		if (flags & ImGuiSelectableFlags_NoHoldingActiveID) { button_flags |= ImGuiButtonFlags_NoHoldingActiveId; }
		if (flags & ImGuiSelectableFlags_NoSetKeyOwner) { button_flags |= ImGuiButtonFlags_NoSetKeyOwner; }
		if (flags & ImGuiSelectableFlags_SelectOnClick) { button_flags |= ImGuiButtonFlags_PressedOnClick; }
		if (flags & ImGuiSelectableFlags_SelectOnRelease) { button_flags |= ImGuiButtonFlags_PressedOnRelease; }
		if (flags & ImGuiSelectableFlags_AllowDoubleClick) { button_flags |= ImGuiButtonFlags_PressedOnClickRelease | ImGuiButtonFlags_PressedOnDoubleClick; }
		if ((flags & ImGuiSelectableFlags_AllowOverlap) || (g.LastItemData.InFlags & ImGuiItemFlags_AllowOverlap)) { button_flags |= ImGuiButtonFlags_AllowOverlap; }

		const bool was_selected = is_selected;
		bool hovered, held;
		bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, button_flags);

		// Auto-select when moved into
		// - This will be more fully fleshed in the range-select branch
		// - This is not exposed as it won't nicely work with some user side handling of shift/control
		// - We cannot do 'if (g.NavJustMovedToId != id) { selected = false; pressed = was_selected; }' for two reasons
		//   - (1) it would require focus scope to be set, need exposing PushFocusScope() or equivalent (e.g. BeginSelection() calling PushFocusScope())
		//   - (2) usage will fail with clipped items
		//   The multi-select API aim to fix those issues, e.g. may be replaced with a BeginSelection() API.
		if ((flags & ImGuiSelectableFlags_SelectOnNav) && g.NavJustMovedToId != 0 && g.NavJustMovedToFocusScopeId == g.CurrentFocusScopeId)
			if (g.NavJustMovedToId == id)
				is_selected = pressed = true;

		// Update NavId when clicking or when Hovering (this doesn't happen on most widgets), so navigation can be resumed with gamepad/keyboard
		if (pressed || (hovered && (flags & ImGuiSelectableFlags_SetNavIdOnHover))) {
			if (!g.NavDisableMouseHover && g.NavWindow == window && g.NavLayer == window->DC.NavLayerCurrent) {
				ImGui::SetNavID(id, window->DC.NavLayerCurrent, g.CurrentFocusScopeId, ImGui::WindowRectAbsToRel(window, bb)); // (bb == NavRect)
				g.NavDisableHighlight = true;
			}
		}
		if (pressed)
			ImGui::MarkItemEdited(id);

		// In this branch, Selectable() cannot toggle the selection so this will never trigger.
		if (is_selected != was_selected) //-V547
			g.LastItemData.StatusFlags |= ImGuiItemStatusFlags_ToggledSelection;

		// Render
		if (hovered || is_selected) {
			const ImU32 col = ImGui::GetColorU32((held && hovered) ? ImGuiCol_HeaderActive : hovered ? ImGuiCol_HeaderHovered : ImGuiCol_Header);
			ImGui::RenderFrame(bb.Min, bb.Max, col, false, 0.0f);
		}
		if (g.NavId == id)
			ImGui::RenderNavHighlight(bb, id, ImGuiNavHighlightFlags_Compact | ImGuiNavHighlightFlags_NoRounding);

		if (span_all_columns) {
			if (g.CurrentTable)
				ImGui::TablePopBackgroundChannel();
			else if (window->DC.CurrentColumns)
				ImGui::PopColumnsBackground();
		}

		//Image
		const float inner_width = height - style.FramePadding.y * 2.f;
		{
			const ImVec2 ui_txt_size = txt_size.x > txt_size.y ?
				ImVec2{ inner_width, (inner_width / (fl32)txt_size.x) * (fl32)txt_size.y }
			: ImVec2{ (inner_width / (fl32)txt_size.y) * (fl32)txt_size.x, inner_width };
			const ImVec2 txt_padding = (ImVec2{ inner_width, inner_width } - ui_txt_size) / 2.f;

			const ImVec2 image_pos = pos + style.FramePadding + txt_padding;
			window->DrawList->AddImage((ImTextureID)(LLJGFX::Texture::IsValid(texture) ? texture.data->texture_gpu_handle : 0), image_pos, image_pos + ui_txt_size, uv0, uv1, ImGui::GetColorU32(tint_col));
		}

		//Top text
		{
			const ImVec2 text_pos = pos + ImVec2(inner_width + style.ItemInnerSpacing.x + style.FramePadding.x, 0);
			ImGui::RenderTextClipped(text_pos, text_pos + label_size, label, NULL, &label_size, style.SelectableTextAlign, &bb);
		}
		//Bottom text
		{
			const ImVec2 text_pos = pos + ImVec2(inner_width + style.ItemInnerSpacing.x + style.FramePadding.x, height - label_size.y - style.FramePadding.y);
			ImGui::RenderTextClipped(text_pos, text_pos + label_size, bottom_text.c_str(), NULL, &label_size, style.SelectableTextAlign, &bb);
		}

		// Automatically close popups
		if (pressed && (window->Flags & ImGuiWindowFlags_Popup) && !(flags & ImGuiSelectableFlags_DontClosePopups) && !(g.LastItemData.InFlags & ImGuiItemFlags_SelectableDontClosePopup))
			ImGui::CloseCurrentPopup();

		if (disabled_item && !disabled_global)
			ImGui::EndDisabled();

		//IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags);
		return pressed; //-V1020
	}
	bool ImageDoubleTextSelectable(const std::string& title, const std::string& bottom_text, JGFX::Internal::TxtFnArg texture, pos2du16 txt_size, const ImVec2& uv0 = { 0,0 }, const ImVec2& uv1 = { 1,1 }, const ImVec4& tint_col = { 1,1,1,1 }, bool is_selected = false, ImGuiSelectableFlags flags = 0, float height = 50) {
		return ImageDoubleTextSelectable(ImGui::GetID(title.c_str()), title, bottom_text, texture, txt_size, uv0, uv1, tint_col, is_selected, flags, height);
	}

    pos2d32 GetMousePosInsideWidget(pos2d32 global_mouse_pos, ImVec2 element_cursor_pos) {
		
		pos2d32 mspos = { global_mouse_pos.x - (ImGui::GetWindowPos().x + element_cursor_pos.x),
						global_mouse_pos.y - (ImGui::GetWindowPos().y + element_cursor_pos.y) };
        return mspos;
    }
	pos2d32 GetMousePosInsideWidget(ImVec2 element_cursor_pos) {
		return GetMousePosInsideWidget({ Internal::default_io->MousePos.x, Internal::default_io->MousePos.y }, element_cursor_pos);
	}

    inline pos2d32 GetWindowInternalSize() {
        return { static_cast<int>(ImGui::GetWindowContentRegionMax().x - ImGui::GetWindowContentRegionMin().x),
                 static_cast<int>(ImGui::GetWindowContentRegionMax().y - ImGui::GetWindowContentRegionMin().y) };
    }

    inline pos2d32 GetWindowAvailableSpace() {
        return { static_cast<int>(ImGui::GetContentRegionAvail().x),
                 static_cast<int>(ImGui::GetContentRegionAvail().y) };
    }

    inline void DisplayFB(JGFX::Internal::TxtFnArg handle, pos2d32 element_size){
		ImGui::Image((ImTextureID)(size_t)(handle.data->texture_gpu_handle), ImVec2(element_size.x, element_size.y),
			ImVec2(0, 1), ImVec2(1, 0));
    }
    /*
    class fb_widget {
    public:
        FramebufferObject *fb;
        pos2d winsize, mspos, old_winsize;
        bool is_hovered;

        void start(pos2d mouse_pos) {
            old_winsize = winsize;
            winsize = { int(ImGui::GetContentRegionAvail().x), int(ImGui::GetContentRegionAvail().y) };
            //mspos = { -1, -1 };
            mspos = get_mouse_pos_inside_widget(mouse_pos, winsize);
        }

        void end() {
            ImGui::Image(ImTextureID(fb->texture_id), ImVec2(winsize.x, winsize.y), ImVec2(0, 1), ImVec2(1, 0)); //ãëàâíîå îêíî
            is_hovered = ImGui::IsItemHovered();
        }
    };*/
}
