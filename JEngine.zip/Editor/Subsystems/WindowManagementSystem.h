#pragma once
#include <cassert>
#include <JupiterUtils.h>
#include <JGFX/JGFX.h>

//TODO later
namespace Editor {
	namespace Window {
		struct Data;
		typedef JE::MHandle<Data> Handle;
		const Handle NULL_WINDOW = { nullptr };
	}

	namespace WindowTemplate {
		struct Data {
			void(*Open)(Window::Handle raw_window, void* data);
			bool(*Update)(Window::Handle window); //Returns if the window was active in the current frame
			void(*Close)(Window::Handle window);

			std::string(*GetName)(Window::Handle window);
		};

		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}
		typedef JE::MHandle<Data> Handle;
		const Handle NULL_WIN_TMPL = { nullptr };

		inline bool IsValid(Handle handle)
			{ return Internal::manager.DoesExists(handle); }

		inline Data& GetData(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle];
		}
		void CallOpen(Handle handle, Window::Handle raw_window, void* data) {
			assert(IsValid(handle));
			Internal::manager[handle].Open(raw_window, data);
		}
		bool CallUpdate(Handle handle, Window::Handle window) {
			assert(IsValid(handle));
			return Internal::manager[handle].Update(window);
		}
		void CallClose(Handle handle, Window::Handle window) {
			assert(IsValid(handle));
			Internal::manager[handle].Close(window);
		}
		std::string CallGetName(Handle handle, Window::Handle window) {
			assert(IsValid(handle));
			return Internal::manager[handle].GetName(window);
		}

		inline Handle Make(const Data& dat)
			{ return Internal::manager.Add(dat); }
		inline void Delete(Handle handle) {
			if (IsValid(handle))
				Internal::manager.Remove(handle);
		}
	}
	namespace Window {
		struct Data {
			WindowTemplate::Handle type;
			uint32 last_active_frame = 0;
			void* data = nullptr;
		};

		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}
		inline bool IsValid(Handle handle)
			{ return Internal::manager.DoesExists(handle); }


		inline Data& GetData(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle];
		}
		inline WindowTemplate::Handle GetType(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].type;
		}
		inline std::string GetName(Handle handle) {
			return WindowTemplate::CallGetName(GetType(handle), handle);
		}
		inline uint32 GetLastActiveFrame(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].last_active_frame;
		}


		void Update(Handle handle) {
			assert(IsValid(handle));
			auto& dat = Internal::manager[handle];

			bool was_active = WindowTemplate::CallUpdate(GetType(handle), handle);

			if (IsValid(handle)) { //The "if" here is because the window can be destroyed inside of the update call (and its actually an intended behaviour)
				dat.last_active_frame = was_active ? JGFX::FrameCount() : dat.last_active_frame;
			}
		}

		Handle Open(WindowTemplate::Handle type, void* initialization_data) { 
			Handle handle = Internal::manager.Add({.type = type});
			WindowTemplate::CallOpen(type, handle, initialization_data);
			//Update(handle);
			return handle; 
		}
		inline void Close(Handle handle) {
			if (IsValid(handle)) {
				WindowTemplate::CallClose(GetType(handle), handle);
				Internal::manager.Remove(handle);
			}
		}
	}
	Window::Handle play_window = Window::NULL_WINDOW;
	namespace WindowSystem {
		void UpdateAllWindows() {
			auto all_windows = Window::Internal::manager.raw_data(); //It MUST be copied in order to work properly
			
			for (const auto& i : all_windows) {
				bool is_play_win = i != play_window && Window::IsValid(play_window);
				if(is_play_win)
					ImGui::BeginDisabled();
				Window::Update(i);
				if (is_play_win)
					ImGui::EndDisabled();
			}
		}

		inline const std::unordered_set<Window::Handle>& ListAllWindows() 
			{ return Window::Internal::manager.raw_data(); }

		const std::unordered_set<Window::Handle> GetAllWindowsOfType(WindowTemplate::Handle type) {
			const auto& all_windows = Window::Internal::manager.raw_data();
			std::unordered_set<Window::Handle> res;

			for (const auto& i : all_windows) {
				if (Window::GetType(i) == type)
					res.insert(i);
			}
			return res;
		}
		//List all windows
		Window::Handle GetLastActiveWindowByType(WindowTemplate::Handle type) {
			const auto& all_windows = Window::Internal::manager.raw_data();
			Window::Handle res = Window::NULL_WINDOW;
			uint32 max_f = 0;

			for (const auto& i : all_windows) {
				if (Window::GetLastActiveFrame(i) > max_f && Window::GetType(i) == type) {
					res = i;
					max_f = Window::GetLastActiveFrame(i);
				}
			}
			return res;
		}
	}
}