#pragma once
#include <JGFX/JGFX.h>
#include <string>
#include "Subsystems/FilesystemBase.h"
#include <nfd.h>
#include <filesystem>
#include "EditorGlobals.h"
#include "Subsystems/SerializationEssentials.h"

namespace Editor {
	namespace SceneFile {
		struct Data {
			LLJE::Scene::Handle scene;
			int active_layer = -1;

			//JGFX::Texture prerendered_thumbnail = { std::string((const char*)&LLJE::Scene::Internal::DEFAULT_BACKGROUND_COLOR, 4), {1,1}};
			//Window::Handle viewport_that_was_prerendered = Window::NULL_WINDOW;
			int opened_windows = 0;
			//bool is_being_edited = false;
		};
		namespace Internal {
			
			namespace Func {
				void Make(File::Handle handle, void* dat) {
					auto& file_dat = File::Advanced::GetData(handle);
					file_dat.data = new Data{ *(Data*)dat };
				}
				void Copy(File::Handle to, File::Handle from) {
					auto& src_file_dat = File::Advanced::GetData(from);
					Data& src_dat = *(Data*)src_file_dat.data;

					auto& targ_file_dat = File::Advanced::GetData(to);
					assert(targ_file_dat.data == nullptr);
					Data& targ_dat = *(Data*)(targ_file_dat.data = new Data{});
					targ_dat = src_dat; //Copies most of the regular data
					targ_dat.opened_windows = 0;

					targ_dat.scene = Scene::Make(src_dat.scene);
				}
				void Delete(File::Handle handle) {
					auto& file_dat = File::Advanced::GetData(handle);
					Data& main_dat = *(Data*)file_dat.data;

					LLJE::Scene::Delete(main_dat.scene);

					delete (Data*)file_dat.data;
				}

				FileType::Thumbnail thumb = { .uv0 = ImVec2{0,1}, .uv1 = ImVec2{1,0} };
				const FileType::Thumbnail& GetThumbnail(File::Handle handle) {
					auto& file_dat = File::Advanced::GetData(handle);
					Data& main_dat = *(Data*)file_dat.data;

					Scene::Internal::Data& dat = LLJE::Scene::Advanced::GetAdditionalData<Scene::Internal::Data>(main_dat.scene);
					if (dat.update_frame != JGFX::FrameCount()) {
						LLJE::Render(dat.cam_for_thumbnail_rendering, main_dat.scene);
						dat.update_frame = JGFX::FrameCount();
					}
					win.Bind();

					thumb.texture = dat.cam_for_thumbnail_rendering.frm.handle();

					//main_dat.viewport_to_prerender = Window::NULL_WINDOW;
					return thumb;
				}
				LLJGFX::Texture::Handle GetFileTypeIcon(File::Handle handle) {
					auto& file_dat = File::Advanced::GetData(handle);
					Data& main_dat = *(Data*)file_dat.data;

					if (!main_dat.opened_windows)
						return SCENE_TYPE_ICON.handle();//FOLDER_TYPE_ICON.handle();

					return ACTIVE_SCENE_ICON_ANIM[(int)(JGFX::GetTime() / 0.15) % ACTIVE_SCENE_ICON_ANIM.size()].handle();
				}

				JSerial::StructFieldsTemplate chunk_template = {
					{.name = "location", .type = SerializationEssentials::Pos2d32 },
					{.name = "tiles", .type = JSerial::Array(Tile::Internal::TileHandleType) }
				};
				JSerial::StructFieldsTemplate layer_template = {
					{.name = "chunks", .type = JSerial::Array(JSerial::Struct("Chunk"))},
					{.name = "name", .type = JSerial::String()},
					{.name = "grid_size", .type = SerializationEssentials::Pos2df64},
					{.name = "chunk_size", .type = SerializationEssentials::Pos2du16},
					{.name = "layer_settings", .type = JSerial::Struct("LayerSettings")}
				};
				JSerial::StructFieldsTemplate layer_settings_template = {
					{"parallax_speed", .type = SerializationEssentials::Pos2df64},
					{"offset", .type = SerializationEssentials::Pos2df64},
					{"transparency", .type = JSerial::NumericType(JSerial::TypeEnum::FLOAT32)},
					{"is_visible", .type = JSerial::NumericType(JSerial::TypeEnum::BOOL)}
				};
				JSerial::StructFieldsTemplate main_templ = {
					{.name = "layers", .type = JSerial::Array(JSerial::Struct("Layer"))},
					{.name = "background_color", .type = SerializationEssentials::Rgb}
				};

				JSerial::TemplateSet scene_set = {
					Tile::Internal::set,
					{.name = "Chunk", .fields = chunk_template},
					{.name = "Layer", .fields = layer_template},
					{.name = "LayerSettings", .fields = layer_settings_template}
				};

				JSerial::TemplateSet set = JSerial::MergeSets(scene_set, SerializationEssentials::templ);

				struct TmpDataForChunkSerialization {
					std::vector<JSerial::SerializedStruct>* serialized_chunks = nullptr;
					const JSerial::CompiledTemplateSet* templ = nullptr;
				};

				JSerial::SerializedStruct Serialize(File::Handle file, const JSerial::CompiledTemplateSet& templ, const std::string& internal_struct_name) {
					auto& file_dat = File::Advanced::GetData(file);
					Data& main_dat = *(Data*)file_dat.data;

					std::vector<JSerial::SerializedStruct> serialized_layers;
					const auto& layers = LLJE::Scene::ListLayers(main_dat.scene);

					for (auto& i : layers) {

						const auto& layer_name = Map::GetName(i);
						const auto grid_size = Map::GetGridSize(i);
						const auto chunk_size = Map::GetChunkSize(i);

						std::vector<JSerial::SerializedStruct> serialized_chunks;
						TmpDataForChunkSerialization tmp = { .templ = &templ, .serialized_chunks = &serialized_chunks };

						LLJE::ChunkMap::ExecuteForAllChunks(i, 
							[](LLJE::Layer::Handle map, pos2d32 pos, void* dest) { 
								TmpDataForChunkSerialization& dat = *(TmpDataForChunkSerialization*)dest; 
								const auto chunk_size = Map::GetChunkSize(map);

								std::vector<JSerial::SerializedStruct> serialized_tiles;
								serialized_tiles.reserve(chunk_size.x * chunk_size.y);
								

								auto tile_data = LLJE::ChunkMap::GetChunk<Map::Internal::ChunkData>(map, pos).tiles;
								for (int i = 0; i < chunk_size.x * chunk_size.y; i++)
									serialized_tiles.push_back(Tile::Internal::SerializeTileHandle(tile_data[i], *dat.templ));

								dat.serialized_chunks->push_back(JSerial::SerializeStruct("Chunk", *dat.templ,
									JSerial::Field{ "location", SerializationEssentials::SerializePos2d32(pos, *dat.templ) },
									JSerial::Field{ "tiles", serialized_tiles }
								));
							}, &tmp);

						const auto src_settings = LLJE::Layer::GetEditableLayerSettings(i);
						JSerial::SerializedStruct layer_settings = JSerial::SerializeStruct("LayerSettings", templ, 
							JSerial::Field{"parallax_speed", SerializationEssentials::SerializePos2df64(src_settings.parallax_speed, templ)},
							JSerial::Field{ "transparency", src_settings.transparency },
							JSerial::Field{ "is_visible", src_settings.is_visible },
							JSerial::Field{ "offset", SerializationEssentials::SerializePos2df64(src_settings.pos, templ) }
						);

						serialized_layers.push_back(JSerial::SerializeStruct("Layer", templ,
							JSerial::Field{ "chunks", serialized_chunks },
							JSerial::Field{ "name", layer_name },
							JSerial::Field{ "grid_size", SerializationEssentials::SerializePos2df64(grid_size, templ) },
							JSerial::Field{ "chunk_size", SerializationEssentials::SerializePos2du16(chunk_size, templ) },
							JSerial::Field{ "layer_settings", layer_settings }
						));
					}

					return JSerial::SerializeStruct(internal_struct_name, templ,
						JSerial::Field{ "layers", serialized_layers },
						JSerial::Field{ "background_color", SerializationEssentials::SerializeRgb({ LLJE::Scene::GetBackgroundColor(main_dat.scene)}, templ) }
					);
				}
				void Deserialize(File::Handle raw_file, const JSerial::Document& src, const JSerial::ParsedStruct& file_struct) {
					auto& file_dat = File::Advanced::GetData(raw_file);
					auto& data = *(Data*)(file_dat.data = new Data{});

					FilesystemSerialization::DeserializeAllFilesOfType(Tileset::FILETYPE_TYPE_PRESET, src);

					data.scene = Scene::Make(SerializationEssentials::DeserializeRgb(JSerial::Deserialize<JSerial::ParsedStruct>(file_struct, src, "background_color"), src));

					auto layers = JSerial::Deserialize<std::vector<JSerial::ParsedStruct>>(file_struct, src, "layers");
					for (auto& c_layer : layers) {
						const pos2du16 chunk_size = SerializationEssentials::DeserializePos2du16(JSerial::Deserialize<JSerial::ParsedStruct>(c_layer, src, "chunk_size"), src);

						JSerial::ParsedStruct parsed_settings = JSerial::Deserialize<JSerial::ParsedStruct>(c_layer, src, "layer_settings");
						LLJE::Layer::LayerSettings deserialized_settings = { 
							.parallax_speed = SerializationEssentials::DeserializePos2df64(JSerial::Deserialize<JSerial::ParsedStruct>(parsed_settings, src, "parallax_speed"), src),
							.transparency = JSerial::Deserialize<fl32>(parsed_settings, src, "transparency"),
							.is_visible = JSerial::Deserialize<bool>(parsed_settings, src, "is_visible"),
							.pos = src.templates.types[parsed_settings.struct_template_id].ids.contains("offset") ? SerializationEssentials::DeserializePos2df64(JSerial::Deserialize<JSerial::ParsedStruct>(parsed_settings, src, "offset"), src) : pos2df64{0,0}
						};

						auto layer_handle = Map::MakeLayer(data.scene, LLJE::Layer::BACK, 0,
							JSerial::Deserialize<std::string>(c_layer, src, "name"),
							SerializationEssentials::DeserializePos2df64(JSerial::Deserialize<JSerial::ParsedStruct>(c_layer, src, "grid_size"), src),
							chunk_size,
							deserialized_settings
						);

						//Chunks
						auto chunks = JSerial::Deserialize<std::vector<JSerial::ParsedStruct>>(c_layer, src, "chunks");
						for (auto& c_chunk : chunks) {
							const pos2d32 chunk_pos = SerializationEssentials::DeserializePos2d32(JSerial::Deserialize<JSerial::ParsedStruct>(c_chunk, src, "location"), src);
							Map::Functions::MakeChunk(LLJE::ChunkMap::MakeEmptyChunk(layer_handle, chunk_pos), Map::GetChunkSize(layer_handle), chunk_pos, Map::GetGridSize(layer_handle));
							auto& c_chunk_data = LLJE::ChunkMap::GetChunk<Map::Internal::ChunkData>(layer_handle, chunk_pos);

							std::vector<JSerial::ParsedStruct> tiles = JSerial::Deserialize<std::vector<JSerial::ParsedStruct>>(c_chunk, src, "tiles");

							for (int c_tile_id = 0; c_tile_id < chunk_size.x * chunk_size.y; c_tile_id++) {
								const auto c_tile = Tile::Internal::DeserializeTileHandle(tiles[c_tile_id], src);
								c_chunk_data.tiles[c_tile_id] = c_tile == Tile::NULL_TILE ? Tile::NULL_TILE : Tileset::Internal::tile_linking_table[c_tile];
							}
							c_chunk_data.cache_ver--;
						}
					}
				}
			}
		}
		const FileType::Handle FILETYPE_TYPE_PRESET = FileType::Make({ .Make = Internal::Func::Make, .Copy = Internal::Func::Copy, .Delete = Internal::Func::Delete, .GetFileThumbnailTexture = Internal::Func::GetThumbnail, .GetTypeIconTexture = Internal::Func::GetFileTypeIcon, .name = "Сцена", .SerializeFile = Internal::Func::Serialize, .DeserializeFile = Internal::Func::Deserialize });

		typedef File::Handle Handle;
		const Handle NULL_FILE = File::NULL_FILE;

		bool IsScene(File::Handle handle)
			{ return File::GetType(handle) == FILETYPE_TYPE_PRESET; }

		Handle Make(rgb background_color, const ::std::string& name, Handle parent_folder) {
			Data dat;
			dat.scene = Scene::Make(background_color);

			//TODO: this is just for testing
			Map::MakeLayer(dat.scene);
			dat.active_layer = 0;

			return File::Make(name, parent_folder, FILETYPE_TYPE_PRESET, &dat);
		}

		Data& GetData(Handle handle) {
			assert(File::IsValid(handle));
			assert(IsScene(handle));
			return *(Data*)File::Advanced::GetData(handle).data;
		}
		Scene::Handle GetScene(Handle handle) {
			assert(File::IsValid(handle));
			assert(IsScene(handle));
			return (*(Data*)File::Advanced::GetData(handle).data).scene;
		}

		namespace Internal {
			bool CreateFileModal(Folder::Handle save_to) {
				static std::string buff = "";

				bool state = false;
				if (state = Modals::Rename(buff, "Без имени", "Создать сцену"))
					SceneFile::Make(rgb{0, 50, 170}, buff, save_to);

				return state;
			}
			bool InitFileType() {
				FilesystemSerialization::IntegrateSerialisationTemplate(FILETYPE_TYPE_PRESET, Func::main_templ, Func::set);
				((FileType::Data&)FileType::GetData(FILETYPE_TYPE_PRESET)).CreateFileModal = CreateFileModal;
				editor_filesystem_data_types.push_back({ "Сцену", FILETYPE_TYPE_PRESET });
				return false;
			}
			bool init_dummy = InitFileType();
		}
	}
}