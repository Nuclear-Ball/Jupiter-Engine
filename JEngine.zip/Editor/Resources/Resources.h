#pragma once
#include <JGFX/JGFX.h>
#include "../../Engine/Utility/TextureProcessing.h"

namespace Editor {
#ifdef NDEBUG
	const std::string default_resource_path = "Res/";
#else
	const std::string default_resource_path = "../../Editor/Resources/";
#endif
	//const std::string default_resource_path = "../../Editor/Resources/";
	const JGFX::Texture UP_ARROW_TEXTURE = { default_resource_path + "UpArrow.png" };
	const JGFX::Texture PLAY_ICON = { default_resource_path + "PlayIcon.png" };
	const JGFX::Texture PAUSE_ICON = { default_resource_path + "PauseIcon.png" };

	const JGFX::Texture FOLDER_ICON = { default_resource_path + "FolderIcon.png" };
	const JGFX::Texture FOLDER_TYPE_ICON = { "\0\0\0\0", {1,1} };
	const JGFX::Texture TEXTURE_TYPE_ICON = { default_resource_path + "TextureTypeIcon.png" };
	const JGFX::Texture TILESET_TYPE_ICON = { default_resource_path + "TilesetTypeIcon.png" };
	const JGFX::Texture SCENE_TYPE_ICON = { default_resource_path + "SceneTypeIcon.png" };

	const JGFX::Texture ACTIVE_ICON_ANIMATION_ATLAS = { default_resource_path + "ActiveSceneIcon.png" };
	const std::vector<JGFX::Texture> ACTIVE_SCENE_ICON_ANIM = TextureProcessing::CropAndLoad(ACTIVE_ICON_ANIMATION_ATLAS, TextureProcessing::GenerateCroplist(ACTIVE_ICON_ANIMATION_ATLAS.size(), 8, { 8,8 }));
	//const JGFX::Texture TEXTURE_ICON = { "" };
}