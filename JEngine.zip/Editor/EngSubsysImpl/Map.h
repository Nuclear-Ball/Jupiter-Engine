#pragma once
#include "../../Engine/Engine.h"
#include "../Subsystems/FilesystemBase.h"
#include "../EditorGlobals.h"
#include "../TextureFileType.h"

#include "../../PSN_Game/Map.h"
#include "../../PSN_Game/Player.h"
#include "../Subsystems/SerializationEssentials.h"
//#include "../../PSN_Game/Map.h"

namespace Editor{
namespace Tileset {
	typedef File::Handle Handle;
	const Handle NULL_TSET = File::NULL_FILE;
}
namespace Tile {
	struct Data;
	typedef JE::MHandle<Data> Handle;
	const Handle NULL_TILE = { nullptr };

	namespace Internal {
		Handle CopyData(Handle from, Tileset::Handle where_to_put);
		void DeleteData(Handle handle);

		JSerial::InitializationStructTemplate set = { .name = "TileHandle", .fields = { {.name = "Id", .type = JSerial::NumericType(JSerial::TypeEnum::INT64)}} };

		JSerial::GenericType TileHandleType = JSerial::Struct("TileHandle");
		JSerial::SerializedStruct SerializeTileHandle(Handle data, const JSerial::CompiledTemplateSet& templ) 
			{ return JSerial::SerializeStruct("TileHandle", templ, JSerial::Field{"Id", (uint64)data.data}); }
		Tile::Handle DeserializeTileHandle(const JSerial::ParsedStruct& serialized_handle, const JSerial::Document& src) 
			{ return { (decltype(Tile::Handle::data))JSerial::Deserialize<uint64>(serialized_handle, src, "Id") }; }
	}
}
namespace Tileset {
	struct Data {
		::std::vector<Tile::Handle> tiles;
		LLJGFX::Texture::Handle tset_thumbnail_framebuffer;
	};
	namespace Internal {
		namespace Func {
			void Make(File::Handle handle, void*) {
				auto& file_dat = File::Advanced::GetData(handle);
				file_dat.data = new Data{};
			}
			void Copy(File::Handle to, File::Handle from) {
				auto& src_file_dat = File::Advanced::GetData(from);
				Data& src_dat = *(Data*)src_file_dat.data;

				auto& targ_file_dat = File::Advanced::GetData(to);
				assert(targ_file_dat.data == nullptr);
				Data& targ_dat = *(Data*)(targ_file_dat.data = new Data{});

				for (const auto& i : src_dat.tiles) 
					targ_dat.tiles.push_back(Tile::Internal::CopyData(i, to));
				targ_dat.tset_thumbnail_framebuffer = LLJGFX::Texture::Make(LLJGFX::Texture::GetData(src_dat.tset_thumbnail_framebuffer), LLJGFX::Texture::GetSize(src_dat.tset_thumbnail_framebuffer));
			}
			void Delete(File::Handle handle) {
				auto& file_dat = File::Advanced::GetData(handle);
				Data& main_dat = *(Data*)file_dat.data;

				for (const auto& i : main_dat.tiles)
					Tile::Internal::DeleteData(i);
				LLJGFX::Texture::Delete(main_dat.tset_thumbnail_framebuffer);

				delete (Data*)file_dat.data;
			}

			FileType::Thumbnail thumb_template = {};
			const FileType::Thumbnail& GetThumbnail(File::Handle handle) {
				thumb_template.texture = (*(Data*)File::Advanced::GetData(handle).data).tset_thumbnail_framebuffer;
				return thumb_template;
			}
			LLJGFX::Texture::Handle GetFileTypeIcon(File::Handle) {
				return TILESET_TYPE_ICON.handle();//FOLDER_TYPE_ICON.handle();
			}
		}
	}
	const FileType::Handle FILETYPE_TYPE_PRESET = FileType::Make({ .Make = Internal::Func::Make, .Copy = Internal::Func::Copy, .Delete = Internal::Func::Delete, .GetFileThumbnailTexture = Internal::Func::GetThumbnail, .GetTypeIconTexture = Internal::Func::GetFileTypeIcon });

	bool IsTileset(File::Handle handle)
		{ return File::GetType(handle) == FILETYPE_TYPE_PRESET; }

	Handle Make(const ::std::string& name, Handle parent_folder)
		{ return File::Make(name, parent_folder, FILETYPE_TYPE_PRESET, nullptr); }

	const Data& GetData(Handle handle) {
		assert(File::IsValid(handle));
		assert(IsTileset(handle));
		return *(Data*)File::Advanced::GetData(handle).data;
	}

	void SwapTiles(Handle handle, int id1, int id2) {
		assert(File::IsValid(handle));
		assert(IsTileset(handle));

		auto& dat = *(Data*)File::Advanced::GetData(handle).data;
		std::swap(dat.tiles[id1], dat.tiles[id2]);
	}

	namespace Internal {
		void RemoveTileFromList(Tile::Handle tile, Handle handle) {
			auto& dat = *(Data*)File::Advanced::GetData(handle).data;
			for (int i = 0; i < dat.tiles.size(); i++) {
				if (dat.tiles[i] == tile) {
					dat.tiles.erase(dat.tiles.begin() + i);
					return;
				}
			}
		}

		bool CreateFileModal(Folder::Handle save_to) {
			static std::string buff = "";

			bool state = false;
			if (state = Modals::Rename(buff, "Без имени", "Создать тайлсет"))
				Tileset::Make(buff, save_to);

			return state;
			//TODO: make file creation modal
		}
	}
	}
	namespace Tile {
		struct Data {
			Texture::Handle texture = Texture::NULL_TEXTURE;
			std::vector<JE::ChainShape> colission_mesh;
			Tileset::Handle parent_tset = Tileset::NULL_TSET;
		};

		namespace Internal {
			JE::AnonymousManager<Data> manager;
		}
		bool IsValid(Handle handle) { return Internal::manager.DoesExists(handle); }

		const Data& GetData(Handle handle) { 
			assert(IsValid(handle));
			return Internal::manager[handle]; 
		}
		std::vector<JE::ChainShape>& GetCollisionMesh(Handle handle) { //These functions make sure its possible to edit the data, but not to desync tset reference
			assert(IsValid(handle));
			return Internal::manager[handle].colission_mesh;
		}
		Texture::Handle& GetTexture(Handle handle) {
			assert(IsValid(handle));
			return Internal::manager[handle].texture;
		}

		void MoveToTileset(Handle handle, Tileset::Handle to) {
			assert(IsValid(handle));
			assert(File::IsValid(to));
			assert(Tileset::IsTileset(to));

			auto& dat = Internal::manager[handle];
			Tileset::Internal::RemoveTileFromList(handle, dat.parent_tset);
			dat.parent_tset = to;

			Tileset::Data& tset_dat = *(Tileset::Data*)File::Advanced::GetData(to).data;
			tset_dat.tiles.push_back(handle);
		}

		inline Handle Make(Texture::Handle texture, const std::vector<JE::ChainShape>& collision_mesh, Tileset::Handle parent_tset) { 
			Handle handle = Internal::manager.Add(Data{.texture = texture, .colission_mesh = collision_mesh, .parent_tset = parent_tset});

			Tileset::Data& tset_dat = *(Tileset::Data*)File::Advanced::GetData(parent_tset).data;
			tset_dat.tiles.push_back(handle);

			return handle;
		}
		
		void Delete(Handle handle) {
			if (IsValid(handle)) {
				auto& dat = Internal::manager[handle];

				assert(dat.parent_tset != Tileset::NULL_TSET); //Tile shouldnt exist without a tileset
				Tileset::Internal::RemoveTileFromList(handle, dat.parent_tset);

				Internal::manager.Remove(handle);
			}
		}

		namespace Internal {
			Handle CopyData(Handle from, Tileset::Handle where_to_put) {
				auto& dat = Internal::manager[from];
				return Internal::manager.Add({ .texture = dat.texture, .colission_mesh = dat.colission_mesh, .parent_tset = where_to_put });
			}
			void DeleteData(Handle handle) {
				Internal::manager.Remove(handle);
			}

			std::unordered_map<Handle, PsnGame::Tile::Handle> tile_conversion_table;
			void DropConversionTable() {
				for (auto& i : tile_conversion_table)
					PsnGame::Tile::Delete(i.second);

				tile_conversion_table.clear();
			}
		}
	}
	namespace Tileset {
		namespace Internal {
			JSerial::StructFieldsTemplate templ = {
				{.name = "tiles", .type = JSerial::Array(JSerial::Struct("Tile"))}
			};
			JSerial::TemplateSet set = {
				FilesystemSerialization::file_handle_template,
				{
					.name = "Tile",
					.fields = {
						{.name = "texture", .type = FilesystemSerialization::file_handle},
						{.name = "collision_mesh", .type = JSerial::Array(JSerial::Struct("TileCollisionMesh"))},
						{.name = "id", .type = Tile::Internal::TileHandleType}
					}
				},
				{
					.name = "TileCollisionMesh",
					.fields = {
						{.name = "points", .type = JSerial::Array(SerializationEssentials::Pos2df32)}
					}
				}
			};

			JSerial::SerializedStruct Serialize(File::Handle file, const JSerial::CompiledTemplateSet& templ, const std::string& internal_struct_name) {
				const auto file_dat = (*(Data*)File::Advanced::GetData(file).data);

				std::vector<JSerial::SerializedStruct> serialized_tiles;
				for (auto& i : file_dat.tiles) {
					auto& tile_data = Tile::GetData(i);

					std::vector<JSerial::SerializedStruct> mesh_segments;
					for (auto& c_segment : tile_data.colission_mesh) {
						std::vector<JSerial::SerializedStruct> mesh_points;
						for(auto& c_point : c_segment.points)
							mesh_points.push_back(SerializationEssentials::SerializePos2df32(c_point, templ));
						mesh_segments.push_back(JSerial::SerializeStruct("TileCollisionMesh", templ, JSerial::Field{ "points", mesh_points }));
					}
					serialized_tiles.push_back(JSerial::SerializeStruct("Tile", templ,
						JSerial::Field{ "texture", FilesystemSerialization::SerializeFileHandle(tile_data.texture, templ) },
						JSerial::Field{ "collision_mesh", mesh_segments },
						JSerial::Field{ "id", Tile::Internal::SerializeTileHandle(i, templ) }
					));
				}

				return JSerial::SerializeStruct(internal_struct_name, templ, JSerial::Field{ "tiles", serialized_tiles });
			}

			std::unordered_map<Tile::Handle, Tile::Handle> tile_linking_table;

			void Deserialize(File::Handle raw_file, const JSerial::Document& src, const JSerial::ParsedStruct& file_struct) {
				auto& file_dat = File::Advanced::GetData(raw_file);
				file_dat.data = new Data{};

				std::vector<JSerial::ParsedStruct> serialized_tiles = JSerial::Deserialize<std::vector<JSerial::ParsedStruct>>(file_struct, src, "tiles");
				for (auto& c_tile_src : serialized_tiles) {
					std::vector<JE::ChainShape> collision_mesh;
					std::vector<JSerial::ParsedStruct> src_collision_mesh = JSerial::Deserialize<std::vector<JSerial::ParsedStruct>>(c_tile_src, src, "collision_mesh");
					for (auto& c_segm : src_collision_mesh) {
						decltype(JE::ChainShape::points) deserialized_points;
						std::vector<JSerial::ParsedStruct> src_points = JSerial::Deserialize<std::vector<JSerial::ParsedStruct>>(c_segm, src, "points");
						for (auto& c_point : src_points)
							deserialized_points.push_back(SerializationEssentials::DeserializePos2df32(c_point, src));

						collision_mesh.push_back({ .points = deserialized_points, .is_loop = true });
					}
					auto src_texture_handle = FilesystemSerialization::DeserializeFileHandle(JSerial::Deserialize<JSerial::ParsedStruct>(c_tile_src, src, "texture"), src);
					auto tile_handle = Tile::Make(FilesystemSerialization::Internal::Deserialization::real_file_linking_table[src_texture_handle], collision_mesh, raw_file);
					tile_linking_table[Tile::Internal::DeserializeTileHandle(JSerial::Deserialize<JSerial::ParsedStruct>(c_tile_src, src, "id"), src)] = tile_handle;
				}
			}

			bool InitFileType() {
				editor_filesystem_data_types.push_back({ "Тайлсет", FILETYPE_TYPE_PRESET });
				auto& dat = ((FileType::Data&)FileType::GetData(FILETYPE_TYPE_PRESET));
				dat.CreateFileModal = CreateFileModal;
				dat.SerializeFile = Serialize;
				dat.DeserializeFile = Deserialize;

				FilesystemSerialization::IntegrateSerialisationTemplate(FILETYPE_TYPE_PRESET, templ, set);

				return false;
			}
			bool init_dummy = InitFileType();
		}
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	namespace Scene {
	namespace Internal {
		struct Data {
			J2D::Cam2D cam_for_thumbnail_rendering = { {256, 256} };
			int update_frame = 0;
		};
		LLJE::ScenePreset::Handle compare_handle = LLJE::ScenePreset::NULL_PRESET;
	}

	typedef LLJE::Scene::Handle Handle;
	const Handle NULL_SCENE = { nullptr };

	inline bool IsTypeValid(Handle handle) {
		assert(LLJE::Scene::IsValid(handle));
		return LLJE::Scene::Advanced::GetPreset(handle) == Internal::compare_handle;
	}
	}

	namespace Map {
		namespace Internal {
			LLJE::LayerPreset::Handle compare_handle = LLJE::LayerPreset::NULL_PRESET;
		}
	}
	namespace Map {
	enum class Type {
		BACKGROUND,
		FOREGROUND
	};

	namespace Internal {
		struct DTM_RandomAhhPlaceholderJustForTypeSafety {};

		struct TmapData {
			pos2df64 grid_size;
			pos2du16 tiles_in_chunk;

			J2D::Cam2D cam = { {256,256} };
			int update_frame = 0;

			std::string name = "Без имени";
			Type layer_type = Type::FOREGROUND;
			int curr_global_version = 0; //When changing the grid size
		};

		struct IrDrawListElement {
			LLJ2D::TransfBuff::Handle transforms = LLJ2D::TransfBuff::NULL_TBUFF;
			Tile::Handle tile = Tile::NULL_TILE;
		};

		struct ChunkData {
			Tile::Handle* tiles;
			
			std::vector<IrDrawListElement> draw_list;
			int cache_ver = 0;
		};
	}

	typedef LLJE::Layer::Handle Handle;
	const Handle NULL_TMAP = { nullptr };
		
	inline bool IsTypeValid(LLJE::Layer::Handle handle) {
		assert(LLJE::Layer::IsValid(handle));
		return LLJE::Layer::Advanced::GetPreset(handle) == Internal::compare_handle;
	}
	inline bool IsValid(Handle handle)
		{ return LLJE::Layer::IsValid(handle); }

	void SetGridSize(Handle handle, pos2df64 size) {
		assert(IsValid(handle));
		assert(IsTypeValid(handle));

		auto& tmap_data = *(Internal::TmapData*)LLJE::Layer::Advanced::GetAdditionalData(handle);

		LLJE::ChunkMap::SetChunkSize(handle, size * (pos2df64)tmap_data.tiles_in_chunk);
		tmap_data.grid_size = size;
		tmap_data.curr_global_version++;
	}

	const std::string& GetName(Handle handle) {
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return ((Internal::TmapData*)LLJE::Layer::Advanced::GetAdditionalData(handle))->name;
	}
	void SetName(Handle handle, const std::string& name) {
		assert(IsValid(handle));
		assert(IsTypeValid(handle));

		auto& tmap_data = *(Internal::TmapData*)LLJE::Layer::Advanced::GetAdditionalData(handle);
		tmap_data.name = name;
	}

	pos2df64 GetGridSize(Handle handle) { 
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return ((Internal::TmapData*)LLJE::Layer::Advanced::GetAdditionalData(handle))->grid_size; 
	}
	pos2du16 GetChunkSize(Handle handle) { 
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return ((Internal::TmapData*)LLJE::Layer::Advanced::GetAdditionalData(handle))->tiles_in_chunk; 
	}
	
	const Internal::TmapData& GetData(Handle handle) {
		assert(IsValid(handle));
		assert(IsTypeValid(handle));
		return *(Internal::TmapData*)LLJE::Layer::Advanced::GetAdditionalData(handle);
	}

	namespace Functions {
		void MakeChunk(LLJE::ChunkMap::ChunkData& dat, ::pos2du16 chunk_size, pos2d32 chunk_pos, pos2df64 grid_size) {
			dat.data = new Internal::ChunkData{};
			Internal::ChunkData& c_chunk = *(Internal::ChunkData*)dat.data;

			c_chunk.tiles = (Tile::Handle*)malloc(sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
			memset(c_chunk.tiles, 0, sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
		}
		void DeleteChunk(LLJE::Layer::Handle map, pos2d32 pos, void* = nullptr) {
			LLJE::ChunkMap::ChunkData& c_raw_chunk = LLJE::ChunkMap::GetChunk(map, pos);
			Internal::ChunkData& c_chunk = *(Internal::ChunkData*)c_raw_chunk.data;
			free(c_chunk.tiles);

			for (auto& i : c_chunk.draw_list)
				LLJ2D::TransfBuff::Delete(i.transforms);

			delete (Internal::ChunkData*)c_raw_chunk.data;
		}

		std::vector<LLJE::Renderer::LLDrawListData> ConvertIrDrawList(const std::vector<Internal::IrDrawListElement>& ir_cache) {
			std::vector<LLJE::Renderer::LLDrawListData> res;
			res.reserve(ir_cache.size());

			for (const auto& i : ir_cache) {
				if (Tile::IsValid(i.tile)) {
					const auto& tile_dat = Tile::GetData(i.tile);

					res.push_back({ i.transforms, Texture::GetTexture(tile_dat.texture), J2D::TransfProps{}.MakeMatrix(LLJGFX::Texture::GetSize(Texture::GetTexture(tile_dat.texture))) });
				}
			}

			return res;
		}
		std::vector<LLJE::Renderer::LLDrawListData> ChunkCacher(LLJE::Layer::Handle map, pos2d32 pos) {
			if (!LLJE::ChunkMap::DoesChunkExists(map, pos))
				return {};

			Internal::TmapData& c_map = LLJE::Layer::Advanced::GetAdditionalDataC<Internal::TmapData>(map);
			Internal::ChunkData& c_chunk = *(Internal::ChunkData*)LLJE::ChunkMap::GetChunk(map, pos).data;
			if (c_chunk.cache_ver == c_map.curr_global_version) {
				const auto& tmp = ConvertIrDrawList(c_chunk.draw_list);
				return tmp;
			}

			//cache chunk
			const pos2du16 chunk_size = GetChunkSize(map);
			const pos2df32 grid_size = GetGridSize(map);

			std::unordered_map<Tile::Handle, std::vector<glm::mat4>> tmp_cache;

			for (int y = 0; y < chunk_size.y; y++) {
				for (int x = 0; x < chunk_size.x; x++) {
					const Tile::Handle c_tile_handle = c_chunk.tiles[chunk_size.x * y + x];
					if (!Tile::IsValid(c_tile_handle))
						continue;
					tmp_cache[c_tile_handle].push_back(glm::translate(glm::mat4(1), { x * grid_size.x, y * grid_size.y, 0.f }));
				}
			}

			for (const auto& i : c_chunk.draw_list)
				LLJ2D::TransfBuff::Delete(i.transforms);
			c_chunk.draw_list.clear();
			c_chunk.draw_list.reserve(tmp_cache.size());

			for (const auto& i : tmp_cache) {
				if (i.first != Tile::NULL_TILE) {
					LLJGFX::Texture::Handle c_txt = Texture::GetTexture(Tile::GetData(i.first).texture);
					c_chunk.draw_list.push_back({ .transforms = LLJ2D::TransfBuff::Make(i.second, {}), .tile = i.first });
				}
			}
			c_chunk.cache_ver = c_map.curr_global_version;

			return ConvertIrDrawList(c_chunk.draw_list);
		}

		void Initialize(LLJE::Layer::Handle handle, void* data) {
			//const InitData& dat = *(InitData*)data;
			auto& dat = *(Internal::TmapData*)data;
			LLJE::Layer::Advanced::SetAdditionalData(handle, new Internal::TmapData{ dat });
			LLJE::ChunkMap::SetChunkSize(handle, dat.grid_size * (pos2df64)dat.tiles_in_chunk);
		}
		void Destroy(LLJE::Layer::Handle handle) {
			LLJE::ChunkMap::ExecuteForAllChunks(handle, DeleteChunk);
			delete (Internal::TmapData*)LLJE::Layer::Advanced::GetAdditionalData(handle);
		}
		/*
		void ChmapCopier(Chunkmap::Handle to, Chunkmap::Handle from) {
			Handle to_tmap = FromChmap(to);
			Handle from_tmap = FromChmap(from);

			Chunkmap::ExecuteForAllChunks(to, Functions::DeleteChunk);
			Chunkmap::Clear(to);

			SetGridSize(FromChmap(to), GetGridSize(FromChmap(from)));

			Internal::TmapData* tmap_data = (Internal::TmapData*)Chunkmap::GetAdditionalData(to);
			if (tmap_data == nullptr) {
				tmap_data = new Internal::TmapData;
				Chunkmap::SetAdditionalData(to, tmap_data);
			}

			((Internal::TmapData*)Chunkmap::GetAdditionalData(to))->tiles_in_chunk = GetChunkSize(FromChmap(from));

			Chunkmap::ExecuteForAllChunks(from,
				[](Chunkmap::Handle map, pos2d32 pos, void* to_map) -> void {
					const Chunkmap::Handle to = { (Chunkmap::Internal::ChunkmapData*)to_map };
					const Internal::ChunkData& from_chunk = *(Internal::ChunkData*)LLJE::Chunkmap::GetChunk(map, pos).data;

					auto& to_chunk = *(Internal::ChunkData*)Chunkmap::MakeChunk(to, pos).data;

					const pos2du16 chunk_size = GetChunkSize(FromChmap(map));
					to_chunk.tiles = (Tile::Handle*)malloc(sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
					memcpy(to_chunk.tiles, from_chunk.tiles, sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
				},
				to.data);
		}*/
	}
	const LLJE::LayerPreset::Handle preset = Internal::compare_handle = LLJE::LayerPreset::Make(Functions::ChunkCacher, Functions::Initialize, Functions::Destroy);// , Functions::ChmapCopier);

	LLJGFX::Texture::Handle GetThumbnail(Handle handle) {
		auto& layer_data = (Map::Internal::TmapData&)Map::GetData(handle);
		auto& regular_layer_data = LLJE::Layer::GetEditableLayerSettings(handle);

		auto& scene_dat = LLJE::Scene::Advanced::GetAdditionalData<Scene::Internal::Data>(LLJE::Layer::GetParentScene(handle));
		if (layer_data.update_frame != JGFX::FrameCount()) {
			bool was_visible = regular_layer_data.is_visible;
			regular_layer_data.is_visible = true;

			layer_data.cam.center_pos = scene_dat.cam_for_thumbnail_rendering.center_pos;
			layer_data.cam.props = scene_dat.cam_for_thumbnail_rendering.props;
			//Render layer
			LLJE::DrawLayer(layer_data.cam, handle);

			regular_layer_data.is_visible = was_visible;
			win.Bind();
		}
		return layer_data.cam.frm.handle();
	}

	inline void SetTile(Handle handle, Tile::Handle tile, pos2d64 pos){
		assert(IsValid(handle));
		assert(IsTypeValid(handle));

		const pos2du16 chunk_size = GetChunkSize(handle);
		const pos2d32 chunk_pos = LLJE::Convert::ChunkFromTile(pos, chunk_size);
		const pos2du16 local_tile_pos = LLJE::Convert::LocalTileFromGlobalTile(pos, chunk_size);

		if (!LLJE::ChunkMap::DoesChunkExists(handle, chunk_pos))
			Functions::MakeChunk(LLJE::ChunkMap::MakeEmptyChunk(handle, chunk_pos), chunk_size, chunk_pos, GetGridSize(handle));
		Internal::ChunkData& c_chunk = *(Internal::ChunkData*)LLJE::ChunkMap::GetChunk(handle, chunk_pos).data;

		c_chunk.tiles[chunk_size.x * local_tile_pos.y + local_tile_pos.x] = tile;
		c_chunk.cache_ver--;
	}
	inline Tile::Handle GetTile(Handle handle, pos2d64 pos) {
		assert(IsValid(handle));
		assert(IsTypeValid(handle));

		const pos2du16 chunk_size = GetChunkSize(handle);
		const pos2d32 chunk_pos = LLJE::Convert::ChunkFromTile(pos, chunk_size);
		const pos2du16 local_tile_pos = LLJE::Convert::LocalTileFromGlobalTile(pos, chunk_size);

		if (!LLJE::ChunkMap::DoesChunkExists(handle, chunk_pos))
			return Tile::NULL_TILE;
		const Internal::ChunkData& c_chunk = *(Internal::ChunkData*)LLJE::ChunkMap::GetChunk(handle, chunk_pos).data;

		return c_chunk.tiles[chunk_size.x * local_tile_pos.y + local_tile_pos.x];
	}

	inline void Clear(Handle handle) {
		LLJE::ChunkMap::ExecuteForAllChunks(handle, Functions::DeleteChunk);
		LLJE::ChunkMap::Clear(handle);
	}
	/*
	inline void TransferData(Map::Handle to, Handle from) {
		Map::TurnInto(Map::ToLayer(to), GetGridSize(from), GetChunkSize(from));
		LLJE::ChunkMap::ExecuteForAllChunks(ToLayer(from),
			[](LLJE::Layer::Handle src_layer, pos2d32 chunk_pos, void* target_map) {
				const LLJE::Layer::Handle target = *(LLJE::Layer::Handle*)target_map;
				const auto& targ_data = LLJE::Layer::GetEditableLayerData(target);
				const auto& type_specific_data = LLJE::Layer::Advanced::GetAdditionalDataC<Map::Internal::TmapData>(target);

				auto& new_chunk = LLJE::ChunkMap::MakeEmptyChunk(target, chunk_pos);
				Map::Functions::MakeChunk(new_chunk, type_specific_data.tiles_in_chunk, chunk_pos, type_specific_data.grid_size);

				auto& targ_chunk_data = *(Map::Internal::ChunkData*)new_chunk.data;

				auto& src_chunk_data = LLJE::ChunkMap::GetChunk<Internal::ChunkData>(src_layer, chunk_pos);

				memcpy(targ_chunk_data.tiles, src_chunk_data.tiles, sizeof(Tile::Handle) * type_specific_data.tiles_in_chunk.x * type_specific_data.tiles_in_chunk.y);
				targ_chunk_data.cache_ver--;
			},
			&to
		);
	}
	*/
	/*
	inline Map::Handle CreateNewGameMap(Handle handle) {
		const LLJE::Layer::Handle src = ToLayer(handle);
		const auto& src_data = LLJE::Layer::GetEditableLayerData(src);
		LLJE::Layer::Handle new_map = LLJE::Layer::Make(
			src_data.parallax_speed,
			src_data.props,
			src_data.pos,
			src_data.transparency,
			src_data.is_visible,
			src_data.upper_view_range_extension,
			src_data.lower_view_range_extension
		);
		const auto conv = Map::TurnInto(new_map, GetGridSize(handle), GetChunkSize(handle));
		TransferData(conv, handle);
		return conv;
	}
	*/

	inline Handle TurnInto(LLJE::Layer::Handle layer, pos2df64 grid_size = { 1,1 }, pos2du16 chunk_size = { 16,16 }, const std::string& name = "Без имени") {
		Internal::TmapData tmp_dat = { .grid_size = grid_size,.tiles_in_chunk = chunk_size, .name = name};
		LLJE::Layer::Advanced::SetPreset(layer, preset, &tmp_dat); 
		return layer; 
	}

	inline void Copy(LLJE::Layer::Handle to, Handle from) {
		assert(LLJE::Layer::IsValid(to));
		assert(IsValid(from));
		assert(IsTypeValid(from));

		Handle conv_layer = TurnInto(to, GetGridSize(from), GetChunkSize(from));
		LLJE::Layer::SetLayerSettings(to, LLJE::Layer::GetEditableLayerSettings(from));
		//TODO: also copy all of the layer settings data, such as parallax speed, offset, etc
		
		LLJE::ChunkMap::ExecuteForAllChunks(from,
			[](LLJE::Layer::Handle map, pos2d32 pos, void* to_map) -> void {
				const LLJE::Layer::Handle to = { (LLJE::Layer::Internal::Data*)to_map };
				const Internal::ChunkData& from_chunk = *(Internal::ChunkData*)LLJE::ChunkMap::GetChunk(map, pos).data;

				const pos2du16 chunk_size = GetChunkSize(map);
				Functions::MakeChunk(LLJE::ChunkMap::MakeEmptyChunk(to, pos), chunk_size, pos, GetGridSize(map));

				auto& to_chunk = *(Internal::ChunkData*)LLJE::ChunkMap::GetChunk(to, pos).data;
				memcpy(to_chunk.tiles, from_chunk.tiles, sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
				to_chunk.cache_ver--;
			},
		to.data);
	}

	inline LLJE::Layer::Handle MakeLayer(LLJE::Scene::Handle scene, LLJE::Layer::SceneInsertionDirection direction = LLJE::Layer::BACK, int insertion_id = 0, 
							const std::string& name = "Без имени", pos2df64 grid_size = {1,1}, pos2du16 chunk_size = {16,16},
							const LLJE::Layer::LayerSettings& settings = {}) {
		Internal::TmapData tmp_dat = { .grid_size = grid_size, .tiles_in_chunk = chunk_size, .name = name };
		return LLJE::Layer::Make(
			scene,
			direction,
			insertion_id,
			settings,
			preset,
			&tmp_dat
		); 
	}

	inline LLJE::Layer::Handle MakeLayer(Handle from, LLJE::Scene::Handle target_scene, LLJE::Layer::SceneInsertionDirection direction = LLJE::Layer::BACK, int insertion_id = 0) {
		assert(IsValid(from));
		assert(IsTypeValid(from));
		Internal::TmapData tmp_dat = GetData(from);
		LLJE::Layer::Handle handle = LLJE::Layer::Make(target_scene, direction, insertion_id, {}, preset, &tmp_dat);
		Copy(handle, from);
		return handle;
	}

	inline void Delete(Handle handle) 
		{ LLJE::Layer::Delete(handle); }
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	namespace Scene {
	namespace Functions {
		void InitializeSceneData(Scene::Handle raw_scene, void* initialization_data) {
			LLJE::Scene::Advanced::SetAdditionalDataPtr(raw_scene, new Internal::Data{});
		}
		void DeleteSceneData(Scene::Handle scene) {
			delete (Internal::Data*)LLJE::Scene::Advanced::GetAdditionalDataPtr(scene);
		}

		void AddLayer(LLJE::Scene::Handle scene, LLJE::Layer::Handle layer) {
			assert(LLJE::Layer::Advanced::GetPreset(layer) == Map::Internal::compare_handle);
		}
		void LayerPresetChange(Handle scene, LLJE::Layer::Handle layer) {
			assert(LLJE::Layer::Advanced::GetPreset(layer) == Map::Internal::compare_handle);
		}
	}
	const LLJE::ScenePreset::Handle preset = Internal::compare_handle = LLJE::ScenePreset::Make({.AddLayer = Functions::AddLayer, .LayerPresetChange = Functions::LayerPresetChange, .InitializeSceneData = Functions::InitializeSceneData, .DeleteSceneData = Functions::DeleteSceneData });// , Functions::ChmapCopier);

	Internal::Data& GetDataUnsafe(Handle handle) {
		assert(IsTypeValid(handle));
		return LLJE::Scene::Advanced::GetAdditionalData<Internal::Data>(handle);
	}

	inline void TurnInto(Scene::Handle scene) { 
		LLJE::Scene::Advanced::SetPreset(scene, preset, nullptr);
	}

	void Copy(LLJE::Scene::Handle to, Scene::Handle from) {
		assert(IsTypeValid(from));

		LLJE::Scene::ClearLayerList(to);
		TurnInto(to);


		const auto& src_layers = LLJE::Scene::ListLayers(from);
		for (const auto& i : src_layers)
			Map::MakeLayer(i, to);

		/*
		When needed, put here code for copying scene data
		*/

		LLJE::Scene::SetBackgroundColor(to, LLJE::Scene::GetBackgroundColor(from));
	}

	LLJE::Scene::Handle ConvertScene(Handle handle) {
		const auto& src_scene_data = GetDataUnsafe(handle);
		const auto& src_layers = LLJE::Scene::ListLayers(handle);

		PsnGame::Scene::Handle scene = PsnGame::Scene::Make(LLJE::Scene::GetBackgroundColor(handle));

		for (const auto& i : src_layers) {
			auto c_layer = PsnGame::MainGameLayer::MakeLayer(scene, LLJE::Layer::BACK, 0, Map::GetGridSize(i), Map::GetChunkSize(i), LLJE::Layer::GetEditableLayerSettings(i));

			LLJE::ChunkMap::ExecuteForAllChunks(i,
				[](LLJE::Layer::Handle map, pos2d32 pos, void* to_map) -> void {
					const LLJE::Layer::Handle to = *(LLJE::Layer::Handle*)to_map;
					const Map::Internal::ChunkData& from_chunk = *(Map::Internal::ChunkData*)LLJE::ChunkMap::GetChunk(map, pos).data;

					const pos2du16 chunk_size = Map::GetChunkSize(map);

					PsnGame::MainGameLayer::Functions::MakeChunk(to, pos);
					auto& to_chunk = *(PsnGame::MainGameLayer::Internal::ChunkData*)LLJE::ChunkMap::GetChunk(to, pos).data;

					for (int i = 0; i < (chunk_size.x * chunk_size.y); i++) {
						auto c_tile = from_chunk.tiles[i];
						if (Tile::IsValid(c_tile)) {
							if (!Tile::Internal::tile_conversion_table.contains(c_tile))
								Tile::Internal::tile_conversion_table[c_tile] = PsnGame::Tile::Make(Texture::GetTexture(Tile::GetTexture(c_tile)), Tile::GetCollisionMesh(c_tile));
							to_chunk.tiles[i] = Tile::Internal::tile_conversion_table[c_tile];
						}
					}
					//Map::Functions::MakeChunk(LLJE::ChunkMap::MakeEmptyChunk(to, pos), chunk_size, pos, GetGridSize(map));

					//auto& to_chunk = *(Internal::ChunkData*)LLJE::ChunkMap::GetChunk(to, pos).data;
					//memcpy(to_chunk.tiles, from_chunk.tiles, sizeof(Tile::Handle) * chunk_size.x * chunk_size.y);
					to_chunk.cache_ver--;
				},
				&c_layer);
		}
		PsnGame::PlayerObjType::MakePlayer(LLJE::Scene::ListLayers(scene).back(), {0,0});
		return scene;
	}

	inline Handle Make(rgb color = LLJE::Scene::Internal::DEFAULT_BACKGROUND_COLOR) 
		{ return LLJE::Scene::Make(color, preset);  }
	inline Handle Make(Handle from) {
		Handle handle = LLJE::Scene::Make();
		Copy(handle, from);
		return handle;
	}
	} //Namespace Scene
}