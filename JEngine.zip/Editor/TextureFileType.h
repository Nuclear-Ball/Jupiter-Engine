#pragma once
#include <JGFX/JGFX.h>
#include <string>
#include "Subsystems/FilesystemBase.h"
#include <nfd.h>
#include <filesystem>
#include "EditorGlobals.h"

namespace Editor {
	bool dummy_for_nfd = NFD_Init();
	namespace Texture {
		struct Data {
			LLJGFX::Texture::Handle texture;
		};
		namespace Internal {
			namespace Func {
				void Make(File::Handle handle, void* raw_texture_handle) {
					auto& file_dat = File::Advanced::GetData(handle);
					file_dat.data = new Data{ .texture = *(LLJGFX::Texture::Handle*)raw_texture_handle };
				}
				void Copy(File::Handle to, File::Handle from) {
					auto& src_dat = File::Advanced::GetData(from);
					Data& src_texture_dat = *(Data*)src_dat.data;

					auto& targ_dat = File::Advanced::GetData(to);
					assert(targ_dat.data == nullptr);
					Data& targ_txt_dat = *(Data*)(targ_dat.data = new Data{});

					targ_txt_dat.texture = LLJGFX::Texture::Make(LLJGFX::Texture::GetData(src_texture_dat.texture), LLJGFX::Texture::GetSize(src_texture_dat.texture));
				}
				void Delete(File::Handle handle) {
					auto& file_dat = File::Advanced::GetData(handle);
					Data& main_dat = *(Data*)file_dat.data;

					LLJGFX::Texture::Delete(main_dat.texture);

					delete (Data*)file_dat.data;
				}

				FileType::Thumbnail tmp_thumb = {.texture = { nullptr }};
				const FileType::Thumbnail& GetThumbnail(File::Handle handle) {
					tmp_thumb.texture = (*(Data*)File::Advanced::GetData(handle).data).texture;
					return tmp_thumb;
				}
				LLJGFX::Texture::Handle GetFolderTypeIcon(File::Handle) {
					return TEXTURE_TYPE_ICON.handle();//FOLDER_TYPE_ICON.handle();
				}

				JSerial::StructFieldsTemplate templ = {
					{.name = "binary_data", .type = JSerial::String() },
					{.name = "size_x", .type = JSerial::NumericType(JSerial::TypeEnum::INT16)},
					{.name = "size_y", .type = JSerial::NumericType(JSerial::TypeEnum::INT16)}
				};

				JSerial::SerializedStruct Serialize(File::Handle file, const JSerial::CompiledTemplateSet& templ, const std::string& internal_struct_name) {
					const auto txt = (*(Data*)File::Advanced::GetData(file).data).texture;
					const auto txt_size = LLJGFX::Texture::GetSize(txt);
					return JSerial::SerializeStruct(internal_struct_name, templ, JSerial::Field{ "binary_data", LLJGFX::Texture::GetData(txt) }, JSerial::Field{ "size_x", txt_size.x }, JSerial::Field{ "size_y", txt_size.y });
				}
				void Deserialize(File::Handle raw_file, const JSerial::Document& src, const JSerial::ParsedStruct& file_struct) {
					const std::string texture_data = JSerial::Deserialize<std::string>(file_struct, src, "binary_data");
					const uint16_t size_x = JSerial::Deserialize<uint16_t>(file_struct, src, "size_x");
					const uint16_t size_y = JSerial::Deserialize<uint16_t>(file_struct, src, "size_y");

					const auto txt = LLJGFX::Texture::Make(texture_data, { size_x, size_y });

					auto& file_dat = File::Advanced::GetData(raw_file);
					file_dat.data = new Data{ .texture = txt };
				}
			}
		}
		const FileType::Handle TEXTURE_FILETYPE_TYPE_PRESET = FileType::Make({ .Make = Internal::Func::Make, .Copy = Internal::Func::Copy, .Delete = Internal::Func::Delete, .GetFileThumbnailTexture = Internal::Func::GetThumbnail, .GetTypeIconTexture = Internal::Func::GetFolderTypeIcon, .name = "Texture", .SerializeFile = Internal::Func::Serialize, .DeserializeFile = Internal::Func::Deserialize});
		
		typedef File::Handle Handle;
		const Handle NULL_TEXTURE = File::NULL_FILE;

		bool IsTexture(File::Handle handle) 
			{ return File::GetType(handle) == TEXTURE_FILETYPE_TYPE_PRESET; }

		Handle Make(LLJGFX::Texture::Handle texture, const ::std::string& name, Handle parent_folder)
			{ return File::Make(name, parent_folder, TEXTURE_FILETYPE_TYPE_PRESET, &texture); }

		LLJGFX::Texture::Handle GetTexture(Handle handle) {
			assert(File::IsValid(handle));
			assert(IsTexture(handle));
			return (*(Data*)File::Advanced::GetData(handle).data).texture;
		}

		namespace Internal {
			bool InitTextureFileType() {
				editor_filesystem_data_types.push_back({"Текстуру", Texture::TEXTURE_FILETYPE_TYPE_PRESET});
				FilesystemSerialization::IntegrateSerialisationTemplate(TEXTURE_FILETYPE_TYPE_PRESET, Func::templ, {});
				return false;
			}
			bool init_dummy = InitTextureFileType();

			bool LoadTextureModal(Folder::Handle save_to) {
				static bool is_save_confirmed = false;

				const nfdpathset_t* out_paths;
				nfdu8filteritem_t filters[1] = { { "Изображения", "png,jpg,bmp" } };
				nfdopendialogu8args_t args = {};
				args.filterList = filters;
				args.filterCount = 1;
				nfdresult_t result = NFD_OpenDialogMultipleU8_With(&out_paths, &args);
				if (result == NFD_OKAY) {
					nfdpathsetsize_t path_count;
					NFD_PathSet_GetCount(out_paths, &path_count);

					for (nfdpathsetsize_t i = 0; i < path_count; ++i) {
						nfdchar_t* c_path;
						NFD_PathSet_GetPath(out_paths, i, &c_path);

						const LLJGFX::Texture::Handle c_txt = LLJGFX::Texture::Make(c_path);
						File::Make(std::filesystem::path(c_path).stem().string(), save_to, TEXTURE_FILETYPE_TYPE_PRESET, (void*)&c_txt);
						
						NFD_PathSet_FreePath(c_path);
					}
				}
				else if(result != NFD_CANCEL)
					fmt::println("Error: {}", NFD_GetError());

				return true;
			}
			bool dummy = ((FileType::Data&)FileType::GetData(TEXTURE_FILETYPE_TYPE_PRESET)).CreateFileModal = LoadTextureModal;
		}
	}
}